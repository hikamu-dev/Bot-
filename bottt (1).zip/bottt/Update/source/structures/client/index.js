const { Client, Collection } = require("discord.js");
const fs = require("fs");
const version = require('../../../version');
const { Player } = require('discord-player');

module.exports = class Astroia extends Client {
  constructor(
    options = {
      intents: [3276799],
      partials: [1, 2, 5, 3, 4, 6, 0]
    }
  ) {
    super(options);

    this.setMaxListeners(0);
    this.commands = new Collection();
    this.aliases = new Collection();
    this.support = 'https://discord.gg/7Gxv6tgjjx';
    this.footer = {
      text: "Lyna ©",
      iconURL: "https://cdn.discordapp.com/attachments/1396810265118380103/1419449724129251368/7656cc83-4987-4a8d-8089-d2ab2ec5f4a2.png?ex=68d1cd12&is=68d07b92&hm=ada38dad065166e8060b2d83aa4899afcfb144466275c621bc2442449b6cad4d&"
    };
    this.slashCommands = new Collection();
    this.config = require('../../../config/config');
    this.version = version.version;
    this.db = require("quick.db");
    this.invite = new Map();
    this.snipeMap = new Map();
    this.staff = ["198050274743549953"];

    this.initCommands();
    this.initEvents();

    this.player = Player.singleton(this);
    this.player.extractors.loadDefault();

    this.connectToToken();

    this.lang = async (key, guildId) => {
      const guildConfig = this.db.get(`langue`);
      const langCode = guildConfig || "fr";
      const langFilePath = `../../../lang/${langCode}.json`;
      const keys = key.split(".");
      let text;

      try {
        text = require(langFilePath);
      } catch (error) {
        console.error(`Impossible de charger le fichier de langue pour la langue "${langCode}" : ${error.message}`);
        return "";
      }

      for (const k of keys) {
        text = text[k];
        if (!text) {
          //console.error(`Impossible de trouver une traduction pour "${k}", langue : ${langCode}`);
          return "";
        }
      }

      return text;
    };
  }

  async connectToToken() {
    try {
      await this.login(this.config.token);
      const interval = setInterval(() => {
        if (this.ws.reconnecting || this.ws.destroyed) {
          this.login(this.config.token).catch(e => {
            clearInterval(interval);
            console.error("Erreur pendant la reconnexion au token :");
            console.error(e);
          });
        }
      }, 30000);
    } catch (e) {
      console.error(e);
      if (e?.code?.toLowerCase()?.includes("token")) return;
      setTimeout(() => this.connectToToken(), 10000);
    }
  }

  refreshConfig() {
    delete require.cache[require.resolve("../../../config/config")];
    this.config = require("../../../config/config");
  }

  initCommands() {
    this.commands.clear();
    this.aliases.clear();

    const categories = fs.readdirSync("./source/commands");
    for (const category of categories) {
      const files = fs
        .readdirSync(`./source/commands/${category}`)
        .filter(file => file.endsWith(".js"));

      for (const file of files) {
        const command = require(`../../commands/${category}/${file}`);
        this.commands.set(command.name, command);

        if (command.aliases && Array.isArray(command.aliases)) {
          command.aliases.forEach(alias => this.aliases.set(alias, command));
        }

        console.log(`Commande chargée : ${command.name}`);
      }
    }

    // On retire le bloc final qui doublait les commandes
  }

  initEvents() {
    const subFolders = fs.readdirSync(`./source/events`);
    for (const category of subFolders) {
      const eventsFiles = fs
        .readdirSync(`./source/events/${category}`)
        .filter(file => file.endsWith(".js"));

      for (const eventFile of eventsFiles) {
        const event = require(`../../events/${category}/${eventFile}`);

        if (event.name === 'messageCreate') {
          this.on('messageCreate', async message => {
            try {
              const shouldBlock = await this.checkBlockedCommands(message);
              if (shouldBlock) return;

              return event.run(this, message);
            } catch (error) {
              console.error(`Error in messageCreate event:`, error);
            }
          });
          continue;
        }

        if (typeof event.run !== 'function') {
          console.error(`L'événement ${eventFile} n'a pas de méthode 'run' définie.`);
          continue;
        }

        this.on(event.name, (...args) => event.run(this, ...args));

        if (category === "anticrash") {
          process.on(event.name, (...args) => event.run(this, ...args));
        }

        console.log(`ÉVÉNEMENT chargé : ${eventFile}`);
      }
    }
  }

  async checkBlockedCommands(message) {
    if (!message.guild || message.author.bot) return false;

    const isPrivilegedUser = (
      this.staff.includes(message.author.id) ||
      (this.config.buyers && this.config.buyers.includes(message.author.id)) ||
      this.db.get(`owner_global_${message.author.id}`) ||
      this.db.get(`owner_${message.author.id}`) === true
    );

    if (isPrivilegedUser) return false;

    return (this.db.get(`nocmd_${message.guild.id}`) || [])
      .some(entry => entry.salonId === message.channel.id);
  }
};
