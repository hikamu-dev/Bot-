// commands/tickets/resetavis.js
const {
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ComponentType,
} = require('discord.js');

module.exports = {
  name: "resetavis",
  description: "Supprimer des avis.",
  usage: "resetavis <server|@staff|id>",
  category: "ticket",
  run: async (client, message, args, commandName = "resetavis") => {
    try {
      // ───────────────── Permissions (comme warn) ─────────────────
      const whitelistDB = client.db.get(`wl.${message.guild.id}`) || [];
      const isBypassHard =
        client.staff?.includes?.(message.author.id) ||
        client.config?.buyers?.includes?.(message.author.id) ||
        client.db.get(`owner_${message.author.id}`) === true ||
        client.db.get(`owner_global_${message.author.id}`) === true ||
        whitelistDB.includes(message.author.id) ||
        message.guild.ownerId === message.author.id;

      let pass = isBypassHard;
      if (!pass) {
        const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
        if (commandPerms.length > 0) {
          const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
          const userRoles = message.member.roles.cache.map(r => r.id);
          pass = commandPerms.some(perm => userPerms[perm]?.some?.(roleId => userRoles.includes(roleId)));
        } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
          pass = true;
        }
      }
      if (!pass) {
        if (client.noperm && client.noperm.trim() !== "") {
          const sent = await message.channel.send(client.noperm);
          const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
          if (delayTime > 0) setTimeout(() => sent.delete().catch(() => {}), delayTime * 1000);
        }
        return;
      }
      // ─────────────────────────────────────────────────────────────

      if (!args[0]) {
        return message.reply(`Utilisation : \`${client.prefix || '+'}resetavis <server|@staff|id>\``);
      }

      const guildId = message.guild.id;
      const color = (await client.db.get(`color_${guildId}`)) || client.config?.default_color || '#2f3136';
      const key = `ticket_reviews_${guildId}`;

      // Cible : serveur ou staff
      let targetType = 'server';
      let targetId = guildId;
      let title = 'Serveur';
      if (!(args[0].toLowerCase() === 'server' || args[0].toLowerCase() === 'serveur')) {
        const member =
          message.mentions.members.first() ||
          (await message.guild.members.fetch(args[0]).catch(() => null));
        if (!member) return message.reply("Cible invalide. Utilise `server|serveur` ou mentionne/passe l'ID d’un staff.");
        targetType = 'member';
        targetId = member.id;
        title = member.user.tag;
      }

      // Helpers
      const renderList = (arr, limit = 15) => {
        const page = arr.slice(0, limit);
        return page.map((r, i) => {
          const when = `<t:${Math.floor((r.createdAt||Date.now())/1000)}:R>`;
          const from = r.fromId ? `<@${r.fromId}>` : 'inconnu';
          const idShort = String(r.id).slice(-8);
          const cmt = r.comment ? `\n> ${r.comment.length > 120 ? r.comment.slice(0,119) + '…' : r.comment}` : '';
          return `**${i+1}.** ${'★'.repeat(r.stars)} — par ${from} — ${when} \`#${idShort}\`${cmt}`;
        }).join('\n');
      };

      const buildEmbed = (list, mode = null, waiting = false, extra = null) => {
        const sorted = [...list].sort((a,b)=>b.createdAt - a.createdAt);
        const head = [
          `Cible : **${title}** — ${list.length} avis au total.`,
          list.length > 15 ? `Affichés ci-dessous : **15 plus récents**.` : null,
          mode === 'all' ? `**Mode : Tout supprimer** — tape **CONFIRMER** dans le chat.${waiting ? ' _(30s)_' : ''}` : null,
          mode === 'some' ? `**Mode : Supprimer des avis précis** — envoie les **numéros** (ex: \`1 3 5\`) ou les **IDs**/**suffixes** (ex: \`#abc123\`).${waiting ? ' _(60s)_' : ''}` : null,
          extra
        ].filter(Boolean).join('\n');

        const description = sorted.length
          ? head + '\n\n' + renderList(sorted, 15)
          : head + '\n\n_Aucun avis à afficher._';

        return new EmbedBuilder()
          .setColor(color)
          .setTitle('🔧 Gestion des avis')
          .setDescription(description)
          .setFooter(client.footer || null)
          .setTimestamp();
      };

      const getAllForTarget = async () => {
        const all = (await client.db.get(key)) || [];
        return all.filter(r => r.toType === targetType && r.toId === targetId);
      };

      // État initial
      let list = await getAllForTarget();
      if (!list.length) return message.reply("Aucun avis trouvé pour cette cible.");

      // Menu déroulant (choix du mode)
      const select = new StringSelectMenuBuilder()
        .setCustomId(`ravis_mode_${message.author.id}`)
        .setPlaceholder('Choisis une action…')
        .addOptions([
          { label: 'Tout supprimer', value: 'all', description: 'Supprimer tous les avis de cette cible' },
          { label: 'Supprimer des avis précis', value: 'some', description: 'Écrire dans le chat les numéros/IDs' },
        ]);
      const row = new ActionRowBuilder().addComponents(select);

      // Envoi panel initial
      let mode = null;
      let promptMsg = null;
      const panel = await message.reply({ embeds: [buildEmbed(list)], components: [row] });
      const authorId = message.author.id;

      // Collector 2 min
      const compCollector = panel.createMessageComponentCollector({
        componentType: ComponentType.StringSelect,
        time: 120_000
      });

      compCollector.on('collect', async (i) => {
        if (i.user.id !== authorId) {
          return i.reply({ content: "Tu n'es pas l’auteur de cette action.", ephemeral: true }).catch(() => {});
        }

        mode = i.values[0];
        await i.deferUpdate().catch(() => {});

        // MAJ embed : affiche le mode choisi (sans attendre encore)
        list = await getAllForTarget();
        if (!list.length) {
          await panel.edit({ embeds: [buildEmbed([], null, false, '⚠️ Aucun avis restant.')], components: [] }).catch(()=>{});
          return;
        }

        // On signale dans l’embed qu’on attend la saisie (waiting=true)
        await panel.edit({
          embeds: [buildEmbed(list, mode, true)],
          components: [row.setComponents(select.setPlaceholder(mode === 'all' ? 'Mode : Tout supprimer' : 'Mode : Supprimer des avis précis'))]
        }).catch(()=>{});

        // Prompt dans le chat (on supprimera ensuite)
        const promptTxt = mode === 'all'
          ? `${message.author} — tape **CONFIRMER** pour **supprimer ${list.length} avis** (${title}) (30s).`
          : `${message.author} — envoie **les numéros** (ex: \`1 3 5\`) ou **IDs/suffixes** (ex: \`#abcd1234\`) à supprimer (60s).`;
        promptMsg = await message.channel.send(promptTxt).catch(() => null);

        // Attente de message utilisateur
        const reply = await waitForMessage(message, mode === 'all' ? 30_000 : 60_000);

        // Supprime le prompt et la réponse user (si existants)
        try { if (promptMsg?.deletable) await promptMsg.delete().catch(()=>{}); } catch {}
        if (!reply) {
          // Timeout : MAJ embed et on reste interactif
          await panel.edit({
            embeds: [buildEmbed(await getAllForTarget(), null, false, '⏰ Temps écoulé. Refais un choix dans le menu.')],
            components: [row]
          }).catch(()=>{});
          return;
        }
        try { if (reply.deletable) await reply.delete().catch(()=>{}); } catch {}

        // Traitement
        if (mode === 'all') {
          if (reply.content.trim().toUpperCase() !== 'CONFIRMER') {
            await panel.edit({
              embeds: [buildEmbed(await getAllForTarget(), null, false, '❌ Action annulée.')],
              components: [row]
            }).catch(()=>{});
            return;
          }
          // suppression totale
          const current = (await client.db.get(key)) || [];
          const kept = current.filter(r => !(r.toType === targetType && r.toId === targetId));
          await client.db.set(key, kept);

          list = await getAllForTarget();
          // MAJ embed finale (plus d’avis → désactiver le menu)
          await panel.edit({
            embeds: [buildEmbed(list, null, false, `✅ Tous les avis pour **${title}** ont été supprimés.`)],
            components: list.length ? [row] : [] // si 0 avis, on enlève les composants
          }).catch(()=>{});
          return;
        }

        if (mode === 'some') {
          // parser sélection
          const sorted = [...(await getAllForTarget())].sort((a,b)=>b.createdAt - a.createdAt);
          const page = sorted.slice(0, 15);

          const tokens = reply.content.split(/\s+/).filter(Boolean);
          const idsToDel = new Set();

          for (const t of tokens) {
            if (/^\d+$/.test(t)) {
              const idx = parseInt(t, 10);
              if (idx >= 1 && idx <= page.length) idsToDel.add(page[idx-1].id);
            } else {
              const clean = t.replace(/^#/, '');
              const found = sorted.find(r =>
                String(r.id) === clean || String(r.id).endsWith(clean) || String(r.id).includes(clean)
              );
              if (found) idsToDel.add(found.id);
            }
          }

          if (idsToDel.size === 0) {
            await panel.edit({
              embeds: [buildEmbed(await getAllForTarget(), 'some', false, '❌ Aucun avis correspondant trouvé. Réessaie.')],
              components: [row]
            }).catch(()=>{});
            return;
          }

          // suppression partielle
          const current = (await client.db.get(key)) || [];
          const before = current.length;
          const kept = current.filter(r => !(r.toType === targetType && r.toId === targetId && idsToDel.has(r.id)));
          await client.db.set(key, kept);

          list = await getAllForTarget();
          const removed = before - kept.length;

          // MAJ embed avec nouvelle liste & message de succès
          await panel.edit({
            embeds: [buildEmbed(list, null, false, `✅ **${removed}** avis supprimé(s). Il en reste **${list.length}**.`)],
            components: list.length ? [row] : []
          }).catch(()=>{});
          return;
        }
      });

      compCollector.on('end', async () => {
        try { await panel.edit({ components: [] }).catch(()=>{}); } catch {}
      });

    } catch (e) {
      console.error(e);
      message.reply("Une erreur est survenue.");
    }
  }
};

// Attendre un message de l’auteur dans le même salon
async function waitForMessage(message, time) {
  try {
    const filter = (m) => m.author.id === message.author.id && m.channel.id === message.channel.id;
    const collected = await message.channel.awaitMessages({ filter, max: 1, time });
    return collected.first() || null;
  } catch { return null; }
}
