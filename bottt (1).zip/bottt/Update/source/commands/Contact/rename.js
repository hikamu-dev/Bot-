const Discord = require('discord.js');
const { example } = require('./add');

module.exports = {
    name: "rename",
    description: "Renomme le salon",
    use: "<nouveau nom>",
    usage: "rename <nouveau nom>",
    example: "➜ rename Ticket de support\n➜ rename Problème résolu",
    /**
     * @param {Discord.Client} client
     * @param {Discord.Message} message
     * @param {string[]} args
     */
    run: async (client, message, args, commandName) => {
      
    let pass = false;

    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) || 
        client.db.get(`owner_global_${message.author.id}`) === true || 
        client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true) {
      pass = true;
    } else {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        pass = true;
      }
    }

    if (!pass) {
        if (client.noperm && client.noperm.trim() !== '') {
            const sentMessage = await message.channel.send(client.noperm);
            const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
            if (delayTime > 0) {
                setTimeout(() => {
                    sentMessage.delete().catch(() => {});
                }, delayTime * 1000);
            }
        }
        return;
    }
        const newName = args.join(" ");
        if (!newName) {
            return message.channel.send("Veuillez fournir un nouveau nom pour le ticket.");
        }

        if (newName.length > 100) {
            return message.channel.send("Le nom du salon ne peut pas dépasser 100 caractères.");
        }

        try {
            await message.channel.setName(newName);
            return message.channel.send(`Le ticket a été renommé en **${newName}**.`);
        } catch (error) {
            console.error("Erreur lors du renommage du salon :", error);
            return message.channel.send("Une erreur s'est produite lors du renommage du salon.");
        }
    }
};
