// commands/tickets/avis.js
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, ComponentType } = require('discord.js');

module.exports = {
  name: "avis",
  description: "Voir les avis donnés aux tickets.",
  usage: "avis <server|@staff|id>",
  category: "ticket",
  run: async (client, message, args, commandName = "avis") => {
    try {
      // ───────────────── Permissions "comme warn" ─────────────────
      const whitelistDB = client.db.get(`wl.${message.guild.id}`) || [];
      const isBypassHard =
        client.staff?.includes?.(message.author.id) ||
        client.config?.buyers?.includes?.(message.author.id) ||
        client.db.get(`owner_${message.author.id}`) === true ||
        client.db.get(`owner_global_${message.author.id}`) === true ||
        whitelistDB.includes(message.author.id) ||
        message.guild.ownerId === message.author.id;

      let pass = isBypassHard;
      if (!pass) {
        const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
        if (commandPerms.length > 0) {
          const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
          const userRoles = message.member.roles.cache.map(r => r.id);
          pass = commandPerms.some(perm => userPerms[perm]?.some?.(roleId => userRoles.includes(roleId)));
        } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
          pass = true;
        }
      }
      if (!pass) {
        if (client.noperm && client.noperm.trim() !== "") {
          const sent = await message.channel.send(client.noperm);
          const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
          if (delayTime > 0) setTimeout(() => sent.delete().catch(() => {}), delayTime * 1000);
        }
        return;
      }
      // ─────────────────────────────────────────────────────────────

      const guildId = message.guild.id;
      const key = `ticket_reviews_${guildId}`;
      const allReviews = (await client.db.get(key)) || [];

      const color = (await client.db.get(`color_${guildId}`)) || client.config?.default_color || '#2f3136';
      const fmtStars = (n) => '★'.repeat(n);
      const snippet = (s, max=160) => {
        if (!s) return '';
        s = s.replace(/\s+/g, ' ').trim();
        return s.length > max ? s.slice(0, max-1) + '…' : s;
      };

      // Cible: server | @staff | id
      if (!args[0]) {
        return message.reply([
          `**Utilisation :**`,
          `• \`${client.prefix || '+'}avis server\` — voir les avis attribués au serveur`,
          `• \`${client.prefix || '+'}avis @staff\` — voir les avis attribués à un membre du staff`,
          `• \`${client.prefix || '+'}avis <id_staff>\` — idem par ID`,
        ].join('\n'));
      }

      let targetType = 'server';
      let targetId = guildId;
      let title = 'Avis (Serveur)';

      const arg0 = args[0].toLowerCase();
      if (!(arg0 === 'server' || arg0 === 'serveur')) {
        const staff =
          message.mentions.members.first() ||
          (await message.guild.members.fetch(args[0]).catch(() => null));
        if (!staff) return message.reply("Mentionne un membre du staff ou utilise `server`/`serveur`.");
        targetType = 'member';
        targetId = staff.id;
        title = `Avis (${staff.user.tag})`;
      }

      // Filtrer
      const list = allReviews.filter(r => r.toType === targetType && r.toId === targetId);
      if (list.length === 0) return message.reply("Aucun avis trouvé.");

      // Stats globales (sur TOUT l'ensemble, pas seulement la page)
      const total = list.length;
      const avg = list.reduce((a, r) => a + (r.stars || 0), 0) / total;
      const dist = [1,2,3,4,5].map(s => [s, list.filter(r => r.stars === s).length]);

      // Pagination
      const PAGE_SIZE = 10;
      const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
      let page = 1;

      const buildEmbed = (pageNum) => {
        const start = (pageNum - 1) * PAGE_SIZE;
        const pageItems = list
          .slice()
          .sort((a,b)=>b.createdAt - a.createdAt)
          .slice(start, start + PAGE_SIZE);

        const lines = pageItems.map(r => {
          const when = `<t:${Math.floor((r.createdAt||Date.now())/1000)}:R>`;
          const by = r.fromId ? `<@${r.fromId}>` : 'inconnu';
          const cmt = r.comment ? `\n> ${snippet(r.comment)}` : '';
          return `• **${fmtStars(r.stars)}** — par ${by} — ${when}${cmt}`;
        }).join('\n');

        return new EmbedBuilder()
          .setColor(color)
          .setTitle(title)
          .setDescription(lines || "_(aucun élément sur cette page)_")
          .addFields(
            { name: 'Moyenne', value: `**${avg.toFixed(2)}** / 5 — ${total} avis`, inline: true },
            { name: 'Répartition', value: dist.map(([s,c]) => `${'★'.repeat(s)} : ${c}`).join('  |  '), inline: false },
          )
          .setFooter({ text: `Page ${pageNum}/${totalPages}` })
          .setTimestamp();
      };

      const buildComponents = (pageNum) => {
        const first = new ButtonBuilder()
          .setCustomId(`avis_nav_first_${guildId}_${targetType}_${targetId}_${message.author.id}`)
          .setEmoji('⏮️')
          .setStyle(ButtonStyle.Secondary)
          .setDisabled(pageNum === 1);

        const prev = new ButtonBuilder()
          .setCustomId(`avis_nav_prev_${guildId}_${targetType}_${targetId}_${message.author.id}`)
          .setEmoji('◀️')
          .setStyle(ButtonStyle.Secondary)
          .setDisabled(pageNum === 1);

        const next = new ButtonBuilder()
          .setCustomId(`avis_nav_next_${guildId}_${targetType}_${targetId}_${message.author.id}`)
          .setEmoji('▶️')
          .setStyle(ButtonStyle.Secondary)
          .setDisabled(pageNum === totalPages);

        const last = new ButtonBuilder()
          .setCustomId(`avis_nav_last_${guildId}_${targetType}_${targetId}_${message.author.id}`)
          .setEmoji('⏭️')
          .setStyle(ButtonStyle.Secondary)
          .setDisabled(pageNum === totalPages);

        const rowBtns = new ActionRowBuilder().addComponents(first, prev, next, last);

        // Select de pages (max 25 options)
        if (totalPages > 1 && totalPages <= 25) {
          const options = [];
          for (let p = 1; p <= totalPages; p++) {
            options.push({
              label: `Page ${p}`,
              value: String(p),
              description: `Afficher les avis ${((p-1)*PAGE_SIZE)+1} à ${Math.min(p*PAGE_SIZE, total)}`
            });
          }
          const select = new StringSelectMenuBuilder()
            .setCustomId(`avis_nav_select_${guildId}_${targetType}_${targetId}_${message.author.id}`)
            .setPlaceholder(`Aller à la page… (${pageNum}/${totalPages})`)
            .setMinValues(1).setMaxValues(1)
            .addOptions(options);

          const rowSel = new ActionRowBuilder().addComponents(select);
          return [rowBtns, rowSel];
        }

        return [rowBtns];
      };

      // Envoi initial
      const msg = await message.reply({
        embeds: [buildEmbed(page)],
        components: total > PAGE_SIZE ? buildComponents(page) : []
      });

      if (total <= PAGE_SIZE) return; // pas de pagination nécessaire

      // Collector (2 minutes)
      const collector = msg.createMessageComponentCollector({ componentType: ComponentType.MessageComponent, time: 120_000 });

      collector.on('collect', async (i) => {
        // sécurité: seul l’auteur peut naviguer
        if (i.user.id !== message.author.id) {
          return i.reply({ content: "Seul l’auteur de la commande peut utiliser ces boutons.", ephemeral: true }).catch(() => {});
        }

        const parts = i.customId.split('_');
        // avis_nav_{first|prev|next|last|select}_{guildId}_{targetType}_{targetId}_{authorId}

        const action = parts[2];
        const _guildId = parts[3];
        const _targetType = parts[4];
        const _targetId = parts[5];
        const _authorId = parts[6];

        // contexte cohérent ?
        if (_guildId !== guildId || _targetType !== targetType || _targetId !== String(targetId) || _authorId !== message.author.id) {
          return i.reply({ content: "Contexte invalide (message périmé).", ephemeral: true }).catch(() => {});
        }

        if (action === 'select') {
          const choice = i.values?.[0];
          const p = parseInt(choice, 10);
          if (!isNaN(p) && p >= 1 && p <= totalPages) page = p;
          await i.update({ embeds: [buildEmbed(page)], components: buildComponents(page) }).catch(() => {});
          return;
        }

        if (action === 'first') page = 1;
        else if (action === 'prev') page = Math.max(1, page - 1);
        else if (action === 'next') page = Math.min(totalPages, page + 1);
        else if (action === 'last') page = totalPages;

        await i.update({ embeds: [buildEmbed(page)], components: buildComponents(page) }).catch(() => {});
      });

      collector.on('end', async () => {
        try { await msg.edit({ components: [] }); } catch {}
      });

    } catch (e) {
      console.error(e);
      message.reply("Une erreur est survenue.");
    }
  }
};
