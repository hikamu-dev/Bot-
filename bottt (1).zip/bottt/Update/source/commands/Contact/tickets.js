const Discord = require('discord.js');
const Valory = require('../../structures/client/index');
const ms = require('ms');

/**
 * Commande pour gérer le système de tickets
 * @module ticket
 */
module.exports = {
    name: 'ticket',
    aliases: ['tickets'],
    description: 'Permet de créer et configurer le système de tickets.',

    /**
     * Exécute la commande ticket
     * @param {Valory} client - Instance du client Valory
     * @param {Discord.Message} message - Message reçu
     * @param {string[]} args - Arguments de la commande
     * @param {string} commandName - Nom de la commande
     */
    run: async (client, message, args, commandName) => {
      
    let pass = false;

    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) || 
        client.db.get(`owner_global_${message.author.id}`) === true || 
        client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true) {
      pass = true;
    } else {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        pass = true;
      }
    }

    if (!pass) {
        if (client.noperm && client.noperm.trim() !== '') {
            const sentMessage = await message.channel.send(client.noperm);
            const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
            if (delayTime > 0) {
                setTimeout(() => {
                    sentMessage.delete().catch(() => {});
                }, delayTime * 1000);
            }
        }
        return;
    }

    if (commandName === 'rappel') {
        // Permission staff
        if (!client.staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id)) {
            return message.reply('Vous n\'avez pas la permission d\'utiliser cette commande.');
        }
        const arg = args[0];
        if (!arg) return message.reply('Merci de fournir l\'ID du ticket ou mentionner l\'utilisateur.');
        const tickeruser = await client.db.get(`ticket_user_${message.guild.id}`) || [];
        let ticketData = tickeruser.find(t => t.id === arg.replace(/[^a-zA-Z0-9]/g, ''));
        if (!ticketData && message.mentions.users.size > 0) {
            ticketData = tickeruser.find(t => t.author === message.mentions.users.first().id);
        }
        if (!ticketData) return message.reply('Ticket introuvable.');
        if (ticketData.author === message.author.id) return message.reply('Vous ne pouvez pas vous rappeler vous-même !');
        const user = await client.users.fetch(ticketData.author).catch(() => null);
        if (!user) return message.reply('Utilisateur introuvable.');
        const db = await client.db.get(`ticket_${message.guild.id}`);
        const option = db?.option?.find(opt => opt.value === ticketData.option);
        const color = await client.db.get(`color_${message.guild.id}`) || client.config.default_color;
        const ticketName = option?.text || 'Ticket';
        const embed = new Discord.EmbedBuilder()
            .setColor(color)
            .setTitle('🔔 Rappel de ticket')
            .setDescription(`Vous avez été rappelé pour votre ticket **${ticketName}** sur le serveur **${message.guild.name}**.\n\nCliquez ici pour y accéder : <#${ticketData.salon}>`)
            .setTimestamp()
            .setFooter({ text: `Rappelé par ${message.author.tag}`, iconURL: message.author.displayAvatarURL() });
        await user.send({ embeds: [embed] }).then(() => {
            message.reply(`Rappel envoyé avec succès à <@${user.id}> !`);
        }).catch(() => {
            message.reply('Impossible d\'envoyer un message privé à l\'utilisateur. Il a peut-être désactivé les messages privés.');
        });
        return;
    }

        // ════════ Initialisation du message ════════
        const msg = await message.channel.send({ content: '⏳ Chargement du panneau de configuration...' });

        // ════════ Mise à jour de l'embed principal ════════
        async function updateFirst() {
            const db = await client?.db.get(`ticket_${message.guild.id}`) || {
                option: [],
                salon: message.channel.id, // Salon par défaut = salon de la commande
                messageidoption: null,
                type: 'select',
                Suppauto: true,
                messageid: null,
                maxticket: 1,
                leaveclose: false,
                claimbutton: true,
                buttonclose: true,
                transcript: false,
                rolerequis: null,
                roleinterdit: null,
            };

            const modules = db.type === 'select' ? 'Menu déroulant' : 'Boutons';

            // Nouvelle esthétique de l'embed principal
            const embed = new Discord.EmbedBuilder()
                .setTitle('🎟️・Configuration des Tickets')
                .setDescription(
                    `Bienvenue dans le panneau de configuration du système de tickets !\n\n` +
                    `> Personnalisez chaque aspect de votre système pour offrir la meilleure expérience à vos membres.\n` +
                    `\n__**Paramètres actuels :**__`)
                .setColor(client.color) // Couleur Discord moderne, modifiable
                .setThumbnail('https://cdn.discordapp.com/emojis/1178530158573275277.webp?size=96&quality=lossless') // À personnaliser si besoin
                .setImage('https://cdn.discordapp.com/attachments/1178530158573275277/1178530158573275277/banner.png') // À personnaliser ou retirer
                .setFooter({ text: client.footer.text || 'Système de Tickets', iconURL: client.footer.iconURL })
                .setTimestamp()
                .addFields([
                    { name: 'Salon', value: client.channels.cache.get(db.salon)?.toString() || 'Non défini', inline: true },
                    { name: 'Message', value: db.autoembed
                        ? 'Message intégré automatique'
                        : (db.messageidoption ? `\`${db.messageidoption}\`` : 'Non défini'),
                      inline: true },
                    { name: 'Type', value: modules, inline: true },
                    { name: '\u200B', value: '\u200B', inline: false },
                    { name: 'Bouton Claim', value: db.claimbutton ? '✅' : '❌', inline: true },
                    { name: 'Tickets max/utilisateur', value: `\`${db.maxticket}\``, inline: true },
                    { name: 'Fermeture auto (leave)', value: db.leaveclose ? '✅' : '❌', inline: true },
                    { name: '\u200B', value: '\u200B', inline: false },
                    { name: 'Transcript en MP', value: db.transcript ? '✅' : '❌', inline: true },
                    { name: 'Bouton rappel', value: db.boutonrappel ? '✅' : '❌', inline: true },
                    { name: 'Autoriser les liens', value: db.autoriserliens ? '✅' : '❌', inline: true },
                    { name: '\u200B', value: '\u200B', inline: false },
                    { name: 'Rôles interdits', value: db.roleinterdit && db.roleinterdit.length > 0 ? db.roleinterdit.map(roleId => `<@&${roleId}>`).join(', ') : 'Aucun', inline: true },
                    { name: 'Rôles requis', value: db.rolerequis && db.rolerequis.length > 0 ? db.rolerequis.map(roleId => `<@&${roleId}>`).join(', ') : 'Aucun', inline: true },
                    { name: '\u200B', value: '\u200B', inline: false },
                    { name: '📋 Options configurées', value: db.option.map(option => {
                        const motifsText = option.motifs && option.motifs.length > 0 ? ` (${option.motifs.length} motif${option.motifs.length > 1 ? 's' : ''})` : '';
                        return `- ${option.text}${motifsText}`;
                    }).join('\n') || 'Aucune option', inline: false },
                ]);

            const optionSelect = db.option.map(option => ({
                label: option.text.length > 100 ? option.text.substring(0, 97) + '...' : option.text,
                description: option.description?.length > 100 ? option.description.substring(0, 97) + '...' : option.description || 'Sans description',
                value: option.value
            }));

            // Menu déroulant pour gérer les options avec un style épuré
            const selectOption = new Discord.StringSelectMenuBuilder()
                .setCustomId('selectoption')
                .setPlaceholder('⚙️ Sélectionner une option à modifier')
                .addOptions([
                    ...optionSelect,
                    { label: 'Ajouter une nouvelle option', emoji: '➕', value: 'addoption' }
                ]);

            // Bouton de validation avec un design modernisé
            const buttons = new Discord.ActionRowBuilder().addComponents(
                new Discord.ButtonBuilder()
                    .setCustomId('activer')
                    .setLabel('Valider et Activer')
                    .setEmoji('✅')
                    .setStyle(Discord.ButtonStyle.Success),
                new Discord.ButtonBuilder()
                    .setCustomId('resetconfig')
                    .setLabel('Réinitialiser')
                    .setEmoji('♻️')
                    .setStyle(Discord.ButtonStyle.Danger)
            );

            // Menu déroulant de configuration avec des emojis plus expressifs
            const selectMenu = new Discord.ActionRowBuilder().addComponents(
                new Discord.StringSelectMenuBuilder()
                    .setCustomId('selectconfigticket')
                    .setPlaceholder('🛠️ Configurer les paramètres')
                    .addOptions([
                        { label: 'Salon des tickets', emoji: '📍', value: 'salon' },
                        { label: 'ID du message', emoji: '📩', value: 'messageidoption' },
                        { label: 'Envoyer un embed automatique', emoji: '💬', value: 'autoembed' },
                        { label: 'Type d\'interface', emoji: '🎮', value: 'type' },
                        { label: 'Bouton Claim', emoji: '🛠️', value: 'claim' },
                        { label: 'Transcript en MP', emoji: '📜', value: 'transcript' },
                        { label: 'Tickets maximum', emoji: '🔢', value: 'maxticket' },
                        { label: 'Fermeture auto (leave)', emoji: '🚪', value: 'fermetureleave' },
                        { label: 'Rôles interdits', emoji: '🚫', value: 'roleinterdit' },
                        { label: 'Rôles requis', emoji: '✅', value: 'rolerequis' },
                        { label: 'Bouton rappel', emoji: '🔔', value: 'boutonrappel' },
                        { label: 'Autoriser les liens', emoji: '🔗', value: 'autoriserliens' }
                    ])
            );

            const row = new Discord.ActionRowBuilder().addComponents(selectOption);

            await msg.edit({
                content: null,
                embeds: [embed],
                components: [row, selectMenu, buttons]
            });
        }

        await updateFirst();

        // ════════ Gestion des interactions ════════
        const collector = msg.createMessageComponentCollector();

        collector.on('collect', async i => {
            if (i.user.id !== message.author.id) {
                return i.reply({ content: '🚫 Vous n\'êtes pas autorisé à interagir avec ce panneau !', ephemeral: true });
            }

            const db = await client?.db.get(`ticket_${message.guild.id}`) || {
                option: [],
                salon: message.channel.id, // Salon par défaut = salon de la commande
                messageidoption: null,
                type: 'select',
                Suppauto: true,
                maxticket: 1,
                leaveclose: false,
                claimbutton: true,
                buttonclose: true,
                transcript: false,
                rolerequis: [],
                roleinterdit: [],
            };

            // ════════ Retour au menu principal ════════
            if (i.customId === 'retourmenu') {
                await i.deferUpdate();
                return updateFirst();
            }

            // ════════ Réinitialisation de la configuration ════════
            if (i.customId === 'resetconfig') {
                if (i.user.id !== message.author.id) {
                    return i.reply({ content: '🚫 Vous n\'êtes pas autorisé à réinitialiser la configuration.', ephemeral: true });
                }
                await i.reply({ content: '⚠️ Êtes-vous sûr de vouloir réinitialiser la configuration des tickets ? Répondez "oui" dans la minute pour confirmer.', ephemeral: true });
                const filter = response => response.author.id === message.author.id && response.content.toLowerCase() === 'oui';
                try {
                    const collected = await message.channel.awaitMessages({ filter, max: 1, time: ms('1m'), errors: ['time'] });
                    // Suppression de la configuration
                    await client.db.delete(`ticket_${message.guild.id}`);
                    await message.channel.send({ content: '♻️ Configuration des tickets réinitialisée !', ephemeral: true });
                    await updateFirst();
                } catch (error) {
                    await message.channel.send({ content: '⏰ Réinitialisation annulée (pas de confirmation).', ephemeral: true });
                }
                return;
            }

            // ════════ Activation du système de tickets ════════
if (i.customId === 'activer') {
    if (!db?.option || db.option.length === 0) {
        return i.reply({ content: '⚠️ Les options du système de tickets ne sont pas configurées.', ephemeral: true });
    }
    if (!db.salon || !i.guild.channels.cache.get(db.salon)) {
        return i.reply({ content: '⚠️ Le salon des tickets n\'est pas configuré ou est invalide.', ephemeral: true });
    }
    if (!db.messageidoption && !db.autoembed) {
        return i.reply({ content: '⚠️ L\'ID du message n\'est pas configuré.', ephemeral: true });
    }

    const channel = i.guild.channels.cache.get(db.salon);
    if (!channel.permissionsFor(i.guild.members.me).has(['VIEW_CHANNEL', 'READ_MESSAGE_HISTORY'])) {
        return i.reply({ content: '❌ Le bot n\'a pas les permissions nécessaires pour accéder au salon.', ephemeral: true });
    }

    const rows = [];
    if (db.type === 'button') {
        const buttons = db.option.map(option => {
            const button = new Discord.ButtonBuilder()
                .setCustomId(`ticket_${option.value}`)
                .setLabel(option.text.length > 80 ? option.text.substring(0, 77) + '...' : option.text)
                .setStyle(Discord.ButtonStyle.Primary);

            if (option.emoji) {
                const customEmojiRegex = /<a?:[a-zA-Z0-9_]+:(\d+)>/;
                const match = option.emoji.match(customEmojiRegex);
                if (match) {
                    const emojiId = match[1];
                    const emojiObj = client.emojis.cache.get(emojiId);
                    if (emojiObj) {
                        button.setEmoji(emojiId);
                    }
                } else {
                    const unicodeEmojiRegex = /\p{Emoji}/u;
                    if (unicodeEmojiRegex.test(option.emoji)) {
                        button.setEmoji(option.emoji);
                    }
                }
            }

            return button;
        });

        rows.push(new Discord.ActionRowBuilder().addComponents(buttons));
    } else if (db.type === 'select') {
        const options = db.option.map(option => {
            let emoji = undefined;
            //console.log(`[activer] Processing emoji for option ${option.value}: ${option.emoji}`);
            if (option.emoji) {
                const customEmojiRegex = /<a?:[a-zA-Z0-9_]+:(\d+)>/;
                const match = option.emoji.match(customEmojiRegex);
                if (match) {
                    const emojiId = match[1];
                    const emojiObj = client.emojis.cache.get(emojiId);
                    if (emojiObj) {
                        emoji = emojiId;
                    } else {
                        //console.log(`[activer] Custom emoji ${option.emoji} not found in cache`);
                    }
                } else {
                    const unicodeEmojiRegex = /\p{Emoji}/u;
                    if (unicodeEmojiRegex.test(option.emoji)) {
                        emoji = option.emoji;
                    } else {
                        //console.log(`[activer] Invalid emoji format: ${option.emoji}`);
                    }
                }
            }

            return {
                label: option.text.length > 100 ? option.text.substring(0, 97) + '...' : option.text,
                description: option.description?.length > 100 ? option.description.substring(0, 97) + '...' : option.description || 'Sans description',
                value: `ticket_${option.value}`,
                ...(emoji && { emoji })
            };
        });

        //console.log('[activer] Select menu options:', options);
        rows.push(new Discord.ActionRowBuilder().addComponents(
            new Discord.StringSelectMenuBuilder()
                .setCustomId('ticket')
                .setPlaceholder('Choisir une option de ticket')
                .addOptions(options)
        ));
    }

    try {
        //console.log(`[activer] Attempting to fetch message ID: ${db.messageidoption} in channel ID: ${db.salon}`);
        let targetMessage;
        if (db.autoembed) {
            // On modifie le message existant pour mettre l'embed automatique et les composants
            targetMessage = await channel.messages.fetch(db.messageidoption);
            if (targetMessage.author.id !== client.user.id) {
                return i.reply({ content: '❌ Le message spécifié n\'appartient pas au bot. Veuillez utiliser l\'ID d\'un message ou embed créé par le bot.', ephemeral: true });
            }
            const embed = new Discord.EmbedBuilder()
                .setTitle('Tickets')
                .setDescription('Utiliser ce menu pour créer un ticket & contacter le personnel')
                .setColor(client.color);
            await targetMessage.edit({ content: null, embeds: [embed], components: rows });
        } else if (db.messageidoption) {
            // Sinon, on édite juste les composants
            targetMessage = await channel.messages.fetch(db.messageidoption);
            if (targetMessage.author.id !== client.user.id) {
                return i.reply({ content: '❌ Le message spécifié n\'appartient pas au bot. Veuillez utiliser l\'ID d\'un message ou embed créé par le bot.', ephemeral: true });
            }
            await targetMessage.edit({ components: rows });
        } else if (!db.messageidoption) {
            // Si pas de messageidoption, on crée un nouveau message (cas legacy)
            const embed = new Discord.EmbedBuilder()
                .setTitle('Tickets')
                .setDescription('Utiliser ce menu pour créer un ticket & contacter le personnel')
                .setColor(client.color);
            targetMessage = await channel.send({ embeds: [embed], components: rows });
            db.messageidoption = targetMessage.id;
            await client.db.set(`ticket_${i.guild.id}`, db);
            await updateFirst();
        }
        await i.reply({ content: '✅ Système de tickets activé avec succès !', ephemeral: true });
    } catch (error) {
        if (error.code === 10008) {
            return i.reply({ content: '❌ L\'ID du message est invalide ou le message n\'existe pas.', ephemeral: true });
        }
        console.error('[activer] Error:', error);
        return i.reply({ content: '❌ Erreur lors de l\'activation du système.', ephemeral: true });
    }
}

            // ════════ Suppression d'une option ════════
            if (i.customId.startsWith('suppoption_')) {
                const optionId = i.customId.split('_')[1];
                const index = db.option.findIndex(option => option.value === optionId);
                if (index !== -1) {
                    db.option.splice(index, 1);
                    await client.db.set(`ticket_${i.guild.id}`, db);
                    await i.deferUpdate();
                    return updateFirst();
                }
            }

            // ════════ Gestion des options de configuration ════════
            if (i.values?.[0] === 'type') {
                db.type = db.type === 'button' ? 'select' : 'button';
                await client.db.set(`ticket_${i.guild.id}`, db);
                await i.deferUpdate();
                await updateFirst();
            }

            if (i.values?.[0] === 'claim') {
                db.claimbutton = !db.claimbutton;
                await client.db.set(`ticket_${i.guild.id}`, db);
                await i.deferUpdate();
                await updateFirst();
            }

            if (i.values?.[0] === 'fermetureleave') {
                db.leaveclose = !db.leaveclose;
                await client.db.set(`ticket_${i.guild.id}`, db);
                await i.deferUpdate();
                await updateFirst();
            }

            if (i.values?.[0] === 'transcript') {
                db.transcript = !db.transcript;
                await client.db.set(`ticket_${i.guild.id}`, db);
                await i.deferUpdate();
                await updateFirst();
            }

            if (i.values?.[0] === 'roleinterdit') {
                const filter = response => response.author.id === message.author.id;
                const sentMessage = await i.reply({ content: '🚫 Mentionnez les rôles interdits ou fournissez leurs IDs. Tapez \'aucun\' pour supprimer.', ephemeral: true });

                try {
                    const collected = await message.channel.awaitMessages({ filter, max: 1, time: ms('1m'), errors: ['time'] });
                    const content = collected.first().content.trim();

                    if (content.toLowerCase() === 'aucun' || content.toLowerCase() === 'none' || content.toLowerCase() === 'null') {
                        db.roleinterdit = [];
                        await client.db.set(`ticket_${i.guild.id}`, db);
                        await sentMessage.delete();
                        await collected.first().delete();
                        await updateFirst();
                    } else {
                        const mentionedRoles = collected.first().mentions.roles;
                        const roleIds = [];

                        // Ajouter les rôles mentionnés
                        if (mentionedRoles.size > 0) {
                            roleIds.push(...mentionedRoles.map(role => role.id));
                        }

                        // Vérifier s'il y a des IDs de rôles dans le message
                        const words = content.split(/\s+/);
                        for (const word of words) {
                            const roleId = word.replace(/[<@&>]/g, ''); // Enlever les caractères de mention
                            if (/^\d{17,19}$/.test(roleId)) { // Vérifier si c'est un ID valide
                                const role = i.guild.roles.cache.get(roleId);
                                if (role && !roleIds.includes(roleId)) {
                                    roleIds.push(roleId);
                                }
                            }
                        }

                        if (roleIds.length === 0) {
                            await message.channel.send({ content: '❌ Aucun rôle valide trouvé. Mentionnez les rôles ou fournissez leurs IDs.', ephemeral: true });
                        } else {
                            db.roleinterdit = roleIds;
                            await client.db.set(`ticket_${i.guild.id}`, db);
                            await sentMessage.delete();
                            await collected.first().delete();
                            await updateFirst();
                        }
                    }
                } catch (error) {
                    console.error(error);
                    await sentMessage.delete();
                    await updateFirst();
                    await message.channel.send({ content: '⏰ Temps de réponse expiré.', ephemeral: true });
                }
            }

            if (i.values?.[0] === 'rolerequis') {
                const filter = response => response.author.id === message.author.id;
                const sentMessage = await i.reply({ content: '✅ Mentionnez les rôles requis ou fournissez leurs IDs. Tapez \'aucun\' pour supprimer.', ephemeral: true });

                try {
                    const collected = await message.channel.awaitMessages({ filter, max: 1, time: ms('1m'), errors: ['time'] });
                    const content = collected.first().content.trim();

                    if (content.toLowerCase() === 'aucun' || content.toLowerCase() === 'none' || content.toLowerCase() === 'null') {
                        db.rolerequis = [];
                        await client.db.set(`ticket_${i.guild.id}`, db);
                        await sentMessage.delete();
                        await collected.first().delete();
                        await updateFirst();
                    } else {
                        const mentionedRoles = collected.first().mentions.roles;
                        const roleIds = [];

                        // Ajouter les rôles mentionnés
                        if (mentionedRoles.size > 0) {
                            roleIds.push(...mentionedRoles.map(role => role.id));
                        }

                        // Vérifier s'il y a des IDs de rôles dans le message
                        const words = content.split(/\s+/);
                        for (const word of words) {
                            const roleId = word.replace(/[<@&>]/g, ''); // Enlever les caractères de mention
                            if (/^\d{17,19}$/.test(roleId)) { // Vérifier si c'est un ID valide
                                const role = i.guild.roles.cache.get(roleId);
                                if (role && !roleIds.includes(roleId)) {
                                    roleIds.push(roleId);
                                }
                            }
                        }

                        if (roleIds.length === 0) {
                            await message.channel.send({ content: '❌ Aucun rôle valide trouvé. Mentionnez les rôles ou fournissez leurs IDs.', ephemeral: true });
                        } else {
                            db.rolerequis = roleIds;
                            await client.db.set(`ticket_${i.guild.id}`, db);
                            await sentMessage.delete();
                            await collected.first().delete();
                            await updateFirst();
                        }
                    }
                } catch (error) {
                    console.error(error);
                    await sentMessage.delete();
                    await updateFirst();
                    await message.channel.send({ content: '⏰ Temps de réponse expiré.', ephemeral: true });
                }
            }

            if (i.values?.[0] === 'boutonrappel') {
                db.boutonrappel = !db.boutonrappel;
                await client.db.set(`ticket_${i.guild.id}`, db);
                await i.deferUpdate();
                await updateFirst();
            }

            if (i.values?.[0] === 'autoriserliens') {
                db.autoriserliens = !db.autoriserliens;
                await client.db.set(`ticket_${i.guild.id}`, db);
                await i.deferUpdate();
                await updateFirst();
            }

            if (i.values?.[0] === 'maxticket') {
                const filter = response => response.author.id === message.author.id;
                const sentMessage = await i.reply({ content: '🔢 Nombre maximum de tickets par utilisateur ?', ephemeral: true });

                try {
                    const collected = await message.channel.awaitMessages({ filter, max: 1, time: ms('1m'), errors: ['time'] });
                    const newMaxTickets = parseInt(collected.first().content.trim());

                    if (!isNaN(newMaxTickets) && newMaxTickets > 0) {
                        db.maxticket = newMaxTickets;
                        await client.db.set(`ticket_${i.guild.id}`, db);
                        await sentMessage.delete();
                        await collected.first().delete();
                        await updateFirst();
                    } else {
                        await message.channel.send({ content: '⚠️ Veuillez entrer un nombre entier positif.', ephemeral: true });
                        await sentMessage.delete();
                        await collected.first().delete();
                        await updateFirst();
                    }
                } catch (error) {
                    console.error(error);
                    await sentMessage.delete();
                    await updateFirst();
                    await message.channel.send({ content: '⏰ Temps de réponse expiré.', ephemeral: true });
                }
            }

            if (i.values?.[0] === 'salon') {
                const filter = response => response.author.id === message.author.id;
                const sentMessage = await i.reply({ content: '📍 Mentionnez le salon des tickets.', ephemeral: true });

                try {
                    const collected = await message.channel.awaitMessages({ filter, max: 1, time: ms('1m'), errors: ['time'] });
                    const channelId = collected.first().content.trim().replace(/[<#>]/g, '');
                    const channel = message.guild.channels.cache.get(channelId);

                    if (!channel) {
                        await message.channel.send({ content: '❌ Salon introuvable.', ephemeral: true });
                        await sentMessage.delete();
                        await collected.first().delete();
                        await updateFirst();
                    } else {
                        db.salon = channel.id;
                        await client.db.set(`ticket_${i.guild.id}`, db);
                        await sentMessage.delete();
                        await collected.first().delete();
                        await updateFirst();
                    }
                } catch (error) {
                    console.error(error);
                    await sentMessage.delete();
                    await updateFirst();
                    await message.channel.send({ content: '⏰ Temps de réponse expiré.', ephemeral: true });
                }
            }

            if (i.values?.[0] === 'messageidoption') {
                if (!db.salon) {
                    return i.reply({ content: '⚠️ Configurez d\'abord le salon des tickets.', ephemeral: true });
                }

                const filter = response => response.author.id === i.user.id;
                const sentMessage = await i.reply({ content: '📩 ID du message pour le système de tickets ?', ephemeral: true });

                try {
                    const collected = await i.channel.awaitMessages({ filter, max: 1, time: ms('1m'), errors: ['time'] });
                    const messageId = collected.first().content.trim();
                    const channel = i.guild.channels.cache.get(db.salon);

                    if (!channel) {
                        await i.followUp({ content: '❌ Salon de tickets introuvable.', ephemeral: true });
                        await sentMessage.delete();
                        await collected.first().delete();
                        await updateFirst();
                        return;
                    }

                    try {
                        await channel.messages.fetch(messageId);
                        db.messageidoption = messageId;
                        db.autoembed = false; // Désactive le mode autoembed pour afficher l'ID
                        await client.db.set(`ticket_${i.guild.id}`, db);
                        await i.followUp({ content: `✅ ID du message mis à jour : \`${messageId}\``, ephemeral: true });
                    } catch (fetchError) {
                        await i.followUp({ content: '❌ Message introuvable avec cet ID.', ephemeral: true });
                    } finally {
                        await sentMessage.delete();
                        await collected.first().delete();
                        await updateFirst();
                    }
                } catch (error) {
                    console.error(error);
                    await sentMessage.delete();
                    await updateFirst();
                    await i.followUp({ content: '⏰ Temps de réponse expiré.', ephemeral: true });
                }
            }

            if (i.values?.[0] === 'addoption') {
                if (db.option.length >= 10) {
                    return msg.edit({ content: '⚠️ Maximum 10 options configurables.', embeds: [], components: [] });
                }
                db.option.push({
                    categorie: null,
                    emoji: null,
                    text: 'Ouvrir un ticket',
                    value: code(10),
                    description: 'Aucune description',
                    message: 'Merci d\'avoir contacté le support\nDécrivez votre problème puis attendez une réponse',
                    logs: null,
                    mention: null,
                    acess: null,
                    motifs: []
                });
                await client.db.set(`ticket_${i.guild.id}`, db);
                await updateFirst();
            }

            if (i.values?.[0] === 'autoembed') {
                db.autoembed = !db.autoembed; // toggle
                await client.db.set(`ticket_${i.guild.id}`, db);
                await i.deferUpdate();
                await updateFirst();
            }

            // ════════ Configuration des options spécifiques ════════
            if (i.values?.[0].startsWith('categorieoption_')) {
                const id = i.values[0].split('_')[1];
                const validOption = db.option.find(option => option.value === id);

                if (validOption) {
                    const filter = response => response.author.id === message.author.id;
                    const sentMessage = await i.reply({ content: '📂 Mentionnez la catégorie.', ephemeral: true });

                    try {
                        const collected = await message.channel.awaitMessages({ filter, max: 1, time: ms('1m'), errors: ['time'] });
                        const categoryId = collected.first().content.trim();
                        const category = message.guild.channels.cache.get(categoryId);

                        if (category?.type !== 4) {
                            await message.channel.send({ content: '❌ Catégorie invalide.', ephemeral: true });
                            await sentMessage.delete();
                            await collected.first().delete();
                            await optionUpdate(id);
                        } else {
                            validOption.categorie = categoryId;
                            await client.db.set(`ticket_${i.guild.id}`, db);
                            await sentMessage.delete();
                            await collected.first().delete();
                            await optionUpdate(id);
                        }
                    } catch (error) {
                        console.error(error);
                        await sentMessage.delete();
                        await optionUpdate(id);
                        await message.channel.send({ content: '⏰ Temps de réponse expiré.', ephemeral: true });
                    }
                }
            }

            if (i.values?.[0].startsWith('textoption_')) {
                const id = i.values[0].split('_')[1];
                const validOption = db.option.find(option => option.value === id);

                if (validOption) {
                    const filter = response => response.author.id === message.author.id;
                    const sentMessage = await i.reply({ content: '✍️ Texte de l\'option ?', ephemeral: true });

                    try {
                        const collected = await message.channel.awaitMessages({ filter, max: 1, time: ms('1m'), errors: ['time'] });
                        const text = collected.first().content.trim();

                        if (!text) {
                            await message.channel.send({ content: '❌ Texte invalide.', ephemeral: true });
                        } else {
                            validOption.text = text;
                            await client.db.set(`ticket_${i.guild.id}`, db);
                            await sentMessage.delete();
                            await collected.first().delete();
                            await optionUpdate(id);
                        }
                    } catch (error) {
                        console.error(error);
                        await sentMessage.delete();
                        await optionUpdate(id);
                        await message.channel.send({ content: '⏰ Temps de réponse expiré.', ephemeral: true });
                    }
                }
            }

            if (i.values?.[0].startsWith('roleoption_')) {
                const id = i.values[0].split('_')[1];
                const validOption = db.option.find(option => option.value === id);

                if (validOption) {
                    const filter = response => response.author.id === message.author.id;
                    const sentMessage = await i.reply({ content: '🔔 Mentionnez le rôle ou fournissez son ID, ou tapez \'aucun\' pour supprimer.', ephemeral: true });

                    try {
                        const collected = await message.channel.awaitMessages({ filter, max: 1, time: ms('1m'), errors: ['time'] });
                        const content = collected.first().content.trim();

                        if (content.toLowerCase() === 'aucun' || content.toLowerCase() === 'none' || content.toLowerCase() === 'null') {
                            validOption.mention = null;
                            await client.db.set(`ticket_${i.guild.id}`, db);
                            await sentMessage.delete();
                            await collected.first().delete();
                            await optionUpdate(id);
                        } else {
                            const mentionedRoles = collected.first().mentions.roles;
                            let roleId = null;
                            if (mentionedRoles.size > 0) {
                                roleId = mentionedRoles.first().id;
                            } else if (/^\d{17,19}$/.test(content)) {
                                const role = message.guild.roles.cache.get(content);
                                if (role) {
                                    roleId = role.id;
                                }
                            }
                            if (!roleId) {
                                await message.channel.send({ content: '❌ Rôle invalide. Mentionnez le rôle ou fournissez un ID valide. Tapez "aucun" pour supprimer.', ephemeral: true });
                            } else {
                                validOption.mention = roleId;
                                await client.db.set(`ticket_${i.guild.id}`, db);
                                await sentMessage.delete();
                                await collected.first().delete();
                                await optionUpdate(id);
                            }
                        }
                    } catch (error) {
                        console.error(error);
                        await sentMessage.delete();
                        await optionUpdate(id);
                        await message.channel.send({ content: '⏰ Temps de réponse expiré.', ephemeral: true });
                    }
                }
            }

            if (i.values?.[0].startsWith('salonoption_')) {
                const id = i.values[0].split('_')[1];
                const validOption = db.option.find(option => option.value === id);

                if (validOption) {
                    const filter = response => response.author.id === message.author.id;
                    const sentMessage = await i.reply({ content: '📜 Mentionnez le salon des logs ou fournissez son ID.', ephemeral: true });

                    try {
                        const collected = await message.channel.awaitMessages({ filter, max: 1, time: ms('1m'), errors: ['time'] });
                        const userInput = collected.first().content.trim();
                        
                        let channelId = null;
                        const channelMention = userInput.match(/<#(\d+)>/);
                        if (channelMention) {
                            channelId = channelMention[1];
                        } else if (/^\d{17,19}$/.test(userInput)) {
                            channelId = userInput;
                        }

                        if (!channelId) {
                            await message.channel.send({ content: '❌ Mention ou ID de salon invalide.', ephemeral: true });
                            await sentMessage.delete();
                            await collected.first().delete();
                            return;
                        }

                        const channel = client.channels.cache.get(channelId);

                        if (!channel) {
                            await message.channel.send({ content: '❌ Salon introuvable ou inaccessible.', ephemeral: true });
                        } else {
                            validOption.logs = channelId;
                            await client.db.set(`ticket_${i.guild.id}`, db);
                            await sentMessage.delete();
                            await collected.first().delete();
                            await optionUpdate(id);
                        }
                    } catch (error) {
                        console.error(error);
                        await sentMessage.delete();
                        await message.channel.send({ content: '⏰ Temps de réponse expiré.', ephemeral: true });
                    }
                }
            }

            if (i.values?.[0].startsWith('emojioption_')) {
                const id = i.values[0].split('_')[1];
                const validOption = db.option.find(option => option.value === id);

                if (validOption) {
                    const filter = response => response.author.id === message.author.id;
                    const sentMessage = await i.reply({ content: '🪄 Indiquez un emoji (custom ou standard).', ephemeral: true });

                    try {
                        const collected = await message.channel.awaitMessages({ filter, max: 1, time: ms('1m'), errors: ['time'] });
                        const emojiInput = collected.first().content.trim();

                        let emojiToStore = emojiInput;
                        const customEmojiRegex = /<a?:[a-zA-Z0-9_]+:(\d+)>/;
                        const unicodeEmojiRegex = /\p{Emoji}/u;

                        if (customEmojiRegex.test(emojiInput)) {
                            const match = emojiInput.match(customEmojiRegex);
                            const emojiId = match[1];
                            const emojiObj = client.emojis.cache.get(emojiId);
                            if (!emojiObj) {
                                await message.channel.send({ content: '❌ Emoji personnalisé inaccessible.', ephemeral: true });
                                await sentMessage.delete();
                                await collected.first().delete();
                                await optionUpdate(id);
                                return;
                            }
                            emojiToStore = emojiInput;
                        } else if (!unicodeEmojiRegex.test(emojiInput)) {
                            await message.channel.send({ content: '❌ Emoji invalide.', ephemeral: true });
                            await sentMessage.delete();
                            await collected.first().delete();
                            await optionUpdate(id);
                            return;
                        }

                        validOption.emoji = emojiToStore;
                        await client.db.set(`ticket_${i.guild.id}`, db);
                        console.log(`Stored emoji for option ${id}: ${emojiToStore}`);
                        await sentMessage.delete();
                        await collected.first().delete();
                        await optionUpdate(id);
                    } catch (error) {
                        console.error('Error in emojioption_:', error);
                        await sentMessage.delete();
                        await optionUpdate(id);
                        await message.channel.send({ content: '⏰ Temps de réponse expiré.', ephemeral: true });
                    }
                }
            }

            if (i.values?.[0].startsWith('ouvertoption_')) {
                const id = i.values[0].split('_')[1];
                const validOption = db.option.find(option => option.value === id);

                if (validOption) {
                    const filter = response => response.author.id === message.author.id;
                    const sentMessage = await i.reply({ content: '📬 Texte d\'ouverture du ticket ?', ephemeral: true });

                    try {
                        const collected = await message.channel.awaitMessages({ filter, max: 1, time: ms('1m'), errors: ['time'] });
                        const text = collected.first().content.trim();

                        if (text.length === 0) {
                            await message.channel.send({ content: '❌ Texte d\'ouverture invalide.', ephemeral: true });
                        } else {
                            validOption.message = text;
                            await client.db.set(`ticket_${i.guild.id}`, db);
                            await sentMessage.delete();
                            await collected.first().delete();
                            await optionUpdate(id);
                        }
                    } catch (error) {
                        console.error(error);
                        await sentMessage.delete();
                        await optionUpdate(id);
                        await message.channel.send({ content: '⏰ Temps de réponse expiré.', ephemeral: true });
                    }
                }
            }

            if (i.values?.[0].startsWith('descriptionoption_')) {
                const id = i.values[0].split('_')[1];
                const validOption = db.option.find(option => option.value === id);

                if (validOption) {
                    const filter = response => response.author.id === message.author.id;
                    const sentMessage = await i.reply({ content: '📝 Description du menu déroulant ?', ephemeral: true });

                    try {
                        const collected = await message.channel.awaitMessages({ filter, max: 1, time: ms('1m'), errors: ['time'] });
                        const text = collected.first().content.trim();

                        if (text.length === 0) {
                            await message.channel.send({ content: '❌ Description invalide.', ephemeral: true });
                        } else if (text.length > 100) {
                            await sentMessage.delete();
                            await collected.first().delete();
                            await optionUpdate(id);
                            await i.channel.send({ content: '⚠️ La description doit contenir moins de 100 caractères.', ephemeral: true });
                        } else {
                            validOption.description = text;
                            await client.db.set(`ticket_${i.guild.id}`, db);
                            await sentMessage.delete();
                            await collected.first().delete();
                            await optionUpdate(id);
                        }
                    } catch (error) {
                        console.error(error);
                        await sentMessage.delete();
                        await optionUpdate(id);
                        await message.channel.send({ content: '⏰ Temps de réponse expiré.', ephemeral: true });
                    }
                }
            }

            if (i.values?.[0].startsWith('roleacess_')) {
                const id = i.values[0].split('_')[1];
                const validOption = db.option.find(option => option.value === id);

                if (validOption) {
                    const filter = response => response.author.id === message.author.id;
                    const sentMessage = await i.reply({ content: '🔐 Mentionnez les rôles ou fournissez leurs IDs, ou tapez \'aucun\' pour supprimer.', ephemeral: true });

                    try {
                        const collected = await message.channel.awaitMessages({ filter, max: 1, time: ms('1m'), errors: ['time'] });
                        const content = collected.first().content.trim();

                        if (content.toLowerCase() === 'aucun' || content.toLowerCase() === 'none' || content.toLowerCase() === 'null') {
                            validOption.acess = null;
                            await client.db.set(`ticket_${i.guild.id}`, db);
                            await sentMessage.delete();
                            await collected.first().delete();
                            await optionUpdate(id);
                        } else {
                            const mentionedRoles = collected.first().mentions.roles;
                            const roleIds = [];

                            // Ajouter les rôles mentionnés
                            if (mentionedRoles.size > 0) {
                                roleIds.push(...mentionedRoles.map(role => role.id));
                            }

                            // Vérifier s'il y a des IDs de rôles dans le message
                            const words = content.split(/\s+/);
                            for (const word of words) {
                                const roleId = word.replace(/[<@&>]/g, ''); // Enlever les caractères de mention
                                if (/^\d{17,19}$/.test(roleId)) { // Vérifier si c'est un ID valide
                                    const role = message.guild.roles.cache.get(roleId);
                                    if (role && !roleIds.includes(roleId)) {
                                        roleIds.push(roleId);
                                    }
                                }
                            }

                            if (roleIds.length === 0) {
                                await message.channel.send({ content: '❌ Aucun rôle valide trouvé. Mentionnez les rôles ou fournissez leurs IDs. Tapez "aucun" pour supprimer.', ephemeral: true });
                            } else {
                                validOption.acess = roleIds;
                                await client.db.set(`ticket_${i.guild.id}`, db);
                                await sentMessage.delete();
                                await collected.first().delete();
                                await optionUpdate(id);
                            }
                        }
                    } catch (error) {
                        console.error(error);
                        await sentMessage.delete();
                        await optionUpdate(id);
                        await message.channel.send({ content: '⏰ Temps de réponse expiré.', ephemeral: true });
                    }
                }
            }

            if (i.values?.[0].startsWith('motifsoption_')) {
                const id = i.values[0].split('_')[1];
                const validOption = db.option.find(option => option.value === id);

                if (validOption) {
                    const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
                    const modal = new ModalBuilder()
                        .setCustomId(`config_motifs_modal_${id}`)
                        .setTitle('Configurer les motifs d\'ouverture');
                    for (let idx = 0; idx < 4; idx++) {
                        const input = new TextInputBuilder()
                            .setCustomId(`motif_input_${idx}`)
                            .setLabel(`Motif ${idx + 1}`)
                            .setStyle(TextInputStyle.Short)
                            .setRequired(false)
                            .setValue(validOption.motifs && validOption.motifs[idx] ? validOption.motifs[idx] : '');
                        modal.addComponents(new ActionRowBuilder().addComponents(input));
                    }
                    await i.showModal(modal);
                    return;
                }
            }

            // ----- Gestion du Modal de configuration des motifs -----
// ----- Gestion du Modal de configuration des motifs -----
// ----- Gestion du Modal de configuration des motifs -----
if (i.isModalSubmit && i.customId && i.customId.startsWith('config_motifs_modal_')) {
    const id = i.customId.split('_').pop();
    let db = await client?.db.get(`ticket_${message.guild.id}`) || { option: [] };
    const validOption = db.option.find(option => option.value === id);
    if (!validOption) return await i.reply({ content: 'Option non trouvée.', ephemeral: true });

    // Récupérer les motifs saisis dans le modal
    const motifs = [];
    for (let idx = 0; idx < 4; idx++) {
        const value = i.fields.getTextInputValue(`motif_input_${idx}`);
        if (value && value.trim().length > 0) motifs.push(value.trim());
    }
    validOption.motifs = motifs;

    // Log pour déboguer les motifs avant sauvegarde
    console.log(`[DEBUG] Motifs avant sauvegarde pour option ${id}:`, validOption.motifs);

    // Sauvegarder les modifications dans la base de données
    await client.db.set(`ticket_${message.guild.id}`, db);

    // Recharger la base de données pour garantir la synchronisation
    db = await client.db.get(`ticket_${message.guild.id}`) || { option: [] };
    const updatedOption = db.option.find(option => option.value === id);
    if (!updatedOption) return await i.reply({ content: 'Erreur : Option non trouvée après mise à jour.', ephemeral: true });

    // Log pour déboguer les motifs après rechargement
    console.log(`[DEBUG] Motifs après rechargement pour option ${id}:`, updatedOption.motifs);

    // Répondre à l'interaction
    await i.reply({ content: `✅ Motifs mis à jour !`, ephemeral: true });

    // Mettre à jour l'embed avec les nouvelles données
    const { optionEmbed, buttons, selectMenu } = updateOptionEmbed(updatedOption, client, i);
    
    // Log pour déboguer le contenu de l'embed
    console.log(`[DEBUG] Contenu du champ 'Motifs d\'ouverture' dans l'embed:`, 
        updatedOption.motifs && updatedOption.motifs.length > 0 
            ? updatedOption.motifs.map((motif, index) => `${index + 1}. ${motif}`).join('\n') 
            : 'Aucun motif configuré'
    );

    try {
        await msg.edit({ embeds: [optionEmbed], components: [selectMenu, buttons] });
    } catch (error) {
        console.error('[DEBUG] Erreur lors de l\'édition du message:', error);
        await i.followUp({ content: '❌ Erreur lors de la mise à jour de l\'embed. Vérifiez les permissions du bot.', ephemeral: true });
    }
    return;
}

            if (i.customId === 'selectoption') {
                await i.deferUpdate();
                await optionUpdate(i.values[0]);
            }

            // ════════ Mise à jour de l'embed d'option ════════
            async function optionUpdate(module) {
                const db = await client?.db.get(`ticket_${message.guild.id}`) || {};
                const selectedOption = db.option.find(option => option.value === module);

                if (selectedOption) {
                    const category = client.channels.cache.get(selectedOption.categorie);
                    const logChannel = client.channels.cache.get(selectedOption.logs);
                    const role = message.guild.roles.cache.get(selectedOption.mention);
                    const rolesAccess = Array.isArray(selectedOption.acess)
                        ? selectedOption.acess.map(roleId => `<@&${roleId}>`).join(', ')
                        : 'Aucun';

                    const optionEmbed = new Discord.EmbedBuilder()
                        .setTitle('⚙️ Configuration d\'une Option')
                        .setDescription(`Modifiez les paramètres de l'option : **${selectedOption.text}**`)
                        .setColor(client.color || '#5865F2')
                        .setFooter({ text: client.footer.text || 'Système de Tickets', iconURL: client.footer.iconURL })
                        .setTimestamp()
                        .addFields([
                            { name: '📂 Catégorie', value: category ? `#${category.name}` : 'Non définie', inline: true },
                            { name: '🪄 Emoji', value: selectedOption.emoji || 'Aucun', inline: true },
                            { name: '✍️ Texte', value: selectedOption.text || 'Non défini', inline: true },
                            { name: '📝 Description', value: selectedOption.description || 'Aucune', inline: true },
                            { name: '📜 Salon de logs', value: logChannel ? `<#${logChannel.id}>` : 'Non défini', inline: true },
                            { name: '🔔 Rôle mentionné', value: role ? `<@&${role.id}>` : 'Aucun', inline: true },
                            { name: '📬 Message d\'ouverture', value: selectedOption.message || 'Non défini', inline: true },
                            { name: '🔐 Rôles ayant accès', value: rolesAccess || 'Aucun', inline: true },
                            { name: '📋 Motifs d\'ouverture', value: selectedOption.motifs && selectedOption.motifs.length > 0 ? selectedOption.motifs.map((motif, index) => `${index + 1}. ${motif}`).join('\n') : 'Aucun motif configuré', inline: false }
                        ]);

                    const buttons = new Discord.ActionRowBuilder().addComponents(
                        new Discord.ButtonBuilder()
                            .setCustomId('retourmenu')
                            .setLabel('Retour au menu')
                            .setEmoji('⬅️')
                            .setStyle(Discord.ButtonStyle.Secondary),
                        new Discord.ButtonBuilder()
                            .setCustomId(`suppoption_${selectedOption.value}`)
                            .setLabel('Supprimer l\'option')
                            .setEmoji('🗑️')
                            .setStyle(Discord.ButtonStyle.Danger)
                    );

                    const selectMenu = new Discord.ActionRowBuilder().addComponents(
                        new Discord.StringSelectMenuBuilder()
                            .setCustomId('configmenu')
                            .setPlaceholder('🛠️ Modifier un paramètre')
                            .addOptions([
                                { label: 'Catégorie', emoji: '📂', value: `categorieoption_${selectedOption.value}` },
                                { label: 'Emoji', emoji: '🪄', value: `emojioption_${selectedOption.value}` },
                                { label: 'Texte', emoji: '✍️', value: `textoption_${selectedOption.value}` },
                                { label: 'Description', emoji: '📝', value: `descriptionoption_${selectedOption.value}` },
                                { label: 'Salon de logs', emoji: '📜', value: `salonoption_${selectedOption.value}` },
                                { label: 'Rôle mentionné', emoji: '🔔', value: `roleoption_${selectedOption.value}` },
                                                            { label: 'Message d\'ouverture', emoji: '📬', value: `ouvertoption_${selectedOption.value}` },
                            { label: 'Rôles ayant accès', emoji: '🔐', value: `roleacess_${selectedOption.value}` },
                            { label: 'Motifs d\'ouverture', emoji: '📋', value: `motifsoption_${selectedOption.value}` }
                            ])
                    );

                    await msg.edit({ embeds: [optionEmbed], components: [selectMenu, buttons] });
                }
            }

            // ════════ Fonction utilitaire pour générer un code aléatoire ════════
            function code(length) {
                const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
                let result = '';
                for (let i = 0; i < length; i++) {
                    const randomIndex = Math.floor(Math.random() * characters.length);
                    result += characters.charAt(randomIndex);
                }
                return result;
            }
        });
    }
};

// Fonction utilitaire pour mettre à jour l'embed d'option
function updateOptionEmbed(validOption, client, interaction) {
    const category = client.channels.cache.get(validOption.categorie);
    const logChannel = client.channels.cache.get(validOption.logs);
    const role = interaction.guild.roles.cache.get(validOption.mention);
    const rolesAccess = Array.isArray(validOption.acess)
        ? validOption.acess.map(roleId => `<@&${roleId}>`).join(', ')
        : 'Aucun';

    const Discord = require('discord.js');
    const optionEmbed = new Discord.EmbedBuilder()
        .setTitle('⚙️ Configuration d\'une Option')
        .setDescription(`Modifiez les paramètres de l'option : **${validOption.text}**`)
        .setColor(client.color || '#5865F2')
        .setFooter({ text: client.footer?.text || 'Système de Tickets', iconURL: client.footer?.iconURL })
        .setTimestamp()
        .addFields([
            { name: '📂 Catégorie', value: category ? `#${category.name}` : 'Non définie', inline: true },
            { name: '🪄 Emoji', value: validOption.emoji || 'Aucun', inline: true },
            { name: '✍️ Texte', value: validOption.text || 'Non défini', inline: true },
            { name: '📝 Description', value: validOption.description || 'Aucune', inline: true },
            { name: '📜 Salon de logs', value: logChannel ? `<#${logChannel.id}>` : 'Non défini', inline: true },
            { name: '🔔 Rôle mentionné', value: role ? `<@&${role.id}>` : 'Aucun', inline: true },
            { name: '📬 Message d\'ouverture', value: validOption.message || 'Non défini', inline: true },
            { name: '🔐 Rôles ayant accès', value: rolesAccess || 'Aucun', inline: true },
            { name: '📋 Motifs d\'ouverture', value: validOption.motifs && validOption.motifs.length > 0 ? validOption.motifs.map((motif, index) => `${index + 1}. ${motif}`).join('\n') : 'Aucun motif configuré', inline: false }
        ]);

    const buttons = new Discord.ActionRowBuilder().addComponents(
        new Discord.ButtonBuilder()
            .setCustomId('retourmenu')
            .setLabel('Retour au menu')
            .setEmoji('⬅️')
            .setStyle(Discord.ButtonStyle.Secondary),
        new Discord.ButtonBuilder()
            .setCustomId(`suppoption_${validOption.value}`)
            .setLabel('Supprimer l\'option')
            .setEmoji('🗑️')
            .setStyle(Discord.ButtonStyle.Danger)
    );

    const selectMenu = new Discord.ActionRowBuilder().addComponents(
        new Discord.StringSelectMenuBuilder()
            .setCustomId('configmenu')
            .setPlaceholder('🛠️ Modifier un paramètre')
            .addOptions([
                { label: 'Catégorie', emoji: '📂', value: `categorieoption_${validOption.value}` },
                { label: 'Emoji', emoji: '🪄', value: `emojioption_${validOption.value}` },
                { label: 'Texte', emoji: '✍️', value: `textoption_${validOption.value}` },
                { label: 'Description', emoji: '📝', value: `descriptionoption_${validOption.value}` },
                { label: 'Salon de logs', emoji: '📜', value: `salonoption_${validOption.value}` },
                { label: 'Rôle mentionné', emoji: '🔔', value: `roleoption_${validOption.value}` },
                { label: 'Message d\'ouverture', emoji: '📬', value: `ouvertoption_${validOption.value}` },
                { label: 'Rôles ayant accès', emoji: '🔐', value: `roleacess_${validOption.value}` },
                { label: 'Motifs d\'ouverture', emoji: '📋', value: `motifsoption_${validOption.value}` }
            ])
    );

    return { optionEmbed, buttons, selectMenu };
}

