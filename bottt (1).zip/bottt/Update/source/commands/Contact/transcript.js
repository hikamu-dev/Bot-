const { EmbedBuilder } = require('discord.js');
const discordTranscripts = require('discord-html-transcripts');

module.exports = {
    name: "transcript",
    description: "Envoie le transcript du ticket actuel au créateur en MP",
    category: "ticket",
    usage: "transcript",
    /**
     * @param {Valory} client
     * @param {Discord.Message} message
     * @param {Array} args
     */
    run: async (client, message, args, commandName) => {
      
    let pass = false;

    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) || 
        client.db.get(`owner_global_${message.author.id}`) === true || 
        client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true) {
      pass = true;
    } else {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        pass = true;
      }
    }

    if (!pass) {
        if (client.noperm && client.noperm.trim() !== '') {
            const sentMessage = await message.channel.send(client.noperm);
            const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
            if (delayTime > 0) {
                setTimeout(() => {
                    sentMessage.delete().catch(() => {});
                }, delayTime * 1000);
            }
        }
        return;
    }

        const ticketId = message.channel.id;
        const tickets = await client.db.get(`ticket_user_${message.guild.id}`);
        const ticket = tickets.find(t => t.salon === ticketId);

        if (!ticket) {
            return message.channel.send('Aucun ticket trouvé avec cet ID.');
        }

        const dbserveur = await client.db.get(`ticket_${message.guild.id}`);
        if (!dbserveur) {
            console.error("Configuration des tickets introuvable pour ce serveur.");
            return message.channel.send("Erreur : Configuration des tickets introuvable.");
        }

        const channelticket = message.channel;
        const transcript = await discordTranscripts.createTranscript(channelticket);

        const user = await client.users.fetch(ticket.author).catch(() => null);
        if (dbserveur.transcript === true && user) {
            const userEmbed = new EmbedBuilder()
                .setColor(client.color)
                .setFooter(client.footer)
                .setTimestamp()
                .setTitle('Transcript de votre ticket')
                .addFields({ 
                    name: 'Serveur', 
                    value: message.guild.name,
                    inline: true
                });

            try {
                await user.send({
                    content: `Voici le transcript de votre ticket sur le serveur ${message.guild.name} :`,
                    files: [transcript],
                    embeds: [userEmbed]
                });
                await message.channel.send('Transcript envoyé avec succès au créateur du ticket.');
            } catch (err) {
                console.error(`Erreur lors de l'envoi du transcript à ${user.username} (${user.id}) :`, err);
                await message.channel.send("Erreur lors de l'envoi du transcript au créateur du ticket.");
            }
        } else {
            await message.channel.send("Impossible d'envoyer le transcript : utilisateur introuvable ou transcripts désactivés.");
        }
    }
};