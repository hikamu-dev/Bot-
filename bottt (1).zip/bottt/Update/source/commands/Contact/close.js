const { ActionRowBuilder, ButtonBuilder, EmbedBuilder } = require('discord.js');
const discordTranscripts = require('discord-html-transcripts');
const { example } = require('./add');

module.exports = {
    name: "close",
    description: "Ferme le ticket actuel avec une raison optionnelle",
    category: "ticket",
    usage: "close [raison]",
    example: "➜ close Problème résolu\n➜ close",
    /**
     * @param {Valory} client
     * @param {Discord.Message} message
     * @param {Array} args
     */
    run: async (client, message, args, commandName) => {
      
    let pass = false;

    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) || 
        client.db.get(`owner_global_${message.author.id}`) === true || 
        client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true) {
      pass = true;
    } else {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        pass = true;
      }
    }

    if (!pass) {
        if (client.noperm && client.noperm.trim() !== '') {
            const sentMessage = await message.channel.send(client.noperm);
            const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
            if (delayTime > 0) {
                setTimeout(() => {
                    sentMessage.delete().catch(() => {});
                }, delayTime * 1000);
            }
        }
        return;
    }

    const dbserveur = await client?.db.get(`ticket_${message.guild.id}`);
    if (!dbserveur) return message.reply('Configuration de ticket non trouvée.');

    const tickets = await client.db.get(`ticket_user_${message.guild.id}`);
    if (!tickets || tickets.length === 0) return message.reply('Aucun ticket en cours dans ce serveur.');

    const ticket = tickets.find(t => t.salon === message.channel.id);
    if (!ticket) return message.reply('Ce canal n\'est associé à aucun ticket.');

    const dboption = dbserveur.option.find(option => option.value === ticket.option);
    const channel = message.guild.channels.cache.get(dboption?.logs);
    const channelticket = message.channel;

    // Get the reason from args, or set a default if none provided
    const reason = args.length > 0 ? args.join(' ') : 'Aucune raison spécifiée';

    const transcript = await discordTranscripts.createTranscript(channelticket);

    if (channel) {
        const embed = new EmbedBuilder()
            .setColor(client.color)
            .setFooter(client.footer)
            .setAuthor({ name: `${message.author.username} (${message.author.id})`, iconURL: message.author.displayAvatarURL() })
            .setTimestamp()
            .setTitle(`Ticket Fermé par ${message.author.username}`)
            .addFields({ name: 'Raison', value: reason });
        channel.send({
            files: [transcript],
            embeds: [embed]
        }).catch(err => {
            console.error("Erreur lors de l'envoi du transcript dans le canal de logs :", err);
        });
    }

    const user = await client.users.fetch(ticket.author).catch(() => null);
    if (dbserveur.transcript === true && user) {
        const userEmbed = new EmbedBuilder()
            .setColor(client.color)
            .setFooter(client.footer)
            .setTimestamp()
            .setTitle('Ticket fermé')
            .addFields({ name: 'Raison', value: reason });

        user.send({
            content: `Votre ticket sur le serveur ${message.guild.name} a été fermé. Voici un transcript du ticket :`,
            files: [transcript],
            embeds: [userEmbed]
        }).catch(err => {
            console.error(`Erreur lors de l'envoi du transcript à ${user?.username} (${user?.id}) :`, err);
        });
    }

    // === Envoi DM pour avis (après le transcript)
    try {
        const targetType = ticket.claim ? 'member' : 'server';
        const targetId   = ticket.claim ? ticket.claim : message.guild.id;
        if (user) {
            const endEmbed = new EmbedBuilder()
                .setColor(client.color || (await client.db.get(`color_${message.guild.id}`)) || '#2f3136')
                .setTitle('Ton ticket a été fermé')
                .setDescription('⭐ Note ce ticket en cliquant sur une étoile ci-dessous.\nTu auras 1 minute pour écrire un avis.\nSi tu ne réponds pas, seule la note sera enregistrée.')
                .setTimestamp();

            const starsRow = new ActionRowBuilder().addComponents(
                ...[1,2,3,4,5].map(n =>
                    new ButtonBuilder()
                        .setCustomId(`dmrate_${message.guild.id}_${ticket.id}_${n}_${targetType}_${targetId}`)
                        .setLabel('★'.repeat(n))
                        .setStyle(n <= 2 ? 4 : (n === 3 ? 2 : 3))
                )
            );

            await user.send({ embeds: [endEmbed], components: [starsRow] }).catch(() => {});
        }
    } catch (e) {
        console.error('DM review error (close.js):', e);
    }

    const updatedTickets = tickets.filter(t => t.id !== ticket.id);
    await client.db.set(`ticket_user_${message.guild.id}`, updatedTickets);

    channelticket.delete().catch(err => {
        console.error("Erreur lors de la suppression du canal de ticket :", err);
    });
    }
};
