const { EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require('discord.js');
const Valory = require('../../structures/client');

module.exports = {
    name: "rappel",
    description: "Rappelle le créateur d'un ticket",
    usage: "rappel",
    example: "➜ rappel",
    /**
     * @param {Valory} client
     * @param {Discord.Message} message
     * @param {string[]} args
     */
    run: async (client, message, args, commandName) => {
        let pass = false;

        // Vérification des permissions
        if (client.staff.includes(message.author.id) || 
            client.config.buyers.includes(message.author.id) || 
            client.db.get(`owner_global_${message.author.id}`) === true || 
            client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true) {
            pass = true;
        } else {
            const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
            if (commandPerms.length > 0) {
                const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                const userRoles = message.member.roles.cache.map(role => role.id);
                pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
            } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                pass = true;
            }
        }

        if (!pass) {
            if (client.noperm && client.noperm.trim() !== '') {
                const sentMessage = await message.channel.send(client.noperm);
                const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
                if (delayTime > 0) {
                    setTimeout(() => {
                        sentMessage.delete().catch(() => {});
                    }, delayTime * 1000);
                }
            }
            return;
        }

        const channelId = message.channel.id;
        const tickeruser = await client.db.get(`ticket_user_${message.guild.id}`) || [];
        const ticketData = tickeruser.find(ticket => ticket.salon === channelId);

        if (!ticketData) {
            return message.channel.send("Ce salon n'est pas un ticket valide.");
        }

        if (ticketData.author === message.author.id) {
            return message.channel.send("Vous ne pouvez pas vous rappeler vous-même !");
        }

        try {
            const user = await client.users.fetch(ticketData.author);
            if (user) {
                const db = await client.db.get(`ticket_${message.guild.id}`);
                const option = db?.option?.find(opt => opt.value === ticketData.option);
                const ticketName = option?.text || 'Ticket';
                const color = await client.db.get(`color_${message.guild.id}`) || client.config.default_color;

                const embed = new EmbedBuilder()
                    .setColor(color)
                    .setTitle('🔔 Rappel de ticket')
                    .setDescription(`Vous avez été rappelé pour votre ticket **${ticketName}** sur le serveur **${message.guild.name}**.\n\nCliquez ici pour y accéder : <#${ticketData.salon}>`)
                    .setTimestamp()
                    .setFooter({ text: `Rappelé par ${message.author.tag}`, iconURL: message.author.displayAvatarURL() });

                const ticketUrl = `https://discord.com/channels/${message.guild.id}/${ticketData.salon}`;
                const row = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setLabel('Accéder au ticket')
                        .setStyle(5)
                        .setURL(ticketUrl)
                );

                await user.send({ embeds: [embed], components: [row] }).catch(() => {
                    return message.channel.send("❌ Impossible d'envoyer un message privé à l'utilisateur. Il a peut-être désactivé les messages privés.");
                });

                return message.channel.send(`Rappel envoyé avec succès à \`${user.username}\`.`);
            } else {
                return message.channel.send("❌ Utilisateur introuvable.");
            }
        } catch (error) {
            console.error('Erreur lors de l\'envoi du rappel:', error);
            return message.channel.send("❌ Erreur lors de l'envoi du rappel.");
        }
    }
};