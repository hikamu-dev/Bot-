const Discord = require('discord.js');
const { example } = require('./add');

module.exports = {
    name: "remove",
    description: "Retire un utilisateur d'un ticket",
    use: "<@user/ID>",
    usage: "remove <@user/ID>",
    example: "➜ remove @tokyru\n➜ remove 123456789012345678",
    /**
     * @param {Discord.Client} client
     * @param {Discord.Message} message
     * @param {string[]} args
     */
    run: async (client, message, args, commandName) => {
      
    let pass = false;

    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) || 
        client.db.get(`owner_global_${message.author.id}`) === true || 
        client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true) {
      pass = true;
    } else {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        pass = true;
      }
    }

    if (!pass) {
        if (client.noperm && client.noperm.trim() !== '') {
            const sentMessage = await message.channel.send(client.noperm);
            const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
            if (delayTime > 0) {
                setTimeout(() => {
                    sentMessage.delete().catch(() => {});
                }, delayTime * 1000);
            }
        }
        return;
    }

        let user;
        if (message.mentions.members.first()) {
            user = message.mentions.members.first();
        } else if (args[0] && !isNaN(args[0])) {
            user = message.guild.members.cache.get(args[0]) || await message.guild.members.fetch(args[0]).catch(() => null);
        }
        if (!user) {
            return message.channel.send("Vous devez mentionner un utilisateur ou fournir un ID valide pour le retirer du ticket.");
        }

        const channelId = message.channel.id;
        let db = await client.db.get(`ticket_${message.guild.id}`);

        if (!db || !Array.isArray(db.tickets)) {
            return message.channel.send("Aucun ticket n'a été trouvé dans ce salon.");
        }

        let ticket = db.tickets.find(t => t.channelId === channelId);

        if (!ticket) {
            return message.channel.send("Aucun ticket n'a été trouvé dans ce salon.");
        }

        if (!ticket.users.includes(user.id)) {
            return message.channel.send("Cet utilisateur n'est pas dans ce ticket.");
        }

        try {
            await message.channel.permissionOverwrites.edit(user.id, {
                ViewChannel: false,
                SendMessages: false
            });

            ticket.users = ticket.users.filter(u => u !== user.id);

            await client.db.set(`ticket_${message.guild.id}`, db);

            return message.channel.send(`<@${user.user.id}> a été retiré du ticket.`);
        } catch (error) {
            console.error("Erreur lors de la mise à jour des permissions :", error);
            return message.channel.send("Une erreur s'est produite lors de la mise à jour des permissions.");
        }
    }
}