const ms = require('ms');
const Discord = require('discord.js');
const { StringSelectMenuBuilder, ActionRowBuilder, EmbedBuilder, ChannelSelectMenuBuilder } = require('discord.js');

module.exports = {
    name: 'modmail',
    description: 'Configurez le système de modmail pour votre serveur',
    run: async (client, message, args, commandName) => {
      
    let pass = false;

    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) || 
        client.db.get(`owner_global_${message.author.id}`) === true || 
        client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true) {
      pass = true;
    } else {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        pass = true;
      }
    }

    if (!pass) {
        if (client.noperm && client.noperm.trim() !== '') {
            const sentMessage = await message.channel.send(client.noperm);
            const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
            if (delayTime > 0) {
                setTimeout(() => {
                    sentMessage.delete().catch(() => {});
                }, delayTime * 1000);
            }
        }
        return;
    }
        const originalmsg = await message.channel.send({ content: '⏳ Chargement de la configuration modmail...' });

        async function updateEmbed() {
            const dbmod = client.db.get(`modmail_${message.guild.id}`) || client.db.set(`modmail_${message.guild.id}`, { categorie: null, status: false, modérateur: [] });
            const category = message.guild.channels.cache.get(dbmod.categorie) || null;
            const status = dbmod?.status === true ? '🟢 Activé' : '🔴 Désactivé';
            const modRoles = dbmod?.modérateur || [];
            const modRoleNames = modRoles.length > 0 ? modRoles.map(roleId => message.guild.roles.cache.get(roleId)?.name || "Rôle inconnu").join(', ') : 'Aucun rôle défini';

            const embed = new EmbedBuilder()
                .setTitle('⚙️ Configuration du Modmail')
                .setColor(client.color || '#0099ff')
                .setThumbnail(message.guild.iconURL({ dynamic: true }))
                .setDescription('Configurez les paramètres du modmail pour votre serveur.')
                .addFields(
                    { name: '📊 Statut', value: `\`\`\`${status}\`\`\``, inline: true },
                    { name: '📂 Catégorie', value: `\`\`\`${category ? `${category.name} (ID: ${category.id})` : 'Aucune catégorie sélectionnée'}\`\`\``, inline: true },
                    { name: '🛡️ Rôles Modérateurs', value: `\`\`\`${modRoleNames}\`\`\`` }
                )
                .setFooter({ text: client.footer.text || 'Modmail System', iconURL: client.footer.iconURL })
                .setTimestamp();

            const row = new ActionRowBuilder().addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId(`modmail_${message.id}`)
                    .setPlaceholder('Sélectionnez une option de configuration')
                    .addOptions([
                        {
                            label: 'Modifier le Statut',
                            description: 'Activer ou désactiver le modmail',
                            value: `status_${message.id}`,
                            emoji: '📊',
                        },
                        {
                            label: 'Définir la Catégorie',
                            description: 'Choisir la catégorie pour les tickets modmail',
                            value: `categorie_${message.id}`,
                            emoji: '📂',
                        },
                        {
                            label: 'Gérer les Rôles Modérateurs',
                            description: 'Ajouter ou supprimer des rôles modérateurs',
                            value: `mod_${message.id}`,
                            emoji: '🛡️',
                        },
                    ])
            );

            await originalmsg.edit({ content: null, embeds: [embed], components: [row] });
        }

        await updateEmbed();

        const collector = message.channel.createMessageComponentCollector({ 
            filter: m => m.user.id === message.author.id, 
            componentType: Discord.ComponentType.StringSelect, 
            time: ms('2m') 
        });

        collector.on('collect', async (i) => {
            if (i.values[0] === `status_${message.id}`) {
                let db = client.db.get(`modmail_${message.guild.id}`);
                const newStatus = !db?.status;
                client.db.set(`modmail_${message.guild.id}`, { ...db, status: newStatus });
                await i.reply({ content: newStatus ? '✅ Le modmail a été activé avec succès !' : '✅ Le modmail a été désactivé avec succès !', ephemeral: true });
                await updateEmbed();
            } else if (i.values[0] === `categorie_${message.id}`) {
                const rowcategori = new ChannelSelectMenuBuilder()
                    .setCustomId(`categorieselect_${message.id}`)
                    .setPlaceholder('Sélectionnez une catégorie')
                    .setChannelTypes(Discord.ChannelType.GuildCategory)
                    .setMinValues(1)
                    .setMaxValues(1);
                const row = new ActionRowBuilder().addComponents(rowcategori);
                await i.update({ content: '📂 Veuillez sélectionner la catégorie où les tickets modmail seront créés.', embeds: [], components: [row] });
            } else if (i.values[0] === `mod_${message.id}`) {
                const rowmod = new Discord.RoleSelectMenuBuilder()
                    .setCustomId(`rowmod_${message.id}`)
                    .setPlaceholder('Sélectionnez les rôles modérateurs')
                    .setMinValues(1)
                    .setMaxValues(25);
                const row = new ActionRowBuilder().addComponents(rowmod);
                await i.update({ content: '🎭 Veuillez sélectionner un ou plusieurs rôles modérateurs.', embeds: [], components: [row] });
            }
        });

        client.on('interactionCreate', async (i) => {
            if (i.user.id !== message.author.id) return;

            if (i.customId === `rowmod_${message.id}`) {
                const selectedRoles = i.values;
                const modmailData = client.db.get(`modmail_${message.guild.id}`) || { modérateur: [] };
                const existingRoles = modmailData.modérateur || [];

                for (const roleId of selectedRoles) {
                    const role = message.guild.roles.cache.get(roleId);
                    if (!role) continue;
                    if (role.managed) {
                        await i.reply({ content: `❌ Le rôle **${role.name}** est un rôle géré par un bot, veuillez sélectionner un rôle valide.`, ephemeral: true });
                        await updateEmbed();
                        return;
                    }
                    if (existingRoles.includes(roleId)) {
                        modmailData.modérateur = existingRoles.filter(id => id !== roleId);
                        client.db.set(`modmail_${message.guild.id}`, modmailData);
                        await i.reply({ content: `✅ Le rôle **${role.name}** a été retiré des rôles modérateurs.`, ephemeral: true });
                    } else {
                        existingRoles.push(roleId);
                        modmailData.modérateur = existingRoles;
                        client.db.set(`modmail_${message.guild.id}`, modmailData);
                        await i.reply({ content: `✅ Le rôle **${role.name}** a été ajouté aux rôles modérateurs.`, ephemeral: true });
                    }
                }
                await updateEmbed();
            } else if (i.customId === `categorieselect_${message.id}`) {
                const selectedCategory = i.values[0];
                const modmailData = client.db.get(`modmail_${message.guild.id}`) || {};
                modmailData.categorie = selectedCategory;
                client.db.set(`modmail_${message.guild.id}`, modmailData);
                await i.reply({ content: '✅ La catégorie a été configurée avec succès !', ephemeral: true });
                await updateEmbed();
            }
        });

collector.on('end', async () => {
    const disabledRow = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
            .setCustomId(`modmail_${message.id}`)
            .setPlaceholder('Sélection expirée')
            .setDisabled(true)
            .addOptions([
                {
                    label: 'Modifier le Statut',
                    description: 'Activer ou désactiver le modmail',
                    value: `status_${message.id}`,
                    emoji: '📊',
                },
                {
                    label: 'Définir la Catégorie',
                    description: 'Choisir la catégorie pour les tickets modmail',
                    value: `categorie_${message.id}`,
                    emoji: '📂',
                },
                {
                    label: 'Gérer les Rôles Modérateurs',
                    description: 'Ajouter ou supprimer des rôles modérateurs',
                    value: `mod_${message.id}`,
                    emoji: '🛡️',
                },
            ])
    );

    await originalmsg.edit({
        components: [disabledRow]
    });
});
        }
    }
