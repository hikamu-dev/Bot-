const { ActionRowBuilder, ButtonBuilder } = require('discord.js');

module.exports = {
    name: "claim",
    description: "Permet de claim un ticket ouvert.",
    usage: "claim",
    run: async (client, message, args, commandName) => {
      
    let pass = false;

    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) || 
        client.db.get(`owner_global_${message.author.id}`) === true || 
        client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true) {
      pass = true;
    } else {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        pass = true;
      }
    }

    if (!pass) {
        if (client.noperm && client.noperm.trim() !== '') {
            const sentMessage = await message.channel.send(client.noperm);
            const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
            if (delayTime > 0) {
                setTimeout(() => {
                    sentMessage.delete().catch(() => {});
                }, delayTime * 1000);
            }
        }
        return;
    }
        const tickeruser = await client.db.get(`ticket_user_${message.guild.id}`) || [];
        const ticketData = tickeruser.find(ticket => ticket.salon === message.channel.id);

        if (!ticketData) {
            return message.reply({ content: "Ce salon n'est pas un ticket valide ou n'a pas été trouvé.", ephemeral: true });
        }

        if (ticketData.author === message.author.id) {
            return message.reply({ content: "Vous ne pouvez pas claim votre propre ticket !", ephemeral: true });
        }

        if (ticketData.claim) {
            return message.reply({ content: "Ce ticket a déjà été claim par un autre membre du staff.", ephemeral: true });
        }

        const db = await client.db.get(`ticket_${message.guild.id}`);
        if (!db) {
            return message.reply({ content: "La configuration des tickets n'a pas été trouvée.", ephemeral: true });
        }

        const option = db.option.find(opt => opt.value === ticketData.option);
        if (!option) {
            return message.reply({ content: "L'option de ticket associée n'a pas été trouvée.", ephemeral: true });
        }

        if (option.acess && Array.isArray(option.acess)) {
            for (const roleId of option.acess) {
                const role = message.guild.roles.cache.get(roleId);
                if (role) {
                    await message.channel.permissionOverwrites.edit(role, {
                        SendMessages: false,
                        CreatePrivateThreads: false
                    });
                }
            }
        }

        await message.channel.permissionOverwrites.edit(message.guild.roles.everyone.id, { SendMessages: false });

        await message.channel.permissionOverwrites.edit(message.author.id, {
            SendMessages: true,
            ViewChannel: true,
            AttachFiles: true,
            AddReactions: true,
            ManageMessages: true
        });

        const messages = await message.channel.messages.fetch({ limit: 10 });
        const ticketMessage = messages.find(msg => msg.components.length > 0 && msg.components[0].components.some(comp => comp.customId.startsWith('claim_')));
        
        if (ticketMessage) {
            const row = ticketMessage.components[0];
            const newRow = new ActionRowBuilder();

            for (const component of row.components) {
                if (component.customId.startsWith('claim_')) {
                    newRow.addComponents(
                        ButtonBuilder.from(component).setDisabled(true)
                    );
                } else {
                    newRow.addComponents(component);
                }
            }

            await ticketMessage.edit({ components: [newRow] });
        }

        await message.channel.send({ content: `🔐 Ce ticket a été claim par ${message.author}.` });

        // Changer le nom du ticket
        const ticketOwner = await client.users.fetch(ticketData.author);
        const newChannelName = `🔐・${ticketOwner.username}`;
        
        try {
            await message.channel.setName(newChannelName);
        } catch (error) {
            console.error('Erreur lors du changement de nom du ticket:', error);
        }

        ticketData.claim = message.author.id;
        await client.db.set(`ticket_user_${message.guild.id}`, tickeruser);

        //await message.reply({ content: "Vous avez claim ce ticket avec succès.", ephemeral: true });
    }
};