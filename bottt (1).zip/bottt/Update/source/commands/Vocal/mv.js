const Discord = require('discord.js');

module.exports = {
    name: "mv",
    description: "Déplace un utilisateur spécifié vers un salon vocal donné par son ID.",
    use: "<@utilisateur/id> <id>",
    usage: "mv <@utilisateur/id> <id>",
    example: "➜ mv @tokyru 123456789012345678\n➜ mv 123456789012345678 987654321098765432",
    run: async (client, message, args, commandName) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
                client.db.get(`owner_global_${message.author.id}`) === true || 

client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        // Vérifier si un utilisateur est mentionné
        const targetUser = message.mentions.members.first();
        if (!targetUser) {
            return message.channel.send("Veuillez mentionner un utilisateur à déplacer (ex: @utilisateur).");
        }

        // Vérifier si l'utilisateur est dans un salon vocal
        if (!targetUser.voice.channel) {
            return message.channel.send("L'utilisateur n'est pas dans un salon vocal.");
        }

        // Vérifier si un ID de salon vocal est fourni
        const voiceChannelId = args[1];
        if (!voiceChannelId) {
            return message.channel.send("Veuillez fournir l'ID du salon vocal de destination.");
        }

        // Trouver le salon vocal par son ID
        const targetVoiceChannel = message.guild.channels.cache.get(voiceChannelId);
        if (!targetVoiceChannel || targetVoiceChannel.type !== Discord.ChannelType.GuildVoice) {
            return message.channel.send("L'ID fourni ne correspond pas à un salon vocal valide.");
        }

        // Vérifier si le bot a les permissions nécessaires
        if (!message.guild.members.me.permissions.has(Discord.PermissionsBitField.Flags.MoveMembers)) {
            return message.channel.send("Je n'ai pas la permission de déplacer les membres.");
        }

        try {
            // Déplacer l'utilisateur vers le salon vocal spécifié
            await targetUser.voice.setChannel(targetVoiceChannel);
            return message.channel.send(`**${targetUser.user.tag}** a été déplacé vers <#${targetVoiceChannel.id}>.`);
        } catch (error) {
            console.error(`Erreur lors du déplacement de ${targetUser.user.tag}:`, error);
            return message.channel.send("Une erreur s'est produite lors du déplacement de l'utilisateur.");
        }
    }
};