const Discord = require('discord.js');
const { example } = require('./antijoinvoc');

module.exports = {
    name: "unvoicedeaf",
    description: "Unmute casque un membre en vocal",
    use: "<@user/ID> [raison]",
    usage: 'unvoicedeaf <@user/ID> [raison]',
    example: "➜ unvoicedeaf @tokyru\n➜ unvoicedeaf 123456789012345678 Pas de raison",
    run: async (client, message, args, commandName) => {
        let pass = false;

        // Autoriser automatiquement les staff, buyers, et owners
        if (client.staff.includes(message.author.id) || 
            client.config.buyers.includes(message.author.id) ||
                    client.db.get(`owner_global_${message.author.id}`) === true || 

    client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {               pass = true;
        } else {
            // Vérifier les permissions personnalisées pour la commande
            const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
            if (commandPerms.length > 0) {
                const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                const userRoles = message.member.roles.cache.map(role => role.id);
                // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
                pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
            } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                // Conserver la compatibilité avec le mode "public"
                pass = true;
            }
        }

        // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        // Vérifier si le bot a les permissions nécessaires
        if (!message.guild.members.me.permissions.has(Discord.PermissionsBitField.Flags.DeafenMembers)) {
            return message.channel.send("Je n'ai pas la permission de gérer le casque des membres.");
        }

        // Vérifier les arguments
        if (args.length < 1) {
            return message.channel.send("Utilisation : `unvoicedeaf <@user/ID> [raison]`");
        }

        // Récupérer l'utilisateur
        let userId = args[0].replace(/[<@!>]/g, '');
        let member = message.guild.members.cache.get(userId);
        
        if (!member) {
            return message.channel.send("Utilisateur introuvable.");
        }

        // Vérifier si l'utilisateur est dans un salon vocal
        if (!member.voice.channel) {
            return message.channel.send(`${member.displayName} n'est pas dans un salon vocal.`);
        }

        // Récupérer les informations vocales actuelles
        const voiceState = member.voice;
        
        // Vérifier si l'utilisateur est vraiment deaf (sourdine casque)
        if (!voiceState.deaf && !voiceState.serverDeaf) {
            return message.channel.send(`${member.displayName} n'est pas en sourdine casque.`);
        }
        
        // Vérifier si l'utilisateur s'est mis en sourdine lui-même
        if (voiceState.deaf && !voiceState.serverDeaf) {
            return message.channel.send(`${member.displayName} s'est mis en sourdine casque lui-même. Je ne peux pas le forcer à enlever sa sourdine.`);
        }

        // Récupérer la raison (optionnelle)
        const reason = args.slice(1).join(' ') || 'Aucune raison spécifiée';

        // Vérifier la hiérarchie des rôles
        if (member.roles.highest.position >= message.member.roles.highest.position && message.author.id !== message.guild.ownerId) {
            return message.channel.send("Vous ne pouvez pas unmute ce membre (hiérarchie des rôles).");
        }

        // Vérifier si le membre est un staff/buyer/owner
        const isTargetStaff = client.staff.includes(member.user.id) || 
                             client.config.buyers.includes(member.user.id) || 
                             client.db.get(`owner_${member.user.id}`) === true;

        if (isTargetStaff && !client.staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
            return message.channel.send("Vous ne pouvez pas unmute un staff/buyer/owner.");
        }

        // Effectuer l'unvoice deaf
        try {
            // Vérifier une dernière fois avant d'agir
            const currentVoiceState = member.voice;
            if (!currentVoiceState.deaf && !currentVoiceState.serverDeaf) {
                return message.channel.send(`${member.displayName} n'est déjà plus en sourdine casque.`);
            }
            
            // Vérifier encore si c'est une sourdine auto-appliquée
            if (currentVoiceState.deaf && !currentVoiceState.serverDeaf) {
                return message.channel.send(`${member.displayName} s'est mis en sourdine casque lui-même. Je ne peux pas le forcer à enlever sa sourdine.`);
            }

            await member.voice.setDeaf(false, reason);
            
            // Message de confirmation
            message.channel.send(`<@${member.id}> a été unmute casque raison : **\`${reason}\`**`);
            
            // Envoyer dans les logs de modération
            const modlogsChannel = message.guild.channels.cache.get(client.db.get(`modlogs_${message.guild.id}`));
            if (modlogsChannel) {
                let embed = new Discord.EmbedBuilder()
                    .setColor(client.color)
                    .setDescription(`${message.author} a unmute casque <@${member.user.id}> pour \`${reason}\``);
                
                modlogsChannel.send({ embeds: [embed] });
            }
            
        } catch (error) {
            console.error(`Erreur lors de l'unvoice deaf de ${member.user.tag}:`, error);
            
            // Messages d'erreur plus spécifiques
            if (error.code === 50013) {
                return message.channel.send("❌ Je n'ai pas les permissions nécessaires pour effectuer cette action.");
            } else if (error.code === 50001) {
                return message.channel.send("❌ Accès manquant pour effectuer cette action.");
            } else {
                return message.channel.send("❌ Une erreur s'est produite lors de l'unmute casque.");
            }
        }
    }
};