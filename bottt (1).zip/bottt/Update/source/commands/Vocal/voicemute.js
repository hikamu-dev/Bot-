const Discord = require('discord.js');
const { example } = require('./antijoinvoc');

module.exports = {
    name: "voicemute",
    description: "Mute un membre en vocal (microphone)",
    use: "<@user/ID> [raison]",
    usage: 'voicemute <@user/ID> [raison]',
    example: "➜ voicemute @tokyru\n➜ voicemute 123456789012345678 Pas de raison",
    run: async (client, message, args, commandName) => {
        let pass = false;

        if (client.staff.includes(message.author.id) || 
            client.config.buyers.includes(message.author.id) ||
                    client.db.get(`owner_global_${message.author.id}`) === true || 

    client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {               pass = true;
        } else {
            const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
            if (commandPerms.length > 0) {
                const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                const userRoles = message.member.roles.cache.map(role => role.id);
                pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
            } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                pass = true;
            }
        }

if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        if (!message.guild.members.me.permissions.has(Discord.PermissionsBitField.Flags.MuteMembers)) {
            return message.channel.send("Je n'ai pas la permission de gérer le micro des membres.");
        }

        if (args.length < 1) {
            return message.channel.send("Utilisation : `voicemute <@user/ID> [raison]`");
        }

        let userId = args[0].replace(/[<@!>]/g, '');
        let member = message.guild.members.cache.get(userId);
        
        if (!member) return message.channel.send("Utilisateur introuvable.");
        if (!member.voice.channel) return message.channel.send(`${member.displayName} n'est pas dans un salon vocal.`);
        if (member.voice.mute) return message.channel.send(`${member.displayName} est déjà mute micro.`);

        const reason = args.slice(1).join(' ') || 'Aucune raison spécifiée';

        if (member.roles.highest.position >= message.member.roles.highest.position && message.author.id !== message.guild.ownerId) {
            return message.channel.send("Vous ne pouvez pas mute ce membre (hiérarchie des rôles).");
        }

        const isTargetStaff = client.staff.includes(member.user.id) || 
                              client.config.buyers.includes(member.user.id) || 
                              client.db.get(`owner_${member.user.id}`) === true;

        if (isTargetStaff && !client.staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
            return message.channel.send("Vous ne pouvez pas mute un staff/buyer/owner.");
        }

        try {
            await member.voice.setMute(true, reason);
            message.channel.send(`<@${member.id}> a été mute micro pour : **\`${reason}\`**`);

            const modlogsChannel = message.guild.channels.cache.get(client.db.get(`modlogs_${message.guild.id}`));
            if (modlogsChannel) {
                let embed = new Discord.EmbedBuilder()
                    .setColor(client.color)
                    .setDescription(`${message.author} a mute micro <@${member.user.id}> pour \`${reason}\``);
                modlogsChannel.send({ embeds: [embed] });
            }

            try {
            } catch (dmError) {}
        } catch (error) {
            console.error(`Erreur lors du voicemute de ${member.user.tag}:`, error);
            return message.channel.send("❌ Une erreur s'est produite lors du mute micro.");
        }
    }
};
