const Discord = require('discord.js');
const { example } = require('./antijoinvoc');

module.exports = {
    name: "antimoove",
    description: "Permet de configurer les salons antimoov",
    use: "<add/remove> [salon]",
    usage: 'antimoove <add/remove> [salon]',
    example: "➜ antimoove add #general\n➜ antimoove remove #general",
    run: async (client, message, args, commandName) => {
        let pass = false;

        // Autoriser automatiquement les staff, buyers, et owners
        if (client.staff.includes(message.author.id) || 
            client.config.buyers.includes(message.author.id) ||
                    client.db.get(`owner_global_${message.author.id}`) === true || 
 
    client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {               pass = true;
        } else {
            // Vérifier les permissions personnalisées pour la commande
            const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
            if (commandPerms.length > 0) {
                const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                const userRoles = message.member.roles.cache.map(role => role.id);
                // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
                pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
            } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                // Conserver la compatibilité avec le mode "public"
                pass = true;
            }
        }

        // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        // Récupérer les salons antimoov actuels
        const antiMooveChannels = client.db.get(`antimoove_${message.guild.id}`) || [];
        
        // Vérifier les arguments
        const action = args[0]?.toLowerCase();
        
        if (!action || !['add', 'remove'].includes(action)) {
            let helpMessage = "**Utilisation :** `antimoove <add/remove> [salon]`\n\n";
            
            return message.channel.send(helpMessage);
        }

        // Déterminer le salon cible
        let targetChannel;
        
        if (args[1]) {
            // Salon spécifié en argument
            const channelId = args[1].replace(/[<#>]/g, '');
            targetChannel = message.guild.channels.cache.get(channelId);
            
            if (!targetChannel) {
                return message.channel.send("Salon vocal introuvable.");
            }
        } else {
            // Utiliser le salon vocal actuel de l'utilisateur
            if (!message.member.voice.channel) {
                return message.channel.send("Vous devez être dans un salon vocal ou mentionner un salon vocal.");
            }
            targetChannel = message.member.voice.channel;
        }

        // Vérifier que c'est un salon vocal
        if (targetChannel.type !== Discord.ChannelType.GuildVoice) {
            return message.channel.send("Le salon spécifié n'est pas un salon vocal.");
        }

        // Action ADD
        if (action === 'add') {
            if (antiMooveChannels.includes(targetChannel.id)) {
                return message.channel.send(`Le salon <#${targetChannel.id}> est déjà protégé contre les déplacements.`);
            }
            
            antiMooveChannels.push(targetChannel.id);
            client.db.set(`antimoove_${message.guild.id}`, antiMooveChannels);
            return message.channel.send(`Le salon <#${targetChannel.id}> a été ajouté à la protection antimoove.`);
        }

        // Action REMOVE
        if (action === 'remove') {
            if (!antiMooveChannels.includes(targetChannel.id)) {
                return message.channel.send(`Le salon <#${targetChannel.id}> n'est pas protégé contre les déplacements.`);
            }
            
            const updatedChannels = antiMooveChannels.filter(id => id !== targetChannel.id);
            
            if (updatedChannels.length === 0) {
                client.db.delete(`antimoove_${message.guild.id}`);
            } else {
                client.db.set(`antimoove_${message.guild.id}`, updatedChannels);
            }
            
            return message.channel.send(`Le salon <#${targetChannel.id}> a été retiré de la protection antimoov.`);
        }
    }
};