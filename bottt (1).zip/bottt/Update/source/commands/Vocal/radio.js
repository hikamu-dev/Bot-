const { joinVoiceChannel, createAudioPlayer, createAudioResource, AudioPlayerStatus, demuxProbe } = require('@discordjs/voice');
const { ActionRowBuilder, StringSelectMenuBuilder, EmbedBuilder, ComponentType, ChannelType } = require('discord.js');
const { request } = require('undici');

module.exports = {
  name: "radio",
  use: "radio [#voc/id]",
  usage: "radio [#voc/id]",
  description: "Rejoindre un salon vocal et choisir une radio",
  run: async (client, message, args) => {
    const commandName = "radio";

    // --- Permissions style "infoperms" ---
    let pass = false;
    if (
      client.staff?.includes(message.author.id) ||
      client.config?.buyers?.includes(message.author.id) ||
      client.db.get(`owner_global_${message.author.id}`) === true ||
      client.db.get(`owner_${message.author.id}`) === true
    ) {
      pass = true;
    } else {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(r => r.id);
        pass = commandPerms.some(perm => userPerms[perm]?.some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        pass = true;
      }
    }
    if (!pass) {
      if (client.noperm && client.noperm.trim() !== "") {
        const sentMessage = await message.channel.send(client.noperm);
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) setTimeout(() => sentMessage.delete().catch(() => {}), delayTime * 1000);
      }
      return;
    }

    // --- Radios ---
const radios = {
  "Skyrock": "http://icecast.skyrock.net/s/natio_mp3_128k",
  "Skyrock Urban": "http://icecast.skyrock.net/s/urban_mp3_128k", 
  "FunRadio": "https://streaming.radio.funradio.fr/fun-1-44-128",
  "RTL": "https://streaming.radio.rtl.fr/rtl-1-44-128",
  "Nova": "https://novazz.ice.infomaniak.ch/novazz-128.mp3",
  "FIP": "https://icecast.radiofrance.fr/fip-midfi.mp3",
  "Europe1": "http://stream.europe1.fr/europe1.mp3",
"Mouv'": "https://icecast.radiofrance.fr/mouv-midfi.mp3",                // urbain FR (rap/R&B)
"Mouv' Rap FR": "https://icecast.radiofrance.fr/mouvrapfr-midfi.mp3",    // 100% rap français
"FIP Hip-Hop": "https://icecast.radiofrance.fr/fiphiphop-midfi.mp3",    // 100% rap (FR/US)
"Urban Hit": "http://streaming.radionomy.com/UrbanHit",                           // rap/RnB FR
    // hip-hop sélection FIP
};

    // --- Récup du salon vocal ---
    let channel = message.member.voice?.channel || null;
    if (args[0]) {
      const fetched = message.guild.channels.cache.get(args[0].replace(/[<#>]/g, ""));
      if (fetched && fetched.type === ChannelType.GuildVoice) channel = fetched;
      else return message.reply("Salon vocal invalide.");
    }
    if (!channel) return message.reply("Tu dois être dans un salon vocal ou en spécifier un.");

    // --- Connexion vocale + player ---
    const connection = joinVoiceChannel({
      channelId: channel.id,
      guildId: channel.guild.id,
      adapterCreator: channel.guild.voiceAdapterCreator,
      selfDeaf: true
    });

    const player = createAudioPlayer();
    connection.subscribe(player);

    player.on('error', (e) => {
      console.error('AudioPlayer error:', e);
      message.channel.send("❌ Erreur de lecture du flux audio.");
    });

    // --- Menu de sélection ---
    const menu = new StringSelectMenuBuilder()
      .setCustomId("radio_select")
      .setPlaceholder("Choisis une radio à écouter")
      .addOptions(Object.keys(radios).map(name => ({ label: name, value: name })));

    const row = new ActionRowBuilder().addComponents(menu);

    const baseFooter = typeof client.footer === 'string' ? { text: client.footer } : client.footer;
    const embed = new EmbedBuilder()
      .setTitle("📻 Aucune radio en cours")
      .setDescription("Sélectionne une radio dans le menu ci-dessous pour commencer.")
      .setColor(client.color || 0x2b2d31)
      .setFooter(baseFooter || null);

    const sent = await message.channel.send({ embeds: [embed], components: [row] });

    const collector = sent.createMessageComponentCollector({
      componentType: ComponentType.StringSelect,
      // pas de 'time: 0' → sinon ça stop direct
      filter: (i) => i.customId === 'radio_select'
    });

    // Détruire la connexion quand plus rien ne joue (au cas où un flux se coupe)
    player.on(AudioPlayerStatus.Idle, () => {
      try { connection.destroy(); } catch {}
    });

    collector.on("collect", async (interaction) => {
      if (interaction.user.id !== message.author.id) {
        return interaction.reply({ content: "Ce menu n'est pas pour toi.", ephemeral: true });
      }

      const selected = interaction.values[0];
      const streamURL = radios[selected];

      try {
        // Récupère le flux HTTP
        const { body } = await request(streamURL, { throwOnError: true, maxRedirections: 3 });
        // Détecte le conteneur/codec et crée la resource
        const { stream, type } = await demuxProbe(body);
        const resource = createAudioResource(stream, { inputType: type });
        player.play(resource);
      } catch (err) {
        console.error('Stream error:', err);
        return interaction.reply({ content: "Impossible de lire cette radio (flux indisponible ou FFmpeg manquant).", ephemeral: true });
      }

      const updated = new EmbedBuilder()
        .setTitle("📻 Radio en cours")
        .setDescription(`Tu écoutes maintenant **${selected}**`)
        .addFields({ name: "Salon", value: `<#${channel.id}>` })
        .setColor(client.color || 0x2b2d31)
        .setFooter(baseFooter || null)
        .setTimestamp();

      await interaction.update({ embeds: [updated], components: [row] });
    });
  }
};
