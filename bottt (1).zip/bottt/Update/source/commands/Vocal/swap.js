const Discord = require('discord.js');
const { use, example } = require('./antijoinvoc');

module.exports = {
    name: "swap",
    description: "Inverse les positions de deux membres dans des salons vocaux",
    use: "<@user/ID> [@user/ID]",
    usage: 'swap <@user/ID> [@user/ID]',
    example: "➜ swap @tokyru @autreuser\n➜ swap 123456789012345678 987654321098765432",
    run: async (client, message, args, commandName) => {
        let pass = false;

        // Autoriser automatiquement les staff, buyers, et owners
        if (client.staff.includes(message.author.id) || 
            client.config.buyers.includes(message.author.id) ||
                    client.db.get(`owner_global_${message.author.id}`) === true || 

    client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {               pass = true;
        } else {
            // Vérifier les permissions personnalisées pour la commande
            const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
            if (commandPerms.length > 0) {
                const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                const userRoles = message.member.roles.cache.map(role => role.id);
                // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
                pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
            } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                // Conserver la compatibilité avec le mode "public"
                pass = true;
            }
        }

        // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        // Vérifier si le bot a les permissions nécessaires
        if (!message.guild.members.me.permissions.has(Discord.PermissionsBitField.Flags.MoveMembers)) {
            return message.channel.send("Je n'ai pas la permission de déplacer les membres.");
        }

        // Vérifier les arguments
        if (args.length < 1) {
            return message.channel.send("Utilisation : `swap <@user/ID> [@user/ID]`");
        }

        // Récupérer le premier utilisateur
        let user1Id = args[0].replace(/[<@!>]/g, '');
        let member1 = message.guild.members.cache.get(user1Id);
        
        if (!member1) {
            return message.channel.send("Premier utilisateur introuvable.");
        }

        // Récupérer le deuxième utilisateur (ou utiliser l'auteur du message)
        let member2;
        if (args[1]) {
            let user2Id = args[1].replace(/[<@!>]/g, '');
            member2 = message.guild.members.cache.get(user2Id);
            
            if (!member2) {
                return message.channel.send("Deuxième utilisateur introuvable.");
            }
        } else {
            member2 = message.member;
        }

        // Vérifier si les deux utilisateurs sont différents
        if (member1.id === member2.id) {
            return message.channel.send("Vous ne pouvez pas échanger un utilisateur avec lui-même.");
        }

        // Vérifier si les deux utilisateurs sont dans des salons vocaux
        const voice1 = member1.voice.channel;
        const voice2 = member2.voice.channel;

        if (!voice1) {
            return message.channel.send(`<@${member1.id}> n'est pas dans un salon vocal.`);
        }

        if (!voice2) {
            return message.channel.send(`<@${member2.id}> n'est pas dans un salon vocal.`);
        }

        // Vérifier si les utilisateurs sont dans le même salon
        if (voice1.id === voice2.id) {
            return message.channel.send("Les deux utilisateurs sont dans le même salon vocal.");
        }

        // Vérifier les protections antimoove
        const antiMooveChannels = client.db.get(`antimoove_${message.guild.id}`) || [];
        
        // Vérifier si les utilisateurs peuvent être déplacés (permissions)
        const canMove1 = client.staff.includes(member1.user.id) || 
                        client.config.buyers.includes(member1.user.id) || 
                        client.db.get(`owner_${member1.user.id}`) === true;
        
        const canMove2 = client.staff.includes(member2.user.id) || 
                        client.config.buyers.includes(member2.user.id) || 
                        client.db.get(`owner_${member2.user.id}`) === true;

        // Vérifier les protections antimoove
        if (antiMooveChannels.includes(voice1.id) && !canMove1) {
            return message.channel.send(`<@${member1.id}> est dans un salon protégé contre les déplacements.`);
        }

        if (antiMooveChannels.includes(voice2.id) && !canMove2) {
            return message.channel.send(`<@${member2.id}> est dans un salon protégé contre les déplacements.`);
        }

        // Vérifier les protections antijoinvoc pour les salons de destination
        const antiJoinVocChannels = client.db.get(`antijoinvoc_${message.guild.id}`) || [];
        
        if (antiJoinVocChannels.includes(voice1.id) && !canMove2) {
            return message.channel.send(`${member2.displayName} ne peut pas entrer dans le salon <#${voice1.id}> (protégé).`);
        }

        if (antiJoinVocChannels.includes(voice2.id) && !canMove1) {
            return message.channel.send(`${member1.displayName} ne peut pas entrer dans le salon <#${voice2.id}> (protégé).`);
        }

        // Effectuer l'échange
        try {
            // Méthode alternative : déplacer simultanément vers les nouveaux salons
            const promises = [
                member1.voice.setChannel(voice2),
                member2.voice.setChannel(voice1)
            ];
            
            await Promise.all(promises);

            return message.channel.send(`**<@${member1.id}>** et **<@${member2.id}>** ont été échangés de salon vocal.`);
        } catch (error) {
            console.error(`Erreur lors de l'échange de ${member1.user.tag} et ${member2.user.tag}:`, error);
            return message.channel.send("❌ Une erreur s'est produite lors de l'échange des utilisateurs.");
        }
    }
};