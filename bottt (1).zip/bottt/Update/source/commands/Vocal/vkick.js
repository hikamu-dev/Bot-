const Discord = require('discord.js');

module.exports = {
    name: "voicekick",
    description: "Kick un membre d'un salon vocal.",
    use: "<@user/iduser>",
    usage: "vkick <@user/iduser>",
    example: '➜ vkick <@user/iduser>', // Changé de 'exemple' à 'example'
    run: async (client, message, args, commandName) => {
        let pass = false;

        if (client.staff.includes(message.author.id) || 
            client.config.buyers.includes(message.author.id) ||
                    client.db.get(`owner_global_${message.author.id}`) === true || 

    client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {               pass = true;
        } else {
            const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
            if (commandPerms.length > 0) {
                const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                const userRoles = message.member.roles.cache.map(role => role.id);
                pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
            } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                pass = true;
            }
        }

if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        if (!args[0]) {
            return message.channel.send("Veuillez mentionner un membre ou fournir son ID. Exemple : `voicekick <@user/iduser>`");
        }

        let member = message.mentions.members.first();
        if (!member) {
            const userId = args[0].replace(/[<@!>]/g, '');
            try {
                member = await message.guild.members.fetch(userId);
            } catch {
                return message.channel.send("Aucun membre trouvé avec cet ID.");
            }
        }

        if (!member.voice.channel) {
            return message.channel.send(`<@${member.user.id}> n'est pas dans un salon vocal.`);
        }

        if (!message.guild.members.me.permissions.has(Discord.PermissionsBitField.Flags.MoveMembers)) {
            return message.channel.send("Je n'ai pas la permission de déconnecter des membres.");
        }

        if (member.id === message.author.id) {
            return message.channel.send("Vous ne pouvez pas vous kick vous-même.");
        }

        try {
            const voiceChannel = member.voice.channel;
            await member.voice.setChannel(null);

            message.channel.send(`<@${member.user.id}> a été kick du salon vocal <#${voiceChannel.id}>.`);

            // 🔔 Envoi du log modération
            const modlogsChannel = message.guild.channels.cache.get(client.db.get(`modlogs_${message.guild.id}`));
            if (modlogsChannel) {
                let embed = new Discord.EmbedBuilder()
                    .setColor(client.color)
                    .setDescription(`${message.author} a **kick** <@${member.user.id}> du salon vocal <#${voiceChannel.id}> pour \`${reason}\``)
                modlogsChannel.send({ embeds: [embed] });
            }

        } catch (error) {
            console.error(`Erreur lors du kick vocal de ${member.user.tag}:`, error);
            return message.channel.send("Une erreur s'est produite lors du kick du membre.");
        }
    }
};
