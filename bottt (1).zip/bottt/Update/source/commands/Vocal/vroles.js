const Discord = require('discord.js');
const { example } = require('./antijoinvoc');

module.exports = {
    name: "vrole",
    description: "Gère les rôles attribués automatiquement aux membres qui rejoignent un salon vocal.",
    use: "<add/list/remove> [role(s)]",
    usage: "vrole <add/list/remove> [role(s)]",
    example: "➜ vrole add @Admin\n➜ vrole list\n➜ vrole remove @Admin",
    run: async (client, message, args, commandName) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
                client.db.get(`owner_global_${message.author.id}`) === true || 

client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        // Vérifier si un argument est fourni
        if (!args[0]) {
            return message.channel.send("❌ Veuillez spécifier une action : `add`, `list`, ou `remove`. Exemple : `vrole add @role`");
        }

        const subCommand = args[0].toLowerCase();

        // Sous-commande : add
        if (subCommand === 'add') {
            if (!args[1]) {
                return message.channel.send("❌ Veuillez mentionner ou fournir l'ID d'au moins un rôle à ajouter. Exemple : `vrole add @role`");
            }

            // Récupérer les rôles mentionnés ou fournis par ID
            const roles = [];
            for (let i = 1; i < args.length; i++) {
                const roleId = args[i].replace(/[<@&>]/g, '');
                const role = message.guild.roles.cache.get(roleId);
                if (role) {
                    roles.push(role.id);
                } else {
                    return message.channel.send(`❌ Le rôle avec l'ID ${roleId} n'existe pas.`);
                }
            }

            // Vérifier si le bot peut attribuer ces rôles
            const botMember = message.guild.members.me;
            for (const roleId of roles) {
                const role = message.guild.roles.cache.get(roleId);
                if (role.position >= botMember.roles.highest.position) {
                    return message.channel.send(`❌ Je ne peux pas attribuer le rôle ${role.name} car il est supérieur ou égal à mon rôle le plus élevé.`);
                }
            }

            // Ajouter les rôles à la configuration
            let currentRoles = client.db.get(`vrole_${message.guild.id}`) || [];
            currentRoles = [...new Set([...currentRoles, ...roles])]; // Éviter les doublons
            client.db.set(`vrole_${message.guild.id}`, currentRoles);

            return message.channel.send(`✅ ${roles.length} rôle(s) ajouté(s) à la liste des rôles attribués lors de la connexion à un salon vocal.`);
        }

        // Sous-commande : list
        if (subCommand === 'list') {
            const roles = client.db.get(`vrole_${message.guild.id}`) || [];
            if (roles.length === 0) {
                return message.channel.send("ℹ️ Aucun rôle n'est configuré pour être attribué lors de la connexion à un salon vocal.");
            }

            const roleNames = roles.map(roleId => {
                const role = message.guild.roles.cache.get(roleId);
                return role ? role.name : `(Rôle supprimé : ${roleId})`;
            });

            return message.channel.send(`📜 Rôles attribués lors de la connexion à un salon vocal :\n- ${roleNames.join('\n- ')}`);
        }

        // Sous-commande : remove
        if (subCommand === 'remove') {
            if (!args[1]) {
                return message.channel.send("❌ Veuillez mentionner ou fournir l'ID d'au moins un rôle à supprimer. Exemple : `vrole remove @role`");
            }

            // Récupérer les rôles à supprimer
            const rolesToRemove = [];
            for (let i = 1; i < args.length; i++) {
                const roleId = args[i].replace(/[<@&>]/g, '');
                const role = message.guild.roles.cache.get(roleId);
                if (role) {
                    rolesToRemove.push(role.id);
                } else {
                    return message.channel.send(`❌ Le rôle avec l'ID ${roleId} n'existe pas.`);
                }
            }

            // Supprimer les rôles de la configuration
            let currentRoles = client.db.get(`vrole_${message.guild.id}`) || [];
            const updatedRoles = currentRoles.filter(roleId => !rolesToRemove.includes(roleId));
            client.db.set(`vrole_${message.guild.id}`, updatedRoles);

            return message.channel.send(`✅ ${rolesToRemove.length} rôle(s) supprimé(s) de la liste des rôles attribués lors de la connexion à un salon vocal.`);
        }

        // Si la sous-commande n'est pas reconnue
        return message.channel.send("❌ Action non reconnue. Utilisez `add`, `list`, ou `remove`. Exemple : `vrole add @role`");
    }
};