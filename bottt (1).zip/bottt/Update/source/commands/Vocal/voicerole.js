const Discord = require('discord.js');
const { example } = require('./antijoinvoc');

module.exports = {
    name: "voiceroles",
    description: "Ajouter, retirer ou réinitialiser des rôles attribués lors de la connexion à un salon vocal.",
    use: "<add/remove/clear> <@role/ID>",
    usage: "voiceroles <add/remove/clear> <@role/ID>",
    example: "➜ voiceroles add @Admin\n➜ voiceroles remove @Admin\n➜ voiceroles clear",
    run: async (client, message, args, commandName) => {
        let pass = false;

        if (client.staff.includes(message.author.id) ||
            client.config.buyers.includes(message.author.id) ||
                    client.db.get(`owner_global_${message.author.id}`) === true || 

    client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {               pass = true;
        } else {
            const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
            if (commandPerms.length > 0) {
                const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                const userRoles = message.member.roles.cache.map(role => role.id);
                pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
            } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                pass = true;
            }
        }

if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        const action = args[0];
        const roleArg = args[1];
        const key = `voiceroles_${message.guild.id}`;
        let currentRoles = client.db.get(key) || [];

        if (!["add", "remove", "clear"].includes(action)) {
            return message.channel.send("Utilisation incorrecte `voiceroles add @role`, `voiceroles remove @role`, `voiceroles clear`");
        }

        if (action === "clear") {
            client.db.delete(key);
            return message.channel.send("Les rôles vocaux ont été réinitialisés.");
        }

        if (!roleArg) {
            return message.channel.send("Veuillez mentionner un rôle ou fournir son ID.");
        }

        let role = message.mentions.roles.first() || message.guild.roles.cache.get(roleArg);
        if (!role) {
            return message.channel.send("Rôle invalide.");
        }

        if (action === "add") {
            if (currentRoles.includes(role.id)) {
                return message.channel.send("Ce rôle est déjà attribué lors de la connexion vocale.");
            }
            currentRoles.push(role.id);
            client.db.set(key, currentRoles);
            return message.channel.send(`Le rôle ${role.name} sera désormais attribué lors de la connexion à un salon vocal.`);
        }

        if (action === "remove") {
            if (!currentRoles.includes(role.id)) {
                return message.channel.send("Ce rôle n'est pas dans la liste.");
            }
            currentRoles = currentRoles.filter(r => r !== role.id);
            client.db.set(key, currentRoles);
            return message.channel.send(`Le rôle ${role.name} ne sera plus attribué lors de la connexion vocale.`);
        }
    }
};
