// commands/punish.js
const Discord = require('discord.js');

module.exports = {
  name: "punition",
  aliases: ["punish"],
  description: "Gérer les punitions des modules antiraid (par module, pas de 'antirole' global).",
  use: "<all> <ban/kick/derank/mute>, punition [module] <ban/kick/derank/mute>",
  usage: ["punition all <ban/kick/derank/mute>", "punition [module] <ban/kick/derank/mute>"],
  example: "➜ punition all ban\n➜ punition antichannelcreate kick\n➜ punition antiroleupdate derank",

  run: async (client, message, args, commandName) => {

    // === Permissions (même logique que chez toi) ===
    let pass = false;
    if (
      (client.staff && client.staff.includes(message.author.id)) ||
      (client.config?.buyers && client.config.buyers.includes(message.author.id)) ||
      client.db.get(`owner_global_${message.author.id}`) === true ||
      client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true ||
      message.author.id === message.guild.ownerId
    ) {
      pass = true;
    } else {
      const commandPermissions = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPermissions.length > 0) {
        const userPermissions = client.db.get(`permissions.${message.guild.id}`) || {};
        const hasPermission = commandPermissions.some(permission => {
          return userPermissions[permission] && userPermissions[permission].some(role => message.member.roles.cache.has(role));
        });
        pass = hasPermission;
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        pass = true;
      }
    }

    if (!pass) {
      if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) setTimeout(() => sentMessage.delete().catch(()=>{}), delayTime * 1000);
      }
      return;
    }

    // === Chargement / defaults ===
    let db = await client.db.get(`punish_${message.guild.id}`);
    const defaults = {
      antibot: 'derank',
      antilink: 'derank',
      antispam: 'derank',
      antialt: 'kick',

      // AntiChannel (3 modules séparés)
      antichannelcreate: 'derank',
      antichanneldelete: 'derank',
      antichannelupdate: 'derank',

      // AntiRole (3 modules séparés)
      antirolecreate: 'derank',
      antiroledelete: 'derank',
      antiroleupdate: 'derank',

      antiban: 'ban',
      antikick: 'ban',
      antiwebhook: 'derank',
      antiserveredit: 'ban'
    };

    if (!db) {
      db = { ...defaults };
      await client.db.set(`punish_${message.guild.id}`, db);
    } else {
      // Supprime l'ancien champ global 'antirole' s'il existe (on ne veut plus de global)
      if (db.antirole !== undefined) {
        delete db.antirole;
      }
      // Garantir toutes les clés nécessaires sans toucher aux valeurs existantes
      for (const [k, v] of Object.entries(defaults)) {
        if (db[k] === undefined) db[k] = v;
      }
      await client.db.set(`punish_${message.guild.id}`, db);
    }

    // === Modules autorisés (pas de 'antirole' global ici) ===
    const modules = [
      "antibot",
      "antilink",
      "antispam",
      "antialt",
      "antichannelcreate",
      "antichanneldelete",
      "antichannelupdate",
      "antirolecreate",
      "antiroledelete",
      "antiroleupdate",
      "antiban",
      "antikick",
      "antiwebhook",
      "antiserveredit"
    ];
    const sanctions = ["kick", "ban", "derank", "mute"];

    // === Affichage si pas d'args ou set 'all' ===
    if (args.length === 0) {
      const embed = new Discord.EmbedBuilder()
        .setTitle("Sanctions Antiraid")
        .setColor(client.db.get(`color_${message.guild.id}`) || client.config.default_color)
        .setDescription(Object.entries(db).map(([k, v]) => `• **${k}** → \`${v}\``).join("\n") || "Aucune configuration de punition trouvée.")
        .setTimestamp();
      return message.channel.send({ embeds: [embed] });
    }

    if (args[0] === "all" && sanctions.includes(args[1])) {
      const sanction = args[1];
      modules.forEach(m => db[m] = sanction);
      await client.db.set(`punish_${message.guild.id}`, db);
      return message.channel.send(`Toutes les punitions ont été définies sur **${sanction}**.`);
    }

    // === Set par module ===
    if (modules.includes(args[0]) && sanctions.includes(args[1])) {
      const module = args[0];
      const sanction = args[1];
      db[module] = sanction;
      await client.db.set(`punish_${message.guild.id}`, db);
      return message.channel.send(`La punition pour **__${module}__** a été définie sur **${sanction}**.`);
    }

    // === Aide (arguments invalides) ===
    return message.channel.send(
      "**Usage invalide**\n\n" +
      "**Modules disponibles:** " + modules.join(", ") + "\n" +
      "**Sanctions disponibles:** " + sanctions.join(", ") + "\n\n" +
      `Exemples:\n` +
      `\`${client.prefix}punition all ban\`\n` +
      `\`${client.prefix}punition antichannelcreate kick\`\n` +
      `\`${client.prefix}punition antiroleupdate derank\``
    );
  }
};
