// commands/antirolereset.js
module.exports = {
  name: "antirolereset",
  description: "Réinitialiser les strikes AntiRole",
  use: "<create/delete/update/all> <@membre|id|all>",
  category: "antiraid",
  usage: "<create/delete/update/all> <@membre|id|all>",
  example: "➜ +antirolereset create @User\n➜ +antirolereset all all",

  run: async (client, message, args) => {
    try {
      if (!message.guild) return;

      const pass =
        client.staff?.includes(message.author.id) ||
        client.config?.buyers?.includes(message.author.id) ||
        client.db.get(`owner_global_${message.author.id}`) === true ||
        client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true ||
        message.author.id === message.guild.ownerId;

      if (!pass) {
        if (client.noperm && client.noperm.trim() !== "") {
          const sent = await message.channel.send(client.noperm);
          const d = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
          if (d > 0) setTimeout(() => sent.delete().catch(()=>{}), d*1000);
        }
        return;
      }

      const actionArg = (args[0] || "").toLowerCase();
      const targetArg = (args[1] || "").toLowerCase();
      const validActions = ["create","delete","update","all"];
      if (!validActions.includes(actionArg) || !targetArg) {
        return message.channel.send(`Utilisation incorrecte : \`${client.prefix}antirolereset <create/delete/update/all> <@membre|id|all>\``);
      }

      const guildId = message.guild.id;
      const actionsToDo = actionArg === "all" ? ["create","delete","update"] : [actionArg];
      const parseId = (s) => s.replace(/[<@!>]/g, "");

      const bumpEpoch = (event) => {
        const key = `antirole_${event}_${guildId}`;
        const prev = client.db.get(key) || { status: "off", mode: "normal", seuil_sanction: 1, epoch: 0 };
        prev.epoch = (prev.epoch || 0) + 1;
        client.db.set(key, prev);
      };

      const resetOne = (event, userId) => {
        const cfg = client.db.get(`antirole_${event}_${guildId}`) || {};
        const epoch = cfg.epoch || 0;
        const keyV = `antirole_counter_${guildId}.v${epoch}.${event}.${userId}`;
        const keyLegacy = `antirole_counter_${guildId}.${event}.${userId}`;
        if (client.db.get(keyV) !== undefined) client.db.delete(keyV);
        if (client.db.get(keyLegacy) !== undefined) client.db.delete(keyLegacy);
      };

      if (targetArg === "all") {
        for (const ev of actionsToDo) bumpEpoch(ev);
        return message.channel.send(`Strikes **reset** pour \`${actionsToDo.join(", ")}\` (tous les membres).`);
      }

      const userId = parseId(targetArg);
      const member = message.guild.members.cache.get(userId) || await message.guild.members.fetch(userId).catch(() => null);
      if (!member) return message.channel.send("Membre introuvable.");

      for (const ev of actionsToDo) resetOne(ev, member.id);
      return message.channel.send(`Strikes **reset** pour ${member} sur \`${actionsToDo.join(", ")}\`.`);

    } catch (e) {
      console.error("antirolereset error:", e);
      return message.channel.send("Erreur lors du reset (voir console).");
    }
  }
};
