// commands/bypass.js
module.exports = {
  name: "bypass",
  description: "Gérer la bypass-list par module (users/roles) + voir les modules dispo (avec indicateurs groupés).",
  use: "<module|modules> <add|del|list> [@membre|id|@role|roleId]",
  category: "antiraid",
  usage: "<module|modules> <add|del|list> [@membre|id|@role|roleId]",
  example: "➜ +bypass modules\n➜ +bypass list\n➜ +bypass antichannelcreate list\n➜ +bypass antiwebhook add @User\n➜ +bypass antibot del 123456789012345678",

  run: async (client, message, args, commandName) => {
    try {
      if (!message.guild) return;

      // ===== Permissions (même logique que tes autres cmds) =====
      let pass = false;
      if (
        (client.staff && client.staff.includes(message.author.id)) ||
        (client.config?.buyers && client.config.buyers.includes(message.author.id)) ||
        client.db.get(`owner_global_${message.author.id}`) === true ||
        client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true ||
        message.author.id === message.guild.ownerId
      ) pass = true;
      else {
        const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
        if (commandPerms.length > 0) {
          const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
          const roles = message.member.roles.cache.map(r => r.id);
          pass = commandPerms.some(p => userPerms[p]?.some(id => roles.includes(id)));
        } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") pass = true;
      }
      if (!pass) {
        if (client.noperm?.trim()) {
          const sent = await message.reply({ content: client.noperm, allowedMentions: { parse: [] } });
          const d = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
          if (d > 0) setTimeout(() => sent.delete().catch(()=>{}), d*1000);
        }
        return;
      }

      // ===== Modules (séparés) =====
      const MODULES = [
        // AntiChannel
        "antichannel",
        // AntiRole
        "antirole",
        // Seuils
        "antiban","antikick",
        // Chat
        "antispam","antilink",
        // Système
        "antibot","antiwebhook","antiserveredit",
        // Emojis
        "antiemojiadd","antiemojidelete",
        // Divers
        "antinick"
      ];

      // ===== Groupes (indicateur visuel uniquement) =====
      const GROUPS = {
        antichannel: ["antichannelcreate","antichanneldelete","antichannelupdate"],
        antirole:    ["antirolecreate","antiroledelete","antiroleupdate"],
      };

      // ===== Alias utiles → module canon =====
      const ALIAS = {
        // ergonomie
        "channelcreate":"antichannelcreate","channeldelete":"antichanneldelete","channelupdate":"antichannelupdate",
        "rolecreate":"antirolecreate","roledelete":"antiroledelete","roleupdate":"antiroleupdate",
        "ban":"antiban","kick":"antikick",
        "spam":"antispam","link":"antilink",
        "bot":"antibot","webhook":"antiwebhook","serveredit":"antiserveredit",
        "emojiadd":"antiemojiadd","emojidelete":"antiemojidelete","nick":"antinick",

        // variantes fréquentes
        "antiwebhookcreate":"antiwebhook",
        "antichannel":"antichannelcreate", // indicateur groupé dans l'affichage, opérations par sous-module
        "antirole":"antirolecreate"       // idem
      };

      const canon = (m) => {
        if (!m) return null;
        m = m.toLowerCase();
        if (ALIAS[m]) return ALIAS[m];
        if (MODULES.includes(m)) return m;
        const hit = MODULES.find(x => x.includes(m));
        return hit || null;
      };

      const sub0 = (args[0] || "").toLowerCase();
      const sub1 = (args[1] || "").toLowerCase();

      // ===== Helper: texte indicateur groupé =====
      const groupIndicatorText = () => {
        const g1 = `• antichannel = ${GROUPS.antichannel.join(", ")}`;
        const g2 = `• antirole    = ${GROUPS.antirole.join(", ")}`;
        return `${g1}\n${g2}`;
      };

      // ===== Helper: compter users/roles d'un module =====
      const countsFor = (mod) => {
        const key = `bypass_${mod}_${message.guild.id}`;
        const cur = client.db.get(key) || { users: [], roles: [] };
        return { u: cur.users?.length || 0, r: cur.roles?.length || 0 };
      };

      // ===== Liste des modules disponibles (avec indicateur groupé) =====
      if (!sub0 || sub0 === "modules") {
        const txt =
          "**Indicateur groupé (affichage) :**\n" +
          groupIndicatorText() + "\n\n" +
          "**Modules disponibles (opérations par sous-module) :**\n" +
          "• " + MODULES.join(", ") + "\n\n" +
          `Exemples:\n` +
          `\`${client.prefix}bypass list\`\n` +
          `\`${client.prefix}bypass antichannel list\`\n` +
          `\`${client.prefix}bypass antiwebhook add @User\``;
        return void message.reply({ content: txt, allowedMentions: { parse: [] } });
      }

      // ===== Liste globale (groupée visuellement) =====
      if (sub0 === "list" && !sub1) {
        let lines = [];

        // Groupe: antichannel
        lines.push("**Antichannel**");
        for (const m of GROUPS.antichannel) {
          const { u, r } = countsFor(m);
          lines.push(`• ${m} → users: ${u} | roles: ${r}`);
        }

        // Groupe: antirole
        lines.push("\n**Antirole**");
        for (const m of GROUPS.antirole) {
          const { u, r } = countsFor(m);
          lines.push(`• ${m} → users: ${u} | roles: ${r}`);
        }

        // Autres modules
        const grouped = new Set([...GROUPS.antichannel, ...GROUPS.antirole]);
        const others = MODULES.filter(m => !grouped.has(m));
        lines.push("\n**Autres**");
        for (const m of others) {
          const { u, r } = countsFor(m);
          lines.push(`• ${m} → users: ${u} | roles: ${r}`);
        }

        return void message.reply({ content: lines.join("\n"), allowedMentions: { parse: [] } });
      }

      // ===== Opérations par module =====
      const moduleName = canon(sub0);
      const action = sub1;

      if (!moduleName || !["add","del","list"].includes(action)) {
        const help =
          `Utilisation : \`${client.prefix}bypass <module> <add|del|list> [@membre|id|@role|roleId]\`\n` +
          `\n**Indicateur groupé (affichage) :**\n` + groupIndicatorText() + "\n" +
          `\n**Modules (opérations par sous-module) :**\n` + MODULES.join(", ") + "\n" +
          `\nEx: \`${client.prefix}bypass antichannelcreate add @User\`, \`${client.prefix}bypass antiroleupdate list\``;
        return void message.reply({ content: help, allowedMentions: { parse: [] } });
      }

      const key = `bypass_${moduleName}_${message.guild.id}`;
      const current = client.db.get(key) || { users: [], roles: [] };

      if (action === "list") {
        const users = (current.users || []).map(id => `<@${id}>`).join(", ") || "aucun";
        const roles = (current.roles || []).map(id => `<@&${id}>`).join(", ") || "aucun";
        const out = `**Bypass \`${moduleName}\`**\n• Users: ${users}\n• Roles: ${roles}\n\n` +
                    `Indicateur groupé (visuel)\n` + groupIndicatorText();
        return void message.reply({ content: out, allowedMentions: { parse: [] } });
      }

      const target = args[2];
      if (!target) return void message.reply({ content: "Précise un membre/role (mention ou id).", allowedMentions: { parse: [] } });

      const id = target.replace(/[<@!&>]/g, "");
      const isRole = message.guild.roles.cache.has(id);
      const isUser = (/^[0-9]{16,20}$/.test(id));

      if (!isRole && !isUser) {
        return void message.reply({ content: "Cible invalide (mention/ID).", allowedMentions: { parse: [] } });
      }

      if (action === "add") {
        if (isRole) {
          if (!current.roles.includes(id)) current.roles.push(id);
          else return void message.reply({ content: `Déjà dans la bypass **${moduleName}** : <@&${id}>`, allowedMentions: { parse: [] } });
        } else {
          if (!current.users.includes(id)) current.users.push(id);
          else return void message.reply({ content: `Déjà dans la bypass **${moduleName}** : <@${id}>`, allowedMentions: { parse: [] } });
        }
        client.db.set(key, current);
        return void message.reply({ content: `Ajouté à la bypass **${moduleName}** : ${isRole ? `<@&${id}>` : `<@${id}>`}`, allowedMentions: { parse: [] } });
      }

      if (action === "del") {
        if (isRole) {
          const before = current.roles.length;
          current.roles = current.roles.filter(r => r !== id);
          if (current.roles.length === before) return void message.reply({ content: `Ce rôle n'était pas dans la bypass **${moduleName}**.`, allowedMentions: { parse: [] } });
        } else {
          const before = current.users.length;
          current.users = current.users.filter(u => u !== id);
          if (current.users.length === before) return void message.reply({ content: `Cet utilisateur n'était pas dans la bypass **${moduleName}**.`, allowedMentions: { parse: [] } });
        }
        client.db.set(key, current);
        return void message.reply({ content: `Retiré de la bypass **${moduleName}** : ${isRole ? `<@&${id}>` : `<@${id}>`}`, allowedMentions: { parse: [] } });
      }

    } catch (e) {
      console.error("bypass cmd error:", e);
      return message.reply({ content: "Erreur lors de la commande (voir console).", allowedMentions: { parse: [] } });
    }
  }
};
