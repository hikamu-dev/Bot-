const { Astroia } = require("../../structures/client/index");
const ms = require('ms');
const Discord = require('discord.js');

module.exports = {
    name: 'antialt',
    description: 'Configure la protection contre les comptes trop récents.',
    use: "<here/all> <on/off> <âge minimum du compte>",
    usage: 'antialt <here/all> <on/off> <âge minimum du compte>',
    example: "➜ antialt here on 10m\n➜ antialt all off\n➜ antialt here on 7d",
    run: async (client, message, args, commandName) => {
      
    let pass = false;

if (client.staff.includes(message.author.id) || 
    client.config.buyers.includes(message.author.id) || 
    message.guild.ownerId === message.author.id || 
    client.db.get(`owner_global_${message.author.id}`) === true || 
    client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true) {
  pass = true;
}
 else {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        pass = true;
      }
    }

    if (!pass) {
        if (client.noperm && client.noperm.trim() !== '') {
            const sentMessage = await message.channel.send(client.noperm);
            const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
            if (delayTime > 0) {
                setTimeout(() => {
                    sentMessage.delete().catch(() => {});
                }, delayTime * 1000);
            }
        }
        return;
    }
        if (args.length < 1) {
            return message.channel.send(`Utilisation incorecte : \`${client.prefix}antialt <on/off> [âge minimum du compte]\``);
        }

        const antialtData = client.db.get(`antialt_${message.guild.id}`) || {
            minAge: '7d', // Valeur par défaut: 7 jours
            status: 'off'
        };

        // Gestion des commandes simples (on/off)
        if (args[0] === 'on') {
            // Si un âge minimum est spécifié
            if (args[1]) {
                const minAgeMs = parseInterval(args[1]);
                if (isNaN(minAgeMs)) {
                    return message.channel.send('Durée invalide. Utilisez par exemple: 1h, 2d, 7j, 30d, 1a');
                }
                antialtData.minAge = args[1];
            }
            antialtData.status = 'on';
            client.db.set(`antialt_${message.guild.id}`, antialtData);
            return message.channel.send(`L'anti-alt est activé. Les comptes de moins de ${antialtData.minAge} ne pourront pas rejoindre.`);
        }

        if (args[0] === 'off') {
            antialtData.status = 'off';
            client.db.set(`antialt_${message.guild.id}`, antialtData);
            return message.channel.send('L\'anti-alt est désactivé.');
        }

        return message.channel.send(`Usage: \`${client.prefix}antialt <on/off> [âge minimum du compte]\`\nExemple: \`${client.prefix}antialt on 3d\` pour bloquer les comptes de moins de 3 jours`);
    },
};

function parseInterval(input) {
    if (!input || typeof input !== 'string') return NaN;
    
    const intervalRegex = /^(\d+)([smhdwja])$/;
    const match = input.match(intervalRegex);
    if (!match) return NaN;

    const value = parseInt(match[1]);
    const unit = match[2];

    switch (unit) {
        case 's': return value * 1000; // secondes
        case 'm': return value * 60000; // minutes
        case 'h': return value * 3600000; // heures
        case 'd': return value * 86400000; // jours
        case 'w': return value * 604800000; // semaines
        case 'a': return value * 31536000000; // années (365 jours)
        default: return NaN;
    }
}