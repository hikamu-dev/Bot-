// commands/protect.js
const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder
} = require('discord.js');

/* ====== Const UI ====== */
const NAME_W = 26;
const STATUS_W = 6;
const SANC_W = 8;

const SanctionList = ["ban","kick","derank","mute"];

function ucFirst(s){ return s ? s.charAt(0).toUpperCase() + s.slice(1) : s; }
function pad(s, w){ s = String(s ?? ""); return s.length >= w ? s : s + " ".repeat(w - s.length); }

/* ====== Modules (MAX partout sauf antialt) ====== */
function getModules(guildId){
  return [
    // === AntiChannel (seuil + max) ===
    { key: "antichannelcreate", label: "AntiChannelCreate", type: "cfg_object", supportsMax: true,  supportsThreshold: true,  cfgKey: `antichannel_create_${guildId}`, punishKey: "antichannelcreate" },
    { key: "antichanneldelete", label: "AntiChannelDelete", type: "cfg_object", supportsMax: true,  supportsThreshold: true,  cfgKey: `antichannel_delete_${guildId}`, punishKey: "antichanneldelete" },
    { key: "antichannelupdate", label: "AntiChannelUpdate", type: "cfg_object", supportsMax: true,  supportsThreshold: true,  cfgKey: `antichannel_update_${guildId}`, punishKey: "antichannelupdate" },

    // === AntiRole (seuil + max) ===
    { key: "antirolecreate",    label: "AntiRoleCreate",    type: "cfg_object", supportsMax: true,  supportsThreshold: true,  cfgKey: `antirole_create_${guildId}`,    punishKey: "antirolecreate" },
    { key: "antiroledelete",    label: "AntiRoleDelete",    type: "cfg_object", supportsMax: true,  supportsThreshold: true,  cfgKey: `antirole_delete_${guildId}`,    punishKey: "antiroledelete" },
    { key: "antiroleupdate",    label: "AntiRoleUpdate",    type: "cfg_object", supportsMax: true,  supportsThreshold: true,  cfgKey: `antirole_update_${guildId}`,    punishKey: "antiroleupdate" },

    // === AntiBan / AntiKick (seuil + max) ===
    { key: "antiban",           label: "AntiBan",           type: "cfg_object", supportsMax: true,  supportsThreshold: true,  cfgKey: `antiban_${guildId}`,            punishKey: "antiban" },
    { key: "antikick",          label: "AntiKick",          type: "cfg_object", supportsMax: true,  supportsThreshold: true,  cfgKey: `antikick_${guildId}`,           punishKey: "antikick" },

    // === AntiSpam (affiche [msgs/seconds] + max) ===
    { key: "antispam",          label: "AntiSpam",          type: "cfg_object", supportsMax: true,  supportsThreshold: false, cfgKey: `antispam_${guildId}`,            punishKey: "antispam" },

    // === AntiLink (affiche [discord]/[all]/[max] + max) ===
    { key: "antilink",          label: "AntiLien",          type: "cfg_object", supportsMax: true,  supportsThreshold: false, cfgKey: `antilink_${guildId}`,            punishKey: "antilink" },

    // === Autres modules (max activé partout) ===
    { key: "antibot",           label: "AntiBot",           type: "cfg_object", supportsMax: true,  supportsThreshold: false, cfgKey: `antibot_${guildId}`,             punishKey: "antibot" },
    { key: "antiwebhook",       label: "AntiWebhook",       type: "cfg_object", supportsMax: true,  supportsThreshold: false, cfgKey: `antiwebhook_${guildId}`,         punishKey: "antiwebhook" },
    { key: "antiserveredit",    label: "AntiServerEdit",    type: "cfg_object", supportsMax: true,  supportsThreshold: false, cfgKey: `antiserveredit.${guildId}`,       punishKey: "antiserveredit" },
    { key: "antinick",          label: "AntiNick",          type: "cfg_object", supportsMax: true,  supportsThreshold: false, cfgKey: `antinick.${guildId}`,             punishKey: "antinick" },
    { key: "antiemojiadd",      label: "AntiEmojiAdd",      type: "cfg_object", supportsMax: true,  supportsThreshold: false, cfgKey: `antiemojiadd_${guildId}`,         punishKey: "antiemojiadd" },
    { key: "antiemojidelete",   label: "AntiEmojiDelete",   type: "cfg_object", supportsMax: true,  supportsThreshold: false, cfgKey: `antiemojidelete_${guildId}`,      punishKey: "antiemojidelete" },

    // === SEUL module sans MAX ===
    { key: "antialt",           label: "AntiAlt",           type: "cfg_object", supportsMax: false, supportsThreshold: false, cfgKey: `antialt_${guildId}`,              punishKey: "antialt" },
  ];
}

/* ====== Punitions (avec défauts) ====== */
function getPunishments(client, guildId){
  const defaults = {
    antibot: 'derank',
    antilink: 'derank',
    antispam: 'derank',
    antialt: 'kick',
    antichannelcreate: 'derank',
    antichanneldelete: 'derank',
    antichannelupdate: 'derank',
    antirolecreate: 'derank',
    antiroledelete: 'derank',
    antiroleupdate: 'derank',
    antiban: 'ban',
    antikick: 'ban',
    antiwebhook: 'derank',
    antiserveredit: 'ban',
    antinick: 'derank',
    antiemojiadd: 'derank',
    antiemojidelete: 'derank'
  };
  const db = client.db.get(`punish_${guildId}`) || {};
  return { ...defaults, ...db };
}

/* ====== Lecture/Ecriture config ====== */
function readModuleConfig(client, mod){
  const raw = client.db.get(mod.cfgKey);
  if (mod.type === "cfg_object") {
    if (!raw || typeof raw !== 'object') {
      return { status: 'off', mode: 'normal', seuil_sanction: 1, ...(raw||{}) };
    }
    return {
      status: raw.status || 'off',
      mode: raw.mode || 'normal',
      seuil_sanction: (raw.seuil_sanction ?? 1),
      epoch: (raw.epoch ?? 0)
    };
  }
  // (plus utilisé ici, tout en cfg_object pour supporter Max)
  if (raw && typeof raw === 'object') return raw.status || 'off';
  return raw || 'off';
}

function writeModuleStatus(client, mod, target){ // 'on'|'off'|'max'
  if (mod.type === "cfg_object") {
    const prev = client.db.get(mod.cfgKey) || {};
    let status = 'off', mode = 'normal';
    if (target === 'off') { status = 'off'; mode = prev.mode || 'normal'; }
    else if (target === 'on') { status = 'on'; mode = 'normal'; }
    else if (target === 'max') { status = 'on'; mode = 'max'; }
    const next = {
      ...prev,
      status,
      mode,
      seuil_sanction: (prev.seuil_sanction ?? 1),
      epoch: (prev.epoch ?? 0)
    };
    client.db.set(mod.cfgKey, next);
  } else {
    const isOn = (target !== 'off');
    const current = client.db.get(mod.cfgKey);
    if (typeof current === "object" && current !== null) client.db.set(mod.cfgKey, { ...current, status: isOn ? 'on' : 'off' });
    else client.db.set(mod.cfgKey, isOn ? 'on' : 'off');
  }
}

function writePunish(client, guildId, punishKey, value){
  const db = client.db.get(`punish_${guildId}`) || {};
  db[punishKey] = value;
  client.db.set(`punish_${guildId}`, db);
}

/* ====== Badges additionnels (AntiSpam/AntiLink) ====== */
function extraBadge(client, guildId, modKey){
  try {
    if (modKey === "antispam") {
      const as = client.db.get(`antispam_${guildId}`) || { message: 5, temps: 5000 };
      if (as.message === 'max' || as.temps === 'max') return "[max] ";
      const secs = Math.max(1, Math.round((as.temps || 1000)/1000));
      return `[${as.message}/${secs}s] `;
    }
    if (modKey === "antilink") {
      const al = client.db.get(`antilink_${guildId}`) || {};
      const lien = (al.lien || "all").toLowerCase();
      if (lien === "max") return "[max] ";
      if (lien === "invites" || lien === "discord") return "[discord] ";
      return "[all] ";
    }
  } catch {}
  return "";
}

/* ====== Table monospaced ====== */
function buildTable(client, guildId, modules, punishments){
  let header = `${pad("Module", NAME_W)} | ${pad("Etat", STATUS_W)} | ${pad("Sanction", SANC_W)}\n`;
  header += `${"-".repeat(NAME_W)} | ${"-".repeat(STATUS_W)} | ${"-".repeat(SANC_W)}\n`;

  let lines = "";
  for (const mod of modules) {
    const cfg = readModuleConfig(client, mod);

    // état
    let stateDisp = "off";
    if (mod.type === "cfg_object") {
      const status = (cfg.status || 'off');
      const mode   = (cfg.mode   || 'normal');
      stateDisp = (status === 'on' && mode === 'max') ? "max" : status;
    } else {
      stateDisp = (cfg === 'on') ? 'on' : 'off';
    }

    // seuil + badges
    let thresholdTxt = "";
    if (mod.supportsThreshold) thresholdTxt = `[${cfg.seuil_sanction ?? 1}] `;
    const badge = extraBadge(client, guildId, mod.key);

    const sanc = ucFirst(punishments[mod.punishKey] || "aucune");
    const namePadded = pad(`${thresholdTxt}${badge}${mod.label}`, NAME_W);
    const statePadded = pad(stateDisp, STATUS_W);
    const sancPadded  = pad(sanc, SANC_W);
    lines += `${namePadded} | ${statePadded} | ${sancPadded}\n`;
  }
  return "```\n" + header + lines + "```";
}

/* ====== UI builders ====== */
function buildControls(selectedKey, mods){
  const select = new StringSelectMenuBuilder()
    .setCustomId('protect:module')
    .setPlaceholder('Choisir un module…');

  for (const m of mods) {
    const opt = new StringSelectMenuOptionBuilder()
      .setLabel(m.label)
      .setValue(m.key)
      .setDescription(m.supportsThreshold ? 'Seuil visible dans la liste' : '—');
    if (selectedKey && m.key === selectedKey) opt.setDefault(true);
    select.addOptions(opt);
  }

  const rowSelect = new ActionRowBuilder().addComponents(select);

  const sancRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`protect:sanc:ban`).setLabel('Ban').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`protect:sanc:kick`).setLabel('Kick').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`protect:sanc:derank`).setLabel('Derank').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`protect:sanc:mute`).setLabel('Mute').setStyle(ButtonStyle.Secondary),
  );

  const stateRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`protect:state:on`).setLabel('On').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`protect:state:off`).setLabel('Off').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`protect:state:max`).setLabel('Max').setStyle(ButtonStyle.Secondary),
  );

  return { rowSelect, sancRow, stateRow };
}

function colorizeRowsByCurrent(rows, client, guildId, selected, punishments){
  if (!selected) return rows;

  // sanction actuelle
  const chosenSanction = (punishments[selected.punishKey] || "").toLowerCase();

  const sancRow = new ActionRowBuilder();
  for (const id of ["ban","kick","derank","mute"]) {
    sancRow.addComponents(
      new ButtonBuilder()
        .setCustomId(`protect:sanc:${id}`)
        .setLabel(ucFirst(id))
        .setStyle(chosenSanction === id ? ButtonStyle.Primary : ButtonStyle.Secondary)
    );
  }

  // état actuel
  const cfg = readModuleConfig(client, selected);
  let state = "off";
  if (selected.type === "cfg_object") state = (cfg.status === 'on' && cfg.mode === 'max') ? 'max' : (cfg.status || 'off');
  else state = (cfg === 'on') ? 'on' : 'off';

  const stateRow = new ActionRowBuilder();
  const states = selected.supportsMax ? ["on","off","max"] : ["on","off"];
  for (const st of states) {
    stateRow.addComponents(
      new ButtonBuilder()
        .setCustomId(`protect:state:${st}`)
        .setLabel(ucFirst(st))
        .setStyle(state === st ? ButtonStyle.Primary : ButtonStyle.Secondary)
    );
  }
  if (!selected.supportsMax) {
    stateRow.addComponents(
      new ButtonBuilder().setCustomId(`protect:state:max`).setLabel("Max").setStyle(ButtonStyle.Secondary).setDisabled(true)
    );
  }

  return { ...rows, sancRow, stateRow };
}

/* ====== Commande ====== */
module.exports = {
  name: "protect",
  aliases: ["secur", "security", "sec", "protections", "protection"],
  description: "Affiche/Configure la sécurité",
  usage: "protect",
  run: async (client, message, args, commandName) => {
    // Permissions (même logique que d’hab)
    let pass = false;
    if (
      (client.staff && client.staff.includes(message.author.id)) ||
      (client.config?.buyers && client.config.buyers.includes(message.author.id)) ||
      client.db.get(`owner_global_${message.author.id}`) === true ||
      client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true ||
      message.author.id === message.guild.ownerId
    ) {
      pass = true;
    } else {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(r => r.id);
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        pass = true;
      }
    }
    if (!pass) {
      if (client.noperm && client.noperm.trim() !== '') {
        const sent = await message.channel.send(client.noperm);
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) setTimeout(() => sent.delete().catch(()=>{}), delayTime * 1000);
      }
      return;
    }

    const guildId = message.guild.id;
    const mods = getModules(guildId);
    const punishments = getPunishments(client, guildId);

    const table = buildTable(client, guildId, mods, punishments);

    const embed = new EmbedBuilder()
      .setColor(client.db.get(`color_${guildId}`) || client.config.default_color || 0x2b2d31)
      .setTitle('🔒 ▸ Paramètres de Protection du Serveur')
      .setDescription(
        `• **Seuils** affichés devant les modules concernés \`[n]\` (AntiChannel/AntiRole/**AntiBan/AntiKick**)\n` +
        `• **AntiSpam** affiche \`[messages/s]\` ou \`[max]\` — **AntiLien** affiche \`[discord]\`, \`[all]\` ou \`[max]\`\n` +
        `• Sélectionne un module avec le menu, puis choisis **Sanction** et **État** avec les boutons`
      )
      .addFields({ name: '🛡️ ▸ Protections', value: table, inline: false });

    // UI initiale
    const selectedKey = mods[0].key;
    const baseRows = buildControls(selectedKey, mods);
    const colored = colorizeRowsByCurrent(baseRows, client, guildId, mods[0], punishments);

    const msg = await message.channel.send({ embeds: [embed], components: [colored.rowSelect, colored.sancRow, colored.stateRow] });

    // Collector unique (buttons + select), 2 minutes
    const collector = msg.createMessageComponentCollector({ time: 120000 });
    let currentKey = selectedKey;

    collector.on('collect', async (i) => {
      try {
        if (i.user.id !== message.author.id) return i.reply({ content: "Pas pour toi ⚠️", ephemeral: true });

        if (i.customId === 'protect:module' && i.isStringSelectMenu?.()) {
          currentKey = i.values[0];
          const selMod = mods.find(m => m.key === currentKey);
          const punish2 = getPunishments(client, guildId);
          const rows2 = colorizeRowsByCurrent(buildControls(currentKey, mods), client, guildId, selMod, punish2);

          const table2 = buildTable(client, guildId, mods, punish2);
          const newEmbed = EmbedBuilder.from(embed).setFields({ name: '🛡️ ▸ Protections', value: table2, inline: false });

          return i.update({ embeds: [newEmbed], components: [rows2.rowSelect, rows2.sancRow, rows2.stateRow] });
        }

        if (i.customId.startsWith('protect:sanc:') && i.isButton?.()) {
          const selMod = mods.find(m => m.key === currentKey);
          if (!selMod) return i.reply({ content: "Module inconnu.", ephemeral: true });
          const sanc = i.customId.split(":")[2];
          if (!SanctionList.includes(sanc)) return i.reply({ content: "Sanction invalide.", ephemeral: true });

          writePunish(client, guildId, selMod.punishKey, sanc);

          const punish2 = getPunishments(client, guildId);
          const rows2 = colorizeRowsByCurrent(buildControls(currentKey, mods), client, guildId, selMod, punish2);
          const table2 = buildTable(client, guildId, mods, punish2);
          const newEmbed = EmbedBuilder.from(embed).setFields({ name: '🛡️ ▸ Protections', value: table2, inline: false });

          return i.update({ embeds: [newEmbed], components: [rows2.rowSelect, rows2.sancRow, rows2.stateRow] });
        }

        if (i.customId.startsWith('protect:state:') && i.isButton?.()) {
          const selMod = mods.find(m => m.key === currentKey);
          if (!selMod) return i.reply({ content: "Module inconnu.", ephemeral: true });
          const state = i.customId.split(":")[2]; // on/off/max
          if (state === 'max' && !selMod.supportsMax) {
            return i.reply({ content: "Ce module ne supporte pas le mode MAX.", ephemeral: true });
          }

          writeModuleStatus(client, selMod, state);

          const punish2 = getPunishments(client, guildId);
          const rows2 = colorizeRowsByCurrent(buildControls(currentKey, mods), client, guildId, selMod, punish2);
          const table2 = buildTable(client, guildId, mods, punish2);
          const newEmbed = EmbedBuilder.from(embed).setFields({ name: '🛡️ ▸ Protections', value: table2, inline: false });

          return i.update({ embeds: [newEmbed], components: [rows2.rowSelect, rows2.sancRow, rows2.stateRow] });
        }

      } catch (e) {
        console.error("protect collector error:", e);
        if (i.deferred || i.replied) {
          await i.followUp({ content: "Erreur pendant l'interaction.", ephemeral: true }).catch(()=>{});
        } else {
          await i.reply({ content: "Erreur pendant l'interaction.", ephemeral: true }).catch(()=>{});
        }
      }
    });

    collector.on('end', async () => {
      try {
        const disabledSelect = new StringSelectMenuBuilder()
          .setCustomId('protect:module:end')
          .setPlaceholder('Session expirée')
          .setDisabled(true);
        for (const m of mods) {
          disabledSelect.addOptions(
            new StringSelectMenuOptionBuilder().setLabel(m.label).setValue(m.key)
          );
        }
        const rowSelectDisabled = new ActionRowBuilder().addComponents(disabledSelect);

        const sancDisabled = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('protect:sanc:ban').setLabel('Ban').setStyle(ButtonStyle.Secondary).setDisabled(true),
          new ButtonBuilder().setCustomId('protect:sanc:kick').setLabel('Kick').setStyle(ButtonStyle.Secondary).setDisabled(true),
          new ButtonBuilder().setCustomId('protect:sanc:derank').setLabel('Derank').setStyle(ButtonStyle.Secondary).setDisabled(true),
          new ButtonBuilder().setCustomId('protect:sanc:mute').setLabel('Mute').setStyle(ButtonStyle.Secondary).setDisabled(true),
        );
        const stateDisabled = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('protect:state:on').setLabel('On').setStyle(ButtonStyle.Secondary).setDisabled(true),
          new ButtonBuilder().setCustomId('protect:state:off').setLabel('Off').setStyle(ButtonStyle.Secondary).setDisabled(true),
          new ButtonBuilder().setCustomId('protect:state:max').setLabel('Max').setStyle(ButtonStyle.Secondary).setDisabled(true),
        );

        await msg.edit({ components: [rowSelectDisabled, sancDisabled, stateDisabled] }).catch(()=>{});
      } catch {}
    });
  }
};
