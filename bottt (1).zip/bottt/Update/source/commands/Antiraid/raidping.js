const Discord = require('discord.js');
const fs = require('fs');
const Astroia = require('../../structures/client');

module.exports = {
    name: "pingraid",
    aliases: ["raidping"],
    description: "Permet de paraméter le pingraid",
    use: "off,pingraid everyone/here/buyers/owners,pingraid role <role>",
    usage: "pingraid <@role/id> | pingraid <everyone/here/buyer",
    example: "➜ pingraid off\n➜ pingraid everyone\n➜ pingraid here\n➜ pingraid buyers\n➜ pingraid owners\n➜ pingraid role @role",

    /**
     * @param {Astroia} client 
     * @param {Discord.Message} message 
     */

    run: async (client, message, args, commandName) => {
      
    let pass = false;

    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) || 
        client.db.get(`owner_global_${message.author.id}`) === true || 
        client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true) {
      pass = true;
    } else {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        pass = true;
      }
    }

    if (!pass) {
        if (client.noperm && client.noperm.trim() !== '') {
            const sentMessage = await message.channel.send(client.noperm);
            const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
            if (delayTime > 0) {
                setTimeout(() => {
                    sentMessage.delete().catch(() => {});
                }, delayTime * 1000);
            }
        }
        return;
    }
                if (!args[0]) {
            return message.channel.send(`Utilisation incorrecte: \`pingraid <@role/id> | pingraid <everyone/here/buyer.\``);
        }

        if (args[0] === "off") {
            if (!client.db.get(`pingraid_${message.guild.id}`)) return message.channel.send(await client.lang(`raidping.message2`))
            client.db.delete(`pingraid_${message.guild.id}`);
            message.channel.send(await client.lang(`raidping.message1`))
        } else if (args[0] === "everyone" || args[0] === "here" || args[0] === "buyers" || args[0] === "owners") {
            if (client.db.get(`pingraid_${message.guild.id}`) === args[0]) return message.channel.send(`Le pingraid est déjà sur \`${args[0]}\`.`)
            client.db.set(`pingraid_${message.guild.id}`, args[0]);
            message.channel.send(`${await client.lang(`raidping.message3`)} \`${args[0]}\`.`)
        } else if (args[0] === "role") {
            let role = message.mentions.roles.first() || message.guild.roles.cache.find(r => r.name === args[1]) || message.guild.roles.cache.find(r => r.id === args[1]);
            if (!role) return message.channel.send(await client.lang(`raidping.message5`))
            if (client.db.get(`pingraid_${message.guild.id}`) === "role") return message.channel.send(await client.lang(`raidping.message7`))
            client.db.set(`pingraid_${message.guild.id}`, "role");
            client.db.set(`pingraid_role_${message.guild.id}`, role.id);
            message.channel.send(`${await client.lang(`raidping.message6`)} \`${role.name}\`.`)
        }



    }
}