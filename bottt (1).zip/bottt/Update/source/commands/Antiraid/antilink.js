// commands/antilink.js
module.exports = {
  name: "antilink",
  description: "Permet de paramétrer l'antilink",
  use: "<discord/all> <on/off/max> [seuil]",
  category: "antiraid",
  usage: "antilink <discord/all> <on/off/max> [seuil]",
  example: "➜ antilink discord on\n➜ antilink all off\n➜ antilink discord max 4",

  run: async (client, message, args) => {
    // permissions: buyers / staff / owner_here / owner_all / guild owner
    const pass =
      (Array.isArray(client.staff) && client.staff.includes(message.author.id)) ||
      (Array.isArray(client.config?.buyers) && client.config.buyers.includes(message.author.id)) ||
      client.db.get(`owner_global_${message.author.id}`) === true ||
      client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true ||
      message.author.id === message.guild.ownerId;

    if (!pass) {
      if (client.noperm && client.noperm.trim() !== "") {
        const sent = await message.channel.send(client.noperm);
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) setTimeout(() => sent.delete().catch(()=>{}), delayTime * 1000);
      }
      return;
    }

    const key = `antilink_${message.guild.id}`;
    const state = client.db.get(key) || {
      sanction: ['delete', 'mute', 'message'],
      ignore: [],
      lien: 'all',     // 'invites' | 'all'
      status: 'off',   // 'on' | 'off'
      mode: 'normal',  // 'normal' | 'max'
      threshold: 2     // nb d'infractions avant sanction (0 = jamais sanctionner)
    };

    // besoin de 2 args minimum
    if (!args[0] || !args[1]) {
      return message.channel.send(
        `Utilisation incorrecte : \`${client.prefix}antilink <discord/all> <on/off/max> [seuil]\``
      );
    }

    const targetArg   = args[0].toLowerCase();
    const actionArg   = args[1].toLowerCase();
    const thresholdArg = args[2];

    // target
    if (["discord","invites","invite"].includes(targetArg)) {
      state.lien = "invites";
    } else if (targetArg === "all") {
      state.lien = "all";
    } else {
      return message.channel.send(
        `Utilisation incorrecte : \`${client.prefix}antilink <discord/all> <on/off/max> [seuil]\``
      );
    }

    // action
    if (actionArg === "on") {
      state.status = "on";
      state.mode = "normal";
      client.db.set(key, state);
      await message.channel.send(`L'antilink est désormais activé.`);
    } else if (actionArg === "off") {
      state.status = "off";
      state.mode = "normal";
      client.db.set(key, state);
      await message.channel.send(`L'antilink est désormais désactivé.`);
    } else if (actionArg === "max") {
      // max = MODE (n'altère pas la cible)
      state.status = "on";
      state.mode = "max";
      client.db.set(key, state);
      await message.channel.send(`Le mode "max" de l'antilink est activé.`);
    } else {
      return message.channel.send(
        `Utilisation incorrecte : \`${client.prefix}antilink <discord/all> <on/off/max> [seuil]\``
      );
    }

    // seuil optionnel (0–50 ; 0 = jamais sanctionner)
    if (typeof thresholdArg !== "undefined") {
      const n = parseInt(thresholdArg, 10);
      if (!Number.isNaN(n) && n >= 0 && n <= 50) {
        state.threshold = n;
        client.db.set(key, state);
        await message.channel.send(
          n === 0
            ? `Seuil de sanction défini à **0** → suppression & avertissement uniquement (aucune sanction).`
            : `Seuil de sanction défini à **${n}**.`
        );
      } else {
        await message.channel.send(`Seuil invalide. Donne un nombre entre **0** et **50**.`);
      }
    }
  }
};
