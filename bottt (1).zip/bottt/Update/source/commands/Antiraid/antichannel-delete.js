// commands/antichanneldelete.js
module.exports = {
  name: "antichanneldelete",
  description: "Configurer l'antichannel pour l'event DELETE.",
  use: "<on/off/max> [seuil_sanction]",
  category: "antiraid",
  usage: "<on/off/max> [seuil_sanction]",
  example: "➜ +antichanneldelete on 3",

  run: async (client, message, args) => {
    if (!message.guild) return;

    const pass =
      client.staff?.includes(message.author.id) ||
      client.config?.buyers?.includes(message.author.id) ||
      client.db.get(`owner_global_${message.author.id}`) === true ||
      client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true ||
      message.author.id === message.guild.ownerId;

    if (!pass) {
      if (client.noperm && client.noperm.trim() !== "") {
        const sent = await message.channel.send(client.noperm);
        const d = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (d > 0) setTimeout(() => sent.delete().catch(()=>{}), d*1000);
      }
      return;
    }

    if (!args[0] || !["on","off","max"].includes(args[0].toLowerCase())) {
      return message.channel.send(`Utilisation incorrecte : \`${client.prefix}antichanneldelete <on/off/max> [seuil_sanction]\``);
    }

    const key = `antichannel_delete_${message.guild.id}`;
    const prev = client.db.get(key) || { status: "off", mode: "normal", seuil_sanction: 1, epoch: 0 };

    const modeArg = args[0].toLowerCase();
    const seuil = (args[1] !== undefined) ? parseInt(args[1], 10) : (prev.seuil_sanction ?? 1);
    if (!Number.isInteger(seuil) || seuil < 0 || seuil > 100) return message.channel.send("`seuil_sanction` invalide (0-100).");

    const state = {
      status: (modeArg === "off") ? "off" : "on",
      mode:   (modeArg === "max") ? "max" : "normal",
      seuil_sanction: seuil,
      epoch: (prev.epoch || 0) + 1 // reset global des compteurs DELETE
    };

    client.db.set(key, state);
    return message.channel.send(`Config **DELETE** ➜ statut **${state.status}**, mode **${state.mode}**, sanction≥**${state.seuil_sanction}**`);
  }
};
