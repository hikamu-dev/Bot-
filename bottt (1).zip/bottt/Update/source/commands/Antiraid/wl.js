const Discord = require('discord.js');
const Astroia = require('../../structures/client');

module.exports = {
    name: "wl",
    aliases: ["whitelist"],
    description: "Permet de gérer la whitelist",
    category: "botcontrol",
    usage: "wl <@utilisateur>, wl [clear]",
    example: "➜ wl @tokyru\n➜ wl 123456789012345678\n➜ wl clear",
    /**
     * @param {Astroia} client 
     * @param {Discord.Message} message
     */
    run: async (client, message, args, commandName) => {
      
    let pass = false;

    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) || 
        client.db.get(`owner_global_${message.author.id}`) === true || 
        client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true) {
      pass = true;
    } else {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        pass = true;
      }
    }

    if (!pass) {
        if (client.noperm && client.noperm.trim() !== '') {
            const sentMessage = await message.channel.send(client.noperm);
            const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
            if (delayTime > 0) {
                setTimeout(() => {
                    sentMessage.delete().catch(() => {});
                }, delayTime * 1000);
            }
        }
        return;
    }

        // Si pas d'argument, afficher la whitelist
        if (!args[0]) {
            let wlz = client.db.get(`wl.${message.guild.id}`);
            if (!wlz || wlz.length === 0) {
                let wl = await client.lang(`wl.aucun`);
                return message.channel.send(wl);
            } else {
                let wl = wlz.map(a => `<@${a}>`).join("\n");
                let embed = new Discord.EmbedBuilder()
                    .setColor(client.color)
                    .setTitle(`Whitelist`)
                    .setDescription(wl)
                    .setFooter({ text: client.footer });
                return message.channel.send({ embeds: [embed] });
            }
        }

        // Gestion des mentions ou IDs utilisateurs
        if (message.mentions.members.size > 0 || client.users.cache.get(args[0])) {
            let member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
            if (!member || !message.guild.members.cache.has(member.id)) {
                return message.channel.send(await client.lang('tempmute.invalidemembre'));
            }

            // Récupérer la whitelist actuelle
            let wl = client.db.get(`wl.${message.guild.id}`) || [];

            // Vérifier si le membre est déjà whitelisté
            if (wl.includes(member.id)) {
                return message.channel.send(`**${member.user.username}** est déjà whiteliste.`);
            }

            // Ajouter le membre à la whitelist
            client.db.push(`wl.${message.guild.id}`, member.id);
            client.db.set(`wlmd_${message.guild.id}_${member.id}`, true);
            return message.channel.send(`**${member.user.username}** ${await client.lang(`wl.message1`)}`);

        } else if (args[0].toLowerCase() === "clear") {
            let data = await client.db.all().filter(data => data.ID.startsWith(`wlmd_${message.guild.id}`));
            client.db.set(`wl.${message.guild.id}`, []);

            message.channel.send(`${data.length || 0} ${data.length > 1 ? await client.lang(`wl.message2`) : await client.lang(`wl.message3`)} ${await client.lang(`wl.message4`)}`);

            for (let i = 0; i < data.length; i++) {
                client.db.delete(data[i].ID);
            }
        }
    }
}
