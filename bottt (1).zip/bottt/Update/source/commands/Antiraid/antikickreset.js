// commands/antikickreset.js
const Discord = require('discord.js');

module.exports = {
  name: "antikickreset",
  description: "Réinitialiser les strikes AntiKick (ciblé ou global).",
  use: "<@membre|id|all>",
  category: "antiraid",
  usage: "<@membre|id|all>",
  example: "➜ +antikickreset @User\n➜ +antikickreset all",

  /**
   * @param {import('../../structures/client').Astroia} client
   * @param {Discord.Message} message
   */
  run: async (client, message, args, commandName) => {
    if (!message.guild) return;

    // === Permissions (même logique que tes autres commandes) ===
    let pass = false;
    if (
      (client.staff && client.staff.includes(message.author.id)) ||
      (client.config?.buyers && client.config.buyers.includes(message.author.id)) ||
      client.db.get(`owner_global_${message.author.id}`) === true ||
      client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true ||
      message.author.id === message.guild.ownerId
    ) {
      pass = true;
    } else {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(r => r.id);
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        pass = true;
      }
    }
    if (!pass) {
      if (client.noperm && client.noperm.trim() !== '') {
        const sent = await message.channel.send(client.noperm);
        const d = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (d > 0) setTimeout(() => sent.delete().catch(()=>{}), d*1000);
      }
      return;
    }

    // === Args ===
    if (!args[0]) {
      return message.channel.send(`Utilisation incorrecte : \`${client.prefix}antikickreset <@membre|id|all>\``);
    }

    const guildId = message.guild.id;
    const keyCfg = `antikick_${guildId}`;
    const prev = client.db.get(keyCfg) || { status: "off", mode: "normal", seuil_sanction: 1, epoch: 0 };

    const targetRaw = args[0];
    const isAll = targetRaw.toLowerCase?.() === "all";

    const bumpEpoch = () => {
      const next = { ...prev, epoch: (prev.epoch || 0) + 1 };
      client.db.set(keyCfg, next);
    };

    const resetOne = async (userId) => {
      const epoch = prev.epoch || 0;
      const vKey = `antikick_counter_${guildId}.v${epoch}.kick.${userId}`;
      const legacyKey = `antikick_counter_${guildId}.kick.${userId}`;
      if (client.db.get(vKey) !== undefined) client.db.delete(vKey);
      if (client.db.get(legacyKey) !== undefined) client.db.delete(legacyKey);
    };

    if (isAll) {
      bumpEpoch();
      return message.channel.send(`Strikes **AntiKick** reset pour **tous** les membres.`);
    }

    const userId = targetRaw.replace(/[<@!>]/g, "");
    if (!userId) return message.channel.send("ID invalide.");

    await resetOne(userId);

    let display = `<@${userId}>`;
    const member = message.guild.members.cache.get(userId) || await message.guild.members.fetch(userId).catch(()=>null);
    if (member) display = `${member}`;

    return message.channel.send(`Strikes **AntiKick** reset pour ${display}.`);
  }
};
