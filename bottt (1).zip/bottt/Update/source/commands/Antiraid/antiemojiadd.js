// commands/antiemojiadd.js
const Discord = require('discord.js');

module.exports = {
  name: "antiemojiadd",
  description: "Activer/Désactiver l'AntiEmojiAdd.",
  category: "antiraid",
  use: "<on/off/max|status>",
  usage: "<on/off/max|status>",
  example: "➜ +antiemojiadd on\n➜ +antiemojiadd max\n➜ +antiemojiadd status",

  run: async (client, message, args, commandName) => {
    if (!message.guild) return;

    // --- Permissions (même logique que d’hab) ---
    let pass = false;
    if (
      (client.staff && client.staff.includes(message.author.id)) ||
      (client.config?.buyers && client.config.buyers.includes(message.author.id)) ||
      client.db.get(`owner_global_${message.author.id}`) === true ||
      client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true ||
      message.author.id === message.guild.ownerId
    ) pass = true;
    else {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const roles = message.member.roles.cache.map(r => r.id);
        pass = commandPerms.some(p => userPerms[p]?.some(id => roles.includes(id)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") pass = true;
    }
    if (!pass) {
      if (client.noperm?.trim()) {
        const sent = await message.reply({ content: client.noperm, allowedMentions: { parse: [] } });
        const d = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (d > 0) setTimeout(() => sent.delete().catch(()=>{}), d * 1000);
      }
      return;
    }

    const key = `antiemojiadd_${message.guild.id}`;
    let cfg = client.db.get(key);
    if (!cfg || typeof cfg !== "object") {
      // compat "on"/"off"
      if (cfg === "on") cfg = { status: "on", mode: "normal" };
      else if (cfg === "off" || !cfg) cfg = { status: "off", mode: "normal" };
    }

    const sub = (args[0] || "").toLowerCase();

    if (["on","off","max"].includes(sub)) {
      const next = {
        status: sub === "off" ? "off" : "on",
        mode: sub === "max" ? "max" : "normal"
      };
      client.db.set(key, next);
      return void message.reply(
        `AntiEmojiAdd ➜ statut **${next.status}**, mode **${next.mode}**.` 
      );
    }

    if (sub === "status" || !sub) {
      const state = cfg?.status || "off";
      const mode  = cfg?.mode   || "normal";
      return void message.reply(
        `AntiEmojiAdd ➜ statut **${state}**, mode **${mode}**.\n` +
        `Usage: \`${client.prefix}antiemojiadd <on/off/max|status>\``
      );
    }

    return void message.reply(`Utilisation incorrecte : \`${client.prefix}antiemojiadd <on/off/max|status>\``);
  }
};
