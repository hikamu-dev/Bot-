// commands/antiban.js
const Discord = require('discord.js');

module.exports = {
  name: "antiban",
  description: "Configurer l'AntiBan",
  use: "<on/off/max> [seuil_sanction]",
  category: "antiraid",
  usage: "<on/off/max> [seuil_sanction]",
  example: "➜ +antiban on 3\n➜ +antiban max 1\n➜ +antiban off",

  /**
   * @param {import('../../structures/client').Astroia} client
   * @param {Discord.Message} message
   */
  run: async (client, message, args, commandName) => {
    if (!message.guild) return;

    // === Permissions (même logique que tes autres commandes) ===
    let pass = false;
    if (
      (client.staff && client.staff.includes(message.author.id)) ||
      (client.config?.buyers && client.config.buyers.includes(message.author.id)) ||
      message.author.id === message.guild.ownerId ||
      client.db.get(`owner_global_${message.author.id}`) === true ||
      client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true
    ) {
      pass = true;
    } else {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(r => r.id);
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        pass = true;
      }
    }
    if (!pass) {
      if (client.noperm && client.noperm.trim() !== '') {
        const sent = await message.channel.send(client.noperm);
        const delay = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delay > 0) setTimeout(() => sent.delete().catch(()=>{}), delay*1000);
      }
      return;
    }

    // === Args ===
    if (!args[0] || !["on","off","max"].includes(args[0].toLowerCase())) {
      return message.channel.send(`Utilisation incorrecte : \`${client.prefix}antiban <on/off/max> [seuil_sanction]\``);
    }

    const key = `antiban_${message.guild.id}`;
    const prev = client.db.get(key) || { status: "off", mode: "normal", seuil_sanction: 1, epoch: 0 };

    const modeArg = args[0].toLowerCase();
    const seuil = (args[1] !== undefined) ? parseInt(args[1], 10) : (prev.seuil_sanction ?? 1);
    if (!Number.isInteger(seuil) || seuil < 0 || seuil > 100) {
      return message.channel.send("`seuil_sanction` invalide (0-100).");
    }

    const state = {
      status: (modeArg === "off") ? "off" : "on",
      mode:   (modeArg === "max") ? "max" : "normal",
      seuil_sanction: seuil,
      epoch: (prev.epoch || 0) + 1 // reset global des strikes
    };

    client.db.set(key, state);

    return message.channel.send(
      `Config **AntiBan** ➜ statut **${state.status}**, mode **${state.mode}**, sanction≥**${state.seuil_sanction}**`
    );
  }
};
