const { Astroia } = require("../../structures/client/index");
const Discord = require('discord.js');

module.exports = {
    name: 'clean',
    description: 'Supprime les webhooks, threads, salons ou rôles contenant le texte spécifié.',
    usage: 'clean <webhook/thread/channel/role> [name]',
    use: "<webhook/thread/channel/role> [name]",
    example: "➜ clean webhook\n➜ clean thread test\n➜ clean channel test\n➜ clean role test",
    run: async (client, message, args, commandName) => {
      
    let pass = false;

    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) || 
        client.db.get(`owner_global_${message.author.id}`) === true || 
        client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true) {
      pass = true;
    } else {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        pass = true;
      }
    }

    if (!pass) {
        if (client.noperm && client.noperm.trim() !== '') {
            const sentMessage = await message.channel.send(client.noperm);
            const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
            if (delayTime > 0) {
                setTimeout(() => {
                    sentMessage.delete().catch(() => {});
                }, delayTime * 1000);
            }
        }
        return;
    }

        if (args.length < 1) {
            return message.channel.send(`Utilisation incorrecte : \`${client.prefix}clean <webhook/thread/channel/role> [name]\``);
        }

        const targetType = args[0].toLowerCase();
        const name = args[1] || '';
        // Nettoyer les nombres du nom fourni
        const cleanName = name.replace(/\d+/g, '').trim();
        let actionTaken = false;

        switch (targetType) {
            case 'webhook':
                const webhooks = await message.guild.fetchWebhooks();
                webhooks.forEach(webhook => {
                    if (webhook.name.replace(/\d+/g, '').includes(cleanName)) {
                        webhook.delete().then(() => actionTaken = true);
                    }
                });
                break;
            case 'thread':
                const threads = await message.guild.channels.fetchActiveThreads();
                threads.threads.forEach(thread => {
                    if (thread.name.replace(/\d+/g, '').includes(cleanName)) {
                        thread.delete().then(() => actionTaken = true);
                    }
                });
                break;
            case 'channel':
                message.guild.channels.cache.forEach(channel => {
                    if (channel.name.replace(/\d+/g, '').includes(cleanName) && channel.deletable) {
                        channel.delete().then(() => actionTaken = true);
                    }
                });
                break;
            case 'role':
                message.guild.roles.cache.forEach(role => {
                    if (role.name.replace(/\d+/g, '').includes(cleanName) && role.editable) {
                        role.delete().then(() => actionTaken = true);
                    }
                });
                break;
            default:
                return message.channel.send('Type invalide. Utilisez : webhook, thread, channel ou role.');
        }

        if (actionTaken) {
            message.channel.send(`Nettoyage effectué pour les ${targetType}s contenant "${cleanName}".`);
        } else {
            message.channel.send(`Aucun ${targetType} contenant "${cleanName}" n\'a été trouvé ou supprimé.`);
        }
    },
};