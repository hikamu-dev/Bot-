// commands/antinick.js
const Discord = require('discord.js');

module.exports = {
  name: "antinick",
  description: "Activer/Désactiver l'AntiNick (pas de sanction, juste revert).",
  category: "antiraid",
  use: "<on/off/max|status>",
  usage: "<on/off/max|status>",
  example: "➜ +antinick on\n➜ +antinick max\n➜ +antinick status",

  /**
   * @param {import('../../structures/client').Astroia} client
   * @param {Discord.Message} message
   */
  run: async (client, message, args, commandName) => {
    if (!message.guild) return;

    // === Permissions (même logique que tes autres commandes) ===
    let pass = false;
    if (
      (client.staff && client.staff.includes(message.author.id)) ||
      (client.config?.buyers && client.config.buyers.includes(message.author.id)) ||
      client.db.get(`owner_global_${message.author.id}`) === true ||
      client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true ||
      message.author.id === message.guild.ownerId
    ) {
      pass = true;
    } else {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(r => r.id);
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        pass = true;
      }
    }
    if (!pass) {
      if (client.noperm && client.noperm.trim() !== '') {
        const sent = await message.reply({ content: client.noperm, allowedMentions: { parse: [] } });
        const d = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (d > 0) setTimeout(() => sent.delete().catch(()=>{}), d*1000);
      }
      return;
    }

    const key = `antinick.${message.guild.id}`;
    let cfg = client.db.get(key);
    if (!cfg || typeof cfg !== "object") {
      if (cfg === "on") cfg = { status: "on", mode: "normal" };
      else cfg = { status: "off", mode: "normal" };
    }

    const sub = (args[0] || "").toLowerCase();

    if (["on","off","max"].includes(sub)) {
      const next = {
        status: sub === "off" ? "off" : "on",
        mode:   sub === "max" ? "max" : "normal"
      };
      client.db.set(key, next);
      return void message.reply(
        `AntiNick ➜ statut **${next.status}**, mode **${next.mode}**.\n` +
        `Action: *revert du pseudo uniquement (aucune sanction)*.`
      );
    }

    if (sub === "status" || !sub) {
      const state = cfg?.status || "off";
      const mode  = cfg?.mode   || "normal";
      return void message.reply(
        `AntiNick ➜ statut **${state}**, mode **${mode}**.\n` +
        `Usage: \`${client.prefix}antinick <on/off/max|status>\`\n` +
        `Action: *revert du pseudo uniquement (aucune sanction)*`
      );
    }

    return void message.reply(`Utilisation incorrecte : \`${client.prefix}antinick <on/off/max|status>\``);
  }
};
