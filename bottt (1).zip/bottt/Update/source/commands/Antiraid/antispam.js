const { Astroia } = require("../../structures/client/index");
const ms = require('ms');
const Discord = require('discord.js');

module.exports = {
    name: 'antispam',
    description: 'Configure les paramètres de l\'anti-spam.',
    use: '<on/off/max>, antispam <message max> <intervalle>',
    usage: 'antispam <on/off/max> <message max> <intervalle>',
    example: "➜ antispam on 5 10s\n➜ antispam off\n➜ antispam max",
    run: async (client, message, args, commandName) => {
      
    let pass = false;

    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) || 
        client.db.get(`owner_global_${message.author.id}`) === true || 
        client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true) {
      pass = true;
    } else {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        pass = true;
      }
    }

    if (!pass) {
        if (client.noperm && client.noperm.trim() !== '') {
            const sentMessage = await message.channel.send(client.noperm);
            const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
            if (delayTime > 0) {
                setTimeout(() => {
                    sentMessage.delete().catch(() => {});
                }, delayTime * 1000);
            }
        }
        return;
    }
        if (args.length < 1) {
            return message.channel.send(`Utilisation incorectte : \`${client.prefix}antispam <on/off/max>\` ou \`${client.prefix}antispam <message max> <intervalle>\``);
        }

        const antispamData = client.db.get(`antispam_${message.guild.id}`) || {
            message: 4,
            temps: 5000,
            status: 'off'
        };

        // Gestion des commandes simples (on/off/max)
        if (args[0] === 'on') {
            antispamData.status = 'on';
            client.db.set(`antispam_${message.guild.id}`, antispamData);
            return message.channel.send('L\'anti-spam est activé.');
        }

        if (args[0] === 'off') {
            antispamData.status = 'off';
            client.db.set(`antispam_${message.guild.id}`, antispamData);
            return message.channel.send('L\'anti-spam est désactivé.');
        }

        if (args[0] === 'max') {
            antispamData.message = 'max';
            antispamData.temps = 'max';
            client.db.set(`antispam_${message.guild.id}`, antispamData);
            return message.channel.send('Le mode "max" de l\'anti-spam est activé.');
        }

        // Gestion de la configuration personnalisée
        if (args.length < 2) {
            return message.channel.send(`Pour configurer l'anti-spam, utilisez : \`${client.prefix}antispam <message max> <intervalle>\``);
        }

        const maxMessages = parseInt(args[0]);
        const interval = parseInterval(args[1]);

        if (isNaN(maxMessages) || maxMessages <= 0 || isNaN(interval) || interval <= 0) {
            return message.channel.send(`Veuillez fournir des valeurs numériques valides, exemple : \`${client.prefix}antispam 5 1s\``);
        }

        antispamData.message = maxMessages;
        antispamData.temps = interval;
        antispamData.status = 'on'; // On active automatiquement quand on configure
        client.db.set(`antispam_${message.guild.id}`, antispamData);

        return message.channel.send(`Paramètres de l'anti-spam mis à jour : Message Max = ${maxMessages}, Intervalle = ${args[1]}`);
    },
};

function parseInterval(input) {
    if (!input || typeof input !== 'string') return NaN;
    
    const intervalRegex = /^(\d+)([smhdwj])$/;
    const match = input.match(intervalRegex);
    if (!match) return NaN;

    const value = parseInt(match[1]);
    const unit = match[2];

    switch (unit) {
        case 's': return value * 1000; 
        case 'm': return value * 60000; 
        case 'h': return value * 3600000; 
        case 'd': return value * 86400000; 
        case 'j': return value * 86400000;
        case 'w': return value * 604800000; 
        default: return NaN;
    }
}