const Discord = require('discord.js');
const Astroia = require('../../structures/client');

module.exports = {
    name: "unwl",
    aliases: ["unwhitelist"],
    description: "Permet d'enlever un utilisateur de la whitelist",
    use: "<@utilisateur/id>",
    usage: "unwl <@utilisateur/id>",
    example: "➜ unwl @tokyru\n➜ unwl 123456789012345678",
    /**
     * @param {Astroia} client 
     * @param {Discord.Message} message 
     */
    run: async (client, message, args, commandName) => {
      
    let pass = false;

    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) || 
        client.db.get(`owner_global_${message.author.id}`) === true || 
        client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true) {
      pass = true;
    } else {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        pass = true;
      }
    }

    if (!pass) {
        if (client.noperm && client.noperm.trim() !== '') {
            const sentMessage = await message.channel.send(client.noperm);
            const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
            if (delayTime > 0) {
                setTimeout(() => {
                    sentMessage.delete().catch(() => {});
                }, delayTime * 1000);
            }
        }
        return;
    }

        let member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        if (!member || !message.guild.members.cache.has(member.id)) {
            return message.channel.send(await client.lang('tempmute.invalidemembre'));
        }

        // Récupérer la whitelist actuelle
        let wl = client.db.get(`wl.${message.guild.id}`) || [];

        // Vérifier si le membre est whitelisté
        if (!wl.includes(member.id)) {
            return message.channel.send(`**${member.user.username}** n'est pas whiteliste.`);
        }

        // Supprimer de la whitelist
        client.db.delete(`wlmd_${message.guild.id}_${member.id}`);
        client.db.set(`wl.${message.guild.id}`, wl.filter(m => m !== member.id));

        return message.channel.send(`${member.user.username} ${await client.lang(`wl.message5`)}`);
    }
}
