const { Astroia } = require("../../structures/client/index");
const Discord = require('discord.js');

module.exports = {
    name: 'rolelimit',
    description: 'Configure les restrictions de rôles pour les nouveaux membres.',
    use: "<add/list/remove> <@role/role_id> <limit>",
    usage: 'rolelimit <add/list/remove> <@role/role_id> <limit>',
    example: "➜ rolelimit add @role 5\n➜ rolelimit list\n➜ rolelimit remove @role",
    run: async (client, message, args, commandName) => {
      
    let pass = false;

    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) || 
        client.db.get(`owner_global_${message.author.id}`) === true || 
        client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true) {
      pass = true;
    } else {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        pass = true;
      }
    }

    if (!pass) {
        if (client.noperm && client.noperm.trim() !== '') {
            const sentMessage = await message.channel.send(client.noperm);
            const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
            if (delayTime > 0) {
                setTimeout(() => {
                    sentMessage.delete().catch(() => {});
                }, delayTime * 1000);
            }
        }
        return;
    }

        if (args.length < 1) {
            return message.channel.send(`Utilisation incorrecte : \`${client.prefix}rolelimit <add/list/remove> <@role/role_id> <limit>`);
        }

        const action = args[0].toLowerCase();
        const roleLimits = client.db.get(`rolelimits_${message.guild.id}`) || {};

        if (action === 'list') {
            const embed = new Discord.EmbedBuilder()
                .setTitle('Liste des limites de rôles')
                .setColor(client.db.get(`color_${message.guild.id}`) || client.config.default_color)
                .setTimestamp();

            if (Object.keys(roleLimits).length === 0) {
                embed.setDescription('Aucune limite de rôle configurée.');
            } else {
                let description = '';
                for (const [roleId, limit] of Object.entries(roleLimits)) {
                    const role = message.guild.roles.cache.get(roleId);
                    if (role) {
                        //const currentCount = role.members.size;
                        description += `<@&${role.id}> - Limite: ${limit}\n`;
                    }
                }
                embed.setDescription(description);
            }

            return message.channel.send({ embeds: [embed] });
        }

        if (args.length < 3 && (action === 'add' || action === 'remove')) {
            return message.channel.send(`Usage: \`${client.prefix}rolelimit ${action} <@role/role_id> ${action === 'add' ? '<limit>' : ''}\``);
        }

        // Récupération du rôle
        let role;
        const roleArg = args[1];
        
        if (roleArg.startsWith('<@&') && roleArg.endsWith('>')) {
            const roleId = roleArg.slice(3, -1);
            role = message.guild.roles.cache.get(roleId);
        } else if (/^\d+$/.test(roleArg)) {
            role = message.guild.roles.cache.get(roleArg);
        } else {
            role = message.guild.roles.cache.find(r => r.name.toLowerCase() === roleArg.toLowerCase());
        }

        if (!role) {
            return message.channel.send('Rôle introuvable. Utilisez une mention de rôle, un ID ou le nom exact du rôle.');
        }

        if (action === 'add') {
            const limit = parseInt(args[2]);
            if (isNaN(limit) || limit < 1) {
                return message.channel.send('La limite doit être un nombre supérieur à 0.');
            }

            roleLimits[role.id] = limit;
            client.db.set(`rolelimits_${message.guild.id}`, roleLimits);
            
            return message.channel.send(`Limite configurée pour le rôle **${role.name}**: ${limit} personnes maximum.`);
        }

        if (action === 'remove') {
            if (!roleLimits[role.id]) {
                return message.channel.send(`Aucune limite configurée pour le rôle **${role.name}**.`);
            }

            delete roleLimits[role.id];
            client.db.set(`rolelimits_${message.guild.id}`, roleLimits);
            
            return message.channel.send(`Limite supprimée pour le rôle **${role.name}**.`);
        }

        return message.channel.send(`Action invalide. Utilisez: \`${client.prefix}rolelimit <add/list/remove> <@role/role_id> <limit>\``);
    },
};