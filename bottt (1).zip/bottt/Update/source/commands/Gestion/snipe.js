const { Astroia } = require("../../structures/client/index");
const Discord = require('discord.js');

module.exports = {
    name: 'snipe',
    description: 'Affiche tous les messages supprimés dans le salon avec navigation.',
    usage: "snipe",
    /** 
     * @param {Astroia} client
     * @param {Discord.Message} message
     * @param {string[]} args
     */
    run: async (client, message, args, commandName) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) || 
                client.db.get(`owner_global_${message.author.id}`) === true || 

client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        try {
            const channelID = message.channel.id;
            let snipeDataArray = client.snipeMap.get(channelID) || [];
            //console.log('Snipe data array:', snipeDataArray);

            if (!snipeDataArray.length) {
                return message.channel.send("💬 Aucun message récent supprimé dans ce salon. (Vérifiez le stockage)");
            }

            let currentIndex = 0;

            const createEmbed = (index) => {
                const snipeData = snipeDataArray[index];
                const timestamp = Math.floor(snipeData.date / 1000);
                const dynamicTimestamp = `<t:${timestamp}:R>`;

                const embed = new Discord.EmbedBuilder()
                    .setColor(client.color)
                    .setAuthor({ 
                        name: `Auteur : ${snipeData.author.username}`, 
                        iconURL: snipeData.author.avatarURL() 
                    })
                    .setTitle('🔍 Message supprimé')
                    .setFooter(client.footer);

                if (snipeData.content) {
                    embed.addFields({ 
                        name: '📝 Contenu', 
                        value: `\`\`\`\n${snipeData.content}\n\`\`\`` 
                    });
                }

                if (snipeData.attachments && snipeData.attachments.length > 0) {
                    embed.setImage(snipeData.attachments[0]);
                    if (snipeData.attachments.length > 1) {
                        embed.addFields({
                            name: `📎 Pièces jointes (${snipeData.attachments.length})`,
                            value: snipeData.attachments.map((url, i) => `[Fichier ${i+1}](${url})`).join(' • ')
                        });
                    }
                }

                embed.addFields({ 
                    name: '⏰ Timestamp', 
                    value: dynamicTimestamp 
                });

                return embed;
            };

            const row = new Discord.ActionRowBuilder()
                .addComponents(
                    new Discord.ButtonBuilder()
                        .setCustomId('prev')
                        .setLabel('◄')
                        .setStyle(Discord.ButtonStyle.Primary)
                        .setDisabled(currentIndex === 0),
                    new Discord.ButtonBuilder()
                        .setCustomId('counter')
                        .setLabel(`${currentIndex + 1}/${snipeDataArray.length}`)
                        .setStyle(Discord.ButtonStyle.Secondary)
                        .setDisabled(true)
                )
                .addComponents(
                    new Discord.ButtonBuilder()
                        .setCustomId('next')
                        .setLabel('►')
                        .setStyle(Discord.ButtonStyle.Primary)
                        .setDisabled(currentIndex === snipeDataArray.length - 1)
                );

            const sentMessage = await message.channel.send({ embeds: [createEmbed(currentIndex)], components: [row] });

            const filter = i => i.user.id === message.author.id;
            const collector = sentMessage.createMessageComponentCollector({ filter, time: 60000 });

            collector.on('collect', async i => {
                if (i.customId === 'next' && currentIndex < snipeDataArray.length - 1) {
                    currentIndex++;
                } else if (i.customId === 'prev' && currentIndex > 0) {
                    currentIndex--;
                }

                const updatedRow = new Discord.ActionRowBuilder()
                    .addComponents(
                        new Discord.ButtonBuilder()
                            .setCustomId('prev')
                            .setLabel('◄')
                            .setStyle(Discord.ButtonStyle.Primary)
                            .setDisabled(currentIndex === 0),
                        new Discord.ButtonBuilder()
                            .setCustomId('counter')
                            .setLabel(`${currentIndex + 1}/${snipeDataArray.length}`)
                            .setStyle(Discord.ButtonStyle.Secondary)
                            .setDisabled(true)
                    )
                    .addComponents(
                        new Discord.ButtonBuilder()
                            .setCustomId('next')
                            .setLabel('►')
                            .setStyle(Discord.ButtonStyle.Primary)
                            .setDisabled(currentIndex === snipeDataArray.length - 1)
                    );

                await i.update({ embeds: [createEmbed(currentIndex)], components: [updatedRow] });
            });

            collector.on('end', collected => {
                if (sentMessage.editable) {
                    const disabledRow = new Discord.ActionRowBuilder()
                        .addComponents(
                            new Discord.ButtonBuilder()
                                .setCustomId('prev')
                                .setLabel('◄')
                                .setStyle(Discord.ButtonStyle.Primary)
                                .setDisabled(true),
                            new Discord.ButtonBuilder()
                                .setCustomId('counter')
                                .setLabel(`${currentIndex + 1}/${snipeDataArray.length}`)
                                .setStyle(Discord.ButtonStyle.Secondary)
                                .setDisabled(true)
                        )
                        .addComponents(
                            new Discord.ButtonBuilder()
                                .setCustomId('next')
                                .setLabel('►')
                                .setStyle(Discord.ButtonStyle.Primary)
                                .setDisabled(true)
                        );
                    sentMessage.edit({ components: [disabledRow] });
                }
            });

        } catch (error) {
            console.error('Erreur avec la commande snipe:', error);
            return message.channel.send("❌ Une erreur est survenue lors de la récupération des messages.");
        }
    }
};