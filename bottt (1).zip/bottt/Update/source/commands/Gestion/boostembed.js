const ms = require('ms');
const {
    EmbedBuilder,
    ActionRowBuilder,
    StringSelectMenuBuilder,
    ChannelSelectMenuBuilder,
    ComponentType
} = require('discord.js');

module.exports = {
    name: 'boostembed',
    description: 'Configurer le message d\'annonce lors d\'un boost du serveur.',
    usage: 'boostembed',
    run: async (client, message, args, commandName) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) || 
              client.db.get(`owner_global_${message.author.id}`) === true || 

client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        const originalmsg = await message.channel.send("Chargement du panneau...");

        async function updateEmbed() {
            const db = client.db.get(`boostembed_${message.guild.id}`) || client.db.set(`boostembed_${message.guild.id}`, {
                status: false,
                channel: null,
                message: null
            });

            const getStatus = (val) => val ? '✅ Activé' : '❌ Désactivé';
            const channel = message.guild.channels.cache.get(db.channel);
            const channelName = channel ? `${channel.name} - ID ${db.channel}` : 'Non défini';
            const msgContent = db.message || 'Aucun message configuré.';

            const embed = new EmbedBuilder()
                .setTitle('🚀 Paramètres Boost')
                .setColor(client.color)
                .setFooter(client.footer)
                .addFields(
                    { name: '🟢 Statut', value: `\`\`\`\n${getStatus(db.status)}\`\`\``, inline: true },
                    { name: '📥 Salon de boost', value: `\`\`\`\n${channelName}\`\`\``, inline: true },
                    { name: '💬 Message de boost', value: `\`\`\`\n${msgContent}\`\`\``, inline: false }
                );

            const select = new StringSelectMenuBuilder()
                .setCustomId(`boostembed_setup_${message.id}`)
                .setMaxValues(1)
                .addOptions([
                    { label: 'Activer / Désactiver', value: `status_${message.id}`, description: 'Activer ou désactiver l\'annonce de boost' },
                    { label: 'Définir le salon', value: `salon_${message.id}`, description: 'Choisir le salon d\'annonce' },
                    { label: 'Définir le message', value: `message_${message.id}`, description: 'Personnaliser le message de boost' }
                ]);

            const row = new ActionRowBuilder().addComponents(select);
            await originalmsg.edit({ content: null, components: [row], embeds: [embed] });
        }

        await updateEmbed();

        const collector = message.channel.createMessageComponentCollector({
            filter: i => i.user.id === message.author.id,
            componentType: ComponentType.StringSelect,
            time: ms("2m")
        });

        collector.on("collect", async (i) => {
            const db = client.db.get(`boostembed_${message.guild.id}`);

            switch (i.values[0]) {
                case `status_${message.id}`:
                    if (!db.channel || !db.message) {
                        const missing = [];
                        if (!db.channel) missing.push('- `Salon de boost`');
                        if (!db.message) missing.push('- `Message de boost`');
                        return i.reply({ content: `⚠️ Configuration incomplète :\n${missing.join('\n')}`, ephemeral: true });
                    }
                    db.status = !db.status;
                    client.db.set(`boostembed_${message.guild.id}`, db);
                    await i.reply({ content: `🚀 Le système de boost est maintenant ${db.status ? 'activé' : 'désactivé'}.`, ephemeral: true });
                    await updateEmbed(); // Met à jour l’embed avec le nouveau statut
                    break;                

                case `salon_${message.id}`:
                    const salonRow = new ActionRowBuilder().addComponents(
                        new ChannelSelectMenuBuilder()
                            .setChannelTypes(0)
                            .setMinValues(1)
                            .setCustomId(`boostembed_setup_salon_${message.id}`)
                    );
                    return i.reply({ content: '📌 Sélectionnez le salon pour les boosts :', components: [salonRow], ephemeral: true });

                case `message_${message.id}`:
                    return askForMessage(i, db);
            }

            await updateEmbed();
        });

        const salonCollector = message.channel.createMessageComponentCollector({
            filter: i => i.user.id === message.author.id && i.customId === `boostembed_setup_salon_${message.id}`,
            componentType: ComponentType.ChannelSelect,
            time: ms("2m")
        });

        salonCollector.on("collect", async (i) => {
            const db = client.db.get(`boostembed_${message.guild.id}`);
            db.channel = i.values[0];
            client.db.set(`boostembed_${message.guild.id}`, db);
            await updateEmbed();
            try { await i.message.delete(); } catch (e) {}
        });

        async function askForMessage(interaction, db) {
            const sent = await interaction.reply({
                content: `💬 Quel message souhaitez-vous envoyer lors d'un boost ?\n(Utilisez \`${client.prefix}variable\` pour voir les variables disponibles.)`,
                ephemeral: true
            });

            const filter = msg => msg.author.id === message.author.id;
            try {
                const collected = await message.channel.awaitMessages({ filter, max: 1, time: ms("1m"), errors: ['time'] });
                const content = collected.first().content.trim();
                db.message = content;

                client.db.set(`boostembed_${message.guild.id}`, db);
                await updateEmbed();
                await sent.delete();
                await collected.first().delete();
            } catch (error) {
                await sent.delete();
                message.channel.send("❌ Temps expiré ou erreur lors de la saisie.");
            }
        }
    }
};
