const Discord = require('discord.js');
const Astroia = require('../../structures/client/index');
const { example } = require('../Owner/changelimit');

module.exports = {
    name: "autoreact",
    aliases: ["auto-react"],
    description: "Permet de configurer le autoreact",
    use: "<add/remove> <emojis> [#channel/id]",
    usage: "autoreact <add/remove> <emojis> [#channel/id]",
    example: "➜ autoreact add :smile: #general\n➜ autoreact remove :smile: #general\n➜ autoreact list",
    /**
     * @param {Astroia} client
     */
    run: async (client, message, args, commandName) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) || 
              client.db.get(`owner_global_${message.author.id}`) === true || 

client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        if (args.length < 1) {
            return message.channel.send("Utilisation incorrecte : autoreact <add/remove/list> <emojis> [#channel/id]");
        }

        let add = args[0] === "add";
        let remove = args[0] === "del" || args[0] === "remove";
        let list = args[0] === "list";

if (add) {
    if (args.length < 2) {
        return message.channel.send("Utilisation : autoreact add <emoji> [#channel/id]");
    }

    let emojiInput = args[1];
    let channel = message.mentions.channels.first() || message.guild.channels.cache.get(args[2]) || message.channel;

    // Vérification de l'emoji
    const customEmojiMatch = emojiInput.match(/^<a?:\w+:(\d+)>$/);
    const isStandardEmoji = !customEmojiMatch;

    if (!isStandardEmoji) {
        const emojiId = customEmojiMatch[1];
        const emoji = message.guild.emojis.cache.get(emojiId);

        if (!emoji) {
            return message.channel.send("L'emoji personnalisé n'existe pas ou n'est pas sur ce serveur.");
        }
    } else {
        try {
            await message.react(emojiInput);
            await message.reactions.removeAll();
        } catch (e) {
            return message.channel.send("L'emoji spécifié est invalide ou non reconnu.");
        }
    }

    let existingAutoreacts = client.db.get(`autoreact_${message.guild.id}`) || [];
    let alreadyExists = existingAutoreacts.some(r => r.channel === channel.id && r.emoji === emojiInput);

    if (alreadyExists) {
        return message.channel.send(`L'autoreact ${emojiInput} existe déjà dans ${channel}.`);
    }

    client.db.push(`autoreact_${message.guild.id}`, { channel: channel.id, emoji: emojiInput });
    message.channel.send(`${await client.lang(`autoreact.message1`)} ${emojiInput} dans ${channel}`);
}


        if (remove) {
            if (args.length < 2) {
                return message.channel.send("Utilisation : autoreact remove <emoji> [#channel/id]");
            }
            
            let emoji = args[1];
            let channel = message.mentions.channels.first() || message.guild.channels.cache.get(args[2]) || message.channel;
            
            if (!emoji) return message.channel.send("Veuillez spécifier un emoji à supprimer.");
            
            let autoreacts = client.db.get(`autoreact_${message.guild.id}`) || [];
            
            // Chercher l'autoreact à supprimer
            let foundIndex = -1;
            if (args[2]) {
                // Si un channel est spécifié, chercher l'emoji dans ce channel spécifique
                foundIndex = autoreacts.findIndex(r => r.emoji === emoji && r.channel === channel.id);
            } else {
                // Si pas de channel spécifié, chercher l'emoji dans le channel courant
                foundIndex = autoreacts.findIndex(r => r.emoji === emoji && r.channel === message.channel.id);
            }
            
            if (foundIndex === -1) {
                return message.channel.send(`Aucun autoreact trouvé avec l'emoji ${emoji} dans ${channel}.`);
            }
            
            // Supprimer l'autoreact trouvé
            autoreacts.splice(foundIndex, 1);
            client.db.set(`autoreact_${message.guild.id}`, autoreacts);
            
            message.channel.send(`L'autoreact ${emoji} a été supprimé du channel ${channel}.`);
        }

        if (list) {
            let autoreact = client.db.get(`autoreact_${message.guild.id}`);
            if (!autoreact || autoreact.length === 0) return message.channel.send(await client.lang('autoreact.message3'));

            if (autoreact.length > 0) {
                const autoreactList = await Promise.all(autoreact.map(async (r, index) => {
                    try {
                        const channel = await client.channels.fetch(r.channel);
                        const channelName = channel.name;
                        return `**${index + 1} - Autoreact** ${r.emoji}\n \`Channel :\` [\`${channelName}\`](https://discord.com/channels/${message.guild.id}/${r.channel}) (\`${r.channel}\`)\n\`Emoji :\` ${r.emoji}`;
                    } catch (error) {
                        return `**${index + 1} - Autoreact** ${r.emoji}\n \`Channel :\` \`Channel supprimé\` (\`${r.channel}\`)\n\`Emoji :\` ${r.emoji}`;
                    }
                }));

                let Embed = new Discord.EmbedBuilder()
                    .setColor(client.color) 
                    .setTitle(await client.lang('autoreact.message4'))
                    .setDescription(autoreactList.join('\n\n'))
                    .setFooter(client.footer);

                message.channel.send({ embeds: [Embed] });
            }
        }
    }
}