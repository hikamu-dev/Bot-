const { Astroia } = require("../../structures/client/index");
const Discord = require('discord.js');

module.exports = {
    name: 'snipeedit',
    description: 'Affiche les derniers messages modifiés d\'un salon',
    usage: "snipeedit [index] [salon]",
    /** 
     * @param {Astroia} client
     * @param {Discord.Message} message
     * @param {string[]} args
     */
    run: async (client, message, args, commandName) => {
        let pass = false;

        // Autoriser automatiquement les staff, buyers, et owners
        if (client.staff.includes(message.author.id) || 
            client.config.buyers.includes(message.author.id) || 
                    client.db.get(`owner_global_${message.author.id}`) === true || 

    client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {               pass = true;
        } else {
            // Vérifier les permissions personnalisées pour la commande
            const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
            if (commandPerms.length > 0) {
                const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                const userRoles = message.member.roles.cache.map(role => role.id);
                // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
                pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
            } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                // Conserver la compatibilité avec le mode "public"
                pass = true;
            }
        }

        // Refuser l'accès si pas de permission
        if (!pass) {
            if (client.noperm && client.noperm.trim() !== '') {
                const sentMessage = await message.channel.send(client.noperm);
                // Récupérer le délai configuré pour ce serveur
                const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
                if (delayTime > 0) {
                    setTimeout(() => {
                        sentMessage.delete().catch(() => {});
                    }, delayTime * 1000);
                }
            }
            return;
        }

        try {
            // Déterminer le salon cible
            let targetChannel = message.channel;
            let targetIndex = 0;

            // Analyser les arguments
            if (args.length > 0) {
                // Si le premier argument est un nombre, c'est l'index
                if (!isNaN(args[0])) {
                    targetIndex = parseInt(args[0]) - 1;
                    
                    // Si il y a un second argument, c'est le salon
                    if (args[1]) {
                        const channelMention = args[1].replace(/[<>#]/g, '');
                        const channel = message.guild.channels.cache.get(channelMention) || 
                                      message.guild.channels.cache.find(ch => ch.name === args[1]);
                        
                        if (channel) {
                            targetChannel = channel;
                        } else {
                            return message.channel.send("❌ Salon introuvable.");
                        }
                    }
                } else {
                    // Si le premier argument n'est pas un nombre, c'est le salon
                    const channelMention = args[0].replace(/[<>#]/g, '');
                    const channel = message.guild.channels.cache.get(channelMention) || 
                                  message.guild.channels.cache.find(ch => ch.name === args[0]);
                    
                    if (channel) {
                        targetChannel = channel;
                    } else {
                        return message.channel.send("❌ Salon introuvable.");
                    }
                }
            }

            const channelID = targetChannel.id;
            // Vérifier si editMap existe, sinon l'initialiser
            if (!client.editMap) {
                client.editMap = new Map();
            }
            let editDataArray = client.editMap.get(channelID) || [];

            if (!editDataArray.length) {
                const channelName = targetChannel.id === message.channel.id ? "ce salon" : `#${targetChannel.name}`;
                return message.channel.send(`📝 Aucun message récent modifié dans ${channelName}.`);
            }

            // Vérifier l'index si spécifié
            if (targetIndex >= editDataArray.length || targetIndex < 0) {
                return message.channel.send(`❌ Index invalide. Veuillez utiliser un nombre entre 1 et ${editDataArray.length}.`);
            }

            let currentIndex = targetIndex;

            const createEmbed = (index) => {
                const editData = editDataArray[index];
                const timestamp = Math.floor(editData.date / 1000);
                const dynamicTimestamp = `<t:${timestamp}:R>`;

                const embed = new Discord.EmbedBuilder()
                    .setColor(client.color)
                    .setAuthor({ 
                        name: `Auteur : ${editData.author.username}`, 
                        iconURL: editData.author.avatarURL() 
                    })
                    .setTitle('📝 Message modifié')
                    .setFooter(client.footer);

                // Contenu original
                if (editData.oldContent) {
                    embed.addFields({ 
                        name: '📄 Contenu original', 
                        value: `\`\`\`\n${editData.oldContent.length > 1000 ? editData.oldContent.substring(0, 1000) + '...' : editData.oldContent}\n\`\`\`` 
                    });
                }

                // Nouveau contenu
                if (editData.newContent) {
                    embed.addFields({ 
                        name: '📝 Nouveau contenu', 
                        value: `\`\`\`\n${editData.newContent.length > 1000 ? editData.newContent.substring(0, 1000) + '...' : editData.newContent}\n\`\`\`` 
                    });
                }

                // Afficher le salon si différent du salon actuel
                if (targetChannel.id !== message.channel.id) {
                    embed.addFields({ 
                        name: '📍 Salon', 
                        value: `<#${targetChannel.id}>` 
                    });
                }

                embed.addFields({ 
                    name: '⏰ Modifié', 
                    value: dynamicTimestamp 
                });

                return embed;
            };

            // Si un seul message ou index spécifié, pas besoin de navigation
            if (editDataArray.length === 1 || (args.length > 0 && !isNaN(args[0]))) {
                const embed = createEmbed(currentIndex);
                return message.channel.send({ embeds: [embed] });
            }

            // Navigation pour plusieurs messages
            const row = new Discord.ActionRowBuilder()
                .addComponents(
                    new Discord.ButtonBuilder()
                        .setCustomId('prev')
                        .setLabel('◄')
                        .setStyle(Discord.ButtonStyle.Primary)
                        .setDisabled(currentIndex === 0),
                    new Discord.ButtonBuilder()
                        .setCustomId('counter')
                        .setLabel(`${currentIndex + 1}/${editDataArray.length}`)
                        .setStyle(Discord.ButtonStyle.Secondary)
                        .setDisabled(true)
                )
                .addComponents(
                    new Discord.ButtonBuilder()
                        .setCustomId('next')
                        .setLabel('►')
                        .setStyle(Discord.ButtonStyle.Primary)
                        .setDisabled(currentIndex === editDataArray.length - 1)
                );

            const sentMessage = await message.channel.send({ embeds: [createEmbed(currentIndex)], components: [row] });

            const filter = i => i.user.id === message.author.id;
            const collector = sentMessage.createMessageComponentCollector({ filter, time: 60000 });

            collector.on('collect', async i => {
                if (i.customId === 'next' && currentIndex < editDataArray.length - 1) {
                    currentIndex++;
                } else if (i.customId === 'prev' && currentIndex > 0) {
                    currentIndex--;
                }

                const updatedRow = new Discord.ActionRowBuilder()
                    .addComponents(
                        new Discord.ButtonBuilder()
                            .setCustomId('prev')
                            .setLabel('◄')
                            .setStyle(Discord.ButtonStyle.Primary)
                            .setDisabled(currentIndex === 0),
                        new Discord.ButtonBuilder()
                            .setCustomId('counter')
                            .setLabel(`${currentIndex + 1}/${editDataArray.length}`)
                            .setStyle(Discord.ButtonStyle.Secondary)
                            .setDisabled(true)
                    )
                    .addComponents(
                        new Discord.ButtonBuilder()
                            .setCustomId('next')
                            .setLabel('►')
                            .setStyle(Discord.ButtonStyle.Primary)
                            .setDisabled(currentIndex === editDataArray.length - 1)
                    );

                await i.update({ embeds: [createEmbed(currentIndex)], components: [updatedRow] });
            });

            collector.on('end', collected => {
                if (sentMessage.editable) {
                    const disabledRow = new Discord.ActionRowBuilder()
                        .addComponents(
                            new Discord.ButtonBuilder()
                                .setCustomId('prev')
                                .setLabel('◄')
                                .setStyle(Discord.ButtonStyle.Primary)
                                .setDisabled(true),
                            new Discord.ButtonBuilder()
                                .setCustomId('counter')
                                .setLabel(`${currentIndex + 1}/${editDataArray.length}`)
                                .setStyle(Discord.ButtonStyle.Secondary)
                                .setDisabled(true)
                        )
                        .addComponents(
                            new Discord.ButtonBuilder()
                                .setCustomId('next')
                                .setLabel('►')
                                .setStyle(Discord.ButtonStyle.Primary)
                                .setDisabled(true)
                        );
                    sentMessage.edit({ components: [disabledRow] });
                }
            });

        } catch (error) {
            console.error('Erreur avec la commande snipeedit:', error);
            return message.channel.send("❌ Une erreur est survenue lors de la récupération des messages modifiés.");
        }
    }
};