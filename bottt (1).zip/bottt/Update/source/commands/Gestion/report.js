const Discord = require('discord.js');
const Astroia = require('../../structures/client');
const { use } = require('../Owner/changelimit');

module.exports = {
  name: "report",
  description: "Signaler un utilisateur aux modérateurs",
  use: "<@utilisateur/ID> <raison>",
  usage: "report <@utilisateur/ID> <raison>",
  example: "➜ report @tokyru Comportement inapproprié\n➜ report 123456789012345678 Spam",

  /**
   * @param {Astroia} client
   * @param {Discord.Message} message
   * @param {string[]} args
   */
  run: async (client, message, args, commandName) => {
    let pass = false;

    if (
      client.staff.includes(message.author.id) ||
      client.config.buyers.includes(message.author.id) ||
              client.db.get(`owner_global_${message.author.id}`) === true || 

      client.db.get(`owner_${message.author.id}`) === true
    ) {
      pass = true;
    } else {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        pass = commandPerms.some(perm =>
          userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId))
        );
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        pass = true;
      }
    }

if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

    const reportConfig = client.db.get(`report_${message.guild.id}`);
    if (!reportConfig || !reportConfig.status) {
      return message.channel.send('Le système de report n\'est pas activé sur ce serveur.');
    }

    if (!reportConfig.channel) {
      return message.channel.send('Aucun salon de report n\'a été configuré.');
    }

    if (args.length < 2) {
      return message.channel.send('Utilisation: `report <@utilisateur/ID> <raison>`');
    }

    const targetArg = args[0];
    let targetUser;

    if (targetArg.startsWith('<@') && targetArg.endsWith('>')) {
      const userId = targetArg.slice(2, -1).replace('!', '');
      targetUser = await client.users.fetch(userId).catch(() => null);
    } else if (/^\d+$/.test(targetArg)) {
      targetUser = await client.users.fetch(targetArg).catch(() => null);
    }

    if (!targetUser) {
      return message.channel.send('Utilisateur introuvable. Vérifiez l\'ID ou la mention.');
    }

    if (targetUser.id === message.author.id) {
      return message.channel.send('Vous ne pouvez pas vous signaler vous-même.');
    }

    if (targetUser.bot) {
      return message.channel.send('Vous ne pouvez pas signaler un bot.');
    }

    let targetMember = message.guild.members.cache.get(targetUser.id);
    if (!targetMember) {
      try {
        targetMember = await message.guild.members.fetch(targetUser.id);
      } catch (e) {
        targetMember = null;
      }
    }

    const reason = args.slice(1).join(' ');
    if (reason.length > 1000) {
      return message.channel.send('La raison est trop longue (maximum 1000 caractères)');
    }

    const cooldownKey = `report_cooldown_${message.author.id}`;
    const lastReport = client.db.get(cooldownKey);
    const cooldownTime = 5 * 60 * 1000;

    if (lastReport && Date.now() - lastReport < cooldownTime) {
      const remainingTime = Math.ceil((cooldownTime - (Date.now() - lastReport)) / 1000);
      return message.channel.send(`Vous devez attendre encore \`${remainingTime}\` secondes avant de pouvoir signaler à nouveau.`);
    }

    const reportChannel = client.channels.cache.get(reportConfig.channel);
    if (!reportChannel) {
      return message.channel.send('Le salon de report configuré est introuvable.');
    }

    const reportEmbed = new Discord.EmbedBuilder()
      .setColor(client.color)
      .setDescription(
        `🚨 **Nouveau Signalement**\n\n` +
        `👤 **Utilisateur signalé :** ${targetUser.tag} (${targetUser.id})\n` +
        `📝 **Signalé par :** ${message.author.tag} (${message.author.id})\n` +
        `📍 **Salon :** ${message.channel}\n` +
        `📋 **Raison :** ${reason}\n` +
        `📅 **Date :** <t:${Math.floor(Date.now() / 1000)}:F>\n` +
        (targetMember
          ? `🏷️ **Surnom :** ${targetMember.displayName}\n` +
            `📅 **Rejoint le :** <t:${Math.floor(targetMember.joinedTimestamp / 1000)}:F>`
          : `⚠️ **Statut :** Utilisateur non présent sur le serveur`)
      )
      .setFooter({
        text: `ID du signalement: ${Date.now()}`,
        iconURL: message.guild.iconURL({ dynamic: true })
      });

    try {
      const reportMessage = await reportChannel.send({ embeds: [reportEmbed] });

      if (reportConfig.role && reportConfig.role.length > 0) {
        const validRoles = reportConfig.role
          .map(roleId => message.guild.roles.cache.get(roleId))
          .filter(role => role)
          .map(role => `<@&${role.id}>`);

        if (validRoles.length > 0) {
          await reportChannel.send({
            content: `${validRoles.join(' ')} - Nouveau signalement`,
            allowedMentions: { roles: reportConfig.role }
          });
        }
      }

      await message.channel.send('Votre signalement a été envoyé aux modérateurs.');

      client.db.set(cooldownKey, Date.now());

      setTimeout(() => {
        if (message.deletable) {
          message.delete().catch(() => {});
        }
      }, 5000);

    } catch (error) {
      console.error('Erreur lors de l\'envoi du report:', error);
      return message.channel.send('Une erreur est survenue lors de l\'envoi du signalement.');
    }
  }
};
