const Discord = require('discord.js');
const Astroia = require('../../structures/client/index.js');

module.exports = {
    name: 'listembed',
    description: "Affiche la liste des embeds sauvegardés",
    usage: "listembed",

    /**
     * @param {Astroia} client 
     * @param {Discord.Message} message 
     * @param {string[]} args 
     */
    run: async (client, message, args) => {
        let pass = false;

        if (
            client.staff.includes(message.author.id) ||
            client.config.buyers.includes(message.author.id) ||
            client.db.get(`owner_global_${message.author.id}`) === true || 
            client.db.get(`owner_${message.author.id}`) === true
        ) {
            pass = true;
        } else {
            const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${module.exports.name}`) || [];
            if (commandPerms.length > 0) {
                const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                const userRoles = message.member.roles.cache.map(role => role.id);
                pass = commandPerms.some(perm =>
                    userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId))
                );
            } else if (client.db.get(`perm_${module.exports.name}.${message.guild.id}`) === "public") {
                pass = true;
            }
        }

if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        const savedEmbeds = await client.db.get('embeds') || {};
        const embedArray = Object.values(savedEmbeds).filter(e => e?.name?.trim());

        if (embedArray.length === 0) return message.channel.send("Aucun embed enregistré.");

        const embedList = embedArray.map(embed => {
            const buttonCount = embed.linkButtons ? embed.linkButtons.length : 0;
            const buttonText = buttonCount > 0 ? ` (${buttonCount} bouton${buttonCount > 1 ? 's' : ''})` : '';
            return `${embed.name}${buttonText}`;
        }).join('\n');

        const embed = new Discord.EmbedBuilder()
            .setColor(client.color)
            .setFooter(client.footer)
            .setDescription(embedList)
            .setTitle("Liste des embeds");

        const row1 = new Discord.ActionRowBuilder().addComponents(
            new Discord.ButtonBuilder().setCustomId('load_embed').setLabel('📥').setStyle(Discord.ButtonStyle.Success),
            new Discord.ButtonBuilder().setCustomId('reset').setLabel('🔄').setStyle(Discord.ButtonStyle.Primary),
            new Discord.ButtonBuilder().setCustomId('delete_embed').setLabel('🗑️').setStyle(Discord.ButtonStyle.Danger),
        );

        const row2 = new Discord.ActionRowBuilder().addComponents(
            new Discord.ButtonBuilder().setCustomId('send_ephemeral').setLabel('👁️').setStyle(Discord.ButtonStyle.Secondary),
        );

        const msg = await message.channel.send({ embeds: [embed], components: [row1, row2] });

        const collector = msg.createMessageComponentCollector({ filter: i => i.user.id === message.author.id, time: 60000 });

        collector.on('collect', async i => {
            try {
                if (i.replied || i.deferred) return;

                if (i.customId === 'load_embed') {
                    const modal = new Discord.ModalBuilder()
                        .setCustomId('load_embed_modal')
                        .setTitle('Charger un embed')
                        .addComponents(
                            new Discord.ActionRowBuilder().addComponents(
                                new Discord.TextInputBuilder()
                                    .setCustomId('embed_name')
                                    .setLabel("Nom de l'embed *")
                                    .setStyle(Discord.TextInputStyle.Short)
                                    .setRequired(true)
                            ),
                            new Discord.ActionRowBuilder().addComponents(
                                new Discord.TextInputBuilder()
                                    .setCustomId('channel')
                                    .setLabel("Salon (Optionnel)")
                                    .setStyle(Discord.TextInputStyle.Short)
                                    .setRequired(false)
                            )
                        );

                    await i.showModal(modal);

                    let modalInteraction;
                    try {
                        modalInteraction = await i.awaitModalSubmit({ time: 60000, filter: m => m.user.id === message.author.id });
                    } catch (error) {
                        console.log('Modal submit timeout ou annulé');
                        return;
                    }
                    
                    // Vérifier si l'interaction est encore valide
                    if (!modalInteraction || modalInteraction.replied || modalInteraction.deferred) {
                        console.log('Interaction déjà traitée ou invalide');
                        return;
                    }

                    try {
                        await modalInteraction.deferReply({ ephemeral: true });
                    } catch (error) {
                        console.log('Erreur lors du deferReply:', error.message);
                        return;
                    }

                    const embedName = modalInteraction.fields.getTextInputValue('embed_name');
                    
                    // Correction pour gérer le champ optionnel
                    let channelInput = '';
                    try {
                        channelInput = modalInteraction.fields.getTextInputValue('channel');
                    } catch (error) {
                        // Le champ channel n'existe pas ou est vide, on utilise le canal actuel
                        channelInput = '';
                    }
                    
                    const targetChannel = channelInput ? await client.channels.fetch(channelInput.replace(/[<#>]/g, '')).catch(() => null) : message.channel;

                    const embedData = embedArray.find(e => e.name === embedName);
                    if (!embedData) {
                        try {
                            return await modalInteraction.editReply({ content: `Aucun embed trouvé avec le nom \`${embedName}\`.`, ephemeral: true });
                        } catch (error) {
                            console.log('Erreur lors de la réponse:', error.message);
                            return;
                        }
                    }

                    const embedToSend = new Discord.EmbedBuilder()
                        .setTitle(embedData.title || null)
                        .setDescription(embedData.description || null)
                        .setColor(embedData.color || null)
                        .setFooter(embedData.footer ? { text: embedData.footer.text, iconURL: embedData.footer.iconURL } : null)
                        .setImage(embedData.image?.url || null)
                        .setThumbnail(embedData.thumbnail?.url || null)
                        .setAuthor(embedData.author || null)
                        .setFields(embedData.fields || []);

                    // Préparer les composants avec les boutons de lien
                    const components = [];
                    if (embedData.linkButtons && embedData.linkButtons.length > 0) {
                        // Diviser les boutons en groupes de 5 maximum par ligne
                        const buttonRows = [];
                        for (let i = 0; i < embedData.linkButtons.length; i += 5) {
                            const rowButtons = embedData.linkButtons.slice(i, i + 5);
                            const buttonRow = new Discord.ActionRowBuilder();
                            rowButtons.forEach(btn => {
                                buttonRow.addComponents(
                                    new Discord.ButtonBuilder()
                                        .setLabel(btn.label)
                                        .setURL(btn.url)
                                        .setStyle(Discord.ButtonStyle.Link)
                                );
                            });
                            buttonRows.push(buttonRow);
                        }
                        components.push(...buttonRows);
                    }

                    await targetChannel.send({ embeds: [embedToSend], components: components });
                    
                    try {
                        return await modalInteraction.editReply({ content: `L'embed \`${embedName}\` a été envoyé dans ${targetChannel}.`, ephemeral: true });
                    } catch (error) {
                        console.log('Erreur lors de la réponse finale:', error.message);
                    }
                }

                else if (i.customId === 'delete_embed') {
                    const modal = new Discord.ModalBuilder()
                        .setCustomId('delete_embed_modal')
                        .setTitle('Supprimer un embed')
                        .addComponents(
                            new Discord.ActionRowBuilder().addComponents(
                                new Discord.TextInputBuilder()
                                    .setCustomId('embed_name')
                                    .setLabel("Nom de l'embed *")
                                    .setStyle(Discord.TextInputStyle.Short)
                                    .setRequired(true)
                            )
                        );

                    await i.showModal(modal);

                    let modalInteraction;
                    try {
                        modalInteraction = await i.awaitModalSubmit({ time: 60000, filter: m => m.user.id === message.author.id });
                    } catch (error) {
                        console.log('Modal submit timeout ou annulé');
                        return;
                    }
                    
                    if (!modalInteraction || modalInteraction.replied || modalInteraction.deferred) {
                        console.log('Interaction déjà traitée ou invalide');
                        return;
                    }

                    try {
                        await modalInteraction.deferReply({ ephemeral: true });
                    } catch (error) {
                        console.log('Erreur lors du deferReply:', error.message);
                        return;
                    }

                    const embedName = modalInteraction.fields.getTextInputValue('embed_name');
                    const embeds = await client.db.get('embeds') || {};

                    if (embeds[embedName]) {
                        delete embeds[embedName];
                        await client.db.set('embeds', embeds);

                        const updatedEmbeds = Object.values(embeds).filter(e => e?.name?.trim());
                        const updatedEmbedList = updatedEmbeds.length > 0 ? updatedEmbeds.map(e => {
                            const buttonCount = e.linkButtons ? e.linkButtons.length : 0;
                            const buttonText = buttonCount > 0 ? ` (${buttonCount} bouton${buttonCount > 1 ? 's' : ''})` : '';
                            return `${e.name}${buttonText}`;
                        }).join('\n') : 'Aucune liste disponible.';
                        
                        const updatedEmbed = new Discord.EmbedBuilder()
                            .setColor(client.color)
                            .setFooter(client.footer)
                            .setDescription(updatedEmbedList)
                            .setTitle("Liste des embeds");

                        await msg.edit({ embeds: [updatedEmbed], components: [row1, row2] });
                        
                        try {
                            return await modalInteraction.editReply({ content: `L'embed \`${embedName}\` a été supprimé avec succès.`, ephemeral: true });
                        } catch (error) {
                            console.log('Erreur lors de la réponse:', error.message);
                        }
                    } else {
                        try {
                            return await modalInteraction.editReply({ content: `Aucun embed trouvé avec le nom \`${embedName}\`.`, ephemeral: true });
                        } catch (error) {
                            console.log('Erreur lors de la réponse:', error.message);
                        }
                    }
                }

                else if (i.customId === 'reset') {
                    try {
                        await i.deferReply({ ephemeral: true });
                    } catch (error) {
                        console.log('Erreur lors du deferReply:', error.message);
                        return;
                    }

                    const embeds = await client.db.get('embeds') || {};
                    if (Object.keys(embeds).length === 0) {
                        try {
                            return await i.editReply({ content: 'Aucun embed à réinitialiser.', ephemeral: true });
                        } catch (error) {
                            console.log('Erreur lors de la réponse:', error.message);
                        }
                        return;
                    }

                    await client.db.set('embeds', {});
                    const clearedEmbed = new Discord.EmbedBuilder()
                        .setColor(client.color)
                        .setFooter(client.footer)
                        .setDescription('Aucune liste disponible.')
                        .setTitle("Liste des embeds");
                    await msg.edit({ embeds: [clearedEmbed], components: [row1, row2] });
                    
                    try {
                        return await i.editReply({ content: 'Tous les embeds ont été réinitialisés avec succès.', ephemeral: true });
                    } catch (error) {
                        console.log('Erreur lors de la réponse:', error.message);
                    }
                }

                else if (i.customId === 'send_ephemeral') {
                    const modal = new Discord.ModalBuilder()
                        .setCustomId('send_ephemeral_modal')
                        .setTitle('Envoyer un embed en éphémère')
                        .addComponents(
                            new Discord.ActionRowBuilder().addComponents(
                                new Discord.TextInputBuilder()
                                    .setCustomId('embed_name')
                                    .setLabel("Nom de l'embed *")
                                    .setStyle(Discord.TextInputStyle.Short)
                                    .setRequired(true)
                            )
                        );

                    await i.showModal(modal);

                    let modalInteraction;
                    try {
                        modalInteraction = await i.awaitModalSubmit({ time: 60000, filter: m => m.user.id === message.author.id });
                    } catch (error) {
                        console.log('Modal submit timeout ou annulé');
                        return;
                    }
                    
                    if (!modalInteraction || modalInteraction.replied || modalInteraction.deferred) {
                        console.log('Interaction déjà traitée ou invalide');
                        return;
                    }

                    try {
                        await modalInteraction.deferReply({ ephemeral: true });
                    } catch (error) {
                        console.log('Erreur lors du deferReply:', error.message);
                        return;
                    }

                    const embedName = modalInteraction.fields.getTextInputValue('embed_name');
                    const embedData = embedArray.find(e => e.name === embedName);

                    if (!embedData) {
                        try {
                            return await modalInteraction.editReply({ content: `Aucun embed trouvé avec le nom \`${embedName}\`.`, ephemeral: true });
                        } catch (error) {
                            console.log('Erreur lors de la réponse:', error.message);
                        }
                        return;
                    }

                    const embedToSend = new Discord.EmbedBuilder()
                        .setTitle(embedData.title || null)
                        .setDescription(embedData.description || null)
                        .setColor(embedData.color || null)
                        .setFooter(embedData.footer ? { text: embedData.footer.text, iconURL: embedData.footer.iconURL } : null)
                        .setImage(embedData.image?.url || null)
                        .setThumbnail(embedData.thumbnail?.url || null)
                        .setAuthor(embedData.author || null)
                        .setFields(embedData.fields || []);

                    // Préparer les composants avec les boutons de lien pour l'affichage éphémère
                    const components = [];
                    if (embedData.linkButtons && embedData.linkButtons.length > 0) {
                        // Diviser les boutons en groupes de 5 maximum par ligne
                        const buttonRows = [];
                        for (let i = 0; i < embedData.linkButtons.length; i += 5) {
                            const rowButtons = embedData.linkButtons.slice(i, i + 5);
                            const buttonRow = new Discord.ActionRowBuilder();
                            rowButtons.forEach(btn => {
                                buttonRow.addComponents(
                                    new Discord.ButtonBuilder()
                                        .setLabel(btn.label)
                                        .setURL(btn.url)
                                        .setStyle(Discord.ButtonStyle.Link)
                                );
                            });
                            buttonRows.push(buttonRow);
                        }
                        components.push(...buttonRows);
                    }

                    try {
                        return await modalInteraction.editReply({ embeds: [embedToSend], components: components, ephemeral: true });
                    } catch (error) {
                        console.log('Erreur lors de la réponse:', error.message);
                    }
                }

            } catch (err) {
                console.error('Erreur Interaction:', err);
                try {
                    if (!i.replied && !i.deferred) {
                        await i.reply({ content: 'Une erreur est survenue.', ephemeral: true });
                    }
                } catch (replyError) {
                    console.log('Erreur lors de la réponse d\'erreur:', replyError.message);
                }
            }
        });

        collector.on('end', () => {
            const disabledComponents = msg.components.map(row => {
                // Recrée une ActionRowBuilder
                const actionRow = new Discord.ActionRowBuilder();
                
                // Pour chaque bouton dans la rangée, recrée un ButtonBuilder désactivé
                row.components.forEach(component => {
                    const button = new Discord.ButtonBuilder()
                        .setCustomId(component.customId)
                        .setLabel(component.label)
                        .setStyle(component.style)
                        .setDisabled(true); // désactiver le bouton
                    
                    if (component.emoji) button.setEmoji(component.emoji);
                    actionRow.addComponents(button);
                });

                return actionRow;
            });

            msg.edit({ components: disabledComponents }).catch(() => {});
        });
    },
};