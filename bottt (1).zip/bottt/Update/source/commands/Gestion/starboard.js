const {
    PermissionFlagsBits,
    ChannelType,
    EmbedBuilder,
    StringSelectMenuBuilder,
    ActionRowBuilder,
    ComponentType
} = require('discord.js');

module.exports = {
    name: 'starboard',
    description: 'Configurer le système de starboard',
    run: async (client, message, args) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
        client.db.get(`owner_global_${message.author.id}`) === true || 
client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}
        const guildId = message.guild.id;

        const getConfigEmbed = () => {
            const currentChannelId = client.db.get(`starboard_channel_${guildId}`);
            const currentEmoji = client.db.get(`starboard_emoji_${guildId}`) || '⭐';
            const currentCount = client.db.get(`starboard_count_${guildId}`) || 3;
            const currentEnabled = client.db.get(`starboard_enabled_${guildId}`) ?? false;
            const currentChannel = currentChannelId ? `<#${currentChannelId}>` : '*Non défini*';

            return new EmbedBuilder()
                .setTitle('📌 Configuration du Starboard')
                .setDescription('Utilisez le menu déroulant ci-dessous pour configurer le système de starboard.')
                .addFields(
                    { name: 'Salon du starboard', value: currentChannel, inline: true },
                    { name: 'Emoji utilisé', value: currentEmoji, inline: true },
                    { name: 'Réactions requises', value: currentCount.toString(), inline: true },
                    { name: 'État', value: currentEnabled ? '✅ Activé' : '❌ Désactivé', inline: true }
                )
                .setColor(client.color || '#FFD700')
                .setFooter({ text: 'Configuration interactive – expire dans 60 secondes' })
                .setTimestamp();
        };

        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('starboard_config')
            .setPlaceholder('Sélectionnez une option à configurer')
            .addOptions([
                {
                    label: 'Définir le salon',
                    value: 'set_channel',
                    description: 'Choisir le salon du starboard',
                },
                {
                    label: 'Définir l’emoji',
                    value: 'set_emoji',
                    description: 'Choisir l’emoji pour déclencher le starboard',
                },
                {
                    label: 'Définir le nombre de réactions',
                    value: 'set_count',
                    description: 'Nombre de réactions nécessaires',
                },
                {
                    label: 'Activer/Désactiver',
                    value: 'toggle_starboard',
                    description: 'Activer ou désactiver le système',
                },
            ]);

        const row = new ActionRowBuilder().addComponents(selectMenu);

        let configMessage = await message.channel.send({
            embeds: [getConfigEmbed()],
            components: [row],
        });

        const collector = configMessage.createMessageComponentCollector({
            componentType: ComponentType.StringSelect,
            time: 60000,
        });

        collector.on('collect', async (interaction) => {
            if (interaction.user.id !== message.author.id) {
                return interaction.reply({ content: "❌ Vous ne pouvez pas utiliser ce menu.", ephemeral: true });
            }

            const filter = m => m.author.id === message.author.id;

            switch (interaction.values[0]) {
                case 'set_channel': {
                        const promptMsg = await message.channel.send('💬 Mentionnez le salon pour le starboard.');
                        await interaction.deferUpdate();
                        const collected = await message.channel.awaitMessages({ filter, max: 1, time: 15000 });
                    try {
                        await promptMsg.delete();
                    } catch {}
                    const mentioned = collected.first()?.mentions.channels.first();
                    if (mentioned && mentioned.type === ChannelType.GuildText) {
                        client.db.set(`starboard_channel_${guildId}`, mentioned.id);
                        message.channel.send(`✅ Salon du starboard défini sur ${mentioned}.`)
                        .then(msg => setTimeout(() => msg.delete().catch(() => {}), 2000));
                    } else {
                        message.channel.send('❌ Salon invalide.');
                    }
                    break;
                }
                case 'set_emoji': {
                    const promptMsg = await message.channel.send('🌟 Envoyez l\'emoji à utiliser pour le starboard.');
                    await interaction.deferUpdate();
                    const collected = await message.channel.awaitMessages({ filter, max: 1, time: 15000 });
                    try {
                        await promptMsg.delete();
                    } catch {}
                    const emoji = collected.first()?.content.trim();
                    if (emoji) {
                        client.db.set(`starboard_emoji_${guildId}`, emoji);
                        message.channel.send(`✅ Emoji défini sur ${emoji}`)
                        .then(msg => setTimeout(() => msg.delete().catch(() => {}), 2000));
                    } else {
                        message.channel.send('❌ Emoji invalide.');
                    }
                    break;
                }
                case 'set_count': {
                    const promptMsg = await message.channel.send('🔢 Entrez le nombre de réactions minimum requis.');
                    await interaction.deferUpdate();
                    const collected = await message.channel.awaitMessages({ filter, max: 1, time: 15000 });
                    try {
                        await promptMsg.delete();
                    } catch {}
                    const number = parseInt(collected.first()?.content);
                    if (!isNaN(number) && number > 0) {
                        client.db.set(`starboard_count_${guildId}`, number);
                        message.channel.send(`✅ Nombre de réactions requis défini sur ${number}`)
                        .then(msg => setTimeout(() => msg.delete().catch(() => {}), 2000))
                    } else {
                        message.channel.send('❌ Nombre invalide.');
                    }
                    break;
                }
                case 'toggle_starboard': {
                    const current = client.db.get(`starboard_enabled_${guildId}`) ?? false;
                    client.db.set(`starboard_enabled_${guildId}`, !current);
                    message.channel.send(`✅ Le starboard est maintenant **${!current ? 'activé' : 'désactivé'}**.`)
                    .then(msg => setTimeout(() => msg.delete().catch(() => {}), 2000));
                    break;
                }
            }

            // Mettre à jour l'embed après modification
            configMessage = await configMessage.edit({ embeds: [getConfigEmbed()] });
        });

        collector.on('end', () => {
            // Récupérer le select menu actuel et le désactiver
            const disabledRow = new ActionRowBuilder().addComponents(
                selectMenu.setDisabled(true)
            );
        
            // Rééditer le message avec le menu désactivé (grisé)
            configMessage.edit({ components: [disabledRow] }).catch(() => {});
        });
    },
};        
