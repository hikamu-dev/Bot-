const { ActionRowBuilder, StringSelectMenuBuilder, EmbedBuilder, Message, ButtonBuilder, ChannelSelectMenuBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const Astroia = require('../../structures/client/index');

module.exports = {
    name: 'embed',
    aliases: ["createembed", "embedbuilder", "builder"],
    description: "Permet de créer un embed personnalisé",
    /**
     *
     * @param {Astroia} client
     * @param {Message} message
     * @param {string[]} args
     */
    run: async (client, message, args) => {
        let pass = false;

    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) || 
        client.db.get(`owner_global_${message.author.id}`) === true || 
client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
        } else {
            const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${module.exports.name}`) || [];
            if (commandPerms.length > 0) {
                const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                const userRoles = message.member.roles.cache.map(role => role.id);
                pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
            } else if (client.db.get(`perm_${module.exports.name}.${message.guild.id}`) === "public") {
                pass = true;
            }
        }

if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        const embed = new EmbedBuilder()
            .setColor(client.color)
            .setDescription('** **');

        // Tableau pour stocker les boutons de lien
        let linkButtons = [];

        const row = new ActionRowBuilder()
            .addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId('options')
                    .addOptions([
                        { label: 'Modifier le titre', emoji: "✏", value: 'titre' },
                        { label: 'Modifier la description', emoji: "💭", value: 'description' },
                        { label: 'Modifier la couleur', emoji: "⚫", value: 'color' },
                        { label: 'Modifier l\'image', emoji: "🖼", value: 'image' },
                        { label: 'Modifier le thumbnail', emoji: "🗺", value: 'thumbnail' },
                        { label: 'Modifier l\'auteur', emoji: "✂", value: 'auteur' },
                        { label: 'Modifier le footer', emoji: "🔻", value: 'footer' },
                        { label: 'Ajouter un field', emoji: "⤵️", value: 'addfield' },
                        { label: 'Supprimer un field', emoji: "⤴️", value: 'removefield' },
                        { label: 'Ajouter un bouton de lien', emoji: "➕", value: 'addlinkbutton' },
                        { label: 'Supprimer un bouton de lien', emoji: "➖", value: 'removelinkbutton' },
                        { label: 'Copier un embed', emoji: "💉", value: 'copy' },
                    ]),
            );

        const rowButton = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('yep')
                    .setStyle(2)
                    .setLabel('✅ Valider'),
                new ButtonBuilder()
                    .setCustomId('nop')
                    .setStyle(4)
                    .setLabel('❌ Annuler'),
                new ButtonBuilder()
                    .setCustomId('save')
                    .setStyle(3)
                    .setLabel('💾 Sauvegarder')
            );

        const msg = await message.channel.send({ content: ``, embeds: [embed], components: [row, rowButton] });

        const collector = msg.createMessageComponentCollector();
        collector.on('collect', async i => {
            if (i.user.id !== message.author.id) {
                return i.reply({ content: await client.lang('interaction'), flags: 64 });
            }

            if (i.customId === 'options') {
                await i.deferUpdate().catch(err => {
                    console.error('Failed to defer interaction:', err);
                });

                const option = i.values[0];
                switch (option) {
                    case 'titre':
                        await handleTitle(msg, message, embed);
                        break;
                    case 'description':
                        await handleDescription(msg, message, embed);
                        break;
                    case 'color':
                        await handleColor(msg, message, embed);
                        break;
                    case 'image':
                        await handleImage(msg, message, embed);
                        break;
                    case 'thumbnail':
                        await handleThumbnail(msg, message, embed);
                        break;
                    case 'auteur':
                        await handleAuthor(msg, message, embed);
                        break;
                    case 'footer':
                        await handleFooter(msg, message, embed);
                        break;
                    case 'addfield':
                        await handleAddField(msg, message, embed);
                        break;
                    case 'removefield':
                        await handleRemoveField(msg, message, embed);
                        break;
                    case 'addlinkbutton':
                        await handleAddLinkButton(msg, message, embed, linkButtons);
                        break;
                    case 'removelinkbutton':
                        await handleRemoveLinkButton(msg, message, embed, linkButtons);
                        break;
                    case 'copy':
                        await handleCopy(msg, message, embed);
                        break;
                }
                return;
            }

            if (i.customId === 'yep') {
                await i.update({
                    content: 'Merci de choisir un channel où l\'embed sera envoyé.',
                    components: [
                        new ActionRowBuilder().addComponents(
                            new ChannelSelectMenuBuilder()
                                .setCustomId('channel-send')
                                .setMinValues(1)
                                .setMaxValues(1)
                                .addChannelTypes(0)
                        ),
                    ],
                });
            }

            if (i.customId === 'nop') {
                await i.message.delete().catch(() => {});
            }

            if (i.customId === 'channel-send') {
                await i.deferUpdate();
                const channeltosend = client.channels.cache.get(i.values[0]);
                const embeds = i.message.embeds;
                if (embeds && embeds.length > 0) {
                    const embedToSend = embeds[0];
                    
                    // Préparer les composants avec les boutons de lien
                    const components = [];
                    if (linkButtons.length > 0) {
                        // Diviser les boutons en groupes de 5 maximum par ligne
                        const buttonRows = [];
                        for (let i = 0; i < linkButtons.length; i += 5) {
                            const rowButtons = linkButtons.slice(i, i + 5);
                            const buttonRow = new ActionRowBuilder();
                            rowButtons.forEach(btn => {
                                buttonRow.addComponents(
                                    new ButtonBuilder()
                                        .setLabel(btn.label)
                                        .setURL(btn.url)
                                        .setStyle(5) // Style Link
                                );
                            });
                            buttonRows.push(buttonRow);
                        }
                        components.push(...buttonRows);
                    }
                    
                    channeltosend.send({ embeds: [embedToSend], components: components }).then(() => {
                        msg.edit({
                            content: `L'embed vient d'être envoyé`,
                            components: [],
                        });
                    }).catch(error => {
                        console.error('Une erreur s\'est produite:', error);
                    });
                } else {
                    console.error('Aucun embed trouvé dans le message d\'origine.');
                }
            }

            if (i.customId === 'save') {
                const modal = new ModalBuilder()
                    .setCustomId('save_embed_modal')
                    .setTitle('Sauvegarder un embed');

                const embedNameInput = new TextInputBuilder()
                    .setCustomId('embed_name')
                    .setLabel("Nom de l'embed *")
                    .setStyle(TextInputStyle.Short)
                    .setRequired(true)
                    .setPlaceholder("Entrez un nom unique pour l'embed");

                const actionRow = new ActionRowBuilder().addComponents(embedNameInput);

                modal.addComponents(actionRow);

                await i.showModal(modal);

                try {
                    const modalInteraction = await i.awaitModalSubmit({
                        filter: (modalInt) => modalInt.customId === 'save_embed_modal' && modalInt.user.id === message.author.id,
                        time: 60000
                    });

                    const embedName = modalInteraction.fields.getTextInputValue('embed_name').trim();
                    if (!embedName) {
                        await modalInteraction.reply({ content: 'Le nom de l\'embed ne peut pas être vide.', ephemeral: true });
                        return;
                    }

                    const existingEmbed = await client.db.get(`embeds.${embedName}`);
                    if (existingEmbed) {
                        await modalInteraction.reply({ content: `Un embed avec le nom \`${embedName}\` existe déjà. Choisissez un autre nom.`, ephemeral: true });
                        return;
                    }

                    // Ajouter le nom et les boutons à l'objet embed avant sauvegarde
                    const embedData = embed.toJSON();
                    embedData.name = embedName;
                    embedData.linkButtons = linkButtons; // Sauvegarder les boutons de lien
                    await client.db.set(`embeds.${embedName}`, embedData);
                    await modalInteraction.reply({ content: `L'embed a été sauvegardé sous le nom \`${embedName}\`.`, ephemeral: true });
                } catch (error) {
                    console.error('Erreur lors de l\'attente du modal:', error);
                    await i.followUp({ content: 'La sauvegarde a expiré ou a échoué.', ephemeral: true }).catch(() => {});
                }
            }
        });

        // [Les fonctions helper restent identiques - parseColor, handleTitle, handleDescription, etc.]
        // Je les omets ici pour la concision mais elles restent inchangées

        async function parseColor(colorInput) {
            const hex = colorInput.replace(/^#/, '');
            const hexRegex = /^[0-9A-Fa-f]{6}$/;
            if (!hexRegex.test(hex)) {
                return null;
            }
            return parseInt(hex, 16);
        }

        async function handleTitle(msg, message, embed) {
            const replyTitle = await msg.reply('Merci de me donner le nouveau titre de l\'embed');
            const responseTitle = message.channel.createMessageCollector(m => m.author.id === message.author.id, { time: 60000 });

            responseTitle.on('collect', async m => {
                const title = m.content.trim();
                if (title.length > 256) {
                    await message.reply('Vous ne pouvez pas mettre plus de 256 caractères.');
                } else if (title) {
                    embed.setTitle(title);
                    await msg.edit({ embeds: [embed] });
                } else {
                    await message.channel.send('Erreur: Titre non valide.');
                }
                await m.delete().catch(() => {});
                await replyTitle.delete().catch(() => {});
                responseTitle.stop();
            });
        }

        async function handleDescription(msg, message, embed) {
            const replyDescription = await msg.reply('Entrez la nouvelle description de l\'embed :');
            const responseDescription = message.channel.createMessageCollector(m => m.author.id === message.author.id, { time: 60000 });

            responseDescription.on('collect', async m => {
                const description = m.content.trim();
                if (description.length > 4096) {
                    await message.reply('Vous ne pouvez pas mettre plus de 4096 caractères.');
                } else if (description) {
                    embed.setDescription(description);
                    await msg.edit({ embeds: [embed] });
                } else {
                    await message.channel.send('Erreur: Description non valide.');
                }
                await m.delete().catch(() => {});
                await replyDescription.delete().catch(() => {});
                responseDescription.stop();
            });
        }

        async function handleColor(msg, message, embed) {
            const replyColor = await msg.reply('Merci de me donner la nouvelle couleur de l\'embed (format hexadécimal, ex: #ff0000)');
            const responseColor = message.channel.createMessageCollector(m => m.author.id === message.author.id, { time: 60000 });

            responseColor.on('collect', async m => {
                const color = m.content.trim();
                const colorValue = await parseColor(color);
                if (colorValue !== null) {
                    embed.setColor(colorValue);
                    await msg.edit({ embeds: [embed] });
                } else {
                    await message.channel.send('Couleur invalide. Assurez-vous que la couleur est en format hexadécimal (ex: #ff0000).');
                }
                await m.delete().catch(() => {});
                await replyColor.delete().catch(() => {});
                responseColor.stop();
            });
        }

        async function handleImage(msg, message, embed) {
            const replyImage = await msg.reply('Merci de me donner le lien de la nouvelle image de l\'embed');
            const responseImage = message.channel.createMessageCollector(m => m.author.id === message.author.id, { time: 60000 });

            responseImage.on('collect', async m => {
                const imageUrl = m.attachments.first()?.url || m.content.trim();
                if (imageUrl) {
                    embed.setImage(imageUrl);
                    await msg.edit({ embeds: [embed] });
                } else {
                    await message.channel.send('Erreur: Lien de l\'image non valide.');
                }
                await m.delete().catch(() => {});
                await replyImage.delete().catch(() => {});
                responseImage.stop();
            });
        }

        async function handleThumbnail(msg, message, embed) {
            const replyThumbnail = await msg.reply('Merci de me donner le lien du nouveau thumbnail de l\'embed');
            const responseThumbnail = message.channel.createMessageCollector(m => m.author.id === message.author.id, { time: 60000 });

            responseThumbnail.on('collect', async m => {
                const thumbnailUrl = m.attachments.first()?.url || m.content.trim();
                if (thumbnailUrl) {
                    embed.setThumbnail(thumbnailUrl);
                    await msg.edit({ embeds: [embed] });
                } else {
                    await message.channel.send('Erreur: Lien du thumbnail non valide.');
                }
                await m.delete().catch(() => {});
                await replyThumbnail.delete().catch(() => {});
                responseThumbnail.stop();
            });
        }

        async function handleAuthor(msg, message, embed) {
            const replyAskName = await msg.reply('Merci de me donner le nom de l\'auteur de l\'embed. Si vous ne souhaitez pas ajouter d\'auteur, répondez "non".');
            const responseName = message.channel.createMessageCollector(m => m.author.id === message.author.id, { time: 60000 });

            responseName.on('collect', async m => {
                const nameResponse = m.content.trim();
                if (nameResponse.toLowerCase() === 'non') {
                    await replyAskName.delete().catch(() => {});
                    responseName.stop();
                    return;
                }

                embed.setAuthor({ name: nameResponse });
                await msg.edit({ embeds: [embed] });
                await replyAskName.delete().catch(() => {});
                await m.delete().catch(() => {});
                responseName.stop();
            });
        }

        async function handleFooter(msg, message, embed) {
            const replyFooterText = await msg.reply("Quel texte voulez-vous ajouter au footer de cet embed ?");
            const footerTextCollector = message.channel.createMessageCollector(m => m.author.id === message.author.id, { max: 1, time: 120000 });

            footerTextCollector.on('collect', async collectedText => {
                const footerText = collectedText.content.trim();
                if (!footerText) {
                    await message.channel.send("Vous n'avez pas fourni de texte pour le footer.");
                    await replyFooterText.delete().catch(() => {});
                    return;
                }

                embed.setFooter({ text: footerText });
                await msg.edit({ embeds: [embed] });
                await replyFooterText.delete().catch(() => {});
                footerTextCollector.stop();
            });
        }

        async function handleAddField(msg, message, embed) {
            if (embed.data.fields && embed.data.fields.length >= 25) {
                await message.channel.send('Vous ne pouvez pas ajouter plus de 25 fields à un embed.');
                return;
            }

            const replyFieldName = await msg.reply('Merci de me donner le nom du field à ajouter :');
            const responseFieldName = message.channel.createMessageCollector(m => m.author.id === message.author.id, { time: 60000 });

            responseFieldName.on('collect', async m => {
                const fieldName = m.content.trim();
                if (fieldName.length > 256) {
                    await message.reply('Le nom du field ne peut pas dépasser 256 caractères.');
                    await m.delete().catch(() => {});
                    return;
                }

                if (!fieldName) {
                    await message.channel.send('Erreur: Nom du field non valide.');
                    await m.delete().catch(() => {});
                    await replyFieldName.delete().catch(() => {});
                    responseFieldName.stop();
                    return;
                }

                await m.delete().catch(() => {});
                await replyFieldName.delete().catch(() => {});
                responseFieldName.stop();

                const replyFieldValue = await msg.reply('Merci de me donner la valeur du field :');
                const responseFieldValue = message.channel.createMessageCollector(m => m.author.id === message.author.id, { time: 60000 });

                responseFieldValue.on('collect', async m => {
                    const fieldValue = m.content.trim();
                    if (fieldValue.length > 1024) {
                        await message.reply('La valeur du field ne peut pas dépasser 1024 caractères.');
                        await m.delete().catch(() => {});
                        return;
                    }

                    if (!fieldValue) {
                        await message.channel.send('Erreur: Valeur du field non valide.');
                        await m.delete().catch(() => {});
                        await replyFieldValue.delete().catch(() => {});
                        responseFieldValue.stop();
                        return;
                    }

                    await m.delete().catch(() => {});
                    await replyFieldValue.delete().catch(() => {});
                    responseFieldValue.stop();

                    const replyFieldInline = await msg.reply('Le field doit-il être inline ? (oui/non)');
                    const responseFieldInline = message.channel.createMessageCollector(m => m.author.id === message.author.id, { time: 60000 });

                    responseFieldInline.on('collect', async m => {
                        const inlineResponse = m.content.trim().toLowerCase();
                        const isInline = inlineResponse === 'oui' || inlineResponse === 'yes' || inlineResponse === 'o';

                        embed.addFields({ name: fieldName, value: fieldValue, inline: isInline });
                        await msg.edit({ embeds: [embed] });

                        await m.delete().catch(() => {});
                        await replyFieldInline.delete().catch(() => {});
                        responseFieldInline.stop();
                    });
                });
            });
        }

        async function handleRemoveField(msg, message, embed) {
            if (!embed.data.fields || embed.data.fields.length === 0) {
                await message.channel.send('Aucun field à supprimer dans cet embed.');
                return;
            }

            let fieldsList = '';
            embed.data.fields.forEach((field, index) => {
                fieldsList += `${index + 1}. ${field.name}\n`;
            });

            const replyRemoveField = await msg.reply(`Voici la liste des fields :\n\`\`\`\n${fieldsList}\`\`\`\nMerci de me donner le numéro du field à supprimer :`);
            const responseRemoveField = message.channel.createMessageCollector(m => m.author.id === message.author.id, { time: 60000 });

            responseRemoveField.on('collect', async m => {
                const fieldIndex = parseInt(m.content.trim());
                
                if (isNaN(fieldIndex) || fieldIndex < 1 || fieldIndex > embed.data.fields.length) {
                    await message.channel.send('Numéro de field invalide. Veuillez choisir un numéro entre 1 et ' + embed.data.fields.length + '.');
                    await m.delete().catch(() => {});
                    return;
                }

                embed.data.fields.splice(fieldIndex - 1, 1);
                await msg.edit({ embeds: [embed] });

                await m.delete().catch(() => {});
                await replyRemoveField.delete().catch(() => {});
                responseRemoveField.stop();
            });
        }

        async function handleAddLinkButton(msg, message, embed, linkButtons) {
            if (linkButtons.length >= 25) {
                await message.channel.send('Vous ne pouvez pas ajouter plus de 25 boutons de lien.');
                return;
            }

            const replyButtonName = await msg.reply('Merci de me donner le nom du bouton :');
            const responseButtonName = message.channel.createMessageCollector(m => m.author.id === message.author.id, { time: 60000 });

            responseButtonName.on('collect', async m => {
                const buttonName = m.content.trim();
                if (buttonName.length > 80) {
                    await message.reply('Le nom du bouton ne peut pas dépasser 80 caractères.');
                    await m.delete().catch(() => {});
                    return;
                }

                if (!buttonName) {
                    await message.channel.send('Erreur: Nom du bouton non valide.');
                    await m.delete().catch(() => {});
                    await replyButtonName.delete().catch(() => {});
                    responseButtonName.stop();
                    return;
                }

                await m.delete().catch(() => {});
                await replyButtonName.delete().catch(() => {});
                responseButtonName.stop();

                const replyButtonUrl = await msg.reply('Merci de me donner le lien du bouton (doit commencer par http:// ou https://) :');
                const responseButtonUrl = message.channel.createMessageCollector(m => m.author.id === message.author.id, { time: 60000 });

                responseButtonUrl.on('collect', async m => {
                    const buttonUrl = m.content.trim();
                    
                    // Vérifier que l'URL est valide
                    if (!buttonUrl.startsWith('http://') && !buttonUrl.startsWith('https://')) {
                        await message.channel.send('Erreur: Le lien doit commencer par http:// ou https://');
                        await m.delete().catch(() => {});
                        return;
                    }

                    // Vérifier que l'URL est valide avec une regex simple
                    const urlRegex = /^https?:\/\/[^\s]+$/;
                    if (!urlRegex.test(buttonUrl)) {
                        await message.channel.send('Erreur: Lien non valide.');
                        await m.delete().catch(() => {});
                        return;
                    }

                    // Ajouter le bouton à la liste
                    linkButtons.push({ label: buttonName, url: buttonUrl });
                    
                    await message.channel.send(`✅ Bouton "${buttonName}" ajouté avec succès ! (${linkButtons.length}/25)`);

                    await m.delete().catch(() => {});
                    await replyButtonUrl.delete().catch(() => {});
                    responseButtonUrl.stop();
                });
            });
        }

        async function handleRemoveLinkButton(msg, message, embed, linkButtons) {
            if (linkButtons.length === 0) {
                await message.channel.send('Aucun bouton de lien à supprimer.');
                return;
            }

            let buttonsList = '';
            linkButtons.forEach((button, index) => {
                buttonsList += `${index + 1}. ${button.label} (${button.url})\n`;
            });

            const replyRemoveButton = await msg.reply(`Voici la liste des boutons :\n\`\`\`\n${buttonsList}\`\`\`\nMerci de me donner le numéro du bouton à supprimer :`);
            const responseRemoveButton = message.channel.createMessageCollector(m => m.author.id === message.author.id, { time: 60000 });

            responseRemoveButton.on('collect', async m => {
                const buttonIndex = parseInt(m.content.trim());
                
                if (isNaN(buttonIndex) || buttonIndex < 1 || buttonIndex > linkButtons.length) {
                    await message.channel.send('Numéro de bouton invalide. Veuillez choisir un numéro entre 1 et ' + linkButtons.length + '.');
                    await m.delete().catch(() => {});
                    return;
                }

                const removedButton = linkButtons.splice(buttonIndex - 1, 1)[0];
                await message.channel.send(`✅ Bouton "${removedButton.label}" supprimé avec succès !`);

                await m.delete().catch(() => {});
                await replyRemoveButton.delete().catch(() => {});
                responseRemoveButton.stop();
            });
        }

        async function handleCopy(msg, message, embed) {
            const embedToCopy = await msg.reply("Merci de me donner l'ID de l'embed que vous souhaitez copier.");
            const responseCopy = message.channel.createMessageCollector(m => m.author.id === message.author.id, { time: 60000 });

            responseCopy.on('collect', async m => {
                const embedId = m.content.trim();
                const fetchedMessage = await message.channel.messages.fetch(embedId).catch(() => null);

                if (fetchedMessage && fetchedMessage.embeds.length > 0) {
                    const copiedEmbed = fetchedMessage.embeds[0];

                    if (copiedEmbed.title) embed.setTitle(copiedEmbed.title);
                    if (copiedEmbed.description) embed.setDescription(copiedEmbed.description);
                    if (copiedEmbed.color) embed.setColor(copiedEmbed.color);
                    if (copiedEmbed.image?.url) embed.setImage(copiedEmbed.image.url);
                    if (copiedEmbed.thumbnail?.url) embed.setThumbnail(copiedEmbed.thumbnail.url);
                    if (copiedEmbed.author?.name) embed.setAuthor({ name: copiedEmbed.author.name });
                    if (copiedEmbed.footer?.text) {
                        embed.setFooter({ text: copiedEmbed.footer.text });
                    }
                    if (copiedEmbed.fields && copiedEmbed.fields.length > 0) {
                        embed.addFields(copiedEmbed.fields);
                    }

                    await msg.edit({ embeds: [embed] });
                } else {
                    await message.channel.send('Erreur: L\'embed n\'a pas été trouvé ou n\'est pas valide.');
                }

                await m.delete().catch(() => {});
                await embedToCopy.delete().catch(() => {});
                responseCopy.stop();
            });
        }
    }
};