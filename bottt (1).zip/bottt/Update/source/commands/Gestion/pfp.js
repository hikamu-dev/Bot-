const Discord = require('discord.js');

module.exports = {
  name: 'pfp',
  description: 'Affiche les photos de profil des membres du serveur dans un salon textuel, configure un salon pour les envois automatiques, ou active/désactive la fonctionnalité.',
  use: "pfp set <ID-du-salon> | pfp enable/disable",
  usage: "pfp <enable/disable>, pfp set <ID-du-salon>",
  example: "➜ pfp set 123456789012345678\n➜ pfp enable\n➜ pfp disable",
  /**
   * 
   * @param {Astroia} client 
   * @param {Discord.Message} message
   * @param {string[]} args 
   */
  run: async (client, message, args, commandName) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) || 
        client.db.get(`owner_global_${message.author.id}`) === true || 
client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

    // Vérifier les arguments
    if (!args[0]) {
      return message.channel.send('Utilisation : `pfp <ID-du-salon>` ou `pfp set <ID-du-salon>` ou `pfp enable/disable`');
    }

    const action = args[0].toLowerCase();

    if (action === 'enable' || action === 'disable') {
      // Activer ou désactiver la fonctionnalité
      const pfpKey = `pfp_${message.guild.id}`;
      const isEnabled = action === 'enable';
      const currentConfig = client.db.get(pfpKey) || { enabled: false };

      if (isEnabled && !currentConfig.channelId) {
        return message.channel.send('Veuillez d\'abord configurer un salon avec `pfp set <ID-du-salon>`.');
      }

      client.db.set(pfpKey, { ...currentConfig, enabled: isEnabled });
      return message.channel.send(`La fonctionnalité d'affichage des photos de profil a été ${isEnabled ? 'activée' : 'désactivée'}.`);
    }

    if (action === 'set') {
      // Configurer un salon pour les envois automatiques
      if (!args[1]) {
        return message.channel.send('Veuillez fournir un ID de salon textuel valide avec `pfp set <ID-du-salon>`.');
      }

      const channelId = args[1].replace(/[^0-9]/g, '');
      const targetChannel = message.guild.channels.cache.get(channelId);
      if (!targetChannel || targetChannel.type !== Discord.ChannelType.GuildText) {
        return message.channel.send('Veuillez fournir un ID de salon textuel valide.');
      }

      if (!targetChannel.permissionsFor(message.guild.members.me).has(Discord.PermissionsBitField.Flags.SendMessages)) {
        return message.channel.send(`Je n'ai pas la permission d'envoyer des messages dans <#${targetChannel.id}>.`);
      }

      const pfpKey = `pfp_${message.guild.id}`;
      const currentConfig = client.db.get(pfpKey) || { enabled: false };
      client.db.set(pfpKey, { ...currentConfig, channelId: targetChannel.id });
      return message.channel.send(`Le salon <#${targetChannel.id}> a été configuré pour l'affichage des photos de profil.`);
    }

    // Afficher les photos de profil dans un salon spécifié
    const channelId = args[0].replace(/[^0-9]/g, '');
    const targetChannel = message.guild.channels.cache.get(channelId);
    if (!targetChannel || targetChannel.type !== Discord.ChannelType.GuildText) {
      return message.channel.send('Veuillez fournir un ID de salon textuel valide.');
    }

    if (!targetChannel.permissionsFor(message.guild.members.me).has(Discord.PermissionsBitField.Flags.SendMessages)) {
      return message.channel.send(`Je n'ai pas la permission d'envoyer des messages dans <#${targetChannel.id}>.`);
    }

    // Récupérer tous les membres du serveur
    const members = await message.guild.members.fetch();
    let sentCount = 0;

    // Parcourir les membres et envoyer leurs photos de profil
    for (const member of members.values()) {
      if (member.user.bot) continue;

      const avatarURL = member.user.displayAvatarURL({ format: 'png', dynamic: true, size: 4096 });
      const embed = new Discord.EmbedBuilder()
        .setColor(client.color)
        .setFooter(client.footer)
        .setDescription(`<@${member.user.id}> | \`${member.user.id}\``)
        .setImage(avatarURL);

      try {
        await targetChannel.send({ embeds: [embed] });
        sentCount++;
      } catch (error) {
        console.error(`Erreur lors de l'envoi de la photo de profil de ${member.user.tag}:`, error);
      }
    }

    return message.channel.send(`J'ai envoyé ${sentCount} photo(s) de profil dans <#${targetChannel.id}>.`);
  }
};