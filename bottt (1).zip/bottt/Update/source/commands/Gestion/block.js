const { example } = require("../Owner/changelimit");

module.exports = {
    name: 'block',
    description: "Gère les salons où les commandes sont désactivées",
    use: "<add/remove/list> [#salon/id]",
    usage: "block <add/remove/list> [#salon/id]",
    example: "➜ block add #general\n➜ block remove #general\n➜ block list",
    run: async (client, message, args, commandName) => {
        let pass = false;

        // Autoriser automatiquement les staff, buyers, et owners
        if (client.staff.includes(message.author.id) || 
            client.config.buyers.includes(message.author.id) || 
                  client.db.get(`owner_global_${message.author.id}`) === true || 

    client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {               pass = true;
        } else {
            // Vérifier les permissions personnalisées pour la commande
            const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
            if (commandPerms.length > 0) {
                const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                const userRoles = message.member.roles.cache.map(role => role.id);
                // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
                pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
            } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                // Conserver la compatibilité avec le mode "public"
                pass = true;
            }
        }

        // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        const prefix = client.config.prefix;
        const dbKey = `nocmd_${message.guild.id}`;
        let nocmdList = client.db.get(dbKey) || [];

        if (args.length < 1) {
            return message.reply(`Veuillez faire \`${prefix}block <add/remove/list> [#salon/id]\``);
        }

        const action = args[0].toLowerCase();

        // Commande LIST
        if (action === 'list') {
            if (nocmdList.length === 0) {
                return message.reply("Aucun salon n'a les commandes désactivées.");
            }

            let salonsList = [];
            nocmdList.forEach(entry => {
                const salon = message.guild.channels.cache.get(entry.salonId);
                const salonName = salon ? salon.toString() : `ID: ${entry.salonId}`;
                salonsList.push(salonName);
            });

            const listMessage = `Salons avec commandes désactivées : ${salonsList.join(', ')}`;
            return message.reply(listMessage);
        }

        // Pour ADD et REMOVE, on a besoin d'un salon (optionnel)
        let salon = null;
        if (args.length >= 2) {
            if (message.mentions.channels.first()) {
                salon = message.mentions.channels.first();
            } else {
                // Essayer de résoudre par ID
                const salonId = args[1];
                salon = message.guild.channels.cache.get(salonId);
                if (!salon) {
                    return message.reply("Salon introuvable. Veuillez mentionner un salon valide ou utiliser un ID valide.");
                }
            }
        }

        // Commande ADD
        if (action === 'add') {
            // Si pas de salon spécifié, utiliser le salon actuel
            if (!salon) {
                salon = message.channel;
            }

            if (nocmdList.some(entry => entry.salonId === salon.id)) {
                return message.reply(`Le salon ${salon} a déjà les commandes désactivées.`);
            }

            nocmdList.push({
                salonId: salon.id
            });

            client.db.set(dbKey, nocmdList);
            return message.reply(`Les commandes sont maintenant désactivées dans ${salon}.`);
        }

        // Commande REMOVE
        else if (action === 'remove') {
            // Si pas de salon spécifié, utiliser le salon actuel
            if (!salon) {
                salon = message.channel;
            }

            // Vérifier si c'est le mot "salon" pour tout supprimer
            if (args[1] && args[1].toLowerCase() === 'salon') {
                if (nocmdList.length === 0) {
                    return message.reply("Aucun salon n'a les commandes désactivées.");
                }

                const removedCount = nocmdList.length;
                client.db.set(dbKey, []);
                return message.reply(`Les commandes ont été réactivées dans ${removedCount} salon(s).`);
            }

            const initialLength = nocmdList.length;
            nocmdList = nocmdList.filter(entry => entry.salonId !== salon.id);

            if (nocmdList.length === initialLength) {
                return message.reply(`Le salon ${salon} n'avait pas les commandes désactivées.`);
            }

            client.db.set(dbKey, nocmdList);
            return message.reply(`Les commandes sont à nouveau autorisées dans ${salon}.`);
        }

        // Action invalide
        else {
            return message.reply("Action invalide. Utilisez `add`, `remove` ou `list`.");
        }
    }
};