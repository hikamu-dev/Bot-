// commands/utils/wordreact.js
// Panel de configuration des réactions automatiques basées sur des mots.
// Auto-refresh : le panel (embed+boutons) se met à jour après CHAQUE interaction.
//
// DB utilisée :
//  wordreact_enabled_<guildId> : true|false
//  wordreact_rules_<guildId>   : [{ id, pattern, type, case, emojis, authorId, createdAt }]
//  wordreact_lastid_<guildId>  : number
//
// type: "contains" | "equals" | "starts" | "ends" | "regex"
// case: true (sensible) | false (insensible)
// emojis: array de strings (unicode ou ID d'emoji custom)

const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  StringSelectMenuBuilder
} = require("discord.js");

const MAX_RULES = 50;
const MAX_EMOJIS_PER_RULE = 5;

function parseEmojiTokens(input = "") {
  const out = [];
  for (const tok of input.split(/\s+/).filter(Boolean)) {
    const m = tok.match(/<?a?:\w+:(\d{15,20})>?/);
    if (m) { out.push(m[1]); continue; }
    if (/^\d{15,20}$/.test(tok)) { out.push(tok); continue; }
    out.push(tok); // unicode
  }
  return Array.from(new Set(out)).slice(0, MAX_EMOJIS_PER_RULE);
}

function sanitizeType(s) {
  const t = (s || "").toLowerCase().trim();
  return ["contains","equals","starts","ends","regex"].includes(t) ? t : "contains";
}

function parseOptions(input = "") {
  // Ex: "type=starts case=yes"
  const o = { type: "contains", case: false };
  const parts = (input || "").split(/\s+/).filter(Boolean);
  for (const p of parts) {
    const [k,v] = p.split("=").map(x => (x||"").trim().toLowerCase());
    if (k === "type") o.type = sanitizeType(v);
    if (k === "case") o.case = (v === "yes" || v === "true" || v === "1");
  }
  return o;
}

module.exports = {
  name: "wordreact",
  description: "Ouvre le panel WordReact (réactions auto basées sur des mots).",
  usages: "wordreact",
  example: "wordreact",
  /**
   * @param {import('discord.js').Client} client
   * @param {import('discord.js').Message} message
   * @param {string[]} args
   */
  run: async (client, message, args, commandName = "wordreact") => {
    try {
      if (!message.guild) return;

      // ---- Permissions (style habituel) ----
      const whitelistDB = client.db.get(`wl.${message.guild.id}`) || [];
      const isBypassHard =
        client.staff?.includes?.(message.author.id) ||
        client.config?.buyers?.includes?.(message.author.id) ||
        client.db.get(`owner_${message.author.id}`) === true ||
        client.db.get(`owner_global_${message.author.id}`) === true ||
        whitelistDB.includes(message.author.id) ||
        message.guild.ownerId === message.author.id;

      let pass = isBypassHard;
      if (!pass) {
        const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
        if (commandPerms.length > 0) {
          const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
          const userRoles = message.member.roles.cache.map(r => r.id);
          pass = commandPerms.some(perm => userPerms[perm]?.some?.(roleId => userRoles.includes(roleId)));
        } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") pass = true;
      }
      if (!pass) {
        if (client.noperm && client.noperm.trim() !== "") {
          const sent = await message.channel.send({ content: client.noperm, allowedMentions: { parse: [] } });
          const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
          if (delayTime > 0) setTimeout(() => sent.delete().catch(() => {}), delayTime * 1000);
        }
        return;
      }

      const gId = message.guild.id;
      const enabledKey = `wordreact_enabled_${gId}`;
      const rulesKey   = `wordreact_rules_${gId}`;
      const counterKey = `wordreact_lastid_${gId}`;

      const fmtRule = (r) =>
        `#${r.id} • **${r.pattern}** (${r.type}${r.case ? ", case" : ""}) • ${r.emojis.map(e=>/^\d{15,20}$/.test(e)?`<:_:${e}>`:e).join(" ")}`;

      // Helpers lecture DB (toujours frais)
      const getEnabled = () => !!client.db.get(enabledKey);
      const getRules   = () => Array.isArray(client.db.get(rulesKey)) ? client.db.get(rulesKey) : [];

      // Builders UI — lisent l'état ACTUEL (pas de variables figées)
      const makeEmbed = () => {
        const isEnabled = getEnabled();
        const rules = getRules();
        const list = rules.slice(0, 10).map(fmtRule).join("\n") || "_Aucune règle._";
        return new EmbedBuilder()
          .setColor(isEnabled ? 0x57F287 : 0xED4245)
          .setTitle("🧩 WordReact — Réactions automatiques")
          .setDescription([
            `**Statut :** ${isEnabled ? "🟢 Activé" : "🔴 Désactivé"}`,
            "",
            "**Aperçu des règles (10 premières) :**",
            list,
            "",
            `**Total :** ${rules.length}/${MAX_RULES}`,
            "",
            "Ajoute une règle via **Ajouter**. Format modale :",
            "• **Mot/texte**",
            "• **Émojis** (séparés par espace) — unicode / `<:name:id>` / `id`",
            "• **Options** : `type=contains|equals|starts|ends|regex` `case=yes|no`"
          ].join("\n"));
      };

      const panelId = `wr_${message.id}_${Date.now()}`;
      const makeRows = () => {
        const isEnabled = getEnabled();
        const row1 = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId(`${panelId}:toggle`).setLabel(isEnabled ? "Désactiver" : "Activer").setStyle(isEnabled ? ButtonStyle.Danger : ButtonStyle.Success),
          new ButtonBuilder().setCustomId(`${panelId}:add`).setLabel("➕ Ajouter").setStyle(ButtonStyle.Primary),
          new ButtonBuilder().setCustomId(`${panelId}:del`).setLabel("🗑️ Supprimer").setStyle(ButtonStyle.Danger),
        );
        const row2 = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId(`${panelId}:list`).setLabel("📋 Lister").setStyle(ButtonStyle.Secondary),
          new ButtonBuilder().setCustomId(`${panelId}:clear`).setLabel("♻️ Tout vider").setStyle(ButtonStyle.Secondary),
          new ButtonBuilder().setCustomId(`${panelId}:close`).setLabel("❌ Fermer").setStyle(ButtonStyle.Secondary),
        );
        return [row1, row2];
      };

      // Envoi initial du panel
      const panelMsg = await message.channel.send({
        embeds: [makeEmbed()],
        components: makeRows(),
        allowedMentions: { parse: [] }
      });

      // Refresh unique (embed + rows) après chaque action
      async function refresh() {
        try { await panelMsg.edit({ embeds: [makeEmbed()], components: makeRows() }); } catch {}
      }

      // Collector pour les boutons
      const collector = panelMsg.createMessageComponentCollector({ time: 10 * 60 * 1000 });

      collector.on("collect", async (i) => {
        if (i.user.id !== message.author.id) {
          return i.reply({ content: "Seul l'initiateur peut utiliser ce panel.", ephemeral: true });
        }
        const [pid, action] = (i.customId || "").split(":");
        if (pid !== panelId) return;

        if (action === "toggle") {
          client.db.set(enabledKey, !getEnabled());
          await i.deferUpdate();
          await refresh(); // <- AUTO-REFRESH
          return;
        }

        if (action === "list") {
          const lines = getRules().map(fmtRule).join("\n") || "Aucune règle.";
          await i.reply({ content: lines.slice(0, 1900), ephemeral: true });
          await refresh(); // pas obligatoire, mais on garde l’UX uniforme
          return;
        }

        if (action === "clear") {
          client.db.set(rulesKey, []);
          await i.deferUpdate();
          await refresh(); // <- AUTO-REFRESH
          return;
        }

        if (action === "add") {
          if (getRules().length >= MAX_RULES) {
            return i.reply({ content: `Limite de ${MAX_RULES} règles atteinte.`, ephemeral: true });
          }
          const modal = new ModalBuilder()
            .setCustomId(`${panelId}:addmodal`)
            .setTitle("Ajouter une règle WordReact");
          const inp1 = new TextInputBuilder().setCustomId("pattern").setLabel("Mot/texte à détecter").setStyle(TextInputStyle.Short).setRequired(true);
          const inp2 = new TextInputBuilder().setCustomId("emojis").setLabel("Émojis (séparés par espace)").setStyle(TextInputStyle.Short).setRequired(true);
          const inp3 = new TextInputBuilder().setCustomId("opts").setLabel("Options (ex: type=contains case=no)").setStyle(TextInputStyle.Short).setRequired(false);
          modal.addComponents(
            new ActionRowBuilder().addComponents(inp1),
            new ActionRowBuilder().addComponents(inp2),
            new ActionRowBuilder().addComponents(inp3),
          );
          await i.showModal(modal);
          return;
        }

        if (action === "del") {
          const rules = getRules();
          if (!rules.length) return i.reply({ content: "Aucune règle à supprimer.", ephemeral: true });
          const menu = new StringSelectMenuBuilder()
            .setCustomId(`${panelId}:delmenu`)
            .setPlaceholder("Choisis une règle à supprimer")
            .addOptions(
              rules.slice(0,25).map(r => ({
                label: `#${r.id} ${r.pattern}`.slice(0,100),
                value: String(r.id),
                description: `${r.type}${r.case ? ", case" : ""} • ${r.emojis.length} emoji(s)`
              }))
            );
          return i.reply({ components: [new ActionRowBuilder().addComponents(menu)], ephemeral: true });
        }

        if (action === "close") {
          collector.stop("closed");
          return i.update({ components: [] });
        }
      });

      // Gestion des modales & menus (avec refresh systématique)
      const onInteraction = async (i) => {
        const [pid, what] = (i.customId || "").split(":");
        if (pid !== panelId) return;
        if (i.user.id !== message.author.id) return i.reply({ content: "Seul l'initiateur peut utiliser ce panel.", ephemeral: true });

        if (i.isModalSubmit() && what === "addmodal") {
          const pattern = i.fields.getTextInputValue("pattern")?.trim();
          const emojisRaw = i.fields.getTextInputValue("emojis")?.trim();
          const optsRaw = i.fields.getTextInputValue("opts")?.trim() || "";

          if (!pattern || !emojisRaw) return i.reply({ content: "Champs requis manquants.", ephemeral: true });

          const ems = parseEmojiTokens(emojisRaw);
          if (!ems.length) return i.reply({ content: "Aucun émoji valide détecté.", ephemeral: true });

          const { type, case: isCase } = parseOptions(optsRaw);

          const nextId = (client.db.get(counterKey) || 0) + 1;
          const current = getRules();
          current.push({
            id: nextId,
            pattern,
            type,
            case: !!isCase,
            emojis: ems,
            authorId: message.author.id,
            createdAt: Date.now()
          });

          client.db.set(rulesKey, current);
          client.db.set(counterKey, nextId);

          await i.reply({ content: `✅ Règle ajoutée (#${nextId}) : **${pattern}** (${type}${isCase ? ", case" : ""})`, ephemeral: true });
          await refresh(); // <- AUTO-REFRESH
          return;
        }

        if (i.isStringSelectMenu() && what === "delmenu") {
          const val = i.values?.[0];
          const before = getRules();
          const after = before.filter(r => String(r.id) !== String(val));
          client.db.set(rulesKey, after);
          await i.update({ content: `🗑️ Règle #${val} supprimée.`, components: [] });
          await refresh(); // <- AUTO-REFRESH
          return;
        }
      };

      client.on("interactionCreate", onInteraction);

      collector.on("end", async () => {
        try { await panelMsg.edit({ components: [] }); } catch {}
        client.removeListener("interactionCreate", onInteraction);
      });

    } catch (e) {
      console.error(e);
      message.channel.send({ content: "❌ Impossible d'ouvrir le panel WordReact.", allowedMentions: { parse: [] } });
    }
  }
};
