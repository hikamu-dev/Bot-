const { EmbedBuilder, PermissionsBitField } = require('discord.js');
const { example } = require('../Owner/changelimit');

module.exports = {
    name: 'sync',
    description: 'Synchronise les salons textuels avec leur catégorie.',
    use: "<channelid/all>",
    usage: "sync <channelid/all>",
    example: "➜ sync #general\n➜ sync all",
    /**
     * @param {Astroia} client 
     * @param {Discord.Message} message
     * @param {string[]} args 
     */
    run: async (client, message, args) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
        client.db.get(`owner_global_${message.author.id}`) === true || 
client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${module.exports.name}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        // Détermine les salons à synchroniser
        const syncChannel = message.mentions.channels.first();
        const syncAll = args.includes('all');

        // Récupération des salons à synchroniser
        const channelsToSync = syncAll ? message.guild.channels.cache.filter(c => c.type === 0) : [syncChannel]; // Utilisez 0 pour les salons textuels

        if (!syncChannel && !syncAll) {
            return message.reply("Vous devez mentionner un salon ou utiliser `all` pour synchroniser tous les salons.");
        }

        let syncedChannels = [];

        for (const channel of channelsToSync) {
            if (channel.type !== 0) continue; // Utilisez 0 pour les salons textuels

            const category = channel.parent;
            if (category) {
                const permissions = category.permissionsFor(message.guild.roles.everyone).serialize();
                await channel.permissionOverwrites.edit(message.guild.roles.everyone.id, {
                    ViewChannel: permissions.ViewChannel // Utilisez PermissionsBitField.Flags.ViewChannel pour Discord.js v14+
                });
                syncedChannels.push(channel);
            }
        }

        // Création d'un embed de réponse
        const embed = new EmbedBuilder()
            .setTitle('Synchronisation des Salons')
            .setColor(client.color)
            .setDescription(syncedChannels.length > 0 ? 
                `Les salons suivants ont été synchronisés avec leur catégorie :\n${syncedChannels.map(c => `<#${c.id}>`).join('\n')}` : 
                "Aucun salon n'a été synchronisé.");

        return message.reply({ embeds: [embed] });
    }
};
