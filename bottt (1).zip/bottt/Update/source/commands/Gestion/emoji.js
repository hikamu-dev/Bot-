
module.exports = {
    name: "emoji",
    aliases: ["addemoji"],
    usage: "emoji <emoji>",
    use: "<emoji>",
    example: "➜ emoji <:tokyru:123456789012345678>",
    run: async (client, message, args, commandName) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
if (client.staff.includes(message.author.id) || 
    client.config.buyers.includes(message.author.id) || 
    client.db.get(`owner_global_${message.author.id}`) === true || 
    client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {            
  pass = true;
} else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}
    
    if (!args.length) {
        return message.channel.send({ content: "Veuillez spécifier l'émoji" });
    }

    const emojiRegex = /<a?:[a-zA-Z0-9_]+:(\d+)>/;
    const totalEmojis = args.length;
    let creeemojis = 0;
    let invalidEmojis = 0;

    // Vérifier d'abord si tous les arguments sont des emojis custom valides
    for (const rawEmoji of args) {
        if (!emojiRegex.test(rawEmoji)) {
            invalidEmojis++;
        }
    }

    if (invalidEmojis > 0) {
        return message.channel.send({ content: "Veuillez utiliser uniquement des emojis custom (format: <:nom:id> ou <a:nom:id>)" });
    }

    const msg = await message.channel.send("Merci de bien patienter pendant la création des emojis...");

    for (const rawEmoji of args) {
        const emojiss = rawEmoji.match(emojiRegex);

        if (emojiss) {
            const emojiId = emojiss[1];
            const extension = rawEmoji.startsWith("<a:") ? ".gif" : ".png";
            const url = `https://cdn.discordapp.com/emojis/${emojiId + extension}`;

            message.guild.emojis.create({ attachment: url, name: emojiId })
                .then((emoji) => {
                    creeemojis++;

                    if (creeemojis === totalEmojis) {
                        msg.edit(`La création des emojis est terminée, nombre d'emojis créés : ${creeemojis}`);
                    }
                })
                .catch((error) => {
                    msg.edit({ content: "Une erreur s'est produite" });
                    console.error(error);
                });
        }
    }
    }
};