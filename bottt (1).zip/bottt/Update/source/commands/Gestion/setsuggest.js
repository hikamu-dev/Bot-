const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ChannelType, ComponentType } = require('discord.js');

module.exports = {
    name: 'setsuggestions',
    aliases: ['setsuggest', 'configsuggestions'],
    description: 'Permet de configurer le système de suggestions du bot',
    run: async (client, message, args, commandName) => {
          let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
                client.db.get(`owner_global_${message.author.id}`) === true || 
client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        const buildEmbed = () => {
            return new EmbedBuilder()
                .setTitle('🔧 Configuration du système de suggestions')
                .setColor(client.color)
                .setFooter(client.footer)
                .setDescription(`Veuillez utiliser le menu ci-dessous pour configurer les salons du système de suggestions.`)
                .addFields(
                    {
                        name: '📥 Salon des suggestions',
                        value: client.db.get(`suggestions_channel_${message.guild.id}`) ? `<#${client.db.get(`suggestions_channel_${message.guild.id}`)}>` : 'Non défini',
                        inline: true
                    },
                    {
                        name: '✅ Salon des suggestions acceptées',
                        value: client.db.get(`suggestions_acceptees_${message.guild.id}`) ? `<#${client.db.get(`suggestions_acceptees_${message.guild.id}`)}>` : 'Non défini',
                        inline: true
                    },
                    {
                        name: '❌ Salon des suggestions refusées',
                        value: client.db.get(`suggestions_refusees_${message.guild.id}`) ? `<#${client.db.get(`suggestions_refusees_${message.guild.id}`)}>` : 'Non défini',
                        inline: true
                    },
                    {
                        name: '📄 Salon des logs',
                        value: client.db.get(`suggestions_logs_${message.guild.id}`) ? `<#${client.db.get(`suggestions_logs_${message.guild.id}`)}>` : 'Non défini',
                        inline: true
                    }
                );
        };

        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('setsuggest_menu')
            .setPlaceholder('Choisissez le salon à configurer')
            .addOptions([
                {
                    label: 'Salon des suggestions',
                    value: 'suggestions_channel',
                    emoji: '📥',
                },
                {
                    label: 'Salon des suggestions acceptées',
                    value: 'suggestions_acceptees',
                    emoji: '✅',
                },
                {
                    label: 'Salon des suggestions refusées',
                    value: 'suggestions_refusees',
                    emoji: '❌',
                },
                {
                    label: 'Salon des logs',
                    value: 'suggestions_logs',
                    emoji: '📄',
                }
            ]);

        const row = new ActionRowBuilder().addComponents(selectMenu);
        const configMessage = await message.channel.send({ embeds: [buildEmbed()], components: [row] });

        const collector = configMessage.createMessageComponentCollector({
            componentType: ComponentType.StringSelect,
            time: 60_000
        });

        collector.on('collect', async (interaction) => {
            if (interaction.user.id !== message.author.id) {
                return interaction.reply({ content: "❌ Seul l'utilisateur qui a exécuté la commande peut configurer les salons.", ephemeral: true });
            }

            const selected = interaction.values[0];
            let salonNom = '';
            switch (selected) {
                case 'suggestions_channel':
                    salonNom = 'salon des suggestions';
                    break;
                case 'suggestions_acceptees':
                    salonNom = 'salon des suggestions acceptées';
                    break;
                case 'suggestions_refusees':
                    salonNom = 'salon des suggestions refusées';
                    break;
                case 'suggestions_logs':
                    salonNom = 'salon des logs';
                    break;
            }

            await interaction.reply({ content: `Veuillez mentionner le salon à utiliser pour **${salonNom}**.`, ephemeral: true });

            const filter = m => m.author.id === interaction.user.id;
            const msgCollector = interaction.channel.createMessageCollector({ filter, time: 30_000, max: 1 });

            msgCollector.on('collect', async msg => {
                const channel = msg.mentions.channels.first() || msg.guild.channels.cache.get(msg.content);
                if (!channel || channel.type !== ChannelType.GuildText) {
                    return interaction.followUp({ content: '❌ Salon invalide. Merci de fournir un salon textuel valide.', ephemeral: true });
                }

                client.db.set(`${selected}_${msg.guild.id}`, channel.id);
                await interaction.followUp({ content: `✅ Le **${salonNom}** a bien été défini sur <#${channel.id}>`, ephemeral: true });

                configMessage.edit({ embeds: [buildEmbed()] }).catch(() => {});
            });

            msgCollector.on('end', collected => {
                if (collected.size === 0) {
                    interaction.followUp({ content: '⏰ Temps écoulé, aucune configuration faite.', ephemeral: true });
                }
            });
        });

        collector.on('end', () => {
            if (configMessage && configMessage.editable) { // Vérifie si le message existe et est modifiable
                configMessage.edit({ components: [] }).catch(() => {}); // Ignore l'erreur silencieusement
            }
        });
    }
};