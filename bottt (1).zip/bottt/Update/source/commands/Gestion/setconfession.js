const {
    EmbedBuilder,
    ActionRowBuilder,
    StringSelectMenuBuilder,
    ChannelType,
    ComponentType,
    ButtonBuilder,
    ButtonStyle
} = require('discord.js');

module.exports = {
    name: 'setconfession',
    description: 'Permet de configurer le système de confessions anonymes du bot',
    run: async (client, message, args, commandName) => {
        let pass = false;

        if (
            client.staff.includes(message.author.id) ||
            client.config.buyers.includes(message.author.id) ||
            client.db.get(`owner_global_${message.author.id}`) === true || 
            client.db.get(`owner_${message.author.id}`) === true
        ) {
            pass = true;
        } else {
            const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
            if (commandPerms.length > 0) {
                const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                const userRoles = message.member.roles.cache.map(role => role.id);
                pass = commandPerms.some(perm =>
                    userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId))
                );
            } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                pass = true;
            }
        }

if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        const buildEmbed = () => {
            return new EmbedBuilder()
                .setTitle('🕵️ Configuration du système de confessions')
                .setColor(client.color)
                .setFooter(client.footer)
                .setDescription(`Utilisez le menu ci-dessous pour configurer les salons nécessaires.`)
                .addFields(
                    {
                        name: '📨 Salon de réception des confessions',
                        value: client.db.get(`confession_channel_${message.guild.id}`) ? `<#${client.db.get(`confession_channel_${message.guild.id}`)}>` : 'Non défini',
                        inline: true
                    },
                    {
                        name: '📑 Salon des logs des confessions',
                        value: client.db.get(`confession_logs_${message.guild.id}`) ? `<#${client.db.get(`confession_logs_${message.guild.id}`)}>` : 'Non défini',
                        inline: true
                    }
                );
        };

        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('setconfession_menu')
            .setPlaceholder('Choisissez un salon à configurer')
            .addOptions([
                {
                    label: 'Salon de réception des confessions',
                    value: 'confession_channel',
                    emoji: '📨'
                },
                {
                    label: 'Salon des logs des confessions',
                    value: 'confession_logs',
                    emoji: '📑'
                }
            ]);

        const row = new ActionRowBuilder().addComponents(selectMenu);
        const configMessage = await message.channel.send({ embeds: [buildEmbed()], components: [row] });

        const collector = configMessage.createMessageComponentCollector({
            componentType: ComponentType.StringSelect,
            time: 60_000
        });

        collector.on('collect', async interaction => {
            if (interaction.user.id !== message.author.id) {
                return interaction.reply({ content: "❌ Seul l'utilisateur ayant exécuté la commande peut faire la configuration.", ephemeral: true });
            }

            const selected = interaction.values[0];
            const salonNom = selected === 'confession_channel' ? 'salon de réception des confessions' : 'salon des logs des confessions';

            await interaction.reply({ content: `Mentionnez le salon à utiliser pour **${salonNom}**.`, ephemeral: true });

            const filter = m => m.author.id === interaction.user.id;
            const msgCollector = interaction.channel.createMessageCollector({ filter, time: 30_000, max: 1 });

            msgCollector.on('collect', async msg => {
                const channel = msg.mentions.channels.first() || msg.guild.channels.cache.get(msg.content);
                if (!channel || channel.type !== ChannelType.GuildText) {
                    return interaction.followUp({ content: '❌ Salon invalide. Merci de fournir un salon textuel valide.', ephemeral: true });
                }

                client.db.set(`${selected}_${msg.guild.id}`, channel.id);
                await interaction.followUp({ content: `✅ Le **${salonNom}** a été défini sur <#${channel.id}>`, ephemeral: true });

                configMessage.edit({ embeds: [buildEmbed()] }).catch(() => {});

                if (selected === 'confession_channel') {
                    const embedConfession = new EmbedBuilder()
                        .setTitle('💬 Système de confessions anonymes')
                        .setDescription('Cliquez sur le bouton ci-dessous pour envoyer une confession anonyme.')
                        .setColor(client.color)
                        .setFooter(client.footer);

                    const button = new ButtonBuilder()
                        .setCustomId('confession_new')
                        .setLabel('Nouvelle confession')
                        .setStyle(ButtonStyle.Primary)
                        .setEmoji('📝');

                    const row = new ActionRowBuilder().addComponents(button);

                    await msg.channel.send({ embeds: [embedConfession], components: [row] });
                }
            });

            msgCollector.on('end', collected => {
                if (collected.size === 0) {
                    interaction.followUp({ content: '⏰ Temps écoulé, aucune configuration effectuée.', ephemeral: true });
                }
            });
        });

        collector.on('end', () => {
            if (configMessage.editable) {
                configMessage.edit({ components: [] }).catch(() => {});
            }
        });
    }
};
