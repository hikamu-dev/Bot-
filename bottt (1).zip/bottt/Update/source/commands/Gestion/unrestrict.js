// commands/admin/unrestrict.js
// +unrestrict <emoji | ID_log> → rend l'emoji public (roles = []).

const { PermissionsBitField } = require("discord.js");

function extractEmojiId(input = "") {
  const m = input.match(/<?a?:\w+:(\d{15,20})>?/);
  if (m) return m[1];
  if (/^\d{15,20}$/.test(input)) return input;
  return null;
}

module.exports = {
  name: "unrestrict",
  description: "Rend un émoji public (tout le monde peut l’utiliser). Cible par emoji ou ID de log.",
  usages: "unrestrict <emoji | id_log>",
  example: "unrestrict <:cool:123>  |  unrestrict 42",
  run: async (client, message, args, commandName = "unrestrict") => {
    try {
      if (!message.guild) return;

      // ----- Permissions (style maison) -----
      const whitelistDB = client.db.get(`wl.${message.guild.id}`) || [];
      const isBypassHard =
        client.staff?.includes?.(message.author.id) ||
        client.config?.buyers?.includes?.(message.author.id) ||
        client.db.get(`owner_${message.author.id}`) === true ||
        client.db.get(`owner_global_${message.author.id}`) === true ||
        whitelistDB.includes(message.author.id) ||
        message.guild.ownerId === message.author.id;

      let pass = isBypassHard;
      if (!pass) {
        const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
        if (commandPerms.length > 0) {
          const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
          const userRoles = message.member.roles.cache.map(r => r.id);
          pass = commandPerms.some(perm => userPerms[perm]?.some?.(roleId => userRoles.includes(roleId)));
        } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") pass = true;
      }
      if (!pass) {
        const sent = await message.channel.send({ content: client.noperm || "Pas les permissions.", allowedMentions: { parse: [] } });
        const d = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (d > 0) setTimeout(() => sent.delete().catch(() => {}), d * 1000);
        return;
      }

      // ----- Perms BOT -----
      if (!message.guild.members.me.permissions.has(PermissionsBitField.Flags.ManageGuildExpressions)) {
        return message.channel.send({ content: "❌ Il me faut **Gérer les expressions**.", allowedMentions: { parse: [] } });
      }

      const raw = args[0];
      if (!raw) return message.channel.send({ content: "Utilisation : `+unrestrict <emoji | id_log>`", allowedMentions: { parse: [] } });

      let emoji = null;

      // 1) Si chiffre pur → on considère que c'est un ID de log
      if (/^\d+$/.test(raw)) {
        const logsKey = `emoji_restrict_logs_${message.guild.id}`;
        const logs = client.db.get(logsKey) || [];
        const entry = logs.find(x => x.id === Number(raw) && x.type === "restrict");
        if (!entry) return message.channel.send({ content: "ID de log introuvable.", allowedMentions: { parse: [] } });
        emoji = message.guild.emojis.cache.get(entry.emojiId) || null;
        if (!emoji) return message.channel.send({ content: "Émoji concerné introuvable sur ce serveur.", allowedMentions: { parse: [] } });
      } else {
        // 2) Sinon, on parse l'emoji
        const id = extractEmojiId(raw);
        if (id) emoji = message.guild.emojis.cache.get(id) || null;
        else {
          const q = raw.toLowerCase();
          emoji = message.guild.emojis.cache.find(e => e.name?.toLowerCase() === q) || null;
        }
        if (!emoji) return message.channel.send({ content: "Émoji introuvable sur ce serveur.", allowedMentions: { parse: [] } });
      }

      // Public = aucun rôle
      await emoji.edit({ roles: [] }, `unrestrict par ${message.author.tag} (${message.author.id})`).catch(() => null);

      return message.channel.send({
        content: `✅ Émoji **:${emoji.name}:** (\`${emoji.id}\`) est maintenant **public**.`,
        allowedMentions: { parse: [] }
      });

    } catch (e) {
      console.error(e);
      message.channel.send({ content: "❌ Erreur pendant le unrestrict.", allowedMentions: { parse: [] } });
    }
  }
};
