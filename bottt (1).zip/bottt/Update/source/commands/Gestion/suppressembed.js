// commands/admin/suppressembed.js
// Supprime les embeds d’un message par ID ou via une réponse.

const { PermissionsBitField } = require("discord.js");

module.exports = {
  name: "suppressembed",
  description: "Supprime les embeds d’un message par ID ou en répondant au message.",
  usages: "suppressembed [messageID]",
  example: "suppressembed 123456789012345678",
  run: async (client, message, args, commandName = "suppressembed") => {
    try {
      if (!message.guild) return;

      // ---- Permissions (ton style habituel) ----
      const wl = client.db.get(`wl.${message.guild.id}`) || [];
      const isBypassHard =
        client.staff?.includes?.(message.author.id) ||
        client.config?.buyers?.includes?.(message.author.id) ||
        client.db.get(`owner_${message.author.id}`) === true ||
        client.db.get(`owner_global_${message.author.id}`) === true ||
        wl.includes(message.author.id) ||
        message.guild.ownerId === message.author.id;

      let pass = isBypassHard;
      if (!pass) {
        const ps = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
        if (ps.length > 0) {
          const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
          const userRoles = message.member.roles.cache.map(r => r.id);
          pass = ps.some(perm => userPerms[perm]?.some?.(roleId => userRoles.includes(roleId)));
        } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") pass = true;
      }
      if (!pass) {
        const sent = await message.channel.send({ content: client.noperm || "Pas les permissions.", allowedMentions: { parse: [] } });
        const d = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (d > 0) setTimeout(() => sent.delete().catch(() => {}), d * 1000);
        return;
      }

      // ---- BOT perms ----
      if (!message.guild.members.me.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
        return message.channel.send({
          content: "❌ Il me faut la permission **Gérer les messages** pour modifier les embeds.",
          allowedMentions: { parse: [] }
        });
      }

      // ---- Trouver le message ciblé ----
      let target = null;

      // 1) ID donné en argument
      if (args[0]) {
        const id = args[0].match(/\d{15,20}/)?.[0];
        if (id) {
          try {
            target = await message.channel.messages.fetch(id);
          } catch { /* introuvable */ }
        }
      }

      // 2) Réponse directe
      if (!target && message.reference) {
        try {
          target = await message.channel.messages.fetch(message.reference.messageId);
        } catch { /* introuvable */ }
      }

      if (!target) {
        return message.channel.send({
          content: "❌ Message introuvable. Utilise `+suppressembed <messageID>` ou réponds à un message.",
          allowedMentions: { parse: [] }
        });
      }

      // ---- Vérifier qu’il y a des embeds ----
      if (!target.embeds?.length) {
        return message.channel.send({
          content: "ℹ️ Ce message n’a aucun embed.",
          allowedMentions: { parse: [] }
        });
      }

      // ---- Supprimer uniquement les embeds (edit du message) ----
      await target.edit({ embeds: [] });

      return message.channel.send({
        content: `✅ Les embeds du message \`${target.id}\` ont été supprimés.`,
        allowedMentions: { parse: [] }
      });

    } catch (e) {
      console.error(e);
      return message.channel.send({ content: "❌ Erreur pendant suppressembed.", allowedMentions: { parse: [] } });
    }
  }
};
