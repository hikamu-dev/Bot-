const Discord = require('discord.js');
const Astroia = require('../../structures/client');
const ms = require('ms');

module.exports = {
  name: "reportconfig",
  description: "Permet de configurer le système de report",
  
  /**
   * @param {Astroia} client
   * @param {Discord.Message} message
   */
  run: async (client, message, args, commandName) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) || 
                client.db.get(`owner_global_${message.author.id}`) === true || 

client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

    let msg = await message.reply({ content: 'Chargement en cours...' });

    async function update() {
      const db = client.db.get(`report_${message.guild.id}`) || { status: false, role: [], channel: null };

      const channelName = client.channels.cache.get(db.channel)?.name || "Aucun défini";
      const status = db.status ? '🟢 Activé' : '🔴 Désactivé';
      const roleNames = db.role.map(roleId => message.guild.roles.cache.get(roleId)?.name || "Inconnu");

      const embed = new Discord.EmbedBuilder()
        .setColor(client.color)
        .setFooter(client.footer)
        .setTitle('Système de Report')
        .addFields(
          { name: 'Statut', value: `\`\`\`${status}\`\`\``, inline: true },
          { name: "Rôles", value: `\`\`\`${roleNames.join(', ') || "Aucun rôle défini"}\`\`\``, inline: true },
          { name: "Salon", value: `\`\`\`${channelName}\`\`\``, inline: true }
        );

      const buttons = new Discord.ActionRowBuilder().addComponents(
        new Discord.ButtonBuilder()
          .setCustomId(`report_active_${message.id}`)
          .setEmoji(db.status ? '🟢' : '🔴')
          .setStyle(Discord.ButtonStyle.Secondary),
        new Discord.ButtonBuilder()
          .setCustomId(`report_role_${message.id}`)
          .setLabel('🎭 Rôles')
          .setStyle(Discord.ButtonStyle.Secondary),
        new Discord.ButtonBuilder()
          .setCustomId(`report_channel_${message.id}`)
          .setLabel('🏠 Salon')
          .setStyle(Discord.ButtonStyle.Secondary),
      );

      await msg.edit({ embeds: [embed], components: [buttons], content: null });
    }

    await update();

    const collector = message.channel.createMessageComponentCollector({
      filter: i => i.user.id === message.author.id,
      time: ms("2m"),
    });

    collector.on("collect", async (i) => {
      if (!i.deferred) await i.deferUpdate();

      const db = client.db.get(`report_${message.guild.id}`) || { status: false, role: [], channel: null };

      switch (i.customId) {
        case `report_role_${message.id}`:
          await i.editReply({
            content: "Sélectionne les rôles à ajouter ou retirer :",
            embeds: [],
            components: [
              new Discord.ActionRowBuilder().addComponents(
                new Discord.RoleSelectMenuBuilder()
                  .setCustomId(`report_role_select_${message.id}`)
                  .setMinValues(1)
                  .setMaxValues(25)
              ),
              new Discord.ActionRowBuilder().addComponents(
                new Discord.ButtonBuilder()
                  .setCustomId(`report_role_retour_${message.id}`)
                  .setStyle(Discord.ButtonStyle.Danger)
                  .setEmoji('◀')
              )
            ]
          });
          break;

        case `report_channel_${message.id}`:
          await i.editReply({
            content: "Choisis un salon pour recevoir les reports :",
            embeds: [],
            components: [
              new Discord.ActionRowBuilder().addComponents(
                new Discord.ChannelSelectMenuBuilder()
                  .setCustomId(`report_channel_select_${message.id}`)
                  .setChannelTypes([Discord.ChannelType.GuildText])
                  .setMinValues(1)
                  .setMaxValues(1)
              ),
              new Discord.ActionRowBuilder().addComponents(
                new Discord.ButtonBuilder()
                  .setCustomId(`report_role_retour_${message.id}`)
                  .setStyle(Discord.ButtonStyle.Danger)
                  .setEmoji('◀')
              )
            ]
          });
          break;

        case `report_role_retour_${message.id}`:
          await update();
          break;

        case `report_active_${message.id}`:
          db.status = !db.status;
          client.db.set(`report_${message.guild.id}`, db);
          await i.followUp({ content: `Le système de report est maintenant ${db.status ? "activé 🟢" : "désactivé 🔴"}`, ephemeral: true });
          await update();
          break;

        case `report_reset_${message.id}`:
          client.db.delete(`report_${message.guild.id}`);
          await i.followUp({ content: '`✅` Les paramètres de report ont été réinitialisés.', ephemeral: true });
          await update();
          break;

        case `report_channel_select_${message.id}`:
          db.channel = i.values[0];
          client.db.set(`report_${message.guild.id}`, db);
          await i.followUp({ content: `Salon défini : ${client.channels.cache.get(db.channel)?.name || "Inconnu"}`, ephemeral: true });
          await update();
          break;

        case `report_role_select_${message.id}`:
          const selectedRoles = i.values;
          const currentRoles = db.role || [];
          let added = 0, removed = 0, invalid = 0, inaccessible = 0;

          for (const roleId of selectedRoles) {
            const role = message.guild.roles.cache.get(roleId);
            if (!role) { invalid++; continue; }
            if (role.managed || !role.editable) { inaccessible++; continue; }

            if (currentRoles.includes(roleId)) {
              db.role = db.role.filter(id => id !== roleId);
              removed++;
            } else {
              db.role.push(roleId);
              added++;
            }
          }

          client.db.set(`report_${message.guild.id}`, db);

          let summary = [];
          if (added) summary.push(`➕ Ajouté : \`${added}\``);
          if (removed) summary.push(`➖ Retiré : \`${removed}\``);
          if (invalid) summary.push(`❌ Invalides : \`${invalid}\``);
          if (inaccessible) summary.push(`🔒 Inaccessibles : \`${inaccessible}\``);

          await i.followUp({ content: summary.join('\n'), ephemeral: true });
          await update();
          break;
      }
    });

    collector.on('end', () => {
      msg.edit({ components: [] });
    });
  }
};
