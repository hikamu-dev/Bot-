// commands/admin/restrictlist.js
// Liste interactive des émojis ACTUELLEMENT restreints (menu déroulant + pagination).
// Sélectionne un émoji pour voir les détails : rôles autorisés + dernier log connu.

const {
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle
} = require("discord.js");

function fmtDate(ts) {
  try { return new Date(ts).toLocaleString(); } catch { return String(ts); }
}

module.exports = {
  name: "restrictlist",
  description: "Affiche les émojis restreints via un menu déroulant (sélection pour voir les détails).",
  usages: "restrictlist",
  example: "restrictlist",
  /**
   * @param {import('discord.js').Client} client
   * @param {import('discord.js').Message} message
   * @param {string[]} args
   */
  run: async (client, message, args, commandName = "restrictlist") => {
    try {
      if (!message.guild) return;

      // ----- Permissions (ton style) -----
      const whitelistDB = client.db.get(`wl.${message.guild.id}`) || [];
      const isBypassHard =
        client.staff?.includes?.(message.author.id) ||
        client.config?.buyers?.includes?.(message.author.id) ||
        client.db.get(`owner_${message.author.id}`) === true ||
        client.db.get(`owner_global_${message.author.id}`) === true ||
        whitelistDB.includes(message.author.id) ||
        message.guild.ownerId === message.author.id;

      let pass = isBypassHard;
      if (!pass) {
        const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
        if (commandPerms.length > 0) {
          const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
          const userRoles = message.member.roles.cache.map(r => r.id);
          pass = commandPerms.some(perm => userPerms[perm]?.some?.(roleId => userRoles.includes(roleId)));
        } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") pass = true;
      }
      if (!pass) {
        const sent = await message.channel.send({ content: client.noperm || "Pas les permissions.", allowedMentions: { parse: [] } });
        const d = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (d > 0) setTimeout(() => sent.delete().catch(() => {}), d * 1000);
        return;
      }

      // ----- Construire la liste des émojis restreints (roles.size > 0) -----
      const all = [...message.guild.emojis.cache.values()];
      const restricted = all
        .filter(e => (e.roles?.size || 0) > 0)
        .sort((a, b) => (b.roles.size - a.roles.size) || a.name.localeCompare(b.name));

      if (!restricted.length) {
        return message.channel.send({
          content: "Aucun émoji restreint pour l’instant.",
          allowedMentions: { parse: [] }
        });
      }

      // Pagination (25 options max par menu)
      const PAGE_SIZE = 25;
      let page = 0;
      const pages = Math.ceil(restricted.length / PAGE_SIZE);

      const buildOptions = (p) => {
        const slice = restricted.slice(p * PAGE_SIZE, p * PAGE_SIZE + PAGE_SIZE);
        return slice.map(e => ({
          label: `:${e.name}:`,
          value: e.id,
          description: `Rôles autorisés: ${e.roles.size}`,
          emoji: { id: e.id, animated: e.animated || false } // affiche le visuel si dispo
        }));
      };

      const buildRow = (p) => {
        const select = new StringSelectMenuBuilder()
          .setCustomId(`rl:sel:${message.id}:${p}`)
          .setPlaceholder(`Sélectionne un émoji (page ${p + 1}/${pages})`)
          .addOptions(buildOptions(p));

        const buttons = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId(`rl:prev:${message.id}:${p}`)
            .setLabel("◀")
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(p === 0),
          new ButtonBuilder()
            .setCustomId(`rl:next:${message.id}:${p}`)
            .setLabel("▶")
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(p >= pages - 1)
        );

        return [new ActionRowBuilder().addComponents(select), buttons];
      };

      const baseEmbed = new EmbedBuilder()
        .setColor(0x2F3136)
        .setTitle("📜 Émojis restreints")
        .setDescription("Choisis un émoji dans le menu ci-dessous pour voir **les rôles autorisés** et le **dernier log** associé.\n*(Les détails s’affichent en privé pour toi.)*")
        .setFooter({ text: `Total restreints : ${restricted.length}` });

      const prompt = await message.channel.send({
        embeds: [baseEmbed],
        components: buildRow(page),
        allowedMentions: { parse: [] }
      });

      const collector = prompt.createMessageComponentCollector({ time: 2 * 60 * 1000 }); // 2 min

      collector.on("collect", async (itx) => {
        // sécurité : seul l’initiateur peut manipuler ce menu
        if (itx.user.id !== message.author.id) {
          return itx.reply({ content: "Seul l'initiateur peut utiliser ce menu.", ephemeral: true });
        }

        const [ns, kind, msgId, rawPage] = (itx.customId || "").split(":");
        if (ns !== "rl" || msgId !== message.id) return;

        // Navigation
        if (kind === "prev" || kind === "next") {
          let p = Number(rawPage) || 0;
          if (kind === "prev") p = Math.max(0, p - 1);
          if (kind === "next") p = Math.min(pages - 1, p + 1);
          page = p;
          await itx.update({
            components: buildRow(page)
          });
          return;
        }

        // Sélection d'un émoji
        if (kind === "sel") {
          const chosenId = itx.values?.[0];
          const emoji = message.guild.emojis.cache.get(chosenId);
          if (!emoji) {
            return itx.reply({ content: "Émoji introuvable.", ephemeral: true });
          }

          // Rôles autorisés
          const rolesTxt = emoji.roles?.size
            ? emoji.roles.map(r => `<@&${r.id}>`).join(", ")
            : "—";

          // Dernier log pour cet emoji (facultatif)
          const logs = (client.db.get(`emoji_restrict_logs_${message.guild.id}`) || [])
            .filter(x => x.emojiId === emoji.id && x.type === "restrict")
            .sort((a, b) => b.timestamp - a.timestamp);

          const last = logs[0] || null;
          const logTxt = last
            ? `**ID log :** \`${last.id}\`\n**Par :** <@${last.authorId}>\n**Date :** ${fmtDate(last.timestamp)}\n**Rôles set :** ${last.roles?.map(id => `<@&${id}>`).join(", ") || "—"}`
            : "_Pas de log enregistré pour cet émoji._";

          const emb = new EmbedBuilder()
            .setColor(0x5865F2)
            .setTitle(`🔒 Détails de : ${emoji}  \`:${emoji.name}:\``)
            .addFields(
              { name: "ID de l’émoji", value: `\`${emoji.id}\`` },
              { name: "Rôles autorisés (actuel)", value: rolesTxt },
              { name: "Dernier log", value: logTxt }
            );

          return itx.reply({ embeds: [emb], ephemeral: true });
        }
      });

      collector.on("end", async () => {
        try { await prompt.edit({ components: [] }); } catch {}
      });

    } catch (e) {
      console.error(e);
      message.channel.send({ content: "❌ Erreur pendant le restrictlist.", allowedMentions: { parse: [] } });
    }
  }
};
