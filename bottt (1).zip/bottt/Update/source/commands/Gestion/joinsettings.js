const ms = require('ms');
const {
    StringSelectMenuBuilder,
    ActionRowBuilder,
    EmbedBuilder,
    ChannelSelectMenuBuilder,
    ComponentType,
    ButtonBuilder,
    ButtonStyle,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle
} = require('discord.js');

module.exports = {
    name: 'joinsettings',
    description: 'Configurer le système de joins du bot (message, salon, DM, embed)',
    usage: "joinsettings",
    run: async (client, message, args, commandName) => {
        let pass = false;

        // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) || 
        client.db.get(`owner_global_${message.author.id}`) === true || 
client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
        } else {
            // Vérifier les permissions personnalisées pour la commande
            const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
            if (commandPerms.length > 0) {
                const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                const userRoles = message.member.roles.cache.map(role => role.id);
                pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
            } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                pass = true;
            }
        }

if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        const originalmsg = await message.channel.send('⚙️ Chargement du panneau de configuration...');

        async function updateEmbed() {
            const db = client.db.get(`joinsettings_${message.guild.id}`) || client.db.set(`joinsettings_${message.guild.id}`, {
                channel: null,
                message: null,
                status: false,
                embed: false,
                autoDelete: {
                    status: false,
                    time: 10
                },
                dm: {
                    status: false,
                    message: null,
                    embed: false,
                    autoDelete: {
                        status: false,
                        time: 10
                    }
                }
            });

            const getStatus = (val) => val ? '🟢 **Activé**' : '🔴 **Désactivé**';
            const getFormatStatus = (val) => val ? '📄 **Embed**' : '💬 **Message**';
            const getAutoDeleteStatus = (autoDelete) => autoDelete?.status ? `🟢 **Activé** (${autoDelete.time}s)` : '🔴 **Désactivé**';
            
            const channel = message.guild.channels.cache.get(db.channel);
            const channelDisplay = channel ? `<#${db.channel}>` : '`Aucun salon défini`';
            const welcomeMsg = db.message ? `\`\`\`\n${db.message.length > 100 ? db.message.substring(0, 100) + '...' : db.message}\`\`\`` : '`Aucun message défini`';
            const dmMsg = db.dm?.message ? `\`\`\`\n${db.dm.message.length > 100 ? db.dm.message.substring(0, 100) + '...' : db.dm.message}\`\`\`` : '`Aucun message défini`';

            const embed = new EmbedBuilder()
                .setTitle('⚙️ Configuration du Système de Bienvenue')
                .setDescription(`Pour le message de bienvenue (embed compris) vous pouvez utiliser les variables présentes dans la commande \`${client.prefix}variables\``)
                .setColor(client.color || '#2F3136')
                .setFooter(client.footer)
                .setTimestamp()
                .addFields(
                    {
                        name: '> 🏠 Configuration Principale',
                        value: [
                            `**Statut Général:** ${getStatus(db.status)}`,
                            `**Salon de bienvenue:** ${channelDisplay}`,
                            `**Format d'envoi:** ${getFormatStatus(db.embed)}`,
                            `**Suppression automatique:** ${getAutoDeleteStatus(db.autoDelete)}`,
                            '',
                            '💬 Message de Bienvenue',
                            welcomeMsg
                        ].join('\n'),
                        inline: true
                    },
                    {
                        name: '> 📩 Configuration Messages Privés',
                        value: [
                            `**Statut DM:** ${getStatus(db.dm?.status)}`,
                            `**Format DM:** ${getFormatStatus(db.dm?.embed)}`,
                            `**Suppression automatique MP:** ${getAutoDeleteStatus(db.dm?.autoDelete)}`,
                            '',
                            '✉️ Message de Bienvenue MP',
                            dmMsg
                        ].join('\n'),
                        inline: false
                    }
                );

            const mainSelect = new StringSelectMenuBuilder()
                .setCustomId(`joins_main_${message.id}`)
                .setPlaceholder('🔧 Sélectionnez une option à configurer')
                .setMaxValues(1)
                .addOptions([
                    { 
                        label: 'Activer/Désactiver le système', 
                        value: `toggle_status_${message.id}`,
                        description: 'Active ou désactive le système de bienvenue',
                        emoji: '🔄'
                    },
                    { 
                        label: 'Configurer le salon', 
                        value: `set_channel_${message.id}`,
                        description: 'Choisir le salon de bienvenue',
                        emoji: '🏠'
                    },
                    { 
                        label: 'Modifier le message', 
                        value: `set_message_${message.id}`,
                        description: 'Personnaliser le message de bienvenue',
                        emoji: '✏️'
                    },
                    { 
                        label: 'Format d\'envoi', 
                        value: `toggle_embed_${message.id}`,
                        description: 'Choisir entre embed et message texte',
                        emoji: '📄'
                    },
                    { 
                        label: 'Suppression automatique', 
                        value: `toggle_autodelete_${message.id}`,
                        description: 'Configurer la suppression automatique des messages',
                        emoji: '⏰'
                    }
                ]);

            const dmSelect = new StringSelectMenuBuilder()
                .setCustomId(`joins_dm_${message.id}`)
                .setPlaceholder('📩 Configuration des Messages Privés')
                .setMaxValues(1)
                .addOptions([
                    { 
                        label: 'Activer/Désactiver les DM', 
                        value: `toggle_dm_status_${message.id}`,
                        description: 'Active ou désactive les messages privés',
                        emoji: '🔄'
                    },
                    { 
                        label: 'Modifier le message DM', 
                        value: `set_dm_message_${message.id}`,
                        description: 'Personnaliser le message privé',
                        emoji: '✏️'
                    },
                    { 
                        label: 'Format DM', 
                        value: `toggle_dm_embed_${message.id}`,
                        description: 'Choisir entre embed et message texte pour les DM',
                        emoji: '📄'
                    },
                    { 
                        label: 'Suppression automatique MP', 
                        value: `toggle_dm_autodelete_${message.id}`,
                        description: 'Configurer la suppression automatique des MP',
                        emoji: '⏰'
                    }
                ]);

            const actionButtons = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId(`test_welcome_${message.id}`)
                        .setLabel('Tester')
                        .setStyle(ButtonStyle.Primary)
                        .setEmoji('🧪'),
                    new ButtonBuilder()
                        .setCustomId(`validate_config_${message.id}`)
                        .setLabel('Valider')
                        .setStyle(ButtonStyle.Success)
                        .setEmoji('✅'),
                    new ButtonBuilder()
                        .setCustomId(`reset_config_${message.id}`)
                        .setLabel('Réinitialiser')
                        .setStyle(ButtonStyle.Danger)
                        .setEmoji('🗑️')
                );

            const rows = [
                new ActionRowBuilder().addComponents(mainSelect),
                new ActionRowBuilder().addComponents(dmSelect),
                actionButtons
            ];

            await originalmsg.edit({ content: null, components: rows, embeds: [embed] });
        }

        await updateEmbed();

        const collector = message.channel.createMessageComponentCollector({
            filter: i => i.user.id === message.author.id && i.isSelectMenu(),
            time: ms("10m")
        });

        const channelCollector = message.channel.createMessageComponentCollector({
            filter: i => i.user.id === message.author.id && i.customId === `channel_select_${message.id}`,
            componentType: ComponentType.ChannelSelect,
            time: ms("10m")
        });

        collector.on("collect", async (i) => {
            const db = client.db.get(`joinsettings_${message.guild.id}`);

            switch (i.values?.[0]) {
                case `toggle_status_${message.id}`:
                    if (!db.channel || !db.message) {
                        const missing = [];
                        if (!db.channel) missing.push('🏠 **Salon de bienvenue**');
                        if (!db.message) missing.push('💬 **Message de bienvenue**');
                        
                        const errorEmbed = new EmbedBuilder()
                            .setTitle('⚠️ Configuration Incomplète')
                            .setDescription(`Veuillez d'abord configurer :\n${missing.join('\n')}`)
                            .setColor(client.color)
                            .setFooter({ text: 'Configuration requise' });
                            
                        return i.reply({ embeds: [errorEmbed], ephemeral: true });
                    }
                    db.status = !db.status;
                    client.db.set(`joinsettings_${message.guild.id}`, db);
                    
                    const statusEmbed = new EmbedBuilder()
                        .setTitle(db.status ? '🟢 Système Activé' : '🔴 Système Désactivé')
                        .setDescription(`Le système de bienvenue est maintenant **${db.status ? 'activé' : 'désactivé'}**.`)
                        .setColor(db.status ? '#4CAF50' : '#FF6B6B')
                        .setFooter({ text: 'Statut mis à jour' });
                        
                    await i.reply({ embeds: [statusEmbed], ephemeral: true });
                    await updateEmbed();
                    break;

                case `set_channel_${message.id}`:
                    const channelSelect = new ChannelSelectMenuBuilder()
                        .setChannelTypes(0)
                        .setMinValues(1)
                        .setMaxValues(1)
                        .setPlaceholder('🏠 Sélectionnez le salon de bienvenue')
                        .setCustomId(`channel_select_${message.id}`);
                        
                    const channelRow = new ActionRowBuilder().addComponents(channelSelect);
                    
                    const channelEmbed = new EmbedBuilder()
                        .setTitle('🏠 Sélection du Salon')
                        .setDescription('Choisissez le salon où les messages de bienvenue seront envoyés.')
                        .setColor(client.color)
                        .setFooter({ text: 'Sélectionnez un salon' });
                        
                    return i.reply({ embeds: [channelEmbed], components: [channelRow], ephemeral: true });

                case `toggle_embed_${message.id}`:
                    return showFormatModal(i, db, 'welcome');

                case `toggle_dm_embed_${message.id}`:
                    return showFormatModal(i, db, 'dm');

                case `toggle_autodelete_${message.id}`:
                    return showAutoDeleteModal(i, db, 'welcome');

                case `toggle_dm_autodelete_${message.id}`:
                    return showAutoDeleteModal(i, db, 'dm');

                case `set_message_${message.id}`:
                    return showMessageModal(i, db, 'welcome');

                case `toggle_dm_status_${message.id}`:
                    db.dm.status = !db.dm.status;
                    client.db.set(`joinsettings_${message.guild.id}`, db);
                    
                    const dmStatusEmbed = new EmbedBuilder()
                        .setTitle(db.dm.status ? '📱 Messages Privés Activés' : '📱 Messages Privés Désactivés')
                        .setDescription(`Les messages privés sont maintenant **${db.dm.status ? 'activés' : 'désactivés'}**.`)
                        .setColor(client.color)
                        .setFooter({ text: 'Statut DM mis à jour' });
                        
                    await i.reply({ embeds: [dmStatusEmbed], ephemeral: true });
                    await updateEmbed();
                    break;

                case `set_dm_message_${message.id}`:
                    return showMessageModal(i, db, 'dm');
            }
        });

        channelCollector.on("collect", async (i) => {
            const db = client.db.get(`joinsettings_${message.guild.id}`);
            const selectedChannel = i.values[0];
            const channel = message.guild.channels.cache.get(selectedChannel);
            
            db.channel = selectedChannel;
            client.db.set(`joinsettings_${message.guild.id}`, db);
            
            const successEmbed = new EmbedBuilder()
                .setTitle('✅ Salon Configuré')
                .setDescription(`Le salon de bienvenue a été défini sur ${channel}.`)
                .setColor(client.color)
                .setFooter({ text: 'Salon mis à jour' });
                
            await i.update({ embeds: [successEmbed], components: [] });
            await updateEmbed();
        });

        // Handle button interactions
        const buttonCollector = message.channel.createMessageComponentCollector({
            filter: i => i.user.id === message.author.id && i.isButton(),
            time: ms("10m")
        });

        buttonCollector.on("collect", async (i) => {
            const db = client.db.get(`joinsettings_${message.guild.id}`);

            switch (i.customId) {
                case `test_welcome_${message.id}`:
                    return testWelcomeMessage(i, db);

                case `validate_config_${message.id}`:
                    return validateConfiguration(i, db);

                case `reset_config_${message.id}`:
                    return showResetModal(i, db);
            }
        });

        // Handle modal submissions via interactionCreate
        const modalHandler = async (interaction) => {
            if (!interaction.isModalSubmit() || interaction.user.id !== message.author.id) return;
            if (!interaction.customId.includes(message.id)) return;

            try {
                const db = client.db.get(`joinsettings_${message.guild.id}`);
                
                if (interaction.customId === `message_modal_welcome_${message.id}`) {
                    const messageContent = interaction.fields.getTextInputValue('message_input');
                    db.message = messageContent;
                    client.db.set(`joinsettings_${message.guild.id}`, db);
                    
                    const successEmbed = new EmbedBuilder()
                        .setTitle('✅ Message Enregistré')
                        .setDescription('Le message de bienvenue a été mis à jour avec succès.')
                        .setColor(client.color)
                        .setFooter({ text: 'Message mis à jour' });
                    
                    await interaction.reply({ embeds: [successEmbed], ephemeral: true });
                    await updateEmbed();
                }
                
                else if (interaction.customId === `message_modal_dm_${message.id}`) {
                    const messageContent = interaction.fields.getTextInputValue('message_input');
                    db.dm = db.dm || {};
                    db.dm.message = messageContent;
                    client.db.set(`joinsettings_${message.guild.id}`, db);
                    
                    const successEmbed = new EmbedBuilder()
                        .setTitle('✅ Message Enregistré')
                        .setDescription('Le message privé a été mis à jour avec succès.')
                        .setColor(client.color)
                        .setFooter({ text: 'Message mis à jour' });
                    
                    await interaction.reply({ embeds: [successEmbed], ephemeral: true });
                    await updateEmbed();
                }
                
                else if (interaction.customId === `format_modal_welcome_${message.id}`) {
                    const format = interaction.fields.getTextInputValue('format_input').toLowerCase();
                    
                    if (format === 'embed' || format === 'message') {
                        db.embed = format === 'embed';
                        client.db.set(`joinsettings_${message.guild.id}`, db);
                        
                        const successEmbed = new EmbedBuilder()
                            .setTitle('✅ Format Mis à Jour')
                            .setDescription(`Le format de bienvenue a été défini sur **${format === 'embed' ? 'Embed' : 'Message texte'}**.`)
                            .setColor(client.color)
                            .setFooter({ text: 'Format mis à jour' });
                        
                        await interaction.reply({ embeds: [successEmbed], ephemeral: true });
                        await updateEmbed();
                    } else {
                        const errorEmbed = new EmbedBuilder()
                            .setTitle('❌ Format Invalide')
                            .setDescription('Veuillez entrer "embed" ou "message".')
                            .setColor(client.color)
                            .setFooter({ text: 'Format non reconnu' });
                        
                        await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
                    }
                }
                
                else if (interaction.customId === `format_modal_dm_${message.id}`) {
                    const format = interaction.fields.getTextInputValue('format_input').toLowerCase();
                    
                    if (format === 'embed' || format === 'message') {
                        db.dm.embed = format === 'embed';
                        client.db.set(`joinsettings_${message.guild.id}`, db);
                        
                        const successEmbed = new EmbedBuilder()
                            .setTitle('✅ Format Mis à Jour')
                            .setDescription(`Le format des messages privés a été défini sur **${format === 'embed' ? 'Embed' : 'Message texte'}**.`)
                            .setColor(client.color)
                            .setFooter({ text: 'Format mis à jour' });
                        
                        await interaction.reply({ embeds: [successEmbed], ephemeral: true });
                        await updateEmbed();
                    } else {
                        const errorEmbed = new EmbedBuilder()
                            .setTitle('❌ Format Invalide')
                            .setDescription('Veuillez entrer "embed" ou "message".')
                            .setColor(client.color)
                            .setFooter({ text: 'Format non reconnu' });
                        
                        await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
                    }
                }
                
                else if (interaction.customId === `autodelete_modal_welcome_${message.id}`) {
                    const status = interaction.fields.getTextInputValue('autodelete_status').toLowerCase();
                    const timeInput = interaction.fields.getTextInputValue('autodelete_time');
                    
                    if (status === 'on' || status === 'off') {
                        db.autoDelete = db.autoDelete || {};
                        db.autoDelete.status = status === 'on';
                        
                        if (status === 'on') {
                            const time = parseInt(timeInput);
                            if (isNaN(time) || time < 5 || time > 300) {
                                const errorEmbed = new EmbedBuilder()
                                    .setTitle('❌ Temps Invalide')
                                    .setDescription('Le temps doit être un nombre entre 5 et 300 secondes.')
                                    .setColor(client.color)
                                    .setFooter({ text: 'Temps invalide' });
                                
                                return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
                            }
                            db.autoDelete.time = time;
                        }
                        
                        client.db.set(`joinsettings_${message.guild.id}`, db);
                        
                        const successEmbed = new EmbedBuilder()
                            .setTitle('✅ Suppression Automatique Configurée')
                            .setDescription(`La suppression automatique des messages de bienvenue est maintenant **${status === 'on' ? `activée (${db.autoDelete.time}s)` : 'désactivée'}**.`)
                            .setColor(client.color)
                            .setFooter({ text: 'Suppression automatique configurée' });
                        
                        await interaction.reply({ embeds: [successEmbed], ephemeral: true });
                        await updateEmbed();
                    } else {
                        const errorEmbed = new EmbedBuilder()
                            .setTitle('❌ Statut Invalide')
                            .setDescription('Veuillez entrer "on" ou "off".')
                            .setColor(client.color)
                            .setFooter({ text: 'Statut invalide' });
                        
                        await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
                    }
                }
                
                else if (interaction.customId === `autodelete_modal_dm_${message.id}`) {
                    const status = interaction.fields.getTextInputValue('autodelete_status').toLowerCase();
                    const timeInput = interaction.fields.getTextInputValue('autodelete_time');
                    
                    if (status === 'on' || status === 'off') {
                        db.dm.autoDelete = db.dm.autoDelete || {};
                        db.dm.autoDelete.status = status === 'on';
                        
                        if (status === 'on') {
                            const time = parseInt(timeInput);
                            if (isNaN(time) || time < 5 || time > 300) {
                                const errorEmbed = new EmbedBuilder()
                                    .setTitle('❌ Temps Invalide')
                                    .setDescription('Le temps doit être un nombre entre 5 et 300 secondes.')
                                    .setColor(client.color)
                                    .setFooter({ text: 'Temps invalide' });
                                
                                return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
                            }
                            db.dm.autoDelete.time = time;
                        }
                        
                        client.db.set(`joinsettings_${message.guild.id}`, db);
                        
                        const successEmbed = new EmbedBuilder()
                            .setTitle('✅ Suppression Automatique MP Configurée')
                            .setDescription(`La suppression automatique des messages privés est maintenant **${status === 'on' ? `activée (${db.dm.autoDelete.time}s)` : 'désactivée'}**.`)
                            .setColor(client.color)
                            .setFooter({ text: 'Suppression automatique MP configurée' });
                        
                        await interaction.reply({ embeds: [successEmbed], ephemeral: true });
                        await updateEmbed();
                    } else {
                        const errorEmbed = new EmbedBuilder()
                            .setTitle('❌ Statut Invalide')
                            .setDescription('Veuillez entrer "on" ou "off".')
                            .setColor(client.color)
                            .setFooter({ text: 'Statut invalide' });
                        
                        await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
                    }
                }
                
                else if (interaction.customId === `reset_modal_${message.id}`) {
                    const confirmation = interaction.fields.getTextInputValue('reset_confirmation').toLowerCase();
                    
                    if (confirmation === 'reset' || confirmation === 'réinitialiser') {
                        client.db.delete(`joinsettings_${message.guild.id}`);
                        
                        const successEmbed = new EmbedBuilder()
                            .setTitle('✅ Configuration Réinitialisée')
                            .setDescription('Tous les paramètres ont été effacés.')
                            .setColor(client.color)
                            .setFooter({ text: 'Réinitialisation terminée' });
                        
                        await interaction.reply({ embeds: [successEmbed], ephemeral: true });
                        await updateEmbed();
                    } else {
                        const errorEmbed = new EmbedBuilder()
                            .setTitle('❌ Confirmation Incorrecte')
                            .setDescription('Veuillez taper "reset" ou "réinitialiser" pour confirmer.')
                            .setColor(client.color)
                            .setFooter({ text: 'Réinitialisation annulée' });
                        
                        await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
                    }
                }
            } catch (error) {
                console.error('Erreur dans le traitement du modal:', error);
                
                if (!interaction.replied && !interaction.deferred) {
                    const errorEmbed = new EmbedBuilder()
                        .setTitle('❌ Erreur')
                        .setDescription('Une erreur s\'est produite lors du traitement de votre demande.')
                        .setColor('#FF0000')
                        .setFooter({ text: 'Erreur système' });
                    
                    await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
                }
            }
        };

        // Register modal handler
        client.on('interactionCreate', modalHandler);

        // Cleanup when collectors end
        const cleanup = () => {
            client.removeListener('interactionCreate', modalHandler);
            collector.stop();
            channelCollector.stop();
            buttonCollector.stop();
            
            const expiredEmbed = new EmbedBuilder()
                .setTitle('⏰ Session Expirée')
                .setDescription('Le panneau de configuration a expiré.')
                .setColor(client.color)
                .setFooter({ text: 'Utilisez la commande à nouveau pour configurer' });
                
            originalmsg.edit({ embeds: [expiredEmbed], components: [] }).catch(() => {});
        };

        collector.on("end", cleanup);
        channelCollector.on("end", cleanup);
        buttonCollector.on("end", cleanup);

        async function showFormatModal(interaction, db, type) {
            const isForDM = type === 'dm';
            const currentFormat = isForDM ? (db.dm?.embed ? 'embed' : 'message') : (db.embed ? 'embed' : 'message');
            
            const modal = new ModalBuilder()
                .setCustomId(`format_modal_${type}_${message.id}`)
                .setTitle(`📄 Format ${isForDM ? 'DM' : 'de Bienvenue'}`);

            const formatInput = new TextInputBuilder()
                .setCustomId('format_input')
                .setLabel('Format d\'envoi')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('Tapez "embed" ou "message"')
                .setValue(currentFormat)
                .setRequired(true)
                .setMaxLength(10);

            const row = new ActionRowBuilder().addComponents(formatInput);
            modal.addComponents(row);
            await interaction.showModal(modal);
        }

        async function showAutoDeleteModal(interaction, db, type) {
            const isForDM = type === 'dm';
            const currentAutoDelete = isForDM ? (db.dm?.autoDelete || {}) : (db.autoDelete || {});
            const currentStatus = currentAutoDelete.status ? 'on' : 'off';
            const currentTime = currentAutoDelete.time || 10;
            
            const modal = new ModalBuilder()
                .setCustomId(`autodelete_modal_${type}_${message.id}`)
                .setTitle(`🗑️ Suppression Automatique ${isForDM ? 'MP' : ''}`);

            const statusInput = new TextInputBuilder()
                .setCustomId('autodelete_status')
                .setLabel('Statut de la suppression automatique')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('Tapez "on" ou "off"')
                .setValue(currentStatus)
                .setRequired(true)
                .setMaxLength(5);

            const timeInput = new TextInputBuilder()
                .setCustomId('autodelete_time')
                .setLabel('Temps avant suppression (en secondes)')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('Entre 5 et 300 secondes')
                .setValue(currentTime.toString())
                .setRequired(false)
                .setMaxLength(3);

            const row1 = new ActionRowBuilder().addComponents(statusInput);
            const row2 = new ActionRowBuilder().addComponents(timeInput);
            modal.addComponents(row1, row2);
            await interaction.showModal(modal);
        }

async function showMessageModal(interaction, db, type) {
            const isForDM = type === 'dm';
            const currentMessage = isForDM ? (db.dm?.message || '') : (db.message || '');
            
            const modal = new ModalBuilder()
                .setCustomId(`message_modal_${type}_${message.id}`)
                .setTitle(`💬 Message ${isForDM ? 'Privé' : 'de Bienvenue'}`);

            const messageInput = new TextInputBuilder()
                .setCustomId('message_input')
                .setLabel(`Message ${isForDM ? 'privé' : 'de bienvenue'}`)
                .setStyle(TextInputStyle.Paragraph)
                .setPlaceholder('Tapez votre message ici... Variables: {user}, {guild}, {memberCount}')
                .setValue(currentMessage)
                .setRequired(true)
                .setMaxLength(2000);

            const row = new ActionRowBuilder().addComponents(messageInput);
            modal.addComponents(row);
            await interaction.showModal(modal);
        }

        async function showResetModal(interaction, db) {
            const modal = new ModalBuilder()
                .setCustomId(`reset_modal_${message.id}`)
                .setTitle('🗑️ Réinitialisation Configuration');

            const confirmInput = new TextInputBuilder()
                .setCustomId('reset_confirmation')
                .setLabel('Confirmation')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('Tapez "reset" ou "réinitialiser" pour confirmer')
                .setRequired(true)
                .setMaxLength(20);

            const row = new ActionRowBuilder().addComponents(confirmInput);
            modal.addComponents(row);
            await interaction.showModal(modal);
        }

        async function testWelcomeMessage(interaction, db) {
            if (!db.status || !db.channel || !db.message) {
                const missing = [];
                if (!db.status) missing.push('🔴 **Système non activé**');
                if (!db.channel) missing.push('🏠 **Salon non défini**');
                if (!db.message) missing.push('💬 **Message non défini**');
                
                const errorEmbed = new EmbedBuilder()
                    .setTitle('⚠️ Test Impossible')
                    .setDescription(`Le test ne peut pas être effectué car :\n${missing.join('\n')}`)
                    .setColor('#FF6B6B')
                    .setFooter({ text: 'Configuration requise' });
                    
                return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }

            const testChannel = message.guild.channels.cache.get(db.channel);
            if (!testChannel) {
                const errorEmbed = new EmbedBuilder()
                    .setTitle('❌ Salon Introuvable')
                    .setDescription('Le salon configuré n\'existe plus ou n\'est pas accessible.')
                    .setColor('#FF6B6B')
                    .setFooter({ text: 'Erreur de configuration' });
                    
                return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }

            try {
                // Simuler l'arrivée de l'utilisateur
                const testMessage = db.message
                    .replace(/{user}/g, `<@${message.author.id}>`)
                    .replace(/{guild}/g, message.guild.name)
                    .replace(/{memberCount}/g, message.guild.memberCount.toString());

                if (db.embed) {
                    const welcomeEmbed = new EmbedBuilder()
                        .setDescription(testMessage)
                        .setColor(client.color || '#2F3136')
                        .setFooter({ text: '🧪 Message de test' })
                        .setTimestamp();
                        
                    const sentMessage = await testChannel.send({ embeds: [welcomeEmbed] });
                    
                    // Suppression automatique si configurée
                    if (db.autoDelete?.status) {
                        setTimeout(() => {
                            sentMessage.delete().catch(() => {});
                        }, db.autoDelete.time * 1000);
                    }
                } else {
                    const sentMessage = await testChannel.send(testMessage);
                    
                    // Suppression automatique si configurée
                    if (db.autoDelete?.status) {
                        setTimeout(() => {
                            sentMessage.delete().catch(() => {});
                        }, db.autoDelete.time * 1000);
                    }
                }

                // Test DM si activé
                if (db.dm?.status && db.dm?.message) {
                    const dmTestMessage = db.dm.message
                        .replace(/{user}/g, `<@${message.author.id}>`)
                        .replace(/{guild}/g, message.guild.name)
                        .replace(/{memberCount}/g, message.guild.memberCount.toString());

                    if (db.dm.embed) {
                        const dmEmbed = new EmbedBuilder()
                            .setDescription(dmTestMessage)
                            .setColor(client.color || '#2F3136')
                            .setFooter({ text: '🧪 Message de test DM' })
                            .setTimestamp();
                            
                        const dmMessage = await message.author.send({ embeds: [dmEmbed] });
                        
                        // Suppression automatique DM si configurée
                        if (db.dm.autoDelete?.status) {
                            setTimeout(() => {
                                dmMessage.delete().catch(() => {});
                            }, db.dm.autoDelete.time * 1000);
                        }
                    } else {
                        const dmMessage = await message.author.send(dmTestMessage);
                        
                        // Suppression automatique DM si configurée
                        if (db.dm.autoDelete?.status) {
                            setTimeout(() => {
                                dmMessage.delete().catch(() => {});
                            }, db.dm.autoDelete.time * 1000);
                        }
                    }
                }

                const successEmbed = new EmbedBuilder()
                    .setTitle('✅ Test Réussi')
                    .setDescription(`Le message de test a été envoyé dans ${testChannel}${db.dm?.status ? ' et en message privé' : ''}.`)
                    .setColor('#4CAF50')
                    .setFooter({ text: 'Test terminé' });
                    
                await interaction.reply({ embeds: [successEmbed], ephemeral: true });
            } catch (error) {
                console.error('Erreur lors du test:', error);
                
                const errorEmbed = new EmbedBuilder()
                    .setTitle('❌ Erreur de Test')
                    .setDescription('Une erreur s\'est produite lors de l\'envoi du message de test.')
                    .setColor('#FF6B6B')
                    .setFooter({ text: 'Erreur système' });
                    
                await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }
        }

        async function validateConfiguration(interaction, db) {
            const issues = [];
            
            if (!db.status) {
                issues.push('🔴 **Système non activé**');
            }
            
            if (!db.channel) {
                issues.push('🏠 **Salon de bienvenue non défini**');
            } else {
                const channel = message.guild.channels.cache.get(db.channel);
                if (!channel) {
                    issues.push('🏠 **Salon de bienvenue introuvable**');
                } else if (!channel.permissionsFor(message.guild.members.me).has(['SendMessages', 'ViewChannel'])) {
                    issues.push('🏠 **Permissions insuffisantes dans le salon de bienvenue**');
                }
            }
            
            if (!db.message) {
                issues.push('💬 **Message de bienvenue non défini**');
            }
            
            if (db.dm?.status && !db.dm?.message) {
                issues.push('✉️ **Message privé activé mais non défini**');
            }

            if (issues.length > 0) {
                const errorEmbed = new EmbedBuilder()
                    .setTitle('⚠️ Configuration Incomplète')
                    .setDescription(`Problèmes détectés :\n${issues.join('\n')}`)
                    .setColor('#FF6B6B')
                    .setFooter({ text: 'Configuration requise' });
                    
                return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }

            const successEmbed = new EmbedBuilder()
                .setTitle('✅ Configuration Validée')
                .setDescription('La configuration est complète et fonctionnelle !')
                .addFields(
                    { name: '🏠 Salon', value: `<#${db.channel}>`, inline: true },
                    { name: '📄 Format', value: db.embed ? 'Embed' : 'Message', inline: true },
                    { name: '🗑️ Suppression', value: db.autoDelete?.status ? `${db.autoDelete.time}s` : 'Désactivée', inline: true },
                    { name: '📱 DM', value: db.dm?.status ? 'Activé' : 'Désactivé', inline: true }
                )
                .setColor('#4CAF50')
                .setFooter({ text: 'Configuration vérifiée' });
                
            await interaction.reply({ embeds: [successEmbed], ephemeral: true });
        }
    }
}