// commands/admin/restrict.js
// +restrict <emoji> → ouvre un menu multi-sélection de rôles autorisés pour cet emoji.
// Loggue l'action avec un ID numérique pour pouvoir l'identifier (+restrictlist / +unrestrict <ID>)

const {
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  PermissionsBitField
} = require("discord.js");

function extractEmojiId(input = "") {
  // formats: <:name:123> ou <a:name:123> ou ID direct
  const m = input.match(/<?a?:\w+:(\d{15,20})>?/);
  if (m) return m[1];
  if (/^\d{15,20}$/.test(input)) return input;
  return null;
}

module.exports = {
  name: "restrict",
  description: "Restreint un émoji via un menu de rôles (multi-sélection).",
  usages: "restrict <emoji>",
  example: "restrict <:cool:123456789012345678>",
  /**
   * @param {import('discord.js').Client} client
   * @param {import('discord.js').Message} message
   * @param {string[]} args
   */
  run: async (client, message, args, commandName = "restrict") => {
    try {
      if (!message.guild) return;

      // ----- Permissions (même logique que chez toi) -----
      const whitelistDB = client.db.get(`wl.${message.guild.id}`) || [];
      const isBypassHard =
        client.staff?.includes?.(message.author.id) ||
        client.config?.buyers?.includes?.(message.author.id) ||
        client.db.get(`owner_${message.author.id}`) === true ||
        client.db.get(`owner_global_${message.author.id}`) === true ||
        whitelistDB.includes(message.author.id) ||
        message.guild.ownerId === message.author.id;

      let pass = isBypassHard;
      if (!pass) {
        const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
        if (commandPerms.length > 0) {
          const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
          const userRoles = message.member.roles.cache.map(r => r.id);
          pass = commandPerms.some(perm => userPerms[perm]?.some?.(roleId => userRoles.includes(roleId)));
        } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") pass = true;
      }
      if (!pass) {
        const sent = await message.channel.send({ content: client.noperm || "Pas les permissions.", allowedMentions: { parse: [] } });
        const d = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (d > 0) setTimeout(() => sent.delete().catch(() => {}), d * 1000);
        return;
      }

      // ----- Perms du BOT -----
      if (!message.guild.members.me.permissions.has(PermissionsBitField.Flags.ManageGuildExpressions)) {
        return message.channel.send({ content: "❌ Il me faut **Gérer les expressions** pour modifier les émojis.", allowedMentions: { parse: [] } });
      }

      // ----- Cible: emoji -----
      const raw = args[0];
      if (!raw) return message.channel.send({ content: "Utilisation : `+restrict <emoji>`", allowedMentions: { parse: [] } });

      const id = extractEmojiId(raw);
      let emoji = null;
      if (id) emoji = message.guild.emojis.cache.get(id) || null;
      else {
        const q = raw.toLowerCase();
        emoji = message.guild.emojis.cache.find(e => e.name?.toLowerCase() === q) || null;
      }
      if (!emoji) return message.channel.send({ content: "Émoji introuvable sur ce serveur.", allowedMentions: { parse: [] } });

      // ----- Préparer menu rôles -----
      // On liste les rôles gérables (hors @everyone), on en prend max 25 (limite Discord)
      const roles = message.guild.roles.cache
        .filter(r => r.id !== message.guild.roles.everyone.id)
        .sort((a, b) => b.position - a.position)
        .first(25);

      if (!roles.length) {
        return message.channel.send({ content: "Aucun rôle sélectionnable trouvé.", allowedMentions: { parse: [] } });
      }

      const options = roles.map(r => ({
        label: r.name.slice(0, 100),
        value: r.id,
        description: `ID: ${r.id}`.slice(0, 100)
      }));

      const select = new StringSelectMenuBuilder()
        .setCustomId(`restrict:${message.id}:${emoji.id}`)
        .setPlaceholder("Choisis un ou plusieurs rôles autorisés")
        .setMinValues(1)
        .setMaxValues(Math.min(roles.length, 25))
        .addOptions(options);

      const row = new ActionRowBuilder().addComponents(select);

      const embed = new EmbedBuilder()
        .setColor(0x2F3136)
        .setTitle("🎯 Restriction d’émoji")
        .setDescription(`Émoji cible : ${emoji} \`:${emoji.name}:\` (\`${emoji.id}\`)\n\nSélectionne **les rôles** qui pourront utiliser **cet émoji**.`)
        .setFooter({ text: `Auteur : ${message.author.tag}` });

      const prompt = await message.channel.send({ embeds: [embed], components: [row], allowedMentions: { parse: [] } });

      const collector = prompt.createMessageComponentCollector({ time: 60_000 });

      collector.on("collect", async (itx) => {
        if (itx.user.id !== message.author.id) {
          return itx.reply({ content: "Seul l'initiateur peut utiliser ce menu.", ephemeral: true });
        }
        const [key, msgId, emId] = itx.customId.split(":");
        if (key !== "restrict" || msgId !== message.id || emId !== emoji.id) return;

        const picked = itx.values; // array of roleIds
        await itx.deferUpdate();

        try {
          await emoji.edit({ roles: picked }, `restrict par ${message.author.tag} (${message.author.id})`);
        } catch {
          return prompt.edit({ content: "❌ Échec de la mise à jour de l'émoji.", components: [], embeds: [], allowedMentions: { parse: [] } });
        }

        // ---- Log avec ID numérique ----
        const gid = message.guild.id;
        const counterKey = `emoji_restrict_lastid_${gid}`;
        const logsKey = `emoji_restrict_logs_${gid}`;
        const nextId = (client.db.get(counterKey) || 0) + 1;

        const entry = {
          id: nextId,
          emojiId: emoji.id,
          emojiName: emoji.name,
          roles: picked,
          authorId: message.author.id,
          channelId: message.channel.id,
          timestamp: Date.now(),
          type: "restrict"
        };

        const current = client.db.get(logsKey) || [];
        current.push(entry);
        client.db.set(counterKey, nextId);
        client.db.set(logsKey, current);

        const done = new EmbedBuilder()
          .setColor(0x57F287)
          .setTitle("✅ Restriction appliquée")
          .setDescription([
            `Émoji : ${emoji} \`:${emoji.name}:\` (\`${emoji.id}\`)`,
            `Rôles autorisés : ${picked.map(id => `<@&${id}>`).join(", ")}`,
            `ID de log : \`${nextId}\` (utilisable avec \`+unrestrict ${nextId}\`)`
          ].join("\n"));

        await prompt.edit({ embeds: [done], components: [], allowedMentions: { parse: [] } });
        collector.stop("done");
      });

      collector.on("end", async (reason) => {
        if (reason !== "done") {
          try { await prompt.edit({ components: [] }); } catch {}
        }
      });

    } catch (e) {
      console.error(e);
      message.channel.send({ content: "❌ Erreur pendant le restrict.", allowedMentions: { parse: [] } });
    }
  }
};
