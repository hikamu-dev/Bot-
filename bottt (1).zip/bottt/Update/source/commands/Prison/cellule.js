const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'cellule',
  description: 'Gérer les membres en prison',
  use: 'cellule <add|remove|list|clear> [@membre]',
  run: async (client, message, args) => {
    const sub = args[0];
    const memberArg = args[1];
    const guildId = message.guild.id;
    const prisonRoleId = client.db.get(`prison_role_${guildId}`);
    const prisonChannelId = client.db.get(`prison_channel_${guildId}`);
    if (!prisonRoleId || !prisonChannelId) {
      return message.reply('Le système de prison n\'est pas configuré.');
    }
    let prisonMembers = client.db.get(`prison_members_${guildId}`) || [];

    if (sub === 'add') {
      if (!memberArg) return message.reply('Mentionne un membre à emprisonner.');
      const member = message.mentions.members.first() || message.guild.members.cache.get(memberArg);
      if (!member) return message.reply('Membre introuvable.');
      // Vérification whitelist
      const whitelist = client.db.get(`prison_whitelist_${guildId}`) || [];
      if (whitelist.includes(member.id) || member.roles.cache.some(r => whitelist.includes(r.id))) {
        return message.reply('Ce membre ou un de ses rôles est dans la whitelist prison.');
      }
      if (prisonMembers.includes(member.id)) return message.reply('Ce membre est déjà en prison.');
      // Sauvegarde des rôles (hors rôle prisonnier)
      const rolesToSave = member.roles.cache.filter(r => r.id !== prisonRoleId && r.id !== message.guild.id).map(r => r.id);
      client.db.set(`prison_roles_${guildId}_${member.id}`, rolesToSave);
      // Retirer tous les rôles sauf le rôle prisonnier
      const rolesToRemove = member.roles.cache.filter(r => r.id !== prisonRoleId && r.id !== message.guild.id).map(r => r.id);
      if (rolesToRemove.length > 0) await member.roles.remove(rolesToRemove).catch(() => {});
      await member.roles.add(prisonRoleId).catch(() => {});
      prisonMembers.push(member.id);
      client.db.set(`prison_members_${guildId}`, prisonMembers);
      // Déplacement vocal si possible
      if (member.voice.channel && member.voice.channel.id !== prisonChannelId) {
        await member.voice.setChannel(prisonChannelId).catch(() => {});
      }
      // Envoi de MP si activé
      const prisonMP = client.db.get(`prison_mp_${guildId}`);
      if (prisonMP) {
        const embed = new EmbedBuilder()
          .setTitle('🚨 Tu as été emprisonné !')
          .setDescription(`Tu as été envoyé en prison sur **${message.guild.name}**.

> Si tu penses qu'il s'agit d'une erreur ou que tu veux sortir, contacte un modérateur ou le staff du serveur.`)
          .setColor(client.color)
          .setFooter(client.footer)
          .setTimestamp();
        member.send({ embeds: [embed] }).catch(() => {});
      }
      // Permissions : accès uniquement au salon prison
      const allChannels = message.guild.channels.cache;
      for (const [id, channel] of allChannels) {
        if (!channel.isTextBased && !channel.isVoiceBased) continue;
        if (id === prisonChannelId) {
          await channel.permissionOverwrites.edit(prisonRoleId, { ViewChannel: true }).catch(() => {});
        } else {
          await channel.permissionOverwrites.edit(prisonRoleId, { ViewChannel: false }).catch(() => {});
        }
      }
      return message.reply(`<@${member.id}> a été envoyé en prison.`);
    }

    if (sub === 'remove') {
      if (!memberArg) return message.reply('Mentionne un membre à libérer.');
      const member = message.mentions.members.first() || message.guild.members.cache.get(memberArg);
      if (!member) return message.reply('Membre introuvable.');
      if (!prisonMembers.includes(member.id)) return message.reply('Ce membre n\'est pas en prison.');
      await member.roles.remove(prisonRoleId).catch(() => {});
      // Rendre les anciens rôles
      const oldRoles = client.db.get(`prison_roles_${guildId}_${member.id}`) || [];
      if (oldRoles.length > 0) {
        const validRoles = oldRoles.filter(rid => message.guild.roles.cache.has(rid));
        if (validRoles.length > 0) await member.roles.add(validRoles).catch(() => {});
      }
      client.db.delete(`prison_roles_${guildId}_${member.id}`);
      prisonMembers = prisonMembers.filter(id => id !== member.id);
      client.db.set(`prison_members_${guildId}`, prisonMembers);
      return message.reply(`<@${member.id}> a été libéré de prison.`);
    }

    if (sub === 'list') {
      if (!prisonMembers.length) return message.reply('Aucun membre en prison.');
      const list = prisonMembers.map(id => `<@${id}>`).join(', ');
      const embed = new EmbedBuilder()
        .setTitle('Membres en prison')
        .setDescription(list)
        .setColor(client.color || 0x5865F2);
      return message.channel.send({ embeds: [embed] });
    }

    if (sub === 'clear') {
      if (!prisonMembers.length) return message.reply('Aucun membre à libérer.');
      for (const id of prisonMembers) {
        const member = message.guild.members.cache.get(id);
        if (member) {
          await member.roles.remove(prisonRoleId).catch(() => {});
          // Rendre les anciens rôles
          const oldRoles = client.db.get(`prison_roles_${guildId}_${member.id}`) || [];
          if (oldRoles.length > 0) {
            const validRoles = oldRoles.filter(rid => message.guild.roles.cache.has(rid));
            if (validRoles.length > 0) await member.roles.add(validRoles).catch(() => {});
          }
          client.db.delete(`prison_roles_${guildId}_${member.id}`);
        }
      }
      client.db.set(`prison_members_${guildId}`, []);
      return message.reply('Tous les prisonniers ont été libérés.');
    }

    // Si aucune sous-commande valide
    return message.reply('Utilisation : cellule <add|remove|list|clear> [@membre]');
  }
}; 