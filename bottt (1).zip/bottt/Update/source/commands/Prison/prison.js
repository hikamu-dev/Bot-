const { ActionRowBuilder, StringSelectMenuBuilder, EmbedBuilder, ComponentType, PermissionFlagsBits } = require('discord.js');

module.exports = {
  name: "prison",
  description: "Configurer le système de prison du serveur",
  run: async (client, message, args) => {
    // Récupération de la config actuelle (exemple, à adapter selon ta BDD)
    const prisonStatus = client.db.get(`prison_status_${message.guild.id}`) || false;
    const prisonChannel = client.db.get(`prison_channel_${message.guild.id}`) || null;
    const prisonRole = client.db.get(`prison_role_${message.guild.id}`) || null;
    const prisonLogs = client.db.get(`prison_logs_${message.guild.id}`) || null;
    const prisonMP = client.db.get(`prison_mp_${message.guild.id}`) ?? true;

    // Embed récapitulatif
    const embed = new EmbedBuilder()
      .setTitle('Paramétrer le système prison')
      .addFields(
        { name: 'Statut de la prison', value: prisonStatus ? 'Ouverte' : 'Fermée', inline: true },
        { name: 'Salon de prison', value: prisonChannel ? `<#${prisonChannel}>` : 'Non défini', inline: true },
        { name: 'Rôle de prisonnier', value: prisonRole ? `<@&${prisonRole}>` : 'Non configuré', inline: true },
        { name: 'Salon de logs', value: prisonLogs ? `<#${prisonLogs}>` : 'Non défini', inline: true },
        { name: 'MP les prisonniers', value: prisonMP ? 'Oui' : 'Non', inline: true },
      )
      .setColor(client.color)
      .setFooter(client.footer);

    // Menu principal
    const menu = new StringSelectMenuBuilder()
      .setCustomId('prison_config_menu')
      .setPlaceholder('Choisir une option de configuration')
      .addOptions([
        { label: 'Activer/Désactiver le système de prison', value: 'toggle', emoji: '🛎️' },
        { label: 'Auto-création de la cellule', value: 'autocell', emoji: '🏛️' },
        { label: 'Définir le salon de prison', value: 'set_channel', emoji: '📑' },
        { label: 'Définir le rôle prisonnier', value: 'set_role', emoji: '🎭' },
        { label: 'Configurer le salon de logs', value: 'set_logs', emoji: '📜' },
        { label: 'Configurer les MP aux prisonniers', value: 'set_mp', emoji: '📩' },
        { label: 'Synchroniser le rôle prisonnier', value: 'sync_role', emoji: '🌟' },
      ]);

    const row = new ActionRowBuilder().addComponents(menu);

    const sent = await message.channel.send({ embeds: [embed], components: [row] });

    // Collector pour gérer les interactions du menu
    const collector = sent.createMessageComponentCollector({
      componentType: ComponentType.StringSelect,
      time: 5 * 60 * 1000 // 5 minutes
    });

    collector.on('collect', async (interaction) => {
      if (interaction.user.id !== message.author.id) {
        return interaction.reply({ content: "Ce menu n'est pas pour toi.", ephemeral: true });
      }
      switch (interaction.values[0]) {
        case 'toggle': {
          // Toggle prison status
          const current = client.db.get(`prison_status_${message.guild.id}`) || false;
          client.db.set(`prison_status_${message.guild.id}`, !current);
          // Update embed
          embed.data.fields[0].value = !current ? 'Ouverte' : 'Fermée';
          await interaction.update({ embeds: [embed], components: [row] });
          break;
        }
        case 'set_mp': {
          // Toggle MP aux prisonniers
          const current = client.db.get(`prison_mp_${message.guild.id}`);
          const newValue = !current;
          client.db.set(`prison_mp_${message.guild.id}`, newValue);
          // Update embed
          embed.data.fields[4].value = newValue ? 'Oui' : 'Non';
          await interaction.update({ embeds: [embed], components: [row] });
          break;
        }
        case 'autocell': {
          // Crée un salon textuel "prison" si besoin
          let prisonChannel = client.db.get(`prison_channel_${message.guild.id}`);
          let channel;
          if (prisonChannel) {
            channel = message.guild.channels.cache.get(prisonChannel);
          }
          if (!channel) {
            channel = await message.guild.channels.create({
              name: 'prison',
              type: 0, // 0 = GUILD_TEXT
              reason: 'Auto-création de la cellule prison'
            });
            client.db.set(`prison_channel_${message.guild.id}`, channel.id);
            embed.data.fields[1].value = `<#${channel.id}>`;
            await interaction.update({ embeds: [embed], components: [row] });
            await message.channel.send(`Salon prison créé : <#${channel.id}>`);
          } else {
            await interaction.reply({ content: `Le salon prison existe déjà : <#${channel.id}>`, ephemeral: true });
          }
          break;
        }
        case 'set_channel': {
          await interaction.reply({ content: 'Merci de mentionner le salon à utiliser pour la prison.', ephemeral: true });
          const filter = m => m.author.id === message.author.id && m.mentions.channels.size > 0;
          const collected = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
          if (!collected.size) return message.channel.send('Aucune mention détectée.');
          const channel = collected.first().mentions.channels.first();
          client.db.set(`prison_channel_${message.guild.id}`, channel.id);
          embed.data.fields[1].value = `<#${channel.id}>`;
          await message.channel.send(`Salon de prison défini sur <#${channel.id}>.`);
          await interaction.deleteReply();
          await sent.edit({ embeds: [embed], components: [row] });
          break;
        }
        case 'set_role': {
          await interaction.reply({ content: 'Merci de mentionner le rôle à utiliser pour les prisonniers.', ephemeral: true });
          const filter = m => m.author.id === message.author.id && m.mentions.roles.size > 0;
          const collected = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
          if (!collected.size) return message.channel.send('Aucune mention détectée.');
          const role = collected.first().mentions.roles.first();
          client.db.set(`prison_role_${message.guild.id}`, role.id);
          embed.data.fields[2].value = `<@&${role.id}>`;
          await message.channel.send(`Rôle prisonnier défini sur <@&${role.id}>.`);
          await interaction.deleteReply();
          await sent.edit({ embeds: [embed], components: [row] });
          // Synchronisation automatique de la cellule
          const prisonMembers = client.db.get(`prison_members_${message.guild.id}`) || [];
          await message.guild.members.fetch();
          let count = 0;
          for (const id of prisonMembers) {
            const member = message.guild.members.cache.get(id);
            if (member && !member.roles.cache.has(role.id)) {
              await member.roles.add(role.id).catch(() => {});
              count++;
            }
          }
          if (count > 0) await message.channel.send(`Synchronisation : ${count} membres ont reçu le rôle prisonnier.`);
          // Mise à jour des permissions du salon prison
          const prisonChannelId = client.db.get(`prison_channel_${message.guild.id}`);
          if (prisonChannelId) {
            const prisonChannel = message.guild.channels.cache.get(prisonChannelId);
            if (prisonChannel) {
              await prisonChannel.permissionOverwrites.edit(message.guild.roles.everyone, { ViewChannel: false });
              await prisonChannel.permissionOverwrites.edit(role.id, { ViewChannel: true, SendMessages: true });
              await message.channel.send('Permissions du salon prison mises à jour.');
            }
          }
          break;
        }
        case 'set_logs': {
          await interaction.reply({ content: 'Merci de mentionner le salon de logs.', ephemeral: true });
          const filter = m => m.author.id === message.author.id && m.mentions.channels.size > 0;
          const collected = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
          if (!collected.size) return message.channel.send('Aucune mention détectée.');
          const channel = collected.first().mentions.channels.first();
          client.db.set(`prison_logs_${message.guild.id}`, channel.id);
          embed.data.fields[3].value = `<#${channel.id}>`;
          await message.channel.send(`Salon de logs défini sur <#${channel.id}>.`);
          await interaction.deleteReply();
          await sent.edit({ embeds: [embed], components: [row] });
          break;
        }
        case 'sync_role': {
          const roleId = client.db.get(`prison_role_${message.guild.id}`);
          if (!roleId) return interaction.reply({ content: 'Aucun rôle prisonnier configuré.', ephemeral: true });
          const role = message.guild.roles.cache.get(roleId);
          if (!role) return interaction.reply({ content: 'Le rôle prisonnier n’existe plus.', ephemeral: true });
          await interaction.deferReply({ ephemeral: true });
          const prisonChannelId = client.db.get(`prison_channel_${message.guild.id}`);
          const allChannels = message.guild.channels.cache;
          let permCount = 0;
          let errorCount = 0;
          for (const [id, channel] of allChannels) {
            if (!channel || (channel.type !== 0 && channel.type !== 2)) continue; // 0: text, 2: voice
            if (id === prisonChannelId) {
              await channel.permissionOverwrites.edit(roleId, { ViewChannel: true }).catch(() => { throw new Error(); });
            } else {
              await channel.permissionOverwrites.edit(roleId, { ViewChannel: false }).catch(() => { throw new Error(); });
            }
            permCount++;
          }
          await interaction.editReply({ content: `Synchronisation terminée. Permissions mises à jour sur ${permCount} salons. Erreurs sur ${errorCount} salons.` });
          break;
        }
        default:
          await interaction.reply({ content: 'Option inconnue.', ephemeral: true });
      }
    });
  }
}; 