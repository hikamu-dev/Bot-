const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'wlprison',
  description: 'Gérer la whitelist du système prison',
  use: 'wlprison <add|remove|clear|list> [@user|@role]',
  run: async (client, message, args) => {
    const sub = args[0];
    const targetArg = args[1];
    const guildId = message.guild.id;
    let whitelist = client.db.get(`prison_whitelist_${guildId}`) || [];

    if (sub === 'add') {
      if (!targetArg) return message.reply('Mentionne un utilisateur ou un rôle à ajouter à la whitelist.');
      const user = message.mentions.users.first();
      const role = message.mentions.roles.first();
      const id = user ? user.id : (role ? role.id : null);
      if (!id) return message.reply('Mention invalide.');
      if (whitelist.includes(id)) return message.reply('Déjà dans la whitelist.');
      whitelist.push(id);
      client.db.set(`prison_whitelist_${guildId}`, whitelist);
      return message.reply(`<@${id}> ajouté à la whitelist prison.`);
    }

    if (sub === 'remove') {
      if (!targetArg) return message.reply('Mentionne un utilisateur ou un rôle à retirer de la whitelist.');
      const user = message.mentions.users.first();
      const role = message.mentions.roles.first();
      const id = user ? user.id : (role ? role.id : null);
      if (!id) return message.reply('Mention invalide.');
      if (!whitelist.includes(id)) return message.reply('Non présent dans la whitelist.');
      whitelist = whitelist.filter(x => x !== id);
      client.db.set(`prison_whitelist_${guildId}`, whitelist);
      return message.reply(`<@${id}> retiré de la whitelist prison.`);
    }

    if (sub === 'clear') {
      client.db.set(`prison_whitelist_${guildId}`, []);
      return message.reply('Whitelist prison vidée.');
    }

    if (sub === 'list') {
      if (!whitelist.length) return message.reply('La whitelist prison est vide.');
      const list = whitelist.map(id => message.guild.roles.cache.get(id) ? `<@&${id}>` : `<@${id}>`).join(', ');
      const embed = new EmbedBuilder()
        .setTitle('Whitelist Prison')
        .setDescription(list)
        .setColor(client.color || 0x5865F2);
      return message.channel.send({ embeds: [embed] });
    }

    return message.reply('Utilisation : wlprison <add|remove|clear|list> [@user|@role]');
  }
}; 