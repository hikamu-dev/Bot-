const { Role, User } = require('discord.js');
const Astroia = require('../../structures/client/index');
const ms = require('ms'); // Assurez-vous d'avoir le module ms installé (npm install ms)

module.exports = {
    name: "temprole",
    description: "Attribue un rôle temporaire à un membre ou affiche la liste des rôles temporaires.",
    use: "<add/list> <@membre/id> <@role/id> <durée>",
    usage: "temprole <add/list> <@membre/id> <@role/id> <durée>",
    example: "➜ temprole add @tokyru @Admin 1↪ n➜ temprole list",

    /**
     * 
     * @param {Astroia} client 
     * @param {Discord.Message} message 
     * @param {String[]} args 
     */
    run: async (client, message, args, commandName) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
        client.db.get(`owner_global_${message.author.id}`) === true || 
client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        // Vérification de l'option
        if (args.length < 1 || !['add', 'list'].includes(args[0].toLowerCase())) {
            return message.channel.send("Utilisation incorrecte : temprole <add/list> <@membre/id> <@role/id> <durée>");
        }

        const option = args[0].toLowerCase();

        if (option === 'add') {
            // Vérification des arguments pour l'ajout
            if (args.length < 4) {
                return message.channel.send("Utilisation incorrecte : temprole add <@membre/id> <@role/id> <durée>");
            }

            // Récupérer le membre
            let member;
            try {
                const userId = args[1].replace(/[<@!>]*/g, '');
                member = await message.guild.members.fetch(userId);
                if (!member) throw new Error();
            } catch {
                return message.channel.send("Membre introuvable ou invalide.");
            }

            // Récupérer le rôle
            let role;
            try {
                const roleId = args[2].replace(/[<@&>]*/g, '');
                role = await message.guild.roles.fetch(roleId);
                if (!role) throw new Error();
            } catch {
                return message.channel.send("Rôle introuvable ou invalide.");
            }

            // Vérifier si le rôle est assignable
            if (!role.editable) {
                return message.channel.send("Je n'ai pas les permissions pour attribuer ce rôle.");
            }

            // Vérifier la durée
            const duration = ms(args[3]);
            if (!duration || isNaN(duration)) {
                return message.channel.send("Durée invalide. Exemples : 1h, 30m, 2d.");
            }

            // Calculer le timestamp de fin
            const endTime = Date.now() + duration;
            const endTimestamp = Math.floor(endTime / 1000); // Convertir en secondes pour Discord timestamp

            // Attribuer le rôle au membre
            try {
                await member.roles.add(role);
                await message.channel.send(`Le rôle ${role} a été attribué à ${member} jusqu'à <t:${endTimestamp}:R>.`);

                // Stocker les informations dans la base de données
                const tempRoleData = {
                    memberId: member.id,
                    roleId: role.id,
                    guildId: message.guild.id,
                    endTime: endTime,
                    durationText: args[3]
                };
                const tempRoles = client.db.get(`temproles_${message.guild.id}`) || [];
                tempRoles.push(tempRoleData);
                client.db.set(`temproles_${message.guild.id}`, tempRoles);

                // Planifier le retrait du rôle
                setTimeout(async () => {
                    try {
                        if (member.roles.cache.has(role.id)) {
                            await member.roles.remove(role);
                            await message.channel.send(`Le rôle ${role} a été retiré de ${member} à <t:${endTimestamp}:R>.`);
                        }
                        // Supprimer de la base de données
                        const updatedTempRoles = client.db.get(`temproles_${message.guild.id}`)?.filter(tr => tr.endTime > Date.now()) || [];
                        client.db.set(`temproles_${message.guild.id}`, updatedTempRoles);
                    } catch (err) {
                        console.error(err);
                        await message.channel.send(`Une erreur est survenue lors du retrait du rôle ${role} de ${member}.`);
                    }
                }, duration);
            } catch (err) {
                console.error(err);
                return message.channel.send("Une erreur est survenue lors de l'attribution du rôle.");
            }
        } else if (option === 'list') {
            // Afficher la liste des rôles temporaires
            const tempRoles = client.db.get(`temproles_${message.guild.id}`) || [];
            if (tempRoles.length === 0) {
                return message.channel.send("Aucun rôle temporaire en cours sur ce serveur.");
            }

            const now = Date.now();
            // Filtrer les rôles temporaires expirés
            const activeTempRoles = tempRoles.filter(tr => tr.endTime > now);
            client.db.set(`temproles_${message.guild.id}`, activeTempRoles);

            if (activeTempRoles.length === 0) {
                return message.channel.send("Aucun rôle temporaire actif trouvé.");
            }

            let response = "**Liste des rôles temporaires actifs :**\n";
            for (const tempRole of activeTempRoles) {
                const member = await message.guild.members.fetch(tempRole.memberId).catch(() => null);
                const role = await message.guild.roles.fetch(tempRole.roleId).catch(() => null);
                const endTimestamp = Math.floor(tempRole.endTime / 1000); // Convertir en secondes pour Discord timestamp
                response += `- Membre : ${member ? `<@${member.id}>` : 'Inconnu'} | Rôle : ${role ? `<@&${role.id}>` : 'Inconnu'} | Temps restant : <t:${endTimestamp}:R>\n`;
            }

            await message.channel.send(response);
        }
    }
};