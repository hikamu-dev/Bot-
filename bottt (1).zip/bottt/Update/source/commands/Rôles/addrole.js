const Discord = require('discord.js');
const Astroia = require('../../structures/client/index');
const { example } = require('../Owner/changelimit');

module.exports = {
    name: "addrole",
    description: "Permet d'ajouter un ou plusieurs rôles à un membre.",
    use: "<membre> <@role/idrole>",
    usage: "addrole <membre> <@role/idrole> [@role/idrole ...]",
    example: "➜ addrole @phebo Lyna Staff \n➜ addrole 123456789012345678 @Admin 987654321098765432",
    run: async (client, message, args, commandName) => {
        try {
            if (!message.guild) {
                return message.reply("Cette commande ne peut être utilisée que dans un serveur.");
            }
            if (!message.channel) {
                console.error('No valid channel found for message:', message);
                return;
            }

            // ====== TON SYSTÈME PERMS TEL QUEL ======
            let pass = false;
            if (client.staff.includes(message.author.id) || 
                client.config.buyers.includes(message.author.id) ||
                client.db.get(`owner_global_${message.author.id}`) === true || 
                client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
                message.guild.ownerId === message.author.id) {
                pass = true;
            } else {
                const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
                if (commandPerms.length > 0) {
                    const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                    const userRoles = message.member.roles.cache.map(role => role.id);
                    pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
                } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                    pass = true;
                }
            }
            if (!pass) {
                if (client.noperm && client.noperm.trim() !== '') {
                    const sentMessage = await message.channel.send(client.noperm);
                    const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
                    if (delayTime > 0) {
                        setTimeout(() => { sentMessage.delete().catch(() => {}); }, delayTime * 1000);
                    }
                }
                return;
            }
            // =========================================

            if (args.length < 2) {
                return message.channel.send("Utilisation incorrecte : `addrole <membre> <@role/idrole | nom(s) de rôle…>`");
            }

            // Membre cible
            const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
            if (!member) {
                return message.channel.send("Membre introuvable sur le serveur. Veuillez mentionner un utilisateur ou fournir un ID valide.");
            }

            // Bot
            const botMember = message.guild.members.me;
            if (!botMember) return message.channel.send("Je ne suis pas dans ce serveur.");
            if (!botMember.permissions.has('MANAGE_ROLES')) {
                return message.channel.send("Je n'ai pas la permission de gérer les rôles.");
            }
            if (message.guild.ownerId !== botMember.id && botMember.roles.highest.position <= member.roles.highest.position) {
                return message.channel.send("Je ne peux pas modifier les rôles de ce membre (ma position est trop basse).");
            }

            // ====== PARSING : mentions + IDs + noms sans séparateur ======
            const rolesToAdd = [];
            const errors = [];
            const alreadyHas = [];
            const pushOnce = (role) => {
                if (role && !rolesToAdd.some(x => x.id === role.id)) rolesToAdd.push(role);
            };

            // 1) rôles mentionnés (zéro ou plusieurs)
            for (const r of (message.mentions.roles?.values?.() || [])) pushOnce(r);

            // 2) texte restant après le membre
            const sanitize = (s) => String(s ?? '').trim();
            let rest = sanitize(args.slice(1).join(' '));
            // retirer les mentions déjà capturées du flux texte
            rest = rest.replace(/<@&\d+>/g, ' ').replace(/\s+/g, ' ').trim();

            // 3) extraire les IDs présents comme mots
            const byId = (s) => /^\d+$/.test(s) ? message.guild.roles.cache.get(s) : null;
            const idMatches = [];
            rest = rest.split(' ').map(tok => {
                const r = byId(tok);
                if (r) { idMatches.push(r); return ''; }
                return tok;
            }).join(' ').replace(/\s+/g, ' ').trim();
            idMatches.forEach(pushOnce);

            // 4) matching glouton par noms (longest-match en tête de chaîne)
            const findExact = (s) => message.guild.roles.cache.find(r => r.name === s);
            const findIcase = (s) => {
                const lower = s.toLowerCase();
                return message.guild.roles.cache.find(r => r.name.toLowerCase() === lower);
            };
            const roleNamesDesc = [...message.guild.roles.cache.values()]
                .map(r => r.name)
                .filter(Boolean)
                .sort((a, b) => b.length - a.length);

            const tryConsumeHead = () => {
                for (const roleName of roleNamesDesc) {
                    const len = roleName.length;
                    const head = rest.slice(0, len);
                    if (head.toLowerCase() === roleName.toLowerCase()) {
                        // vérifier la frontière (fin ou espace)
                        const nextChar = rest.slice(len, len + 1);
                        if (nextChar === '' || /\s/.test(nextChar)) {
                            const role = findExact(roleName) || findIcase(roleName);
                            if (role) {
                                pushOnce(role);
                                rest = rest.slice(len).trimStart();
                                return true;
                            }
                        }
                    }
                }
                return false;
            };

            let guard = 0;
            while (rest && guard < 1000) {
                guard++;
                if (tryConsumeHead()) continue;
                // sinon, on saute le premier mot (bruit) et on réessaie
                const space = rest.indexOf(' ');
                if (space === -1) {
                    const role = byId(rest) || findExact(rest) || findIcase(rest);
                    if (role) pushOnce(role);
                    rest = '';
                } else {
                    rest = rest.slice(space + 1).trimStart();
                }
            }

            // ====== Contrôles & application ======
            for (let i = rolesToAdd.length - 1; i >= 0; i--) {
                const role = rolesToAdd[i];
                if (role.position >= botMember.roles.highest.position && message.guild.ownerId !== botMember.id) {
                    errors.push(`Je ne peux pas ajouter \`${role.name}\` (au-dessus/égal à mon rôle le plus élevé).`);
                    rolesToAdd.splice(i, 1);
                    continue;
                }
                if (member.roles.cache.has(role.id)) {
                    alreadyHas.push(`\`${role.name}\``);
                    rolesToAdd.splice(i, 1);
                }
            }

            if (rolesToAdd.length === 0) {
                let response = "Aucun rôle valide à ajouter.";
                if (alreadyHas.length > 0) response += `\n${member.user.tag} a déjà les rôles suivants : ${alreadyHas.join(', ')}.`;
                if (errors.length > 0) response += `\nErreurs : \n- ${errors.join('\n- ')}`;
                return message.channel.send(response);
            }

            await member.roles.add(rolesToAdd);

            let response = `${member.user.tag} vient de recevoir le(s) rôle(s) : ${rolesToAdd.map(r => `\`${r.name}\``).join(', ')}.`;
            if (alreadyHas.length > 0) response += `\n${member.user.tag} avait déjà les rôles suivants : ${alreadyHas.join(', ')}.`;
            if (errors.length > 0) response += `\nErreurs : \n- ${errors.join('\n- ')}`;

            const embed = new Discord.EmbedBuilder()
                .setColor(client.color)
                .setDescription(`${message.author} a ajouté les rôles ${rolesToAdd.map(r => `\`${r.name}\``).join(', ')} à \`${member.user.tag}\`.`)
                .setTimestamp();

            const modlogChannel = message.guild.channels.cache.get(client.db.get(`modlogs_${message.guild.id}`));
            if (modlogChannel) {
                modlogChannel.send({ embeds: [embed] }).catch(error => console.error("Erreur lors de l'envoi du modlog :", error));
            }

            message.channel.send(response);
        } catch (error) {
            console.error('Erreur lors de l\'ajout des rôles :', error);
            if (message.channel) {
                message.channel.send("Une erreur est survenue lors de l'ajout des rôles.");
            }
        }
    }
};
