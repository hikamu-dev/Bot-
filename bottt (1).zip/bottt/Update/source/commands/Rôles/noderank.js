const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: "noderank",
    description: "Gère les rôles protégés contre le dérank",
    use: "<add/remove/list> <@role/roleid>",
    usage: 'noderank <add/list/remove> ',
example: "➜ noderank add @Membre\n➜ noderank remove @Membre\n➜ noderank list",
    run: async (client, message, args, commandName) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
        client.db.get(`owner_global_${message.author.id}`) === true || 
client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        // Validate subcommand
        const subcommand = args[0]?.toLowerCase();
        if (!['add', 'remove', 'list'].includes(subcommand)) {
            return message.channel.send("Veuillez spécifier une action valide : `add`, `remove` ou `list`.");
        }

        // Handle 'list' subcommand
        if (subcommand === 'list') {
            const protectedRoles = client.db.get(`noderank_roles_${message.guild.id}`) || [];
            if (protectedRoles.length === 0) {
                return message.channel.send("Aucun rôle n'est protégé contre le dérank.");
            }

            const roleMentions = protectedRoles.map(roleId => `<@&${roleId}>`).join(', ');
            const embed = new EmbedBuilder()
                .setColor(client.color)
                .setTitle("Rôles protégés contre le dérank")
                .setDescription(roleMentions)
                .setFooter(client.footer)

            return message.channel.send({ embeds: [embed] });
        }

        // Validate role for 'add' or 'remove'
        const roleInput = args[1];
        if (!roleInput) {
            return message.channel.send("Veuillez spécifier un rôle via une mention ou un ID.");
        }

        let role;
        // Try to get role from mention or ID
        if (roleInput.startsWith('<@&') && roleInput.endsWith('>')) {
            const roleId = roleInput.replace(/[<@&>]/g, '');
            role = message.guild.roles.cache.get(roleId);
        } else {
            role = message.guild.roles.cache.get(roleInput);
        }

        if (!role) {
            return message.channel.send("Rôle introuvable. Veuillez mentionner un rôle valide ou fournir un ID correct.");
        }

        // Get current protected roles
        let protectedRoles = client.db.get(`noderank_roles_${message.guild.id}`) || [];

        // Handle 'add' subcommand
        if (subcommand === 'add') {
            if (protectedRoles.includes(role.id)) {
                return message.channel.send(`Le rôle **${role.name}** est déjà protégé contre le dérank.`);
            }

            protectedRoles.push(role.id);
            client.db.set(`noderank_roles_${message.guild.id}`, protectedRoles);

            const embed = new EmbedBuilder()
                .setColor(client.color)
                .setDescription(`${message.author} a ajouté le rôle **${role.name}** à la liste des rôles protégés contre le dérank.`)
                .setTimestamp();

            message.channel.send(`Le rôle **${role.name}** a été ajouté à la liste des rôles protégés contre le dérank.`);
            const modlogChannel = message.guild.channels.cache.get(client.db.get(`modlogs_${message.guild.id}`));
            if (modlogChannel) {
                modlogChannel.send({ embeds: [embed] }).catch(error => console.error('Error sending modlog:', error));
            }

            return;
        }

        // Handle 'remove' subcommand
        if (subcommand === 'remove') {
            if (!protectedRoles.includes(role.id)) {
                return message.channel.send(`Le rôle **${role.name}** n'est pas dans la liste des rôles protégés contre le dérank.`);
            }

            protectedRoles = protectedRoles.filter(id => id !== role.id);
            client.db.set(`noderank_roles_${message.guild.id}`, protectedRoles);

            const embed = new EmbedBuilder()
                .setColor(client.color)
                .setDescription(`${message.author} a retiré le rôle **${role.name}** de la liste des rôles protégés contre le dérank.`)
                .setTimestamp();

            message.channel.send(`Le rôle **${role.name}** a été retiré de la liste des rôles protégés contre le dérank.`);
            const modlogChannel = message.guild.channels.cache.get(client.db.get(`modlogs_${message.guild.id}`));
            if (modlogChannel) {
                modlogChannel.send({ embeds: [embed] }).catch(error => console.error('Error sending modlog:', error));
            }

            return;
        }
    }
};