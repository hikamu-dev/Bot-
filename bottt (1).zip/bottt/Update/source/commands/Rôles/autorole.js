const Discord = require('discord.js');
const Astroia = require('../../structures/client');
const ms = require('ms');

module.exports = {
  name: "autorole",
  aliases: ["defautrole", "joinrole", "joinsrole", "joinsroles"],
  description: "Configure les rôles attribués automatiquement aux nouveaux membres",
  usage: "autorole",
  
  /**
   * @param {Astroia} client 
   * @param {Discord.Message} message
   */
  run: async (client, message, args, commandName) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
        client.db.get(`owner_global_${message.author.id}`) === true || 
client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

    let msg = await message.reply({ 
      embeds: [
        new Discord.EmbedBuilder()
          .setColor(client.color)
          .setDescription('Chargement de la configuration de l\'autoroles...')
      ] 
    });

    async function update() {
      const db = client.db.get(`defautrole_${message.guild.id}`) || {
        status: false,
        role: []
      };
      
      const status = db?.status ? '🟢 Activé' : '🔴 Désactivé';
      const roles = db?.role?.map(roleId => {
        const role = message.guild.roles.cache.get(roleId);
        return role ? `• ${role.toString()} (${roleId})` : `• Rôle inconnu (${roleId})`;
      }) || ['Aucun rôle configuré'];
    
      const embed = new Discord.EmbedBuilder()
        .setColor(client.color)
        .setTitle('⚙ Configuration des Rôles Automatiques')
        .setThumbnail(message.guild.iconURL({ dynamic: true }));
    
      if (status) {
        embed.addFields({ name: '📊 Statut', value: status, inline: true });
      }
      
      if (roles.length > 0) {
        embed.addFields({ 
          name: `🎭 Rôles (${db?.role?.length || 0})`, 
          value: roles.join('\n') || 'Aucun rôle configuré' 
        });
      }
    
      embed.setFooter(client.footer)
    
      const buttons = new Discord.ActionRowBuilder()
        .addComponents(
          new Discord.ButtonBuilder()
            .setCustomId(`defautrole_active_${message.id}`)
            .setLabel(db?.status ? 'Désactiver' : 'Activer')
            .setStyle(db?.status ? Discord.ButtonStyle.Success : Discord.ButtonStyle.Danger)
            .setEmoji(db?.status ? '✅' : '❌'),
          new Discord.ButtonBuilder()
            .setCustomId(`defautrole_channel_${message.id}`)
            .setLabel('Gérer les rôles')
            .setStyle(Discord.ButtonStyle.Primary)
            .setEmoji('➕'),
          new Discord.ButtonBuilder()
            .setCustomId(`defautrole_reset_${message.id}`)
            .setLabel('Réinitialiser')
            .setStyle(Discord.ButtonStyle.Secondary)
            .setEmoji('🔄')
        );
    
      return msg.edit({ embeds: [embed], components: [buttons] });
    }

    await update();

    const collector = message.channel.createMessageComponentCollector({ 
      filter: i => i.user.id === message.author.id, 
      time: ms("2m") 
    });

    collector.on("collect", async (i) => {
      try {
        if (i.customId === `defautrole_channel_${message.id}`) {
          const roleMenu = new Discord.RoleSelectMenuBuilder()
            .setCustomId(`defautrole_channel_select_${message.id}`)
            .setPlaceholder('Sélectionnez des rôles')
            .setMinValues(0)
            .setMaxValues(25);

          const backButton = new Discord.ButtonBuilder()
            .setCustomId(`defautrole_channel_retour_${message.id}`)
            .setLabel('Retour')
            .setStyle(Discord.ButtonStyle.Secondary)
            .setEmoji('◀');

          const row = new Discord.ActionRowBuilder().addComponents(roleMenu);
          const row2 = new Discord.ActionRowBuilder().addComponents(backButton);

          await i.update({ 
            embeds: [
              new Discord.EmbedBuilder()
                .setColor(client.color)
                .setDescription('🔹 Sélectionnez les rôles à ajouter ou supprimer de la liste des rôles automatiques')
            ], 
            components: [row, row2] 
          });
        } 
        else if (i.customId === `defautrole_channel_retour_${message.id}`) {
          await update();
          await i.update({ embeds: msg.embeds, components: msg.components });
        } 
        else if (i.customId === `defautrole_active_${message.id}`) {
          let db = client.db.get(`defautrole_${message.guild.id}`) || { status: false, role: [] };
          db.status = !db.status;
          client.db.set(`defautrole_${message.guild.id}`, db);
          
          await i.reply({ 
            content: `✅ Le système a été ${db.status ? 'activé' : 'désactivé'} avec succès.`, 
            ephemeral: true 
          });
          setTimeout(() => i.deleteReply().catch(() => {}), 2000);
          await update();
        } 
        else if (i.customId === `defautrole_reset_${message.id}`) {
          client.db.delete(`defautrole_${message.guild.id}`);
          await i.reply({ 
            content: '✅ La configuration a été réinitialisée avec succès.', 
            ephemeral: true 
          });
          setTimeout(() => i.deleteReply().catch(() => {}), 2000);
          await update();
        } 
        else if (i.customId === `defautrole_channel_select_${message.id}`) {
          const selectedRoles = i.values;
          let db = client.db.get(`defautrole_${message.guild.id}`) || { status: false, role: [] };
          
          let changes = {
            added: [],
            removed: []
          };

          selectedRoles.forEach(roleId => {
            const index = db.role.indexOf(roleId);
            if (index === -1) {
              db.role.push(roleId);
              changes.added.push(roleId);
            } else {
              db.role.splice(index, 1);
              changes.removed.push(roleId);
            }
          });

          client.db.set(`defautrole_${message.guild.id}`, db);

          const embed = new Discord.EmbedBuilder()
            .setColor(client.color)
            .setTitle('✅ Modifications appliquées')
            .setDescription('Les changements suivants ont été effectués:')
            .addFields(
              {
                name: `Rôles ajoutés (${changes.added.length})`,
                value: changes.added.map(id => `• ${message.guild.roles.cache.get(id)?.toString() || id}`).join('\n') || 'Aucun',
                inline: true
              },
              {
                name: `Rôles retirés (${changes.removed.length})`,
                value: changes.removed.map(id => `• ${message.guild.roles.cache.get(id)?.toString() || id}`).join('\n') || 'Aucun',
                inline: true
              }
            );

          await i.reply({ embeds: [embed], ephemeral: true });
          await update();
        }
      } catch (error) {
        console.error(error);
        await i.reply({ 
          content: '❌ Une erreur est survenue lors du traitement de votre requête.', 
          ephemeral: true 
        });
      }
    });

    collector.on('end', () => {
      msg.edit({ components: [] }).catch(() => {});
    });
  }
};