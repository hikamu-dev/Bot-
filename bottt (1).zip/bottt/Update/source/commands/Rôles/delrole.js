const Discord = require('discord.js');

module.exports = {
    name: "delrole",
    description: "Permet de retirer un ou plusieurs rôles à un membre.",
    use: "<membre> <@role/idrole>",
    usage: "`delrole <membre> <@role/idrole> [@role/idrole ...]`",
    example: "➜ delrole @phebo Lyna Staff\n➜ delrole 123456789012345678 @Admin 987654321098765432",
    run: async (client, message, args, commandName) => {
        // ====== TON SYSTÈME PERMS TEL QUEL ======
        let pass = false;
        if (client.staff.includes(message.author.id) || 
            client.config.buyers.includes(message.author.id) || 
            client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
            message.guild.ownerId === message.author.id) {
            pass = true;
        } else {
            const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
            if (commandPerms.length > 0) {
                const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                const userRoles = message.member.roles.cache.map(role => role.id);
                pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
            } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                pass = true;
            }
        }
        if (!pass) {
            if (client.noperm && client.noperm.trim() !== '') {
                const sentMessage = await message.channel.send(client.noperm);
                const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
                if (delayTime > 0) {
                    setTimeout(() => { sentMessage.delete().catch(() => {}); }, delayTime * 1000);
                }
            }
            return;
        }
        // =========================================

        if (args.length < 2) {
            return message.channel.send("Utilisation incorrecte : `delrole <membre> <@role/idrole | nom(s) de rôle…>`");
        }

        const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        if (!member) {
            return message.channel.send("Membre introuvable sur le serveur. Veuillez mentionner un utilisateur ou fournir un ID valide.");
        }

        const botMember = message.guild.members.cache.get(client.user.id);
        if (!botMember) return message.channel.send("Je ne suis pas dans ce serveur.");
        if (!botMember.permissions.has('MANAGE_ROLES')) {
            return message.channel.send("Je n'ai pas la permission de gérer les rôles.");
        }
        if (message.guild.ownerId !== botMember.id && botMember.roles.highest.position <= member.roles.highest.position) {
            return message.channel.send("Je ne peux pas modifier les rôles de ce membre (ma position est trop basse).");
        }

        // ====== PARSING : mentions + IDs + noms sans séparateur ======
        const rolesToRemove = [];
        const errors = [];
        const doesntHave = [];
        const pushOnce = (role) => {
            if (role && !rolesToRemove.some(x => x.id === role.id)) rolesToRemove.push(role);
        };

        // mentions
        for (const r of (message.mentions.roles?.values?.() || [])) pushOnce(r);

        // texte restant après le membre
        const sanitize = (s) => String(s ?? '').trim();
        let rest = sanitize(args.slice(1).join(' '));
        rest = rest.replace(/<@&\d+>/g, ' ').replace(/\s+/g, ' ').trim();

        // IDs comme mots
        const byId = (s) => /^\d+$/.test(s) ? message.guild.roles.cache.get(s) : null;
        const idMatches = [];
        rest = rest.split(' ').map(tok => {
            const r = byId(tok);
            if (r) { idMatches.push(r); return ''; }
            return tok;
        }).join(' ').replace(/\s+/g, ' ').trim();
        idMatches.forEach(pushOnce);

        // matching noms (longest-match)
        const findExact = (s) => message.guild.roles.cache.find(r => r.name === s);
        const findIcase = (s) => {
            const lower = s.toLowerCase();
            return message.guild.roles.cache.find(r => r.name.toLowerCase() === lower);
        };
        const roleNamesDesc = [...message.guild.roles.cache.values()]
            .map(r => r.name)
            .filter(Boolean)
            .sort((a, b) => b.length - a.length);

        const tryConsumeHead = () => {
            for (const roleName of roleNamesDesc) {
                const len = roleName.length;
                const head = rest.slice(0, len);
                if (head.toLowerCase() === roleName.toLowerCase()) {
                    const nextChar = rest.slice(len, len + 1);
                    if (nextChar === '' || /\s/.test(nextChar)) {
                        const role = findExact(roleName) || findIcase(roleName);
                        if (role) {
                            pushOnce(role);
                            rest = rest.slice(len).trimStart();
                            return true;
                        }
                    }
                }
            }
            return false;
        };

        let guard = 0;
        while (rest && guard < 1000) {
            guard++;
            if (tryConsumeHead()) continue;
            const space = rest.indexOf(' ');
            if (space === -1) {
                const role = byId(rest) || findExact(rest) || findIcase(rest);
                if (role) pushOnce(role);
                rest = '';
            } else {
                rest = rest.slice(space + 1).trimStart();
            }
        }

        // Vérifs hiérarchie/déjà/absents
        for (let i = rolesToRemove.length - 1; i >= 0; i--) {
            const role = rolesToRemove[i];
            if (role.position >= botMember.roles.highest.position && message.guild.ownerId !== botMember.id) {
                errors.push(`Je ne peux pas retirer \`${role.name}\` (au-dessus/égal à mon rôle le plus élevé).`);
                rolesToRemove.splice(i, 1);
                continue;
            }
            if (!member.roles.cache.has(role.id)) {
                doesntHave.push(`\`${role.name}\``);
                rolesToRemove.splice(i, 1);
            }
        }

        if (rolesToRemove.length === 0) {
            let response = "Aucun rôle valide à retirer.";
            if (doesntHave.length > 0) response += `\n${member.user.tag} n'a pas les rôles suivants : ${doesntHave.join(', ')}.`;
            if (errors.length > 0) response += `\nErreurs : \n- ${errors.join('\n- ')}`;
            return message.channel.send(response);
        }

        try {
            await member.roles.remove(rolesToRemove);
            let response = `${member.user.tag} vient de perdre les rôles : ${rolesToRemove.map(r => `\`${r.name}\``).join(', ')}.`;
            if (doesntHave.length > 0) response += `\n${member.user.tag} n'avait pas les rôles suivants : ${doesntHave.join(', ')}.`;
            if (errors.length > 0) response += `\nErreurs : \n- ${errors.join('\n- ')}`;

            const embed = new Discord.EmbedBuilder()
                .setColor(client.color)
                .setDescription(`${message.author} a retiré les rôles ${rolesToRemove.map(r => `\`${r.name}\``).join(', ')} à \`${member.user.tag}\.`)
                .setTimestamp();

            const modlogChannel = message.guild.channels.cache.get(client.db.get(`modlogs_${message.guild.id}`));
            if (modlogChannel) {
                modlogChannel.send({ embeds: [embed] }).catch(error => console.error('Erreur lors de l\'envoi du modlog :', error));
            }

            message.channel.send(response);
        } catch (error) {
            console.error('Erreur lors du retrait des rôles :', error);
            message.channel.send("Une erreur est survenue lors du retrait des rôles.");
        }
    }
};
