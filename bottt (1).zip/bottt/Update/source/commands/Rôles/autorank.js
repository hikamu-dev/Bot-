const Discord = require('discord.js');
const { example } = require('../Owner/changelimit');

module.exports = {
    name: "autorank",
    description: "Configure l'auto-attribution d'un rôle lorsqu'un utilisateur ping le bot dans un salon spécifique.",
    use: "<add/list/del> <#salon> <@rôle>",
    usage: "autorank <add/list/del> <#salon> <@rôle>",
    example: "➜ autorank add #général @Membre\n➜ autorank list\n➜ autorank del #général",
    run: async (client, message, args, commandName) => {
    let pass = false;

    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
        client.db.get(`owner_global_${message.author.id}`) === true || 
client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        pass = true;
      }
    }

if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        if (args.length < 1) {
            return message.channel.send("Utilisation : `autorank <add/list/del> [#salon] [@rôle]`");
        }

        const action = args[0].toLowerCase();
        const botMember = message.guild.members.cache.get(client.user.id);

        if (!botMember.permissions.has(Discord.PermissionsBitField.Flags.ManageRoles)) {
            return message.channel.send("Je n'ai pas la permission de gérer les rôles.");
        }

        if (action === "add") {
            if (args.length < 3) {
                return message.channel.send("Utilisation : `autorank add <#salon> <@rôle>`");
            }

            const channel = message.mentions.channels.first() || message.guild.channels.cache.get(args[1]);
            if (!channel || channel.type !== Discord.ChannelType.GuildText) {
                return message.channel.send("Veuillez mentionner un salon textuel valide.");
            }

            const role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2]);
            if (!role) {
                return message.channel.send("Veuillez mentionner un rôle valide.");
            }

            if (role.position >= botMember.roles.highest.position) {
                return message.channel.send(`Je ne peux pas attribuer le rôle \`${role.name}\` car il est plus élevé ou égal au mien.`);
            }

            const autorankKey = `autorank_${message.guild.id}`;
            let autorankData = client.db.get(autorankKey) || [];
            autorankData.push({ channelId: channel.id, roleId: role.id });
            client.db.set(autorankKey, autorankData);

            return message.channel.send(`L'auto-rank a été configuré pour le salon <#${channel.id}> avec le rôle <@&${role.id}>.`);

        } else if (action === "list") {
            const autorankKey = `autorank_${message.guild.id}`;
            const autorankData = client.db.get(autorankKey) || [];

            if (autorankData.length === 0) {
                return message.channel.send("Aucune configuration d'auto-rank n'est enregistrée pour ce serveur.");
            }

            const embed = new Discord.EmbedBuilder()
                .setColor(client.color)
                .setTitle("Configurations Auto-Rank")
                .setDescription(autorankData.map((data, index) => 
                    `**${index + 1}.** Salon: <#${data.channelId}> - Rôle: <@&${data.roleId}>`
                ).join('\n'))
                .setTimestamp();

            return message.channel.send({ embeds: [embed] });

        } else if (action === "del") {
            if (args.length < 2) {
                return message.channel.send("Utilisation : `autorank del <#salon>`");
            }

            const channel = message.mentions.channels.first() || message.guild.channels.cache.get(args[1]);
            if (!channel || channel.type !== Discord.ChannelType.GuildText) {
                return message.channel.send("Veuillez mentionner un salon textuel valide.");
            }

            const autorankKey = `autorank_${message.guild.id}`;
            let autorankData = client.db.get(autorankKey) || [];
            const initialLength = autorankData.length;
            autorankData = autorankData.filter(data => data.channelId !== channel.id);

            if (autorankData.length === initialLength) {
                return message.channel.send("Aucune configuration d'auto-rank n'a été trouvée pour ce salon.");
            }

            client.db.set(autorankKey, autorankData);
            return message.channel.send(`La configuration d'auto-rank pour le salon <#${channel.id}> a été supprimée.`);

        } else {
            return message.channel.send("Action invalide. Utilisez `add`, `list` ou `del`.");
        }
    }
};
