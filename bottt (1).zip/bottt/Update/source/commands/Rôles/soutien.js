const ms = require('ms');
const Discord = require('discord.js');
const { StringSelectMenuBuilder, ActionRowBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle, RoleSelectMenuBuilder } = require('discord.js');

module.exports = {
    name: 'soutien',
    description: 'Permet de configurer le système de soutien',
    usage: "soutien",
    run: async (client, message, args, commandName) => {
        let pass = false;

        if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
        client.db.get(`owner_global_${message.author.id}`) === true || 
client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {               pass = true;
        } else {
            const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
            if (commandPerms.length > 0) {
                const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                const userRoles = message.member.roles.cache.map(role => role.id);
                pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
            } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                pass = true;
            }
        }

if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        const authorId = message.author.id;
        const originalmsg = await message.channel.send('Chargement en cours...');

        async function updateEmbed() {
            const db = client.db.get(`soutien_${message.guild.id}`) || client.db.set(`soutien_${message.guild.id}`, {
                names: [],
                role: [],
                status: false
            });

            const status = db.status ? 'Activé' : 'Désactivé';
            const nameSoutien = db.names?.length ? db.names.map((name, index) => `${index + 1}. ${name}`).join('\n') : 'Aucun statut défini';
            const roleNames = db.role?.length ? db.role.map((id, index) => `${index + 1}. <@&${id}>`).join('\n') : 'Aucun rôle défini';

            const embed = new EmbedBuilder()
                .setTitle('Configuration du système de soutien')
                .setColor(client.color)
                .setFooter(client.footer)
                .addFields(
                    { name: '📡 Statut du système', value: `\`\`\`\n${status}\`\`\``, inline: false },
                    { name: '📝 Statuts personnalisés', value: `\`\`\`\n${nameSoutien}\`\`\``, inline: false },
                    { name: '🎭 Rôles de soutien', value: `${roleNames}`, inline: false }
                );

            const selectMenu = new StringSelectMenuBuilder()
                .setCustomId(`soutien_setup_${message.id}`)
                .setPlaceholder('⚙️ Modifier un paramètre')
                .setMinValues(1)
                .setMaxValues(1)
                .addOptions([
                    { label: 'Modifier le statut', value: `status_${message.id}`, emoji: '📡' },
                    { label: 'Ajouter un statut personnalisé', value: `add_statusperso_${message.id}`, emoji: '📝' },
                    { label: 'Retirer un statut personnalisé', value: `remove_statusperso_${message.id}`, emoji: '🗑️' },
                    { label: 'Modifier les rôles', value: `role_${message.id}`, emoji: '🎭' }
                ]);

            const resetButton = new ButtonBuilder()
                .setCustomId(`soutien_reset_${message.id}`)
                .setLabel('Réinitialiser')
                .setEmoji('🔁')
                .setStyle(ButtonStyle.Secondary);

            const rowSelect = new ActionRowBuilder().addComponents(selectMenu);
            const rowButton = new ActionRowBuilder().addComponents(resetButton);

            await originalmsg.edit({
                content: null,
                embeds: [embed],
                components: [rowSelect, rowButton]
            });
        }

        await updateEmbed();

        const collector = message.channel.createMessageComponentCollector({
            filter: i => i.user.id === authorId,
            time: ms('2m')
        });

        collector.on('collect', async (i) => {
            const db = client.db.get(`soutien_${message.guild.id}`) || { names: [], role: [], status: false };

            if (i.customId === `soutien_setup_${message.id}`) {
                const choice = i.values[0];

                if (choice === `status_${message.id}`) {
                    let missing = [];
                    if (!db.role?.length) missing.push('Aucun rôle de soutien défini');
                    if (!db.names?.length) missing.push('Aucun statut personnalisé défini');

                    if (missing.length) {
                        await i.reply({ content: `Veuillez configurer les éléments suivants avant d'activer :\n${missing.map(opt => `- \`${opt}\``).join('\n')}`, ephemeral: true });
                        return;
                    }

                    db.status = !db.status;
                    client.db.set(`soutien_${message.guild.id}`, db);
                    await updateEmbed();
                    await i.reply({ content: db.status ? 'Système de soutien activé !' : 'Système de soutien désactivé !', ephemeral: true });
                }

                if (choice === `role_${message.id}`) {
                    const roleRow = new ActionRowBuilder().addComponents(
                        new RoleSelectMenuBuilder().setCustomId(`soutien_setup_role_${message.id}`).setMinValues(1).setMaxValues(25)
                    );
                    await i.reply({ content: 'Sélectionnez les rôles de soutien :', components: [roleRow], ephemeral: true });
                }

                if (choice === `add_statusperso_${message.id}`) {
                    await i.reply({ content: 'Veuillez entrer le nouveau statut personnalisé :', ephemeral: true });

                    const filter = response => response.author.id === authorId;
                    try {
                        const collected = await message.channel.awaitMessages({ filter, max: 1, time: ms("1m"), errors: ['time'] });
                        const content = collected.first().content.trim();
                        if (!db.names.includes(content)) {
                            db.names.push(content);
                            client.db.set(`soutien_${message.guild.id}`, db);
                            await updateEmbed();
                        }
                        await collected.first().delete().catch(() => {});
                    } catch (err) {
                        await message.channel.send('Temps écoulé, veuillez réessayer.').then(m => setTimeout(() => m.delete().catch(() => {}), 5000));
                    }
                }

                if (choice === `remove_statusperso_${message.id}`) {
                    if (!db.names?.length) {
                        await i.reply({ content: 'Aucun statut personnalisé à retirer.', ephemeral: true });
                        return;
                    }

                    const statusSelect = new StringSelectMenuBuilder()
                        .setCustomId(`soutien_remove_status_${message.id}`)
                        .setPlaceholder('Choisir un statut à supprimer')
                        .setMinValues(1)
                        .setMaxValues(1)
                        .addOptions(db.names.map(name => ({ label: name, value: name })));

                    const row = new ActionRowBuilder().addComponents(statusSelect);
                    await i.reply({ content: 'Sélectionnez le statut à retirer :', components: [row], ephemeral: true });
                }
            }

            if (i.customId === `soutien_reset_${message.id}`) {
                client.db.delete(`soutien_${message.guild.id}`);
                await updateEmbed();
                await i.reply({ content: 'Configuration réinitialisée !', ephemeral: true });
            }

            if (i.customId === `soutien_setup_role_${message.id}`) {
                db.role = i.values;
                client.db.set(`soutien_${message.guild.id}`, db);
                await updateEmbed();
                await i.reply({ content: 'Rôles de soutien mis à jour !', ephemeral: true });
            }

            if (i.customId === `soutien_remove_status_${message.id}`) {
                const statusToRemove = i.values[0];
                db.names = db.names.filter(name => name !== statusToRemove);
                client.db.set(`soutien_${message.guild.id}`, db);
                await updateEmbed();
                await i.reply({ content: `Statut \`${statusToRemove}\` retiré !`, ephemeral: true });
                await i.message.delete().catch(() => {});
            }
        });

        collector.on('end', () => {
            originalmsg.edit({ components: [] }).catch(() => {});
        });
    }
};
