const Discord = require('discord.js');

module.exports = {
    name: "rolemenu",
    description: "Permet de créer un rolemenu interactif.",
    run: async (client, message, args, commandName) => {
        let ii = 1;
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
        client.db.get(`owner_global_${message.author.id}`) === true || 
client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        const mainEmbed = (msg) => {
            const embed = new Discord.EmbedBuilder()
                .setTitle("🛠️ Configuration du Rolemenu")
                .setColor(client.color)
                .setFooter(client.footer)
                .setDescription(`
**Type** : \`${client.db.get(`menu_${message.guild.id}`) ? "Menu déroulant" : "Boutons"}\`
**Salon** : ${message.guild.channels.cache.get(client.db.get(`buttonrolec_${message.guild.id}`)) || "`Aucun salon défini`"}
\n**Configuration des boutons :**
${[1, 2, 3, 4].map(i => 
`- ${client.db.get(`buttoncolor${i}_${message.guild.id}`) || "⚫"} **${client.db.get(`buttonname${i}_${message.guild.id}`) || "Non défini"}** (${message.guild.roles.cache.get(client.db.get(`buttonrole${i}_${message.guild.id}`)) || "Aucun rôle"})`
                    ).join('\n')}`
                );

            const row = new Discord.ActionRowBuilder().addComponents(
                new Discord.StringSelectMenuBuilder()
                    .setCustomId(`menu-${message.id}`)
                    .setPlaceholder("Choisir une option...")
                    .setMaxValues(1)
                    .setMinValues(1)
                    .addOptions([
                        { label: "Modifier le 1er bouton", value: "button1", emoji: client.db.get(`buttoncolor1_${message.guild.id}`) || "⚫" },
                        { label: "Modifier le 2e bouton", value: "button2", emoji: client.db.get(`buttoncolor2_${message.guild.id}`) || "⚫" },
                        { label: "Modifier le 3e bouton", value: "button3", emoji: client.db.get(`buttoncolor3_${message.guild.id}`) || "⚫" },
                        { label: "Modifier le 4e bouton", value: "button4", emoji: client.db.get(`buttoncolor4_${message.guild.id}`) || "⚫" },
                        { label: "Changer le type", value: "type", emoji: "💎" },
                        { label: "Définir le message", value: "msg", emoji: "💬" },
                        { label: "Supprimer les boutons", value: "delete", emoji: "🗑️" },
                        { label: "Envoyer le rolemenu", value: "send", emoji: "✅" }
                    ])
            );

            msg?.edit({ embeds: [embed], components: [row] });
        };

        const editButtonEmbed = (msg, i) => {
            const embed = new Discord.EmbedBuilder()
                .setTitle(`🎛️ Configuration du Bouton ${i}`)
                .setColor(client.color)
                .setFooter(client.footer)
                .addFields(
                    { name: "Couleur", value: `\`${client.db.get(`buttoncolor${i}_${message.guild.id}`) || "⚫"}\``, inline: true },
                    { name: "Texte", value: `\`${client.db.get(`buttonname${i}_${message.guild.id}`) || "Non défini"}\``, inline: true },
                    { name: "Rôle", value: `${message.guild.roles.cache.get(client.db.get(`buttonrole${i}_${message.guild.id}`)) || "`Aucun rôle`"}`, inline: false }
                );

            const row = new Discord.ActionRowBuilder().addComponents(
                new Discord.StringSelectMenuBuilder()
                    .setCustomId(`edit-button-${message.id}`)
                    .setPlaceholder("Modifier une propriété...")
                    .setMaxValues(1)
                    .setMinValues(1)
                    .addOptions([
                        { label: "Changer la couleur", value: "color", emoji: "🎨" },
                        { label: "Modifier le texte", value: "text", emoji: "✍️" },
                        { label: "Assigner un rôle", value: "role", emoji: "🏷️" },
                        { label: "Retour au menu principal", value: "retour", emoji: "⬅️" }
                    ])
            );

            msg.edit({ embeds: [embed], components: [row] });
        };

        const colorEmbed = (msg) => {
            const embed = new Discord.EmbedBuilder()
                .setTitle("🎨 Choisir une couleur")
                .setDescription("Sélectionnez une couleur pour le bouton :")
                .setColor(client.color)
                .setFooter(client.footer);

            const row = new Discord.ActionRowBuilder().addComponents(
                new Discord.StringSelectMenuBuilder()
                    .setCustomId(`color-${message.id}`)
                    .setPlaceholder("Choisir une couleur...")
                    .setMaxValues(1)
                    .setMinValues(1)
                    .addOptions([
                        { label: "Rouge", value: "rouge", emoji: "🔴" },
                        { label: "Vert", value: "vert", emoji: "🟢" },
                        { label: "Bleu", value: "bleu", emoji: "🔵" },
                        { label: "Gris", value: "gris", emoji: "⚫" }
                    ])
            );

            msg.edit({ embeds: [embed], components: [row] });
        };

        const msg = await message.channel.send({ embeds: [new Discord.EmbedBuilder().setDescription("Chargement du Rolemenu...").setColor(client.color || '#00AAFF')], components: [] });
        mainEmbed(msg);

        const filter = (m) => m.author.id === message.author.id;
        const collector = message.channel.createMessageComponentCollector({ time: 1000 * 60 * 10 });

        collector.on('collect', async interaction => {
            if (interaction.user.id !== message.author.id) return interaction.reply({ content: "Vous n'avez pas la permission d'utiliser ce menu.", ephemeral: true });
            interaction.deferUpdate().catch(() => false);
            if (!interaction.isStringSelectMenu()) return;

            const value = interaction.values[0];

            if (value.startsWith('button')) {
                ii = value.split('button')[1];
                editButtonEmbed(msg, ii);
            } else if (value === "delete") {
                for (let i = 1; i <= 4; i++) {
                    client.db.delete(`buttoncolor${i}_${message.guild.id}`);
                    client.db.delete(`buttonname${i}_${message.guild.id}`);
                    client.db.delete(`buttonrole${i}_${message.guild.id}`);
                }
                mainEmbed(msg);
            } else if (value === "type") {
                client.db.get(`menu_${message.guild.id}`) ? client.db.delete(`menu_${message.guild.id}`) : client.db.set(`menu_${message.guild.id}`, true);
                mainEmbed(msg);
            } else if (value === "retour") {
                mainEmbed(msg);
            } else if (value === "text") {
                await msg.edit({ components: [] });
                const prompt = await message.channel.send("✍️ Quel est le nouveau texte du bouton ?");
                const collected = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                if (collected.size > 0) {
                    client.db.set(`buttonname${ii}_${message.guild.id}`, collected.first().content);
                    prompt.delete().catch(() => false);
                    collected.first().delete().catch(() => false);
                }
                editButtonEmbed(msg, ii);
            } else if (value === "role") {
                await msg.edit({ components: [] });
                const prompt = await message.channel.send("🏷️ Quel rôle assigner ? (mentionnez-le ou donnez son ID)");
                const collected = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                if (collected.size > 0) {
                    const role = collected.first().mentions.roles.first() || message.guild.roles.cache.get(collected.first().content);
                    if (role) client.db.set(`buttonrole${ii}_${message.guild.id}`, role.id);
                    else message.channel.send("❌ Rôle non trouvé.").then(m => setTimeout(() => m.delete(), 3000));
                    prompt.delete().catch(() => false);
                    collected.first().delete().catch(() => false);
                }
                editButtonEmbed(msg, ii);
            } else if (value === "color") {
                colorEmbed(msg);
            } else if (["rouge", "vert", "bleu", "gris"].includes(value)) {
                const colors = { rouge: "🔴", vert: "🟢", bleu: "🔵", gris: "⚫" };
                client.db.set(`buttoncolor${ii}_${message.guild.id}`, colors[value]);
                interaction.channel.send(`✅ Couleur définie sur **${value}**`).then(m => setTimeout(() => m.delete(), 2000));
                editButtonEmbed(msg, ii);
            } else if (value === "msg") {
                const prompt1 = await message.channel.send("💬 Dans quel salon envoyer le rolemenu ? (mentionnez-le ou donnez son ID)");
                const collected1 = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                if (collected1.size === 0) return;
                const channel = collected1.first().mentions.channels.first() || message.guild.channels.cache.get(collected1.first().content);
                if (!channel) return message.channel.send("❌ Salon non trouvé.").then(m => setTimeout(() => m.delete(), 3000));

                const prompt2 = await message.channel.send("📩 Quel est l'ID du message à modifier ?");
                const collected2 = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                if (collected2.size === 0) return;

                const msgToEdit = await channel.messages.fetch(collected2.first().content).catch(() => null);
                if (!msgToEdit || msgToEdit.author.id !== client.user.id) return message.channel.send("❌ Message invalide ou je ne suis pas l'auteur.").then(m => setTimeout(() => m.delete(), 3000));

                client.db.set(`buttonrolec_${message.guild.id}`, channel.id);
                client.db.set(`buttonrolem_${message.guild.id}`, msgToEdit.id);
                prompt1.delete().catch(() => false);
                prompt2.delete().catch(() => false);
                collected1.first().delete().catch(() => false);
                collected2.first().delete().catch(() => false);
                mainEmbed(msg);
            } else if (value === "send") {
                const channelId = client.db.get(`buttonrolec_${message.guild.id}`);
                const msgId = client.db.get(`buttonrolem_${message.guild.id}`);
                if (!msgId) return interaction.reply({ content: "❌ Aucun message défini.", ephemeral: true });

                const channel = message.guild.channels.cache.get(channelId);
                if (!channel) return message.channel.send("❌ Salon non trouvé.").then(m => setTimeout(() => m.delete(), 5000));

                const targetMsg = await channel.messages.fetch(msgId).catch(() => null);
                if (!targetMsg || targetMsg.author.id !== client.user.id) return message.channel.send("❌ Message invalide ou je ne suis pas l'auteur.").then(m => setTimeout(() => m.delete(), 5000));

                const row = new Discord.ActionRowBuilder();
                const roles = [1, 2, 3, 4].map(i => message.guild.roles.cache.get(client.db.get(`buttonrole${i}_${message.guild.id}`)));
                const names = [1, 2, 3, 4].map(i => client.db.get(`buttonname${i}_${message.guild.id}`));
                if (!names.some(n => n) || !roles.some(r => r)) return message.channel.send("❌ Créez au moins un bouton/menu.").then(m => setTimeout(() => m.delete(), 5000));

                if (client.db.get(`menu_${message.guild.id}`)) {
                    const menu = new Discord.StringSelectMenuBuilder()
                        .setCustomId(`rolemenu-${message.id}`)
                        .setPlaceholder("Choisir un rôle...")
                        .setMinValues(1);
                    [1, 2, 3, 4].forEach(i => {
                        if (names[i - 1] && roles[i - 1]) menu.addOptions([{ label: names[i - 1], value: `buttonrole${i}_${roles[i - 1].id}` }]);
                    });
                    menu.setMaxValues(menu.options.length);
                    row.addComponents(menu);
                } else {
                    [1, 2, 3, 4].forEach(i => {
                        if (names[i - 1] && roles[i - 1]) {
                            row.addComponents(
                                new Discord.ButtonBuilder()
                                    .setCustomId(`buttonrole${i}_${roles[i - 1].id}`)
                                    .setLabel(names[i - 1])
                                    .setStyle(buttonColor(client.db.get(`buttoncolor${i}_${message.guild.id}`) || "⚫"))
                            );
                        }
                    });
                }
                targetMsg.edit({ components: [row] });
                message.channel.send("✅ Rolemenu envoyé avec succès !").then(m => setTimeout(() => m.delete(), 3000));
            }
        });
    }
};

const buttonColor = (emoji) => {
    return {
        "🟢": Discord.ButtonStyle.Success,
        "🔴": Discord.ButtonStyle.Danger,
        "⚫": Discord.ButtonStyle.Secondary,
        "🔵": Discord.ButtonStyle.Primary
    }[emoji] || Discord.ButtonStyle.Secondary;
};