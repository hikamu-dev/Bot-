const Discord = require('discord.js');

module.exports = {
    name: "mpsettings",
    description: "Affiche et gère les paramètres des messages privés pour les actions",
    use: "mpsettings",
    usages: "mpsettings",
    run: async (client, message, args, commandName) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
        client.db.get(`owner_global_${message.author.id}`) === true || 
client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        let actions = ["kick", "ban", "mute", "unmute", "warn", "unwarn", "derank", "giveaway"];
        let currentSettings = {};
        actions.forEach(action => {
            currentSettings[action] = client.db.get(`mp_${action}_${message.guild.id}`) || false;
        });

        // Fonction pour générer l'embed avec les états actuels
        const updateEmbed = () => {
            const embed = new Discord.EmbedBuilder()
                .setTitle("Paramètres des messages privés")
                .setDescription("Sélectionnez les actions pour lesquelles vous souhaitez activer ou désactiver les MPs.")
                .setColor(client.color);

            actions.forEach(action => {
                let status = currentSettings[action] ? "✅ Activé" : "❌ Désactivé";
                embed.addFields({ name: action.charAt(0).toUpperCase() + action.slice(1), value: status, inline: false });
            });

            return embed;
        };

        // Fonction pour créer les boutons
        const createButtons = () => {
            return actions.map(action => {
                return new Discord.ButtonBuilder()
                    .setCustomId(`toggle_${action}`)
                    .setLabel(action.charAt(0).toUpperCase() + action.slice(1))
                    .setStyle(currentSettings[action] ? Discord.ButtonStyle.Success : Discord.ButtonStyle.Danger);
            });
        };

        // Créer les rows (maximum 5 boutons par row)
        const createRows = () => {
            const buttons = createButtons();
            const rows = [];
            
            for (let i = 0; i < buttons.length; i += 5) {
                const row = new Discord.ActionRowBuilder();
                row.addComponents(buttons.slice(i, i + 5));
                rows.push(row);
            }
            
            return rows;
        };

        // Envoyer l'embed et les boutons
        const rows = createRows();
        const sentMessage = await message.channel.send({ 
            embeds: [updateEmbed()], 
            components: rows 
        });

        const filter = i => i.user.id === message.author.id;
        const collector = sentMessage.createMessageComponentCollector({ filter, time: 60000 });

        collector.on('collect', async i => {
            try {
                // Vérifier si l'interaction est encore valide
                if (!i.isRepliable()) {
                    console.log('Interaction non repliable, ignorée');
                    return;
                }

                const action = i.customId.replace('toggle_', '');
                const newState = !currentSettings[action];
                
                // Mettre à jour la base de données
                client.db.set(`mp_${action}_${i.guild.id}`, newState);
                currentSettings[action] = newState;

                // Recréer les rows avec les nouveaux états
                const updatedRows = createRows();

                // Mettre à jour l'embed et les boutons avec gestion d'erreur
                await i.update({ 
                    embeds: [updateEmbed()], 
                    components: updatedRows 
                }).catch(error => {
                    console.error('Erreur lors de la mise à jour de l\'interaction:', error);
                    // Si l'interaction a échoué, essayer de modifier le message directement
                    sentMessage.edit({ 
                        embeds: [updateEmbed()], 
                        components: updatedRows 
                    }).catch(editError => {
                        console.error('Erreur lors de la modification du message:', editError);
                    });
                });
                
            } catch (error) {
                console.error('Erreur lors de la gestion du bouton:', error);
                
                // Essayer de répondre seulement si l'interaction n'a pas encore été répondue
                if (i.isRepliable()) {
                    try {
                        await i.reply({ 
                            content: 'Une erreur est survenue lors de la mise à jour.', 
                            ephemeral: true 
                        });
                    } catch (replyError) {
                        console.error('Erreur lors de la réponse à l\'interaction:', replyError);
                    }
                }
            }
        });

        collector.on('end', collected => {
            // Désactiver tous les boutons
            try {
                const disabledRows = createRows().map(row => {
                    const newRow = new Discord.ActionRowBuilder();
                    const disabledComponents = row.components.map(button => 
                        Discord.ButtonBuilder.from(button).setDisabled(true)
                    );
                    newRow.addComponents(disabledComponents);
                    return newRow;
                });
                
                sentMessage.edit({ components: disabledRows }).catch(error => {
                    console.error('Erreur lors de la désactivation des boutons:', error);
                });
                
                if (collected.size === 0) {
                    message.channel.send(" ").catch(error => {
                        console.error('Erreur lors de l\'envoi du message de timeout:', error);
                    });
                }
            } catch (error) {
                console.error('Erreur lors de la finalisation du collector:', error);
            }
        });
    }
};