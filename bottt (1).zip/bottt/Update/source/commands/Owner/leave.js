const { EmbedBuilder } = require('discord.js');
const { example, usage } = require('./aliases');

module.exports = {
    name: 'leave',
    description: 'Permet de faire leave le bot d\'un discord ou il est !',
    usage: "leave [id]",
    use:"[id]",
    example: "➜ leave 123456789012345678\n➜ leave",
    run: async (client, message, args, commandName) => {
        let pass = false
        let staff = client.staff
if (!staff.includes(message.author.id) && 
    !client.config.buyers.includes(message.author.id) && 
    client.db.get(`owner_global_${message.author.id}`) !== true && 
    client.db.get(`owner_${message.author.id}`) !== true) {        } else pass = true;
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}
        const guildId = args[0];
        const guildToLeave = guildId ? client.guilds.cache.get(guildId) : message.guild;

        if (!guildToLeave) {
            return message.reply({ content: "Je n'ai pas pu trouver la guilde spécifiée ou actuelle." });
        }

        if(guildId === '1147835194716463145') {
            return message.reply({ content: "Je ne peux pas quitter ce serveur (ceci est un serveur officiel)." });

        }

        try {
            message.reply({ content: `J'ai bien quitté le serveur : **${guildToLeave.name}**` })
            await guildToLeave.leave();
        } catch (error) {
            console.error(error);
            message.reply({ content: "Une erreur s'est produite." });
        }
    }
};
