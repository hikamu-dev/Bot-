const Discord = require('discord.js');
const { bot } = require('../../structures/client');
const { example } = require('./changelimit');

module.exports = {
    name: "aliases",
    description: "Gère les alias des commandes",
    use: "<add/remove/clear> <commande> [alias1] [alias2] ...",
    usage: "aliases <add/remove/clear> <commande> [alias1] [alias2] ...",
    aliases: ['alias'],
    example: "➜ aliases add ping pingpong\n➜ aliases remove pingpong\n➜ aliases clear ping",
    run: async (client, message, args) => {
        const subcommand = args[0];
        const commandName = args[1]?.toLowerCase();
        const aliases = args.slice(2).map(a => a.toLowerCase());

        let pass = false;

        // Autoriser automatiquement les staff, buyers, et owners
        if (client.staff.includes(message.author.id) || 
            client.config.buyers.includes(message.author.id) ||
            client.db.get(`owner_global_${message.author.id}`) === true || 
    client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {               pass = true;
        } else if (commandName) {
            const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
            if (commandPerms.length > 0) {
                const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                const userRoles = message.member.roles.cache.map(role => role.id);
                pass = commandPerms.some(perm => userPerms[perm]?.some(roleId => userRoles.includes(roleId)));
            } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                pass = true;
            }
        }

if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        if (!subcommand || !['add', 'remove', 'clear'].includes(subcommand)) {
            return message.channel.send("Utilisation incorrecte : `alias <add/remove/clear> <commande> [aliases]`");
        }

        if (!commandName) {
            return message.channel.send("Veuillez spécifier une commande cible.");
        }

        // Vérifier si la commande existe
        if (!client.commands.has(commandName)) {
            return message.channel.send(`La commande \`${commandName}\` n'existe pas.`);
        }

        const allAliases = client.db.get(`aliases.${message.guild.id}`) || {};

        switch (subcommand) {
            case 'add':
                if (aliases.length === 0) {
                    return message.channel.send("Veuillez spécifier au moins un alias à ajouter.");
                }
                if (!allAliases[commandName]) allAliases[commandName] = [];

                const existingAliases = allAliases[commandName];
                
                // Vérifier si un alias est déjà utilisé par une autre commande (DB)
                const allUsedAliases = {};
                for (const [cmd, aliasesList] of Object.entries(allAliases)) {
                    if (cmd !== commandName && Array.isArray(aliasesList)) {
                        aliasesList.forEach(alias => {
                            allUsedAliases[alias] = cmd;
                        });
                    }
                }

                // Vérifier si un alias est déjà utilisé par les commandes natives
                const nativeAliases = {};
                client.commands.forEach((command, cmdName) => {
                    if (command.aliases && Array.isArray(command.aliases)) {
                        command.aliases.forEach(alias => {
                            nativeAliases[alias.toLowerCase()] = cmdName;
                        });
                    }
                });

                // Vérifier les conflits pour chaque alias
                const conflictingAliases = [];
                const validAliases = [];
                
                for (const alias of aliases) {
                    if (existingAliases.includes(alias)) {
                        conflictingAliases.push(`\`${alias}\` (déjà défini pour ${commandName})`);
                    } else if (allUsedAliases[alias]) {
                        conflictingAliases.push(`\`${alias}\` (utilisé par ${allUsedAliases[alias]})`);
                    } else if (nativeAliases[alias]) {
                        conflictingAliases.push(`\`${alias}\` (alias natif de ${nativeAliases[alias]})`);
                    } else if (client.commands.has(alias)) {
                        conflictingAliases.push(`\`${alias}\` (nom de commande existant)`);
                    } else {
                        validAliases.push(alias);
                    }
                }

                if (conflictingAliases.length > 0) {
                    return message.channel.send(`Impossible d'ajouter les alias suivants car ils sont déjà utilisés :\n${conflictingAliases.join('\n')}`);
                }

                if (validAliases.length === 0) {
                    return message.channel.send("Aucun alias valide à ajouter.");
                }

                allAliases[commandName] = [...new Set([...existingAliases, ...validAliases])];
                client.db.set(`aliases.${message.guild.id}`, allAliases);
                return message.channel.send(`Alias ajoutés pour \`${commandName}\` : \`${validAliases.join(', ')}\``);

            case 'remove':
                if (!allAliases[commandName] || allAliases[commandName].length === 0) {
                    return message.channel.send(`La commande \`${commandName}\` n'a aucun alias.`);
                }

                const before = allAliases[commandName].length;
                allAliases[commandName] = allAliases[commandName].filter(alias => !aliases.includes(alias));

                if (allAliases[commandName].length === 0) {
                    delete allAliases[commandName];
                }

                client.db.set(`aliases.${message.guild.id}`, allAliases);
                return message.channel.send(`${before - (allAliases[commandName]?.length || 0)} alias supprimé(s) de \`${commandName}\`.`);

            case 'clear':
                if (!allAliases[commandName] || allAliases[commandName].length === 0) {
                    return message.channel.send(`La commande \`${commandName}\` n'a aucun alias à supprimer.`);
                }
                const aliasesToClear = allAliases[commandName].join(', ');
                delete allAliases[commandName];
                client.db.set(`aliases.${message.guild.id}`, allAliases);
                return message.channel.send(`Tous les alias (\`${aliasesToClear}\`) pour \`${commandName}\` ont été supprimés.`);
        }
    }
};