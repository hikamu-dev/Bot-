const { Client, GatewayIntentBits, ChannelType } = require('discord.js');
const Astroia = require('../../structures/client/index');
const { example } = require('./aliases');

module.exports = {
    name: 'servinvite',
    aliases: ['serveur-invite', 'serveurinvite'],
    description: 'Affiche la liste des serveurs sur lesquels le bot est présent',
    example: '➜ servinvite 123456789012345678\n➜ servinvite',
    /**
     * @param {Astroia} client 
     * @param {import('discord.js').Message} message
     * @param {string[]} args
     */
    run: async (client, message, args) => {
    let pass = false;
    const commandName = 'servinvite';

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
        client.db.get(`owner_global_${message.author.id}`) === true || 
client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}
        const guildId = args[0];
        
        // Vérifier si un ID de serveur est fourni
        if (!guildId) {
            return message.channel.send('Veuillez faire `servinvite <id>`');
        }
        
        try {
            const guild = await client.guilds.fetch(guildId);
            if (!guild) return message.channel.send(`Aucun serveur trouvé pour \`${guildId}\``);

            // Vérifier si le bot a accès aux canaux du serveur
            if (!guild.channels || !guild.channels.cache) {
                const guildName = guild.name || `ID: ${guildId}`;
                return message.channel.send(`Je n'ai pas les permissions nécessaires pour accéder aux canaux du serveur ${guildName}.`);
            }

            // Chercher un canal textuel où le bot peut créer une invitation
            const textChannel = guild.channels.cache.find(channel => 
                channel.type === ChannelType.GuildText && 
                channel.permissionsFor(client.user).has('CreateInstantInvite')
            );

            if (!textChannel) {
                const guildName = guild.name || `ID: ${guildId}`;
                return message.channel.send(`Je ne peux pas créer d'invitation sur le serveur ${guildName}. Je n'ai pas les permissions nécessaires dans aucun canal textuel.`);
            }

            const invite = await textChannel.createInvite();
            const guildName = guild.name || `ID: ${guildId}`;
            message.channel.send(`Voici le lien d'invitation pour le serveur ${guildName}: ${invite.url}`);
        } catch (error) {
            console.error('Erreur dans servinvite:', error);
            if (error.code === 50001) {
                message.channel.send(`Je n'ai pas accès au serveur ${args[0] || 'spécifié'}.`);
            } else if (error.code === 50013) {
                message.channel.send(`Je n'ai pas les permissions nécessaires pour créer une invitation sur ce serveur.`);
            } else {
                message.channel.send('Une erreur s\'est produite lors de la création de l\'invitation.');
            }
        }
    }
}
