const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ComponentType
} = require("discord.js");

// fetch natif Node18+ (fallback node-fetch@2 si besoin)
let _fetch = globalThis.fetch;
if (!_fetch) {
  try { _fetch = require("node-fetch"); }
  catch { throw new Error("fetch absent. Utilise Node 18+ ou `npm i node-fetch@2`."); }
}

module.exports = {
  name: "configfivem",
  description: "Connexion avec un serveur FiveM.",
  usage: "+configfivem",
  run: async (client, message, args, commandName) => {
    if (!message.guild) return;

    // === PERMISSIONS (même logique que tes commandes) ===
    const hasPerms = () => {
      if (client.staff?.includes(message.author.id)) return true;
      if (client.config?.buyers?.includes(message.author.id)) return true;
      if (client.db.get(`owner_global_${message.author.id}`) === true) return true;
      if (client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true) return true;

      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member?.roles?.cache?.map(r => r.id) || [];
        return commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      }
      if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") return true;
      return false;
    };

    if (!hasPerms()) {
      if (client.noperm && client.noperm.trim() !== "") {
        const sent = await message.channel.send(client.noperm);
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) setTimeout(() => sent.delete().catch(() => {}), delayTime * 1000);
      }
      return;
    }

    // === KEYS & Interval ===
    const K_IP   = `fivem_ip_${message.guild.id}`;
    const K_LAST = `fivem_last_${message.guild.id}`; // {count,max,host,gametype,map,status}

    if (!client.fivemPollers) client.fivemPollers = new Map();

    // === FETCH FiveM ===
    async function pull(ip) {
      try {
        const ts = Date.now(); // anti-cache
        const [infoRes, playersRes] = await Promise.all([
          _fetch(`http://${ip}/info.json?ts=${ts}`, { cache: "no-store" }),
          _fetch(`http://${ip}/players.json?ts=${ts}`, { cache: "no-store" })
        ]);
        if (!infoRes.ok || !playersRes.ok) throw new Error("bad res");

        const info = await infoRes.json();
        const players = await playersRes.json();

        const data = {
          count: Array.isArray(players) ? players.length : 0,
          max: Number(info?.vars?.sv_maxClients) || (Array.isArray(players) ? players.length : 0),
          host: info?.vars?.sv_projectName || "unknown",
          gametype: info?.vars?.gamename || info?.vars?.gametype || "unknown",
          map: info?.vars?.mapname || "unknown",
          status: "En ligne"
        };
        client.db.set(K_LAST, data);
        return data;
      } catch {
        const data = { count: 0, max: 0, host: "unknown", gametype: "unknown", map: "unknown", status: "Hors ligne" };
        client.db.set(K_LAST, data);
        return data;
      }
    }

    function startPoller(gid, ip) {
      stopPoller(gid);
      if (!ip) return;
      const intv = setInterval(() => pull(ip), 10_000); // 10s (au lieu de 60s)
      client.fivemPollers.set(gid, intv);
      pull(ip); // 1er fetch immédiat
    }
    function stopPoller(gid) {
      const itv = client.fivemPollers.get(gid);
      if (itv) { clearInterval(itv); client.fivemPollers.delete(gid); }
    }

    // === EMBEDS ===
    const ip = client.db.get(K_IP) || "Aucune";
    const last = client.db.get(K_LAST) || { count: "unknown", max: "unknown", host: "unknown", gametype: "unknown", map: "unknown", status: "unknown" };

    const makeEmbedFilled = (d) => new EmbedBuilder()
      .setTitle("Connection avec un serveur FiveM")
      .setColor(client.color)
      .setDescription(`IP: **${client.db.get(K_IP) || "Aucune"}**`)
      .addFields(
        { name: "{FivemMembersCount}", value: `Nombre de joueurs connectés\n**Exemple:** \`${d.count}\``, inline: true },
        { name: "{FivemMaxMembers}",  value: `Nombre maximum de joueurs\n**Exemple:** \`${d.max}\``, inline: true },
        { name: "{FivemHostName}",    value: `Nom du serveur\n**Exemple:** \`${d.host}\``, inline: true },
        { name: "{FivemGameType}",    value: `Type de jeu\n**Exemple:** \`${d.gametype}\``, inline: true },
        { name: "{FivemMapName}",     value: `Nom de la map\n**Exemple:** \`${d.map}\``, inline: true },
        { name: "{FivemStatus}",      value: `Status du serveur\n**Exemple:** \`${d.status}\``, inline: true },
      )
      .setFooter({ text: "Exemple : +stream {FivemMembersCount}/{FivemMaxMembers} sur {FivemHostName}" });

    const makeEmbedEmpty = () => new EmbedBuilder()
      .setTitle("Connection avec un serveur FiveM")
      .setColor(client.color)
      .setDescription(`IP: **${client.db.get(K_IP) || "Aucune"}**`)
      .addFields(
        { name: "{FivemMembersCount}", value: "Nombre de joueurs connectés\n**Exemple:** `unknown`", inline: true },
        { name: "{FivemMaxMembers}",  value: "Nombre maximum de joueurs\n**Exemple:** `unknown`", inline: true },
        { name: "{FivemHostName}",    value: "Nom du serveur\n**Exemple:** `unknown`", inline: true },
        { name: "{FivemGameType}",    value: "Type de jeu\n**Exemple:** `unknown`", inline: true },
        { name: "{FivemMapName}",     value: "Nom de la map\n**Exemple:** `unknown`", inline: true },
        { name: "{FivemStatus}",      value: "Status du serveur\n**Exemple:** `En ligne`", inline: true },
      )
      .setFooter({ text: "Exemple : dans botconfig → {FivemMembersCount}/{FivemMaxMembers} sur {FivemHostName}" });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("fivem_change_ip").setLabel("Modifier l'adresse du serveur").setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId("fivem_clear_ip").setLabel("Supprimer l'adresse du serveur").setStyle(ButtonStyle.Danger)
    );

    const msg = await message.channel.send({
      embeds: [ip === "Aucune" ? makeEmbedEmpty() : makeEmbedFilled(last)],
      components: [row]
    });

    // === COLLECTOR ===
    const collector = msg.createMessageComponentCollector({
      componentType: ComponentType.Button,
      time: 10 * 60 * 1000
    });

    collector.on("collect", async (itx) => {
      // sécurité perms
      if (itx.user.id !== message.author.id && !hasPerms()) {
        return itx.reply({ content: "❌ Tu n’as pas la permission pour ce panel.", ephemeral: true });
      }

      if (itx.customId === "fivem_change_ip") {
        const modal = new ModalBuilder()
          .setCustomId("fivem_set_ip_modal")
          .setTitle("Adresse IP:Port du serveur");

        const input = new TextInputBuilder()
          .setCustomId("fivem_ip_input")
          .setLabel("IP:Port (ex: 51.178.42.10:30120)")
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setPlaceholder("IP:Port");

        modal.addComponents(new ActionRowBuilder().addComponents(input));
        await itx.showModal(modal);

        const submitted = await itx.awaitModalSubmit({
          time: 30_000,
          filter: i => i.customId === "fivem_set_ip_modal" && i.user.id === itx.user.id
        }).catch(() => null);
        if (!submitted) return;

        const raw = submitted.fields.getTextInputValue("fivem_ip_input")?.trim();
        if (!/^\S+:\d{2,5}$/.test(raw)) {
          return submitted.reply({ content: "❌ Format invalide. Utilise `IP:Port`.", ephemeral: true });
        }

        client.db.set(K_IP, raw);
        await submitted.reply({ content: `✅ IP enregistrée : \`${raw}\``, ephemeral: true });

        const data = await pull(raw);
        await msg.edit({ embeds: [makeEmbedFilled(data)], components: [row] }).catch(() => {});
        // démarrer polling auto
        if (!client.fivemPollers.has(message.guild.id)) {
          // au cas où
        }
        startPoller(message.guild.id, raw);

      } else if (itx.customId === "fivem_clear_ip") {
        client.db.delete(K_IP);
        client.db.delete(K_LAST);
        const itv = client.fivemPollers.get(message.guild.id);
        if (itv) { clearInterval(itv); client.fivemPollers.delete(message.guild.id); }
        await itx.reply({ content: "🗑️ Adresse du serveur supprimée.", ephemeral: true });
        await msg.edit({ embeds: [makeEmbedEmpty()], components: [row] }).catch(() => {});
      }
    });

    collector.on("end", async () => {
      const disabled = new ActionRowBuilder().addComponents(
        ButtonBuilder.from(row.components[0]).setDisabled(true),
        ButtonBuilder.from(row.components[1]).setDisabled(true),
      );
      await msg.edit({ components: [disabled] }).catch(() => {});
    });
  }
};
