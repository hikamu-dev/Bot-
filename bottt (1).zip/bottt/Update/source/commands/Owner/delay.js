const { Astroia } = require("../../structures/client/index");
const Discord = require('discord.js');

module.exports = {
    name: 'delay',
    description: 'Configure le délai de suppression quand un utilisateur n\'a pas les permissions',
    usage: 'delay [durée/off]',
    use: "[durée/off]",
    example: "➜ delay 5s\n➜ delay 10s\n➜ delay 30s\n➜ delay off",
    run: async (client, message, args, commandName) => {
        let pass = false;

        // Autoriser automatiquement les staff, buyers, et owners
        if (client.staff.includes(message.author.id) || 
            client.config.buyers.includes(message.author.id) ||
                        client.db.get(`owner_global_${message.author.id}`) === true || 
    client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {               pass = true;
        } else {
            // Vérifier les permissions personnalisées pour la commande
            const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
            if (commandPerms.length > 0) {
                const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                const userRoles = message.member.roles.cache.map(role => role.id);
                pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
            } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                pass = true;
            }
        }

        // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        // Si aucun argument, afficher le délai actuel
        if (args.length < 1) {
            const currentDelay = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
            if (currentDelay === 0) {
                return message.channel.send("Aucun délai configuré. Les messages de permission ne seront pas supprimés automatiquement.");
            } else {
                return message.channel.send(`Délai actuel configuré : \`${currentDelay}s\``);
            }
        }

        const delayInput = args[0].toLowerCase();

        // Supprimer le délai si "off", "disable", "0" ou "0s"
        if (delayInput === 'off' || delayInput === 'disable' || delayInput === '0' || delayInput === '0s') {
            client.db.delete(`noperm_delay_${message.guild.id}`);
            return message.channel.send("Délai de suppression désactivé. Les messages de permission ne seront plus supprimés automatiquement.");
        }

        // Parser la durée (accepter format comme "5s", "10s", etc.)
        let delayTime;
        if (delayInput.endsWith('s')) {
            delayTime = parseInt(delayInput.slice(0, -1));
        } else {
            delayTime = parseInt(delayInput);
        }

        // Vérifier que la durée est valide
        if (isNaN(delayTime) || delayTime < 1 || delayTime > 300) {
            return message.channel.send("Durée invalide. Utilisez une durée entre 1 et 300 secondes (ex: `5s`, `10s`, `30s`).");
        }

        // Sauvegarder le délai dans la base de données
        client.db.set(`noperm_delay_${message.guild.id}`, delayTime);
        
        message.channel.send(`Délai de suppression configuré à \`${delayTime}s\`.`);
    },
};