const { ActivityType } = require('discord.js');
const db = require('quick.db');

module.exports = {
  name: "dnd",
  description: "Met le statut en ne pas déranger (dnd)",
  usage: "dnd",
  category: "status",
  run: async (client, message, args, commandName = "dnd") => {
    if (!message.guild) return;

    const hasPerms = () => {
      if (client.staff?.includes(message.author.id)) return true;
      if (client.config?.buyers?.includes(message.author.id)) return true;
      if (client.db.get(`owner_global_${message.author.id}`) === true) return true;
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member?.roles?.cache?.map(r => r.id) || [];
        return commandPerms.some(perm => userPerms[perm]?.some?.(rid => userRoles.includes(rid)));
      }
      if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") return true;
      return false;
    };
    if (!hasPerms()) {
      if (client.noperm && client.noperm.trim() !== "") {
        const sent = await message.channel.send(client.noperm);
        const delay = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delay > 0) setTimeout(()=>sent.delete().catch(()=>{}), delay*1000);
      }
      return;
    }

    const status = 'dnd';
    db.set('presence', status);

    const type = db.get('type');
    const name = db.get('nomstatut') || '';
    const url  = db.get('streamURL') || undefined;

    const map = {
      STREAMING: ActivityType.Streaming,
      PLAYING: ActivityType.Playing,
      LISTENING: ActivityType.Listening,
      WATCHING: ActivityType.Watching,
      COMPETING: ActivityType.Competing
    };

    const activities = [];
    if (type && name) {
      activities.push({
        name,
        type: map[type] ?? ActivityType.Playing,
        url: type === 'STREAMING' ? url : undefined
      });
    }

    await client.user.setPresence({ activities, status });

    const label = { online: 'en ligne', idle: 'inactif', dnd: 'ne pas déranger', invisible: 'invisible' }[status];
    return message.reply(`${client.user.tag} est actuellement en mode **${label}** sur ce serveur.`);
  }
};
