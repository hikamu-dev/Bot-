const { ActivityType } = require('discord.js');
const db = require('quick.db');

module.exports = {
  name: "watch",
  description: "Définit l’activité Regarde …",
  usage: "watch <texte…>",
  category: "status",
  run: async (client, message, args) => {
    if (!message.guild) return;

    const rawText = args.join(" ").trim();
    if (!rawText) return message.reply("Utilisation : `+watch <texte…>`");

    // ⚠️ mémorise le modèle avec placeholders
    db.set('nomstatut_tpl', rawText);

    const ref = client.db.get(`fivem_last_${message.guild.id}`) || {};
    const textResolved = String(rawText)
      .replace(/\{FivemMembersCount\}/g, String(ref.count ?? 'unknown'))
      .replace(/\{FivemMaxMembers\}/g,   String(ref.max ?? 'unknown'))
      .replace(/\{FivemHostName\}/g,     String(ref.host ?? 'unknown'))
      .replace(/\{FivemGameType\}/g,     String(ref.gametype ?? 'unknown'))
      .replace(/\{FivemMapName\}/g,      String(ref.map ?? 'unknown'))
      .replace(/\{FivemStatus\}/g,       String(ref.status ?? 'unknown'));

    db.set('type', 'WATCHING');
    db.set('nomstatut', textResolved);

    await client.user.setPresence({
      activities: [{ name: textResolved, type: ActivityType.Watching }],
      status: db.get('presence') || 'online'
    });

    if (/\{Fivem/i.test(rawText)) {
      if (client._presenceTimer) clearInterval(client._presenceTimer);
      client._presenceTemplate = rawText;

      client._presenceTimer = setInterval(async () => {
        try {
          const d = client.db.get(`fivem_last_${message.guild.id}`) || {};
          const again = String(client._presenceTemplate)
            .replace(/\{FivemMembersCount\}/g, String(d.count ?? 'unknown'))
            .replace(/\{FivemMaxMembers\}/g,   String(d.max ?? 'unknown'))
            .replace(/\{FivemHostName\}/g,     String(d.host ?? 'unknown'))
            .replace(/\{FivemGameType\}/g,     String(d.gametype ?? 'unknown'))
            .replace(/\{FivemMapName\}/g,      String(d.map ?? 'unknown'))
            .replace(/\{FivemStatus\}/g,       String(d.status ?? 'unknown'));
          db.set('nomstatut', again);
          await client.user.setPresence({
            activities: [{ name: again, type: ActivityType.Watching }],
            status: db.get('presence') || 'online'
          });
        } catch {}
      }, 10_000);
    } else if (client._presenceTimer) { clearInterval(client._presenceTimer); client._presenceTimer = null; }

    return message.reply(`Le statut est passé en **Regarde**.`);
  }
};
