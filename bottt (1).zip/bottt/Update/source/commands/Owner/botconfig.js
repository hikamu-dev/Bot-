const { ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActivityType } = require('discord.js');
const db = require('quick.db');

module.exports = {
    name: 'botconfig',
    usage: 'botconfig',
    description: 'Configuration complète du bot',
    run: async(client, message, args, commandName) => {
    let pass = false;

    // Vérifier si l'utilisateur est dans la liste des buyers
    if (client.config.buyers.includes(message.author.id)) {
        pass = true;
    }

    if (!pass) {
        if (client.noperm && client.noperm.trim() !== '') {
            const sentMessage = await message.channel.send(client.noperm);
            // Récupérer le délai configuré pour ce serveur
            const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
            if (delayTime > 0) {
                setTimeout(() => {
                    sentMessage.delete().catch(() => {});
                }, delayTime * 1000);
            }
        }
        return;
    }


        // Récupération des données actuelles
        const presence = client.db.get('presence') || 'online';
        const autostart = client.db.get('startbot_enabled') || false;
        const protection = client.db.get('securbot') || false;
        const securbot = client.db.get('securbot') || false;
        let activityType = db.get('type') || 'PLAYING';
        let activityName = db.get('nomstatut') || 'Nytheris';
        let streamURL = db.get('streamURL') || 'Streaming non actif';
        let botName = client.user.username;
        let botAvatar = client.user.displayAvatarURL({ dynamic: true, size: 256 });
        let botDescription = client.db.get('description') || 'Aucune biographie configurée';

        const activityTranslations = {
            "PLAYING": "Joue à",
            "WATCHING": "Regarde",
            "LISTENING": "Écoute",
            "STREAMING": "Stream",
            "COMPETING": "Participe à"
        };

        const activityTypeMap = {
            PLAYING: ActivityType.Playing,
            WATCHING: ActivityType.Watching,
            LISTENING: ActivityType.Listening,
            STREAMING: ActivityType.Streaming,
            COMPETING: ActivityType.Competing
        };

        const presenceTranslations = {
            "online": "🟢 En ligne",
            "idle": "🟡 Absent",
            "dnd": "🔴 Ne pas déranger",
            "invisible": "⚫ Invisible"
        };

        // Fonction pour créer l'embed principal
        const createMainEmbed = () => {
            const buyerCount = client.config.buyers.length;
            const currentBuyerIndex = client.config.buyers.indexOf(message.author.id) + 1;

            const statusEmoji = presence === 'online' ? '🟢' : presence === 'idle' ? '🟡' : presence === 'dnd' ? '🔴' : '⚫';
            const autostart = client.db.get('startbot_enabled') || false;
            const readyEmoji = autostart ? '🟢' : '🔴';
            const securbot = client.db.get('securbot') || false;
            const securbotEmoji = securbot ? '🟢' : '🔴';

            const statusText = presence === 'online' ? 'En ligne' : presence === 'idle' ? 'Absent' : presence === 'dnd' ? 'Ne pas déranger' : 'Invisible';
            const readyText = autostart ? 'Activé' : 'Désactivé';
            const securbotText = securbot ? 'Activé' : 'Désactivé';

            return new EmbedBuilder()
                .setTitle('Configuration actuelle')
.setDescription(`**• Buyer**
\`\`\`
➜ Buyer: ${currentBuyerIndex}/${buyerCount} | ${message.author.tag} (ID: ${message.author.id})
\`\`\`

**• Bot**
\`\`\`
➜ Nom: ${client.user.tag}
➜ ID: ${client.user.id}
\`\`\`

**• Statut**
\`\`\`
➜ Statut: ${statusEmoji} ${statusText}
➜ Activité: ${activityTranslations[activityType] || 'Aucune'}
➜ Texte: ${activityName}
➜ URL: ${streamURL}
\`\`\`

**• Ready**
\`\`\`
➜ Statut: ${readyEmoji} ${readyText}
\`\`\`

**• Securbot**
\`\`\`
➜ Statut: ${securbotEmoji} ${securbotText}
\`\`\``)

                .setColor(client.color)
                .setFooter(client.footer);
        };

        // Fonction pour créer l'embed de configuration d'activité
        const createActivityEmbed = () => {
            return new EmbedBuilder()
                .setTitle("Configuration de l'activité")
                .setDescription(`**Activité actuelle** : ${activityTranslations[activityType]} ${activityName}`)
                .setColor(client.color)
.addFields({
    name: ' ',
    value: `• **Type disponible :**
\`\`\`
➜ 🟣 : Type Streaming (Streame)
\`\`\`
\`\`\`
➜ 👁️ : Type Watching (Regarde)
\`\`\`
\`\`\`
➜ 🎮 : Type Playing (Joue à)
\`\`\`
\`\`\`
➜ 🏆 : Type Competing (Participe à)
\`\`\`
\`\`\`
➜ 🎧 : Type Listening (Écoute)
\`\`\`
\`\`\`
➜ ✨ : Activité personnalisée (...)
\`\`\``,
    inline: true
})

                .setFooter(client.footer);
        };

        const createStatusEmbed = () => {
            return new EmbedBuilder()
                .setTitle("Configuration du statut")
                .setDescription(`**Statut actuel** : \`${presenceTranslations[presence]}\``)
                .setColor(client.color)
.addFields({
    name: '**Statut disponible :**',
    value: `
\`\`\`
➜ 🟢 : Type En ligne (online)
\`\`\`
\`\`\`
➜ 🟡 : Type Inactif (idle)
\`\`\`
\`\`\`
➜ 🔴 : Type Ne pas déranger (dnd)
\`\`\`
\`\`\`
➜ ⚫ : Type Hors ligne (offline)
\`\`\``,
    inline: false
})

                .setFooter(client.footer);
        };

        const statusTypeButtons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('status_online')
                    .setEmoji('🟢')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('status_idle')
                    .setEmoji('🟡')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('status_dnd')
                    .setEmoji('🔴')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('status_invisible')
                    .setEmoji('⚫')
                    .setStyle(ButtonStyle.Secondary)
            );

        // Menu de sélection principal
        const mainSelectMenu = new StringSelectMenuBuilder()
            .setCustomId('main_config_select')
            .setPlaceholder('Fais un choix')
            .addOptions([
                {
                    label: 'Activer/désactiver le message de démarrage du bot',
                    value: 'toggle_autostart',
                    emoji: '🟢'
                },
                {
                    label: 'Activer/désactiver la protection d\'invitations du bot',
                    value: 'toggle_protection',
                    emoji: '🔴'
                },
            ]);

        // Première ligne de boutons de modification
        const modificationButtons1 = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('modify_bot_name')
                    .setLabel('Modifier le nom du bot')
                    .setEmoji('✏️')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('modify_bot_avatar')
                    .setLabel('Modifier la photo de profil')
                    .setEmoji('🖼️')
                    .setStyle(ButtonStyle.Secondary)
            );

        // Troisième ligne pour les boutons de statut
        const statusButtons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('modify_status_type')
                    .setLabel('Modifier le type statut')
                    .setEmoji('🟢')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('modify_activity_type')
                    .setLabel('Modifier le type d\'activité')
                    .setEmoji('💬')
                    .setStyle(ButtonStyle.Secondary)
            );

        // Boutons pour les types d'activité avec emojis
        const activityTypeButtons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('activity_streaming')
                    .setEmoji('🟣')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('activity_watching')
                    .setEmoji('👁️')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('activity_playing')
                    .setEmoji('🎮')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('activity_competing')
                    .setEmoji('🏆')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('activity_listening')
                    .setEmoji('🎧')
                    .setStyle(ButtonStyle.Secondary)
            );

        // Boutons supplémentaires pour la configuration d'activité
        const activityConfigButtons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('activity_custom')
                    .setEmoji('✨')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('activity_reset')
                    .setEmoji('🔄')
                    .setStyle(ButtonStyle.Danger)
            );

        // Bouton retour
        const backButton = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('back_main')
                    .setLabel('Retour')
                    .setEmoji('🔙')
                    .setStyle(ButtonStyle.Secondary)
            );

        const selectRow = new ActionRowBuilder().addComponents(mainSelectMenu);

        const mainMsg = await message.channel.send({
            embeds: [createMainEmbed()],
            components: [selectRow, modificationButtons1, statusButtons]
        });

        const filter = (interaction) => interaction.user.id === message.author.id;
        const collector = mainMsg.createMessageComponentCollector({ filter, time: 900000 });

        // Gestion des modals
        const handleModalSubmit = async (modalInteraction) => {
            if (!modalInteraction.isModalSubmit() || modalInteraction.user.id !== message.author.id) return;

            const validModals = ['name_modal', 'avatar_modal', 'banner_modal', 'activity_text_modal', 'stream_url_modal', 'bio_modal', 'streaming_modal', 'watching_modal', 'playing_modal', 'competing_modal', 'listening_modal', 'custom_modal'];
            if (!validModals.includes(modalInteraction.customId)) return;

            // Defer the reply immediately to acknowledge the interaction
            if (!modalInteraction.deferred && !modalInteraction.replied) {
                try {
                    await modalInteraction.deferReply({ ephemeral: true });
                } catch (error) {
                    console.error('Failed to defer modal reply:', error);
                    return;
                }
            }

            try {
                switch (modalInteraction.customId) {
                    case 'name_modal':
                        const newName = modalInteraction.fields.getTextInputValue('name_input');
                        try {
                            await client.user.setUsername(newName);
                            botName = newName;
                            await modalInteraction.editReply({ content: `✅ Nom du bot mis à jour : **${newName}**` });
                        } catch (error) {
                            await modalInteraction.editReply({ content: `❌ Erreur lors du changement de nom : ${error.message}` });
                        }
                        break;

                    case 'avatar_modal':
                        const newAvatarURL = modalInteraction.fields.getTextInputValue('avatar_input');
                        try {
                            await client.user.setAvatar(newAvatarURL);
                            botAvatar = newAvatarURL;
                            await modalInteraction.editReply({ content: '✅ Avatar du bot mis à jour !' });
                        } catch (error) {
                            await modalInteraction.editReply({ content: '❌ Erreur lors du changement d\'avatar. Vérifiez que l\'URL est valide.' });
                        }
                        break;

                    case 'bio_modal':
                        const newBio = modalInteraction.fields.getTextInputValue('bio_input');
                        try {
                            client.db.set('description', newBio);
                            botDescription = newBio;
                            await modalInteraction.editReply({ content: '✅ Biographie du bot mis à jour !' });
                        } catch (error) {
                            await modalInteraction.editReply({ content: '❌ Erreur lors du changement de biographie.' });
                        }
                        break;

                    case 'activity_text_modal':
                        const newActivityText = modalInteraction.fields.getTextInputValue('activity_text_input');
                        db.set('nomstatut', newActivityText);
                        activityName = newActivityText;
                        client.user.setPresence({
                            activities: [{ name: activityName, type: activityTypeMap[activityType], url: activityType === 'STREAMING' ? streamURL : undefined }],
                            status: presence
                        });
                        await modalInteraction.editReply({ content: `✅ Texte d'activité mis à jour : **${newActivityText}**` });
                        break;

                    case 'stream_url_modal':
                        const newStreamURL = modalInteraction.fields.getTextInputValue('stream_url_input');
                        db.set('streamURL', newStreamURL);
                        streamURL = newStreamURL;
                        if (activityType === 'STREAMING') {
                            client.user.setPresence({
                                activities: [{ name: activityName, type: activityTypeMap[activityType], url: newStreamURL }],
                                status: presence
                            });
                        }
                        await modalInteraction.editReply({ content: `✅ URL de stream mise à jour : **${newStreamURL}**` });
                        break;

                    // Nouveaux modals pour chaque type d'activité
                    case 'streaming_modal':
                        const streamingText = modalInteraction.fields.getTextInputValue('streaming_input');
                        activityType = 'STREAMING';
                        activityName = streamingText;
                        db.set('type', activityType);
                        db.set('nomstatut', activityName);
                        client.user.setPresence({
                            activities: [{ name: activityName, type: activityTypeMap[activityType], url: streamURL }],
                            status: presence
                        });
                        await modalInteraction.editReply({ content: `✅ Activité Streaming configurée : **${streamingText}**` });
                        break;

                    case 'watching_modal':
                        const watchingText = modalInteraction.fields.getTextInputValue('watching_input');
                        activityType = 'WATCHING';
                        activityName = watchingText;
                        db.set('type', activityType);
                        db.set('nomstatut', activityName);
                        client.user.setPresence({
                            activities: [{ name: activityName, type: activityTypeMap[activityType] }],
                            status: presence
                        });
                        await modalInteraction.editReply({ content: `✅ Activité Watching configurée : **${watchingText}**` });
                        break;

                    case 'playing_modal':
                        const playingText = modalInteraction.fields.getTextInputValue('playing_input');
                        activityType = 'PLAYING';
                        activityName = playingText;
                        db.set('type', activityType);
                        db.set('nomstatut', activityName);
                        client.user.setPresence({
                            activities: [{ name: activityName, type: activityTypeMap[activityType] }],
                            status: presence
                        });
                        await modalInteraction.editReply({ content: `✅ Activité Playing configurée : **${playingText}**` });
                        break;

                    case 'competing_modal':
                        const competingText = modalInteraction.fields.getTextInputValue('competing_input');
                        activityType = 'COMPETING';
                        activityName = competingText;
                        db.set('type', activityType);
                        db.set('nomstatut', activityName);
                        client.user.setPresence({
                            activities: [{ name: activityName, type: activityTypeMap[activityType] }],
                            status: presence
                        });
                        await modalInteraction.editReply({ content: `✅ Activité Competing configurée : **${competingText}**` });
                        break;

                    case 'listening_modal':
                        const listeningText = modalInteraction.fields.getTextInputValue('listening_input');
                        activityType = 'LISTENING';
                        activityName = listeningText;
                        db.set('type', activityType);
                        db.set('nomstatut', activityName);
                        client.user.setPresence({
                            activities: [{ name: activityName, type: activityTypeMap[activityType] }],
                            status: presence
                        });
                        await modalInteraction.editReply({ content: `✅ Activité Listening configurée : **${listeningText}**` });
                        break;

                    case 'custom_modal':
                        const customText = modalInteraction.fields.getTextInputValue('custom_input');
                        activityName = customText;
                        db.set('nomstatut', activityName);
                        client.user.setPresence({
                            activities: [{ name: activityName, type: activityTypeMap[activityType] }],
                            status: presence
                        });
                        await modalInteraction.editReply({ content: `✅ Activité personnalisée configurée : **${customText}**` });
                        break;
                }

                // Update the main message after modal processing
                await mainMsg.edit({
                    embeds: [createMainEmbed()],
                    components: [selectRow, modificationButtons1, statusButtons]
                });
            } catch (error) {
                console.error('Erreur modal:', error.stack);
                if (!modalInteraction.replied && !modalInteraction.deferred) {
                    await modalInteraction.reply({ content: '❌ Une erreur est survenue.', ephemeral: true }).catch(() => {});
                } else if (modalInteraction.deferred) {
                    await modalInteraction.editReply({ content: '❌ Une erreur est survenue.' }).catch(() => {});
                }
            }
        };

        collector.on('collect', async (interaction) => {
            try {
                if (interaction.isStringSelectMenu()) {
                    const value = interaction.values[0];

                    // Gestion du menu principal
                    switch (value) {
                        case 'toggle_autostart':
                            try {
                                const currentAutostart = client.db.get('startbot_enabled') || false;
                                const newAutostart = !currentAutostart;
                                client.db.set('startbot_enabled', newAutostart);
                                const updatedAutostart = client.db.get('startbot_enabled');

                                if (updatedAutostart === currentAutostart) {
                                    await interaction.reply({
                                        content: '❌ Erreur : Impossible de mettre à jour l\'état de l\'autostart.',
                                        ephemeral: true
                                    });
                                    return;
                                }

                                await interaction.reply({
                                    content: `🔄 Message de démarrage ${newAutostart ? '**activé**' : '**désactivé**'}`,
                                    ephemeral: true
                                });

                                await mainMsg.edit({
                                    embeds: [createMainEmbed()],
                                    components: [selectRow, modificationButtons1, statusButtons]
                                });
                            } catch (error) {
                                await interaction.reply({
                                    content: `❌ Une erreur est survenue lors de la modification de l'autostart : ${error.message}`,
                                    ephemeral: true
                                });
                            }
                            break;

                        case 'toggle_protection':
                            const newProtection = !client.db.get('securbot');
                            client.db.set('securbot', newProtection);
                            await interaction.reply({
                                content: `🔄 Protection d'invitations ${newProtection ? '**activée**' : '**désactivée**'}`,
                                ephemeral: true
                            });
                            await mainMsg.edit({
                                embeds: [createMainEmbed()],
                                components: [selectRow, modificationButtons1, statusButtons]
                            });
                            break;

                        case 'online':
                        case 'idle':
                        case 'dnd':
                        case 'invisible':
                            client.db.set('presence', value);
                            client.user.setPresence({
                                activities: [{ name: activityName, type: activityTypeMap[activityType] }],
                                status: value
                            });
                            await interaction.reply({
                                content: `✅ Statut mis à jour : ${presenceTranslations[value]}`,
                                ephemeral: true
                            });
                            await mainMsg.edit({
                                embeds: [createMainEmbed()],
                                components: [selectRow, modificationButtons1, statusButtons]
                            });
                            break;

                        case 'PLAYING':
                        case 'WATCHING':
                        case 'LISTENING':
                        case 'STREAMING':
                        case 'COMPETING':
                            activityType = value;
                            db.set('type', activityType);
                            client.user.setPresence({
                                activities: [{ name: activityName, type: activityTypeMap[activityType], url: activityType === 'STREAMING' ? streamURL : undefined }],
                                status: presence
                            });
                            await interaction.reply({
                                content: `✅ Type d'activité mis à jour : ${activityTranslations[activityType]}`,
                                ephemeral: true
                            });
                            await mainMsg.edit({
                                embeds: [createMainEmbed()],
                                components: [selectRow, modificationButtons1, statusButtons]
                            });
                            break;
                    }
                }

                if (interaction.isButton()) {
                    switch (interaction.customId) {
                        case 'modify_status_type':
                            await showStatusTypeMenu(interaction);
                            return;

                        case 'modify_activity_type':
                            await showActivityTypeMenu(interaction);
                            return;

                        case 'modify_bot_name':
                            await showNameModal(interaction);
                            return;

                        case 'modify_bot_avatar':
                            await showAvatarModal(interaction);
                            return;

                        case 'modify_bot_bio':
                            await showBioModal(interaction);
                            return;

                        case 'modify_bot_banner':
                            await showBannerModal(interaction);
                            return;

                        case 'back_main':
                            await interaction.update({
                                embeds: [createMainEmbed()],
                                components: [selectRow, modificationButtons1, statusButtons]
                            });
                            return;

                        case 'modify_activity_text':
                            await showActivityTextModal(interaction);
                            return;

                        case 'modify_stream_url':
                            await showStreamURLModal(interaction);
                            return;

                        case 'reset_activity':
                            db.set('type', 'PLAYING');
                            db.set('nomstatut', 'Aucun texte configuré');
                            db.set('streamURL', 'Streaming non actif');
                            client.user.setPresence({
                                activities: [],
                                status: presence
                            });
                            await interaction.reply({
                                content: '✅ Activité réinitialisée !',
                                ephemeral: true
                            });
                            await mainMsg.edit({
                                embeds: [createMainEmbed()],
                                components: [selectRow, modificationButtons1, statusButtons]
                            });
                            return;

                        // Nouveaux boutons pour les types d'activité
                        case 'activity_streaming':
                            await showStreamingModal(interaction);
                            return;

                        case 'activity_watching':
                            await showWatchingModal(interaction);
                            return;

                        case 'activity_playing':
                            await showPlayingModal(interaction);
                            return;

                        case 'activity_competing':
                            await showCompetingModal(interaction);
                            return;

                        case 'activity_listening':
                            await showListeningModal(interaction);
                            return;

                        case 'activity_custom':
                            await showCustomModal(interaction);
                            return;

                        case 'activity_reset':
                            db.set('type', 'PLAYING');
                            db.set('nomstatut', 'Aucun texte configuré');
                            db.set('streamURL', 'Streaming non actif');
                            activityType = 'PLAYING';
                            activityName = 'Aucun texte configuré';
                            client.user.setPresence({
                                activities: [],
                                status: presence
                            });
                            await interaction.reply({
                                content: '✅ Activité réinitialisée !',
                                ephemeral: true
                            });
                            await mainMsg.edit({
                                embeds: [createActivityEmbed()],
                                components: [activityTypeButtons, activityConfigButtons, backButton]
                            });
                            return;

                        // Gestion des boutons de statut
                        case 'status_online':
                            await handleStatusChange(interaction, 'online');
                            return;

                        case 'status_idle':
                            await handleStatusChange(interaction, 'idle');
                            return;

                        case 'status_dnd':
                            await handleStatusChange(interaction, 'dnd');
                            return;

                        case 'status_invisible':
                            await handleStatusChange(interaction, 'invisible');
                            return;
                    }
                }
            } catch (error) {
                console.error('Erreur dans botconfig:', error.stack);
                if (!interaction.replied && !interaction.deferred) {
                    await interaction.reply({
                        content: '❌ Une erreur est survenue.',
                        ephemeral: true
                    }).catch(() => {});
                }
            }
        });

        // Fonction pour gérer les changements de statut
        async function handleStatusChange(interaction, newStatus) {
            try {
                client.db.set('presence', newStatus);
                client.user.setPresence({
                    activities: [{ name: activityName, type: activityTypeMap[activityType], url: activityType === 'STREAMING' ? streamURL : undefined }],
                    status: newStatus
                });
                
                await interaction.reply({
                    content: `✅ Statut mis à jour : ${presenceTranslations[newStatus]}`,
                    ephemeral: true
                });

                // Retour au menu principal
                await mainMsg.edit({
                    embeds: [createMainEmbed()],
                    components: [selectRow, modificationButtons1, statusButtons]
                });
            } catch (error) {
                console.error('Erreur lors du changement de statut:', error);
                await interaction.reply({
                    content: '❌ Erreur lors du changement de statut.',
                    ephemeral: true
                });
            }
        }

        // Fonction pour afficher le menu de type de statut
        async function showStatusTypeMenu(interaction) {
            try {
                await interaction.update({ 
                    embeds: [createStatusEmbed()], 
                    components: [statusTypeButtons, backButton] 
                });
            } catch (error) {
                console.error('Erreur showStatusTypeMenu:', error);
                await interaction.reply({
                    content: '❌ Erreur lors de l\'affichage du menu de statut.',
                    ephemeral: true
                });
            }
        }

        //

        // Fonction pour afficher le menu de type d'activité
        async function showActivityTypeMenu(interaction) {
            await interaction.update({
                embeds: [createActivityEmbed()],
                components: [activityTypeButtons, activityConfigButtons, backButton]
            });
        }

        // Fonctions pour afficher les modals
        async function showNameModal(interaction) {
            const nameModal = new ModalBuilder()
                .setCustomId('name_modal')
                .setTitle('Modifier le nom du bot');

            const nameInput = new TextInputBuilder()
                .setCustomId('name_input')
                .setLabel('Nouveau nom du bot')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('Entrez le nouveau nom')
                .setMaxLength(32)
                .setValue(botName)
                .setRequired(true);

            nameModal.addComponents(new ActionRowBuilder().addComponents(nameInput));
            await interaction.showModal(nameModal);
        }

        async function showAvatarModal(interaction) {
            const avatarModal = new ModalBuilder()
                .setCustomId('avatar_modal')
                .setTitle('Modifier la photo de profil');

            const avatarInput = new TextInputBuilder()
                .setCustomId('avatar_input')
                .setLabel('URL de la nouvelle image')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('https://example.com/image.png')
                .setRequired(true);

            avatarModal.addComponents(new ActionRowBuilder().addComponents(avatarInput));
            await interaction.showModal(avatarModal);
        }

        async function showBioModal(interaction) {
            const bioModal = new ModalBuilder()
                .setCustomId('bio_modal')
                .setTitle('Modifier la biographie du bot');

            const bioInput = new TextInputBuilder()
                .setCustomId('bio_input')
                .setLabel('Nouvelle biographie')
                .setStyle(TextInputStyle.Paragraph)
                .setPlaceholder('Entrez la nouvelle biographie')
                .setValue(botDescription)
                .setMaxLength(2000)
                .setRequired(true);

            bioModal.addComponents(new ActionRowBuilder().addComponents(bioInput));
            await interaction.showModal(bioModal);
        }

        async function showBannerModal(interaction) {
            const bannerModal = new ModalBuilder()
            .setCustomId('banner_modal')
                .setTitle('Modifier la bannière du bot');

            const bannerInput = new TextInputBuilder()
                .setCustomId('banner_input')
                .setLabel('URL de la nouvelle bannière')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('https://example.com/banner.png')
                .setRequired(true);

            bannerModal.addComponents(new ActionRowBuilder().addComponents(bannerInput));
            await interaction.showModal(bannerModal);
        }

        async function showActivityTextModal(interaction) {
            const activityTextModal = new ModalBuilder()
                .setCustomId('activity_text_modal')
                .setTitle('Modifier le texte d\'activité');

            const activityTextInput = new TextInputBuilder()
                .setCustomId('activity_text_input')
                .setLabel('Nouveau texte d\'activité')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('Entrez le nouveau texte')
                .setValue(activityName)
                .setMaxLength(128)
                .setRequired(true);

            activityTextModal.addComponents(new ActionRowBuilder().addComponents(activityTextInput));
            await interaction.showModal(activityTextModal);
        }

        async function showStreamURLModal(interaction) {
            const streamURLModal = new ModalBuilder()
                .setCustomId('stream_url_modal')
                .setTitle('Modifier l\'URL de stream');

            const streamURLInput = new TextInputBuilder()
                .setCustomId('stream_url_input')
                .setLabel('URL de stream')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('https://twitch.tv/username')
                .setValue(streamURL !== 'Streaming non actif' ? streamURL : '')
                .setRequired(true);

            streamURLModal.addComponents(new ActionRowBuilder().addComponents(streamURLInput));
            await interaction.showModal(streamURLModal);
        }

        // Nouveaux modals pour chaque type d'activité
        async function showStreamingModal(interaction) {
            const streamingModal = new ModalBuilder()
                .setCustomId('streaming_modal')
                .setTitle('Configurer l\'activité Streaming');

            const streamingInput = new TextInputBuilder()
                .setCustomId('streaming_input')
                .setLabel('Texte de streaming')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('Ex: Mon stream génial')
                .setMaxLength(128)
                .setRequired(true);

            streamingModal.addComponents(new ActionRowBuilder().addComponents(streamingInput));
            await interaction.showModal(streamingModal);
        }

        async function showWatchingModal(interaction) {
            const watchingModal = new ModalBuilder()
                .setCustomId('watching_modal')
                .setTitle('Configurer l\'activité Watching');

            const watchingInput = new TextInputBuilder()
                .setCustomId('watching_input')
                .setLabel('Texte de watching')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('Ex: Netflix')
                .setMaxLength(128)
                .setRequired(true);

            watchingModal.addComponents(new ActionRowBuilder().addComponents(watchingInput));
            await interaction.showModal(watchingModal);
        }

        async function showPlayingModal(interaction) {
            const playingModal = new ModalBuilder()
                .setCustomId('playing_modal')
                .setTitle('Configurer l\'activité Playing');

            const playingInput = new TextInputBuilder()
                .setCustomId('playing_input')
                .setLabel('Texte de playing')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('Ex: Minecraft')
                .setMaxLength(128)
                .setRequired(true);

            playingModal.addComponents(new ActionRowBuilder().addComponents(playingInput));
            await interaction.showModal(playingModal);
        }

        async function showCompetingModal(interaction) {
            const competingModal = new ModalBuilder()
                .setCustomId('competing_modal')
                .setTitle('Configurer l\'activité Competing');

            const competingInput = new TextInputBuilder()
                .setCustomId('competing_input')
                .setLabel('Texte de competing')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('Ex: Tournoi de gaming')
                .setMaxLength(128)
                .setRequired(true);

            competingModal.addComponents(new ActionRowBuilder().addComponents(competingInput));
            await interaction.showModal(competingModal);
        }

        async function showListeningModal(interaction) {
            const listeningModal = new ModalBuilder()
                .setCustomId('listening_modal')
                .setTitle('Configurer l\'activité Listening');

            const listeningInput = new TextInputBuilder()
                .setCustomId('listening_input')
                .setLabel('Texte de listening')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('Ex: Spotify')
                .setMaxLength(128)
                .setRequired(true);

            listeningModal.addComponents(new ActionRowBuilder().addComponents(listeningInput));
            await interaction.showModal(listeningModal);
        }

        async function showCustomModal(interaction) {
            const customModal = new ModalBuilder()
                .setCustomId('custom_modal')
                .setTitle('Configurer une activité personnalisée');

            const customInput = new TextInputBuilder()
                .setCustomId('custom_input')
                .setLabel('Texte personnalisé')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('Ex: Mon activité personnalisée')
                .setMaxLength(128)
                .setRequired(true);

            customModal.addComponents(new ActionRowBuilder().addComponents(customInput));
            await interaction.showModal(customModal);
        }

        // Gestionnaire pour les modals
        client.on('interactionCreate', handleModalSubmit);

        // Gestion des sélections de statut
        collector.on('collect', async (interaction) => {
            if (interaction.isStringSelectMenu() && interaction.customId === 'status_type_select') {
                const selectedStatus = interaction.values[0];
                client.db.set('presence', selectedStatus);
                client.user.setPresence({
                    activities: [{ name: activityName, type: activityTypeMap[activityType], url: activityType === 'STREAMING' ? streamURL : undefined }],
                    status: selectedStatus
                });
                
                await interaction.reply({
                    content: `✅ Statut mis à jour : ${presenceTranslations[selectedStatus]}`,
                    ephemeral: true
                });

                // Retour au menu principal
                await mainMsg.edit({
                    embeds: [createMainEmbed()],
                    components: [selectRow, modificationButtons1, modificationButtons2, statusButtons]
                });
            }
        });

        collector.on('end', async () => {
            try {
                // Supprimer le gestionnaire de modals
                client.removeListener('interactionCreate', handleModalSubmit);
                
                // Désactiver tous les composants
                const disabledComponents = [selectRow, modificationButtons1, statusButtons].map(row => {
                    const newRow = new ActionRowBuilder();
                    row.components.forEach(component => {
                        if (component.data.type === 3) { // StringSelectMenu
                            newRow.addComponents(
                                StringSelectMenuBuilder.from(component).setDisabled(true)
                            );
                        } else { // Button
                            newRow.addComponents(
                                ButtonBuilder.from(component).setDisabled(true)
                            );
                        }
                    });
                    return newRow;
                });

                await mainMsg.edit({
                    embeds: [createMainEmbed().setFooter({ text: 'Menu expiré' })],
                    components: disabledComponents
                });
            } catch (error) {
                console.error('Erreur lors de la fermeture du collector:', error);
            }
        });
    }
};