module.exports = {
    name: 'changelimit',
    description: "Modifie la limite d'utilisation d'une commande de modération",
    use: "<commande> <maxUse/clear> [temps]",
    usage: "changelimit <commande> <maxUse/clear> [temps]",
    example: "➜ changelimit ban 3 5m\n➜ changelimit ban clear",
    run: async (client, message, args, commandName) => {
        const prefix = client.config.prefix;
        let pass = false;

        if (
            client.staff.includes(message.author.id) ||
            client.config.buyers.includes(message.author.id) ||
                        client.db.get(`owner_global_${message.author.id}`) === true || 
            client.db.get(`owner_${message.author.id}`) === true
        ) {
            pass = true;
        } else {
            const permsCmd = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
            if (permsCmd.length > 0) {
                const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                const roles = message.member.roles.cache.map(r => r.id);
                pass = permsCmd.some(p => userPerms[p]?.some(role => roles.includes(role)));
            } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                pass = true;
            }
        }

if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        if (args.length < 2) {
            return message.reply(
                `Veuillez faire \`${prefix}changelimit <commande> <maxUse/clear> [temps]\`\n\n`
                
            );
        }

        const targetCommand = args[0].toLowerCase();
        const action = args[1].toLowerCase();

        const allowedCommands = [
            'ban', 'banlist', 'blacklist', 'cancelunban', 'clear', 'derank', 'editban',
            'editmute', 'kick', 'lock', 'lockall', 'mutelist', 'renew', 'sanction',
            'slowmode', 'mute', 'unban', 'unbanall', 'unblacklist', 'unlock',
            'unlockall', 'unmute', 'warn'
        ];

        if (!allowedCommands.includes(targetCommand)) {
            return message.reply(`Commande non autorisée. Voici celles acceptées : \`${allowedCommands.join(', ')}\``);
        }

        const dbKey = `command_limit_${message.guild.id}_${targetCommand}`;

        if (action === 'clear') {
            const exists = client.db.get(dbKey);
            if (!exists) return message.reply(`Aucune limite définie pour \`${targetCommand}\`.`);
            client.db.delete(dbKey);
            return message.reply(`Limite pour \`${targetCommand}\` supprimée.`);
        }

        const maxUse = parseInt(action);
        if (isNaN(maxUse) || maxUse <= 0) {
            return message.reply("Le nombre d'utilisations doit être un nombre entier positif.");
        }

        let timeLimit = null;
        if (args[2]) {
            const match = args[2].match(/^(\d+)([smhd])$/);
            if (!match) return message.reply("Temps invalide. Utilisez par exemple : `30s`, `5m`, `1h`, `1d`.");

            const val = parseInt(match[1]);
            const unit = match[2];
            const factors = { s: 1000, m: 60000, h: 3600000, d: 86400000 };
            timeLimit = val * factors[unit];
        }

        client.db.set(dbKey, {
            maxUse,
            timeLimit,
            createdAt: Date.now()
        });

        let msg = `Limite d'utilisation définie pour \`${targetCommand}\` : **${maxUse} utilisation(s)**`;
        if (timeLimit) msg += ` par ${args[2]}`;
        return message.reply(msg + ".");
    }
};
