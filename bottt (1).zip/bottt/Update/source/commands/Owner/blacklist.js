const Discord = require("discord.js");

module.exports = {
  name: "bl",
  use: "<@utilisateur/id> [raison]",
  usage: "bl <@utilisateur/id> [raison]",
  description: "Ajoute quelqu'un à la blacklist, il sera banni de tous les serveurs où le bot se trouve",
  example: "➜ bl @tokyru\n➜ bl 1257279089010675778 Spam excessif",
  run: async (client, message, args, commandName) => {
    const whitelistDB = client.db.get(`wl.${message.guild.id}`) || [];

    const isBypass = (
      client.staff.includes(message.author.id) ||
      client.config.buyers.includes(message.author.id) ||
      client.db.get(`owner_${message.author.id}`) === true ||
                  client.db.get(`owner_global_${message.author.id}`) === true || 
      whitelistDB.includes(message.author.id)
    );

    if (!isBypass) {
      const limitData = client.db.get(`command_limit_${message.guild.id}_bl`);
      if (limitData) {
        const key = `limit_used_bl_${message.guild.id}_${message.author.id}`;
        const userData = client.db.get(key) || { count: 0, timestamp: 0 };
        const now = Date.now();

        if (userData.timestamp + limitData.timeLimit > now) {
          if (userData.count >= limitData.maxUse) {
            const remaining = Math.ceil((userData.timestamp + limitData.timeLimit - now) / 1000);
            return message.reply(`Tu as atteint la limite d'utilisation de la commande \`blacklist\`. Réessaie dans ${remaining}s.`);
          } else {
            userData.count += 1;
          }
        } else {
          userData.count = 1;
          userData.timestamp = now;
        }

        client.db.set(key, userData);
      }
    }

    let pass = false;

    if (
      client.staff.includes(message.author.id) ||
      client.config.buyers.includes(message.author.id) ||
                  client.db.get(`owner_global_${message.author.id}`) === true || 
      client.db.get(`owner_${message.author.id}`) === true
    ) {
      pass = true;
    } else {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map((role) => role.id);
        pass = commandPerms.some((perm) => userPerms[perm] && userPerms[perm].some((roleId) => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        pass = true;
      }
    }

    if (!pass) {
      if (client.noperm && client.noperm.trim() !== "") {
        const sentMessage = await message.channel.send(client.noperm);
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
          setTimeout(() => {
            sentMessage.delete().catch(() => {});
          }, delayTime * 1000);
        }
      }
      return;
    }

    if (args[0]) {
      const member = message.mentions.members.first() || client.users.cache.get(args[0]) || (await client.users.fetch(args[0]).catch(() => false));

      if (!member) {
        return message.reply("Impossible de trouver l'utilisateur spécifié.");
      }

      if (client.db.get(`blacklist_${member.id}`) === true) {
        return message.reply(`${member.username || member.user.username} est déjà blacklisté.`);
      }

      if (client.db.get(`owner_${member.id}`) === true || client.config.buyers.includes(member.id)) {
        return message.channel.send(`Je ne peux pas blacklist un owner ou buyer bot`);
      }

      const reason = args.slice(1).join(" ") || "Blacklist";
      const banReason = `${reason} | par ${message.author.tag}`;

      try {
        const user = member.user || member;
        await user.send(`Vous avez été **blacklisté** sur **tous les serveurs** par ${message.author.tag}. Raison: ${reason}`);
      } catch (error) {
        console.log("Impossible d'envoyer un message privé à l'utilisateur:", error);
      }

      client.guilds.cache.forEach((guild) => {
        guild.members.ban(member, { reason: banReason }).catch(() => {});
      });

      client.db.set(`blacklist_${member.id}`, true);
      client.db.set(`blacklistDate_${member.id}`, Math.floor(Date.now() / 1000));
      client.db.set(`blacklistReason_${member.id}`, reason);
      client.db.set(`blacklistMod_${member.id}`, message.author.id);

      message.reply(`\`${member.username || member.user.username}\` a été blacklisté de tous les serveurs (${client.guilds.cache.size}).\n Raison: \`${reason}\``);
    } else {
      const data = client.db
        .all()
        .filter((data) => data.ID.startsWith(`blacklist_`))
        .sort((a, b) => b.data - a.data);

      const count = 15;
      let p0 = 0;
      let p1 = count;
      let page = 1;

      let embed = new Discord.EmbedBuilder()
        .setTitle(`Blacklist`)
        .setFooter(client.footer)
        .setColor(client.color);

      let description = (
        await Promise.all(
          data.slice(p0, p1).map(async (m, index) => {
            const userID = m.ID.split("_")[1];
            const userTag = await client.users.fetch(userID).catch(() => null);
            if (userTag) {
              return `\`${index + 1}.\` \`${userTag.tag}\` (${userID})`;
            } else {
              return `\`${index + 1}.\` User inconnu (${userID})`;
            }
          })
        )
      ).join("\n");

      if (!description) {
        description = "Aucune blacklist trouvée";
      }

      embed.setDescription(description);
      message.channel.send({ embeds: [embed] });
    }
  },
};
