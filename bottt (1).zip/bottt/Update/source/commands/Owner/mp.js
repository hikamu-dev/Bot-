const Discord = require('discord.js');

module.exports = {
    name: 'mp',
    description: 'Envoie un message privé à une personne spécifiée.',
    use: "<@utilisateur> <message>",
    usage: 'mp <@utilisateur> <message>',
    example: '➜ mp @tokyru Bonjour !\n➜ mp 123456789012345678 Bonjour !',
    run: async (client, message, args, commandName) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
        client.db.get(`owner_global_${message.author.id}`) === true || 
client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {   
      pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}
        if (args.length < 2) {
            const response = (await client.lang('mp.erreuruse')).replace("{prefix}", `\`${client.prefix}\``)
             message.channel.send({content: response}).catch(() => {});
            return;
        }

        const mentionedUser = message.mentions.users.first();

        if (!mentionedUser) {
            message.channel.send(await client.lang('mp.nouser'));
            return;
        }

        args.shift();
        const firstArg = args.shift().toLowerCase();
        let messageContent = args.join(' ');

        try {
            if (firstArg === 'embed') {
                const embedMessage = await message.channel.messages.fetch(messageContent);

                if (!embedMessage || !embedMessage.embeds.length) {
                    message.channel.send(await client.lang('mp.embedinvalide'));
                    return;
                }

                const oldEmbed = embedMessage.embeds[0];

                const newEmbed = new Discord.EmbedBuilder()
                    .setColor(oldEmbed.color)
                    .setTitle(oldEmbed.title)
                    .setDescription(oldEmbed.description)
                    .setURL(oldEmbed.url)
                    .setImage(oldEmbed.image?.url)
                    .setThumbnail(oldEmbed.thumbnail?.url)
                    .setFooter({text: oldEmbed.footer?.text, iconURL: oldEmbed.footer?.iconURL})
                    .setTimestamp();

                oldEmbed.fields.forEach(field => {
                    newEmbed.addFields({name: field.name, value: field.value, inline: field.inline});
                });

                await mentionedUser.send({ embeds: [newEmbed] });
            } else {
                messageContent = firstArg + ' ' + messageContent;
                await mentionedUser.send(messageContent);
            }
            message.channel.send(await client.lang('mp.send'));
        } catch (error) {
            message.channel.send(await client.lang('mp.erreur'));
            console.log(error)
        }
    },
};
