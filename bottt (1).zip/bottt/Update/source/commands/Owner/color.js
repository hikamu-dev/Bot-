const { ActionRowBuilder, StringSelectMenuBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'color',
  aliases: ['theme'],
  description: "Change la couleur de l'embed du bot sur le serveur",
  run: async (client, message, args, commandName) => {
    // Vérifier les permissions
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
                    client.db.get(`owner_global_${message.author.id}`) === true || 
client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}
    
    const colorMap = {
      "rouge": "#FF0000",
      "vert": "#00FF00",
      "bleu": "#0000FF",
      "noir": "#000000",
      "blanc": "#FFFFFF",
      "rose": "#dc14eb",
      "violet": "#764686",
      "orange": "#FFA500",
      "jaune": "#FFFF00",
      "marron": "#A52A2A",
      "gris": "#808080",
      "argent": "#C0C0C0",
      "cyan": "#00FFFF",
      "lavande": "#E6E6FA",
      "corail": "#FF7F50",
      "beige": "#F5F5DC",
      "defaut": client.config.default_color
    };

    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId('select_color')
      .setPlaceholder("Sélectionnez une couleur")
      .addOptions(
        Object.keys(colorMap).map(color => ({
          label: color.charAt(0).toUpperCase() + color.slice(1),
          value: color,
          emoji: '🎨'
        }))
      );

    const row = new ActionRowBuilder().addComponents(selectMenu);

    const embed = new EmbedBuilder()
      .setTitle("Choisissez une couleur")
      .setDescription("Utilisez le menu déroulant pour sélectionner la couleur des embeds.")
      .setColor(client.color)
      .setFooter(client.footer);

    const msg = await message.channel.send({ embeds: [embed], components: [row] });

    const collector = msg.createMessageComponentCollector({ time: 60000 });

    collector.on('collect', async interaction => {
      if (interaction.user.id !== message.author.id) return interaction.reply({ content: "Ce menu ne vous appartient pas.", ephemeral: true });
      
      const selectedColor = interaction.values[0];
      const colorCode = colorMap[selectedColor];
      
      const newEmbed = new EmbedBuilder()
        .setTitle("Couleur mise à jour !")
        .setColor(colorCode)
        .setFooter(client.footer);
      
      client.db.set(`color_${message.guild.id}`, colorCode);
      await interaction.update({ content: `La couleur a été changée en \`${selectedColor}\`.`, embeds: [newEmbed], components: [] });
    });
  }
};