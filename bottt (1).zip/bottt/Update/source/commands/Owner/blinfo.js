const Discord = require("discord.js");

module.exports = {
  name: "blinfo",
  use: "<@utilisateur/id>",
  usage: "blinfo <@utilisateur/id>",
  description: "Affiche les informations de blacklist d'un utilisateur",
  
  run: async (client, message, args) => {
        let pass = false;

    if (
      client.staff.includes(message.author.id) ||
      client.config.buyers.includes(message.author.id) ||
                  client.db.get(`owner_global_${message.author.id}`) === true || 
      client.db.get(`owner_${message.author.id}`) === true
    ) {
      pass = true;
    } else {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map((role) => role.id);
        pass = commandPerms.some((perm) => userPerms[perm] && userPerms[perm].some((roleId) => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        pass = true;
      }
    }

    if (!pass) {
      if (client.noperm && client.noperm.trim() !== "") {
        const sentMessage = await message.channel.send(client.noperm);
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
          setTimeout(() => {
            sentMessage.delete().catch(() => {});
          }, delayTime * 1000);
        }
      }
      return;
    }
    if (!args[0]) return message.reply("Veuillez spécifier un utilisateur avec son ID ou une mention.");

    const member = message.mentions.members.first() || client.users.cache.get(args[0]) || (await client.users.fetch(args[0]).catch(() => false));

    if (!member) return message.reply("Impossible de trouver l'utilisateur spécifié.");

    const isBlacklisted = client.db.get(`blacklist_${member.id}`) === true;
    if (!isBlacklisted) return message.reply(`${member.username || member.user.username} n'est pas blacklisté.`);

    const reason = client.db.get(`blacklistReason_${member.id}`) || "Aucune raison définie";
    const modId = client.db.get(`blacklistMod_${member.id}`) || "Inconnu";
    const moderator = modId === "Inconnu" ? { username: "Inconnu" } : await client.users.fetch(modId).catch(() => ({ username: "Inconnu" }));
    const blacklistTimestamp = client.db.get(`blacklistDate_${member.id}`);
    const date = blacklistTimestamp ? `<t:${blacklistTimestamp}:F>` : "Date inconnue";

    const embed = new Discord.EmbedBuilder()
      .setTitle(`Blacklist de ${member.username || member.user.username}`)
      .setThumbnail(member.displayAvatarURL())
      .addFields(
        { name: "Utilisateur", value: `${member.username || member.user.username} (${member.id})`, inline: true },
        { name: "Modérateur", value: `<@${modId}> (${modId})`, inline: true },
        { name: "Informations", value: `Raison: ${reason}\nDate: ${date}` }
      )
      .setColor(client.color)
      .setFooter(client.footer);

    message.channel.send({ embeds: [embed] });
  },
};
