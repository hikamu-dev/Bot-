const Discord = require('discord.js');
const Astroia = require('../../structures/client/index');

module.exports = {
    name: "renew",
    aliases: ["purge"],
    usage: "renew [#channel/channelid]",
    use: "[#channel/channelid]",
    description: "Permet de récréer un salon à la même position",
    example: "➜ renew #general\n➜ renew 123456789012345678",
    run: async (client, message, args, commandName) => {
                        const whitelistDB = client.db.get(`wl.${message.guild.id}`) || [];

const isBypass = (
    client.staff.includes(message.author.id) ||
    client.config.buyers.includes(message.author.id) ||
    client.db.get(`owner_${message.author.id}`) === true ||
            client.db.get(`owner_global_${message.author.id}`) === true || 

    whitelistDB.includes(message.author.id)
);

if (!isBypass) {
    const limitData = client.db.get(`command_limit_${message.guild.id}_renew`);
    if (limitData) {
        const key = `limit_used_renew_${message.guild.id}_${message.author.id}`;
        const userData = client.db.get(key) || { count: 0, timestamp: 0 };
        const now = Date.now();

        if (userData.timestamp + limitData.timeLimit > now) {
            if (userData.count >= limitData.maxUse) {
                const remaining = Math.ceil((userData.timestamp + limitData.timeLimit - now) / 1000);
                return message.reply(`Tu as atteint la limite d'utilisation de la commande \`renew\`. Réessaie dans ${remaining}s.`);
            } else {
                userData.count += 1;
            }
        } else {
            userData.count = 1;
            userData.timestamp = now;
        }

        client.db.set(key, userData);
    }
}
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
                client.db.get(`owner_global_${message.author.id}`) === true || 

client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        let channel = message.mentions.channels.first() || message.guild.channels.cache.get(args[0]) || message.channel;
        if (!channel) {
            return message.channel.send("Salon introuvable. Veuillez mentionner un salon ou fournir un ID valide.");
        }

        // Vérifier si le bot a les permissions nécessaires
        const botMember = message.guild.members.cache.get(client.user.id);
        if (!botMember.permissions.has(Discord.PermissionsBitField.Flags.ManageChannels)) {
            return message.channel.send("Je n'ai pas la permission de gérer les salons.");
        }

        // Vérification si le serveur est une communauté et si le salon est un salon communautaire
        if (message.guild.features.includes('COMMUNITY')) {
            const communityChannels = message.guild.channels.cache.filter(ch => 
                ch.type === Discord.ChannelType.GuildAnnouncement || 
                ch.id === message.guild.rulesChannelId || 
                ch.id === message.guild.publicUpdatesChannelId
            );

            if (communityChannels.has(channel.id)) {
                return message.channel.send("Impossible de recréer ce salon, car il s'agit d'un salon communautaire essentiel (annonces, règles ou mises à jour).");
            }
        }

        try {
            // Sauvegarder la position de l'ancien salon
            const originalPosition = channel.position;

            // Cloner le salon
            const newChannel = await channel.clone({ 
                reason: `Salon recréé par ${message.author.tag}` 
            });

            // Repositionner le nouveau salon à la place de l'ancien
            await newChannel.setPosition(originalPosition, { 
                reason: `Repositionnement du salon recréé par ${message.author.tag}` 
            });

            // Supprimer l'ancien salon
            await channel.delete({ 
                reason: `Salon recréé par ${message.author.tag}` 
            });

            // Envoyer un message de confirmation dans le nouveau salon
            await newChannel.send(`${message.author}, le salon <#${newChannel.id}> a été recréé avec succès`);

            // Envoyer un modlog
            const embed = new Discord.EmbedBuilder()
                .setColor(client.color)
                .setDescription(`${message.author} a recréé le salon <#${newChannel.id}> à la position ${originalPosition}`)
                .setTimestamp();

            const modlogChannel = message.guild.channels.cache.get(client.db.get(`modlogs_${message.guild.id}`));
            if (modlogChannel) {
                modlogChannel.send({ embeds: [embed] }).catch(error => console.error('Erreur lors de l\'envoi du modlog :', error));
            }
        } catch (error) {
            console.error('Erreur lors de la recréation du salon :', error);
            message.channel.send("Une erreur s'est produite lors de la recréation du salon. Vérifiez mes permissions ou réessayez.");
        }
    }
};