// commands/moderation/antipicture.js
const { ChannelType, PermissionsBitField, EmbedBuilder } = require("discord.js");

module.exports = {
  name: "antipicture",
  description: "Définit/supprime/liste les salons AntiPicture (pas d'images).",
  usages: "antipicture <add|remove|clear|list> [#salon]",
  example: "antipicture add #général",
  /**
   * @param {import('discord.js').Client} client
   * @param {import('discord.js').Message} message
   * @param {string[]} args
   */
  run: async (client, message, args, commandName = "antipicture") => {
    try {
      if (!message.guild) return;

      // ---- Permissions (ton style habituel) ----
      const whitelistDB = client.db.get(`wl.${message.guild.id}`) || [];
      const isBypassHard =
        client.staff?.includes?.(message.author.id) ||
        client.config?.buyers?.includes?.(message.author.id) ||
        client.db.get(`owner_${message.author.id}`) === true ||
        client.db.get(`owner_global_${message.author.id}`) === true ||
        whitelistDB.includes(message.author.id) ||
        message.guild.ownerId === message.author.id;

      let pass = isBypassHard;
      if (!pass) {
        const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
        if (commandPerms.length > 0) {
          const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
          const userRoles = message.member.roles.cache.map(r => r.id);
          pass = commandPerms.some(perm => userPerms[perm]?.some?.(roleId => userRoles.includes(roleId)));
        } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") pass = true;
      }
      if (!pass) {
        if (client.noperm && client.noperm.trim() !== "") {
          const sent = await message.channel.send({ content: client.noperm, allowedMentions: { parse: [] } });
          const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
          if (delayTime > 0) setTimeout(() => sent.delete().catch(() => {}), delayTime * 1000);
        }
        return;
      }

      const gId = message.guild.id;
      const key = `antipic_channels_${gId}`;
      const sub = (args[0] || "").toLowerCase();

      const getSet = () => new Set(client.db.get(key) || []);
      const saveSet = (s) => client.db.set(key, [...new Set([...s])]);

      // Résolution du salon (argument, mention, ID) ; sinon salon courant
      const resolveChannel = () => {
        const token = args[1];
        if (!token) return message.channel;
        const id = token.match?.(/\d{15,20}/)?.[0];
        if (id && message.guild.channels.cache.has(id)) return message.guild.channels.cache.get(id);
        const byName = message.guild.channels.cache.find(ch => ch.name.toLowerCase() === token.toLowerCase());
        return byName || null;
      };

      if (!["add","remove","clear","list"].includes(sub)) {
        return message.channel.send({
          content: "Usage : `+antipicture <add|remove|clear|list> [#salon]`",
          allowedMentions: { parse: [] }
        });
      }

      // ---- LIST ----
      if (sub === "list") {
        const set = getSet();
        const arr = [...set];
        if (!arr.length) {
          return message.channel.send({ content: "ℹ️ Aucun salon AntiPicture n’est configuré.", allowedMentions: { parse: [] } });
        }

        // Construire l’affichage
        const lines = arr
          .map(id => {
            const ch = message.guild.channels.cache.get(id);
            if (!ch) return `• \`${id}\` — *(salon supprimé)*`;
            return `• ${ch}  \`#${ch.name}\`  (\`${ch.id}\`)`;
          })
          .sort((a,b)=>a.localeCompare(b));

        // Split si trop long
        const chunks = [];
        let buf = "";
        for (const line of lines) {
          const add = (buf ? "\n" : "") + line;
          if (buf.length + add.length > 3500) { chunks.push(buf); buf = line; }
          else buf += add;
        }
        if (buf) chunks.push(buf);

        for (let i=0;i<chunks.length;i++) {
          const emb = new EmbedBuilder()
            .setColor(0x2F3136)
            .setTitle(`🖼️ Salons AntiPicture (${i+1}/${chunks.length})`)
            .setDescription(chunks[i])
            .setFooter({ text: `Total: ${arr.length}` });
          await message.channel.send({ embeds: [emb], allowedMentions: { parse: [] } });
        }
        return;
      }

      // ---- CLEAR ----
      if (sub === "clear") {
        client.db.set(key, []);
        return message.channel.send({ content: "♻️ Liste AntiPicture vidée.", allowedMentions: { parse: [] } });
      }

      // ---- ADD / REMOVE ----
      const target = resolveChannel();
      if (!target) {
        return message.channel.send({ content: "❌ Salon introuvable.", allowedMentions: { parse: [] } });
      }

      const allowedTypes = new Set([
        ChannelType.GuildText,
        ChannelType.GuildAnnouncement,
        ChannelType.GuildForum,
        ChannelType.GuildMedia,
        ChannelType.PublicThread,
        ChannelType.PrivateThread,
        ChannelType.AnnouncementThread
      ]);
      if (!allowedTypes.has(target.type)) {
        return message.channel.send({ content: "❌ Ce type de salon n'est pas géré par AntiPicture.", allowedMentions: { parse: [] } });
      }

      const set = getSet();

      if (sub === "add") {
        set.add(target.id);
        saveSet(set);
        return message.channel.send({
          content: `✅ AntiPicture **activé** pour ${target}.`,
          allowedMentions: { parse: [] }
        });
      }

      if (sub === "remove") {
        set.delete(target.id);
        saveSet(set);
        return message.channel.send({
          content: `✅ AntiPicture **désactivé** pour ${target}.`,
          allowedMentions: { parse: [] }
        });
      }

    } catch (e) {
      console.error(e);
      message.channel.send({ content: "❌ Erreur avec la commande antipicture.", allowedMentions: { parse: [] } });
    }
  }
};
