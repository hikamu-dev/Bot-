const Astroia = require("../../structures/client/index");
const Discord = require("discord.js");

module.exports = {
  name: "lock",
  usage: "lock [@user/role] [#channel]",
  use: "[@user/role] [#channel]",
  description: "Empêche les membres de parler dans le salon",
  example: "➜ lock @phebo #general\n➜ lock #general\n➜ lock @Admin",
  run: async (client, message, args, commandName) => {
    const whitelistDB = client.db.get(`wl.${message.guild.id}`) || [];

    const isBypass = (
      client.staff.includes(message.author.id) ||
      client.config.buyers.includes(message.author.id) ||
      client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || // ✅ corrigé
      client.db.get(`owner_global_${message.author.id}`) === true || 
      whitelistDB.includes(message.author.id)
    );

    if (!isBypass) {
      const limitData = client.db.get(`command_limit_${message.guild.id}_lock`);
      if (limitData) {
        const key = `limit_used_lock_${message.guild.id}_${message.author.id}`;
        const userData = client.db.get(key) || { count: 0, timestamp: 0 };
        const now = Date.now();

        if (userData.timestamp + limitData.timeLimit > now) {
          if (userData.count >= limitData.maxUse) {
            const remaining = Math.ceil((userData.timestamp + limitData.timeLimit - now) / 1000);
            return message.reply(`Tu as atteint la limite d'utilisation de la commande \`lock\`. Réessaie dans ${remaining}s.`);
          } else {
            userData.count += 1;
          }
        } else {
          userData.count = 1;
          userData.timestamp = now;
        }

        client.db.set(key, userData);
      }
    }

    let pass = false;
    if (
      client.staff.includes(message.author.id) ||
      client.config.buyers.includes(message.author.id) ||
      client.db.get(`owner_global_${message.author.id}`) === true ||
      client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true // ✅ corrigé
    ) {
      pass = true;
    } else {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        pass = commandPerms.some(perm => userPerms[perm]?.some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        pass = true;
      }
    }

    if (!pass) {
      if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
          setTimeout(() => {
            sentMessage.delete().catch(() => {});
          }, delayTime * 1000);
        }
      }
      return;
    }

    // Détection de la cible (utilisateur ou rôle)
    let target = message.mentions.members.first() || message.mentions.roles.first() || message.guild.roles.everyone;
    // Détection du salon
    let channel = message.mentions.channels.first() || message.channel;

    try {
      const currentPermissions = channel.permissionsFor(target);
      if (!currentPermissions.has('SendMessages') && currentPermissions.has('SendMessages') !== null) {
        return message.channel.send("Le salon est déjà vérouillé !");
      }

      await channel.permissionOverwrites.edit(target, { SendMessages: false });
      await message.channel.send({
        content: `${await client.lang("lock.lock")} ${channel}`,
      });

      const Embed = new Discord.EmbedBuilder()
        .setColor(client.color)
        .setDescription(`${message.author} ${await client.lang(`lock.ll`)} ${channel}`);

      message.guild.channels.cache.get(client.db.get(`modlogs_${message.guild.id}`))?.send({ embeds: [Embed] });
    } catch (err) {
      await message.channel.send({ content: await client.lang("lock.erreur") });
    }
  },
};
