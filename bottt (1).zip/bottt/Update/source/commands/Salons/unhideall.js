// commands/admin/unhideall.js
const { PermissionsBitField, ChannelType } = require("discord.js");

module.exports = {
  name: "unhideall",
  description: "Rend visibles toutes les catégories et salons. Sans argument: everyone. Avec un rôle: ne rouvre que ce rôle. Option 'force' pour resynchroniser.",
  usages: "unhideall [@role|roleId|nom] [force]",
  example: "unhideall\nunhideall @Membres\nunhideall 123456789012345678 force",
  /**
   * @param {import('discord.js').Client} client
   * @param {import('discord.js').Message} message
   */
  run: async (client, message, args, commandName = "unhideall") => {
    try {
      if (!message.guild) return;

      // ----- Permissions d'accès (même logique que tes autres cmds) -----
      const whitelistDB = client.db.get(`wl.${message.guild.id}`) || [];
      const isBypassHard =
        client.staff?.includes?.(message.author.id) ||
        client.config?.buyers?.includes?.(message.author.id) ||
        client.db.get(`owner_${message.author.id}`) === true ||
        client.db.get(`owner_global_${message.author.id}`) === true ||
        whitelistDB.includes(message.author.id) ||
        message.guild.ownerId === message.author.id;

      let pass = isBypassHard;
      if (!pass) {
        const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
        if (commandPerms.length > 0) {
          const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
          const userRoles = message.member.roles.cache.map(r => r.id);
          pass = commandPerms.some(perm => userPerms[perm]?.some?.(roleId => userRoles.includes(roleId)));
        } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
          pass = true;
        }
      }
      if (!pass) {
        if (client.noperm && client.noperm.trim() !== "") {
          const sent = await message.channel.send({ content: client.noperm, allowedMentions: { parse: [] } });
          const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
          if (delayTime > 0) setTimeout(() => sent.delete().catch(() => {}), delayTime * 1000);
        }
        return;
      }

      // ----- Vérif perms du BOT -----
      const me = message.guild.members.me;
      if (!me.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
        return message.channel.send({
          content: "❌ Je n’ai pas la permission **Gérer les salons**.",
          allowedMentions: { parse: [] }
        });
      }

      // ----- Parse args: rôle ciblé + option force -----
      const useForce = args.some(a => String(a).toLowerCase() === "force");

      const roleFromMention = message.mentions.roles.first();
      const idFromArgs = args.find(a => /^\d{15,20}$/.test(a));
      let targetRole =
        roleFromMention ??
        (idFromArgs ? message.guild.roles.cache.get(idFromArgs) : null);

      if (!targetRole && args.length && !useForce) {
        const q = args.join(" ").toLowerCase();
        if (q && !/<@&\d+>/.test(q)) {
          targetRole = message.guild.roles.cache.find(r => r.name.toLowerCase() === q) ??
                       message.guild.roles.cache.find(r => r.name.toLowerCase().includes(q));
        }
      }

      // Par défaut: @everyone
      if (!targetRole) targetRole = message.guild.roles.everyone;

      const everyoneId = message.guild.roles.everyone.id;
      const targetingEveryone = targetRole.id === everyoneId;

      const notice = await message.channel.send({
        content: `🔓 Préparation… (cible: ${targetingEveryone ? "@everyone" : `@${targetRole.name}`})`,
        allowedMentions: { parse: [] }
      });

      // ----- Fetch complet des salons -----
      const fetched = await message.guild.channels.fetch().catch(() => null);
      const allChannels = (fetched ?? message.guild.channels.cache);

      const TYPES = new Set([
        ChannelType.GuildCategory,
        ChannelType.GuildText,
        ChannelType.GuildVoice,
        ChannelType.GuildAnnouncement,
        ChannelType.GuildStageVoice,
        ChannelType.GuildForum,
        ChannelType.GuildMedia
      ]);

      const categories = [];
      const others = [];
      for (const ch of allChannels.values()) {
        if (!TYPES.has(ch.type)) continue;
        if (ch.type === ChannelType.GuildCategory) categories.push(ch); else others.push(ch);
      }

      const total = categories.length + others.length;
      await notice.edit({
        content: `🔓 Réouverture en cours… (${total} éléments) — cible: ${targetingEveryone ? "@everyone" : `@${targetRole.name}`}`,
        allowedMentions: { parse: [] }
      });

      let ok = 0, fail = 0;
      const skipped = []; // {name,id,why}
      const reason = `unhideall par ${message.author.tag} (${message.author.id})${useForce ? " [force]" : ""}`;

      // Helper: applique ALLOW ViewChannel pour le rôle ciblé (et optionnellement resync avant)
      const applyUnhide = async (channelLike) => {
        try {
          if (useForce && channelLike.parentId && typeof channelLike.lockPermissions === "function") {
            try { await channelLike.lockPermissions(); } catch {}
          }

          // ALLOW explicite pour le rôle ciblé
          await channelLike.permissionOverwrites.edit(targetRole.id, { ViewChannel: true }, { reason });
          ok++;
        } catch (e) {
          fail++;
          skipped.push({ name: channelLike.name ?? "(sans nom)", id: channelLike.id, why: e?.message ?? "permission/refus" });
        }
      };

      // 1) Catégories d’abord (pour l’héritage), puis salons
      for (const cat of categories) await applyUnhide(cat);
      for (const ch of others) await applyUnhide(ch);

      // Résumé
      const took = ((Date.now() - message.createdTimestamp) / 1000).toFixed(1);
      const hints = [];
      if (targetRole.permissions.has(PermissionsBitField.Flags.Administrator)) {
        hints.push(`ℹ️ Le rôle **@${targetRole.name}** possède **Administrateur** : il verrait déjà tout, l’ALLOW était superflu.`);
      }
      if (skipped.length) {
        const preview = skipped.slice(0, 10).map(s => `• ${s.name} (${s.id}) — ${s.why}`).join("\n");
        hints.push(`ℹ️ Salons non modifiés (${skipped.length}) — top 10:\n${preview}`);
        hints.push(`Vérifie que le bot a **Gérer les salons** et que son rôle est **au-dessus** des rôles à modifier.`);
      }

      await notice.edit({
        content: `✅ **UnhideAll terminé** — cible: ${targetingEveryone ? "@everyone" : `@${targetRole.name}`} — modifiés: ${ok}, échecs: ${fail}, temps: ${took}s${hints.length ? `\n\n${hints.join("\n")}` : ""}`,
        allowedMentions: { parse: [] }
      });

    } catch (e) {
      console.error(e);
      message.channel.send({ content: "❌ Erreur pendant l’unhideall.", allowedMentions: { parse: [] } });
    }
  }
};
