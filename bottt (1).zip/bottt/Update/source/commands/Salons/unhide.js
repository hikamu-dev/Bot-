const { PermissionsBitField } = require('discord.js');

module.exports = {
    name: 'unhide',
    description: 'Rend un salon textuel visible pour un rôle ou un utilisateur spécifié, ou pour @everyone par défaut.',
    use: "[#salon] [@role/@user]",
    usage: "unhide [#salon] [@role/@user]",
    example: "➜ unhide #general @tokyru\n➜ unhide #general @role\n➜ unhide #general",
    /**
     * 
     * @param {Astroia} client 
     * @param {Discord.Message} message
     * @param {string[]} args 
     */
    run: async (client, message, args) => {
        let pass = false;
        const commandName = 'unhide';

        if (client.staff.includes(message.author.id) || 
            client.config.buyers.includes(message.author.id) ||
            client.db.get(`owner_global_${message.author.id}`) === true || 
    client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {             pass = true;
        } else {
          const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
          if (commandPerms.length > 0) {
            const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
            const userRoles = message.member.roles.cache.map(role => role.id);
            pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
          } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
            pass = true;
          }
        }

if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        const channel = message.mentions.channels.first() || message.guild.channels.cache.get(args[0]) || message.channel;

        if (!channel || channel.type !== 0) {
          return message.reply("Merci de spécifier un salon textuel valide.");
        }

        let target = null;
        const mentionedRoles = message.mentions.roles.filter(r => r.id !== channel.id);
        const mentionedUsers = message.mentions.users.filter(u => u.id !== channel.id);

        if (mentionedRoles.size > 0) target = mentionedRoles.first();
        else if (mentionedUsers.size > 0) target = mentionedUsers.first();

        if (!target && args.length > 1) {
          const possibleRole = message.guild.roles.cache.get(args[1]);
          const possibleMember = message.guild.members.cache.get(args[1]);
          if (possibleRole) target = possibleRole;
          else if (possibleMember) target = possibleMember.user;
        }

        const overwriteId = target ? target.id : message.guild.id;

        if (!overwriteId) {
          return message.reply("Impossible de trouver le rôle ou l'utilisateur spécifié.");
        }

        let displayName = '@everyone';
        if (target) {
          if (target.name) {
            displayName = target.name;
          } else if (target.username) {
            displayName = target.username;
          } else if (target.user && target.user.username) {
            displayName = target.user.username;
          }
        }

        if (displayName === '@everyone') {
          displayName = '`Tout le monde`';
        }

        try {
          await channel.permissionOverwrites.edit(overwriteId, {
              ViewChannel: true
          });

          return message.reply(`Le salon <#${channel.id}> est maintenant visible pour ${displayName}.`);
        } catch (error) {
          console.error(error);
          return message.reply("Une erreur s'est produite en essayant de rendre le salon visible.");
        }
    }
};
