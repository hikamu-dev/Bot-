const { EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    name: 'ghostping',
    description: 'Ajoute, supprime ou liste les salons de ghost ping.',
    use: "[#salon]",
    usage: "ghostping <add/remove/list> [#salon]",
    aliases: ['ghostping', 'gp'],
    example: "➜ ghostping add #general\n➜ ghostping remove #general\n➜ ghostping list",
    /**
     * @param {Astroia} client 
     * @param {Discord.Message} message
     * @param {string[]} args 
     */
    run: async (client, message, args) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
        client.db.get(`owner_global_${message.author.id}`) === true || 
client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        const action = args[0];
        const channel = message.mentions.channels.first() || message.guild.channels.cache.get(args[1]);

        if (action === 'list') {
            const ghostpingChannels = client.db.get(`ghostping_${message.guild.id}`) || [];
            if (ghostpingChannels.length === 0) {
                return message.reply("Il n'y a actuellement aucun salon dans la liste des salons de ghost ping.");
            }

            const channelList = ghostpingChannels.map(id => `<#${id}>`).join('\n');
            const embed = new EmbedBuilder()
                .setTitle('Salons de Ghost Ping')
                .setDescription(channelList)
                .setColor(client.color);

            return message.reply({ embeds: [embed] });
        }

        if (action === 'add') {
            if (!channel) {
                return message.reply("Vous devez mentionner un salon.");
            }

            const ghostpingChannels = client.db.get(`ghostping_${message.guild.id}`) || [];
            if (ghostpingChannels.includes(channel.id)) {
                return message.reply("Ce salon est déjà dans la liste des salons de ghost ping.");
            }

            ghostpingChannels.push(channel.id);
            client.db.set(`ghostping_${message.guild.id}`, ghostpingChannels);

            return message.reply(`Le salon ${channel} a été ajouté à la liste des salons de ghost ping.`);
        } else if (action === 'remove') {
            if (!channel) {
                return message.reply("Vous devez mentionner un salon.");
            }

            let ghostpingChannels = client.db.get(`ghostping_${message.guild.id}`) || [];
            if (!ghostpingChannels.includes(channel.id)) {
                return message.reply("Ce salon n'est pas dans la liste des salons de ghost ping.");
            }

            ghostpingChannels = ghostpingChannels.filter(id => id !== channel.id);
            client.db.set(`ghostping_${message.guild.id}`, ghostpingChannels);

            return message.reply(`Le salon ${channel} a été supprimé de la liste des salons de ghost ping.`);
        } else {
            return message.reply("Vous devez spécifier une action valide : `add`, `remove` ou `list`.");
        }
    }
};
