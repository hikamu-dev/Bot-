const Discord = require('discord.js');
const Astroia = require('../../structures/client/index');
const { MessageActionRow, MessageSelectMenu } = require('discord.js');

module.exports = {
    name: "lockall",
    description: "Permet de vérouiller tout les channels du serveur ",

    run: async (client, message, args, commandName) => {
                      const whitelistDB = client.db.get(`wl.${message.guild.id}`) || [];

const isBypass = (
    client.staff.includes(message.author.id) ||
    client.config.buyers.includes(message.author.id) ||
    client.db.get(`owner_${message.author.id}`) === true ||
            client.db.get(`owner_global_${message.author.id}`) === true || 

    whitelistDB.includes(message.author.id)
);

if (!isBypass) {
    const limitData = client.db.get(`command_limit_${message.guild.id}_lockall`);
    if (limitData) {
        const key = `limit_used_lockall_${message.guild.id}_${message.author.id}`;
        const userData = client.db.get(key) || { count: 0, timestamp: 0 };
        const now = Date.now();

        if (userData.timestamp + limitData.timeLimit > now) {
            if (userData.count >= limitData.maxUse) {
                const remaining = Math.ceil((userData.timestamp + limitData.timeLimit - now) / 1000);
                return message.reply(`Tu as atteint la limite d'utilisation de la commande \`lockall\`. Réessaie dans ${remaining}s.`);
            } else {
                userData.count += 1;
            }
        } else {
            userData.count = 1;
            userData.timestamp = now;
        }

        client.db.set(key, userData);
    }
}
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
                client.db.get(`owner_global_${message.author.id}`) === true || 

client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}
        try {
            const channels = message.guild.channels.cache;
            channels.forEach(async (channel) => {
                await channel.permissionOverwrites.edit(message.guild.roles.everyone, {
                    SendMessages: false
                }).catch((error) => {
                    console.error(`Impossible de lock: ${channel.name}:`, error);
                });
            });

            message.channel.send(await client.lang(`lockall.message1`));

            let Embed = new Discord.EmbedBuilder()
                .setColor(client.color)
                .setDescription(`${message.author} ${await client.lang(`lockall.message2`)}`);
            message.guild.channels.cache.get(client.db.get(`modlogs_${message.guild.id}`))?.send({ embeds: [Embed] });
        } catch (error) {
            console.error(error);
            message.channel.send(await client.lang(`lockall.message3`));
        }
    }
}






