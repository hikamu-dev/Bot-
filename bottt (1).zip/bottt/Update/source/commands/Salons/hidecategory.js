// commands/admin/hidecategory.js
const {
  PermissionsBitField,
  ChannelType,
  ActionRowBuilder,
  StringSelectMenuBuilder
} = require("discord.js");

module.exports = {
  name: "hidecategory",
  description: "Cache tous les salons d'une catégorie pour @everyone.",
  usages: "hidecategory [categoryId|nom]",
  example: "hidecategory 123456789012345678",
  /**
   * @param {import('discord.js').Client} client
   * @param {import('discord.js').Message} message
   * @param {string[]} args
   */
  run: async (client, message, args, commandName = "hidecategory") => {
    try {
      if (!message.guild) return;

      // ----- Permissions (ton style) -----
      const whitelistDB = client.db.get(`wl.${message.guild.id}`) || [];
      const isBypassHard =
        client.staff?.includes?.(message.author.id) ||
        client.config?.buyers?.includes?.(message.author.id) ||
        client.db.get(`owner_${message.author.id}`) === true ||
        client.db.get(`owner_global_${message.author.id}`) === true ||
        whitelistDB.includes(message.author.id) ||
        message.guild.ownerId === message.author.id;

      let pass = isBypassHard;
      if (!pass) {
        const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
        if (commandPerms.length > 0) {
          const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
          const userRoles = message.member.roles.cache.map(r => r.id);
          pass = commandPerms.some(perm => userPerms[perm]?.some?.(roleId => userRoles.includes(roleId)));
        } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
          pass = true;
        }
      }
      if (!pass) {
        if (client.noperm && client.noperm.trim() !== "") {
          const sent = await message.channel.send({ content: client.noperm, allowedMentions: { parse: [] } });
          const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
          if (delayTime > 0) setTimeout(() => sent.delete().catch(() => {}), delayTime * 1000);
        }
        return;
      }

      if (!message.guild.members.me.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
        return message.channel.send({
          content: "❌ Je n’ai pas la permission **Gérer les salons**.",
          allowedMentions: { parse: [] }
        });
      }

      // ----- Résolution de la catégorie -----
      const cats = message.guild.channels.cache
        .filter(c => c.type === ChannelType.GuildCategory);

      const resolveCategory = () => {
        const idMatch = args[0]?.match?.(/\d{15,20}/)?.[0];
        if (idMatch && cats.has(idMatch)) return cats.get(idMatch);
        if (args.length) {
          const q = args.join(" ").toLowerCase();
          const exact = cats.find(c => c.name.toLowerCase() === q);
          if (exact) return exact;
          const part = cats.find(c => c.name.toLowerCase().includes(q));
          if (part) return part;
        }
        return null;
      };

      let category = resolveCategory();

      // Si aucune catégorie passée, on ouvre un menu (max 25)
      if (!category) {
        const options = cats.first(25).map(c => ({
          label: c.name.slice(0, 100),
          value: c.id
        }));

        if (!options.length) {
          return message.channel.send({ content: "Aucune catégorie trouvée.", allowedMentions: { parse: [] } });
        }

        const select = new StringSelectMenuBuilder()
          .setCustomId(`hidecat:${message.id}`)
          .setPlaceholder("Choisis une catégorie à cacher")
          .addOptions(options);

        const row = new ActionRowBuilder().addComponents(select);
        const prompt = await message.channel.send({
          content: "Sélectionne une **catégorie** à cacher pour `@everyone` :",
          components: [row],
          allowedMentions: { parse: [] }
        });

        const collector = prompt.createMessageComponentCollector({ time: 60_000 });
        collector.on("collect", async (i) => {
          if (i.user.id !== message.author.id) {
            return i.reply({ content: "Seul l'initiateur peut utiliser ce menu.", ephemeral: true });
          }
          if (i.customId !== `hidecat:${message.id}`) return;
          const pickedId = i.values[0];
          category = cats.get(pickedId);
          if (!category) {
            return i.reply({ content: "Catégorie introuvable.", ephemeral: true });
          }
          await i.deferUpdate();
          collector.stop("picked");
        });
        collector.on("end", async () => {
          try { await prompt.edit({ components: [] }); } catch {}
          if (category) await applyHide(category);
        });
      } else {
        await applyHide(category);
      }

      // ----- Appliquer le hide -----
      async function applyHide(cat) {
        const everyoneId = message.guild.roles.everyone.id;

        // Message de progression
        const children = message.guild.channels.cache
          .filter(ch => ch.parentId === cat.id);

        const total = children.size + 1; // +1 pour la catégorie elle-même
        let ok = 0, fail = 0;
        const started = Date.now();

        const notice = await message.channel.send({
          content: `🔒 Cache **${cat.name}** en cours… (${total} éléments)`,
          allowedMentions: { parse: [] }
        });

        // 1) Cacher la catégorie (force héritage)
        try {
          if (cat.editable) {
            await cat.permissionOverwrites.edit(
              everyoneId,
              { ViewChannel: false },
              { reason: `hidecategory par ${message.author.tag} (${message.author.id})` }
            );
            ok++;
          } else fail++;
        } catch { fail++; }

        // 2) Cacher tous les salons enfants
        for (const ch of children.values()) {
          if (!ch.editable) { fail++; continue; }
          try {
            await ch.permissionOverwrites.edit(
              everyoneId,
              { ViewChannel: false },
              { reason: `hidecategory par ${message.author.tag} (${message.author.id})` }
            );
            ok++;
          } catch { fail++; }
        }

        const took = ((Date.now() - started) / 1000).toFixed(1);
        await notice.edit({
          content: `✅ **Catégorie cachée : ${cat.name}** — modifiés: ${ok}, échecs: ${fail}, temps: ${took}s`,
          allowedMentions: { parse: [] }
        });
      }

    } catch (e) {
      console.error(e);
      message.channel.send({ content: "❌ Erreur pendant le hidecategory.", allowedMentions: { parse: [] } });
    }
  }
};
