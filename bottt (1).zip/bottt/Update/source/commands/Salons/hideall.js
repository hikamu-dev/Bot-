// commands/admin/hideall.js
const { PermissionsBitField, ChannelType } = require("discord.js");

module.exports = {
  name: "hideall",
  description: "Cache toutes les catégories et salons. Sans argument: everyone. Avec un rôle: ne cache que ce rôle. Option 'force' pour resynchroniser.",
  usages: "hideall [@role|roleId] [force]",
  example: "hideall\nhideall @Membres\nhideall 123456789012345678 force",
  /**
   * @param {import('discord.js').Client} client
   * @param {import('discord.js').Message} message
   */
  run: async (client, message, args, commandName = "hideall") => {
    try {
      if (!message.guild) return;

      // ----- Permissions d'accès (ton style) -----
      const whitelistDB = client.db.get(`wl.${message.guild.id}`) || [];
      const isBypassHard =
        client.staff?.includes?.(message.author.id) ||
        client.config?.buyers?.includes?.(message.author.id) ||
        client.db.get(`owner_${message.author.id}`) === true ||
        client.db.get(`owner_global_${message.author.id}`) === true ||
        whitelistDB.includes(message.author.id) ||
        message.guild.ownerId === message.author.id;

      let pass = isBypassHard;
      if (!pass) {
        const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
        if (commandPerms.length > 0) {
          const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
          const userRoles = message.member.roles.cache.map(r => r.id);
          pass = commandPerms.some(perm => userPerms[perm]?.some?.(roleId => userRoles.includes(roleId)));
        } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
          pass = true;
        }
      }
      if (!pass) {
        if (client.noperm && client.noperm.trim() !== "") {
          const sent = await message.channel.send({ content: client.noperm, allowedMentions: { parse: [] } });
          const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
          if (delayTime > 0) setTimeout(() => sent.delete().catch(() => {}), delayTime * 1000);
        }
        return;
      }

      const me = message.guild.members.me;
      if (!me.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
        return message.channel.send({
          content: "❌ Je n’ai pas la permission **Gérer les salons**.",
          allowedMentions: { parse: [] }
        });
      }

      // ----- Parse args: rôle ciblé + option force -----
      const useForce = args.some(a => String(a).toLowerCase() === "force");

      // Essaye de récupérer un rôle mentionné / id / nom
      const roleFromMention = message.mentions.roles.first();
      const idFromArgs = args.find(a => /^\d{15,20}$/.test(a));
      let targetRole =
        roleFromMention ??
        (idFromArgs ? message.guild.roles.cache.get(idFromArgs) : null);

      if (!targetRole && args.length && !useForce) {
        const q = args.join(" ").toLowerCase();
        if (q && !/<@&\d+>/.test(q)) {
          targetRole = message.guild.roles.cache.find(r => r.name.toLowerCase() === q) ??
                       message.guild.roles.cache.find(r => r.name.toLowerCase().includes(q));
        }
      }

      // Par défaut: @everyone
      if (!targetRole) targetRole = message.guild.roles.everyone;

      const everyoneRole = message.guild.roles.everyone;
      const everyoneId = everyoneRole.id;
      const botRoleIds = new Set(me.roles.cache.map(r => r.id));
      const reason = `hideall par ${message.author.tag} (${message.author.id})${useForce ? " [force]" : ""}`;

      const targetingEveryone = targetRole.id === everyoneId;

      const notice = await message.channel.send({
        content: `🔒 Préparation… (cible: ${targetingEveryone ? "@everyone" : `@${targetRole.name}`})`,
        allowedMentions: { parse: [] }
      });

      // Fetch complet
      const fetched = await message.guild.channels.fetch().catch(() => null);
      const allChannels = (fetched ?? message.guild.channels.cache);

      // Types ciblés
      const TYPES = new Set([
        ChannelType.GuildCategory,
        ChannelType.GuildText,
        ChannelType.GuildVoice,
        ChannelType.GuildAnnouncement,
        ChannelType.GuildStageVoice,
        ChannelType.GuildForum,
        ChannelType.GuildMedia
      ]);

      const categories = [];
      const others = [];
      for (const ch of allChannels.values()) {
        if (!TYPES.has(ch.type)) continue;
        if (ch.type === ChannelType.GuildCategory) categories.push(ch); else others.push(ch);
      }

      const total = categories.length + others.length;
      await notice.edit({ content: `🔒 Cache en cours… (${total} éléments) — cible: ${targetingEveryone ? "@everyone" : `@${targetRole.name}`}` });

      let ok = 0, fail = 0;
      const skipped = []; // {name,id,why}

      // Helper: applique deny pour targetRole.
      // Si on cible @everyone, on neutralise aussi les rôles qui avaient un allow ViewChannel.
      const applyHide = async (channelLike) => {
        try {
          // Option force: resync avec la catégorie parente pour les salons (pas pour la catégorie elle-même)
          if (useForce && channelLike.parentId && typeof channelLike.lockPermissions === "function") {
            try { await channelLike.lockPermissions(); } catch {}
          }

          // a) Deny pour le rôle ciblé
          await channelLike.permissionOverwrites.edit(targetRole.id, { ViewChannel: false }, { reason });

          // b) Si on cible @everyone, neutraliser les rôles qui autorisaient ViewChannel (sauf rôles du bot)
          if (targetingEveryone) {
            for (const [, ow] of channelLike.permissionOverwrites.cache) {
              if (ow.type !== 0) continue; // Role
              const roleId = ow.id;
              if (roleId === everyoneId) continue;
              if (botRoleIds.has(roleId)) continue;
              const allows = ow.allow.bitfield;
              const hasAllowView = (allows & PermissionsBitField.Flags.ViewChannel) === PermissionsBitField.Flags.ViewChannel;
              if (hasAllowView) {
                await channelLike.permissionOverwrites.edit(roleId, { ViewChannel: false }, { reason });
              }
            }
          }

          ok++;
        } catch (e) {
          fail++;
          skipped.push({ name: channelLike.name ?? "(sans nom)", id: channelLike.id, why: e?.message ?? "permission/refus" });
        }
      };

      // 0) Si on cible @everyone et que le bot a Gérer les rôles, tenter d’enlever la permission globale ViewChannel d’@everyone (non bloquant)
      if (targetingEveryone) {
        try {
          if (me.permissions.has(PermissionsBitField.Flags.ManageRoles)) {
            const newPerms = everyoneRole.permissions.remove(PermissionsBitField.Flags.ViewChannel);
            if (newPerms.bitfield !== everyoneRole.permissions.bitfield) {
              await everyoneRole.setPermissions(newPerms, reason);
            }
          }
        } catch {}
      }

      // 1) Catégories d’abord
      for (const cat of categories) {
        await applyHide(cat);
      }

      // 2) Puis tous les salons
      for (const ch of others) {
        await applyHide(ch);
      }

      const took = ((Date.now() - message.createdTimestamp) / 1000).toFixed(1);

      // Avertissements utiles
      const hints = [];
      if (targetRole.permissions.has(PermissionsBitField.Flags.Administrator)) {
        hints.push(`⚠️ Le rôle **@${targetRole.name}** possède **Administrateur** → il **bypass** les denies. Retire Administrateur pour que le hide soit effectif.`);
      }
      if (skipped.length) {
        const preview = skipped.slice(0, 10).map(s => `• ${s.name} (${s.id}) — ${s.why}`).join("\n");
        hints.push(`ℹ️ Salons non modifiés (${skipped.length}) — top 10:\n${preview}`);
        hints.push(`Vérifie que le bot a **Gérer les salons** et que son rôle est **au-dessus** des rôles à modifier.`);
      }

      await notice.edit({
        content: `✅ **HideAll terminé** — cible: ${targetingEveryone ? "@everyone" : `@${targetRole.name}`} — modifiés: ${ok}, échecs: ${fail}${took ? `, temps: ${took}s` : ""}${hints.length ? `\n\n${hints.join("\n")}` : ""}`,
        allowedMentions: { parse: [] }
      });

    } catch (e) {
      console.error(e);
      message.channel.send({ content: "❌ Erreur pendant le hideall.", allowedMentions: { parse: [] } });
    }
  }
};
