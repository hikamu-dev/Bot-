const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags } = require('discord.js');
const { example } = require('./addinvite');

module.exports = {
    name: 'invite',
    aliase: 'invites',
    description: 'Affiche vos statistiques d\'invitations sur le serveur.',
    use: "<@user>",
    usage: "<@user>",
    example: "➜ invite @tokyru\n➜ invite 123456789012345678",
    run: async (client, message, args, commandName) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
        client.db.get(`owner_global_${message.author.id}`) === true || 
client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}
        const invite = message.mentions.users.first() || await client.users.fetch(args[0]).catch(() => null) || message.author;

        if (!invite || !invite.id) {
            const errorEmbed = new EmbedBuilder()
                .setColor(client.color)
                .setTitle('❌ Erreur')
                .setDescription('Veuillez mentionner un utilisateur valide ou fournir un ID d\'utilisateur correct.')
                .setFooter(client.footer)
            return message.channel.send({ embeds: [errorEmbed] });
        }

        const invitesData = await client.db.get(`invites_${invite.id}_${message.guild.id}`);

        if (!invitesData) {
            const noInvitesEmbed = new EmbedBuilder()
                .setColor(client.color)
                .setTitle('📬 Statistiques d\'Invitations')
                .setDescription(`<@${invite.id}> n'a encore aucune invitation sur ce serveur. Commence à inviter pour grimper dans le classement !`)
                .setFooter(client.footer)
            return message.channel.send({ embeds: [noInvitesEmbed] });
        }

        const embed = new EmbedBuilder()
            .setColor(client.color)
            .setTitle(`📬 Invitations de ${invite.tag}`)
            .setThumbnail(invite.displayAvatarURL({ dynamic: true, size: 256 }))
            .setDescription(
                `<@${invite.id}>*, as actuellement un total de \`${(invitesData.total + invitesData.bonus).toLocaleString()}\` invitations !*\n\n` +
                `**✅ Présents :** \`${invitesData.valid.toLocaleString()}\`\n` +
                `**❌ Partis :** \`${invitesData.left.toLocaleString()}\`\n` +
                `**⭐ Bonus :** \`${invitesData.bonus.toLocaleString()}\``
            )
            .setFooter(client.footer)

        // Créer le bouton pour voir les invités
        const viewInvitedButton = new ButtonBuilder()
            .setCustomId(`view_invited_${invite.id}_${message.guild.id}`)
            .setLabel('Voir les invités')
            .setEmoji('🔎')
            .setStyle(ButtonStyle.Secondary);

        const row = new ActionRowBuilder()
            .addComponents(viewInvitedButton);

        const sentMessage = await message.channel.send({ embeds: [embed], components: [row] });

        // Créer un collector pour le bouton
        const collector = sentMessage.createMessageComponentCollector({ 
            time: 300000 // 5 minutes
        });

        collector.on('collect', async (interaction) => {
            if (interaction.customId === `view_invited_${invite.id}_${message.guild.id}`) {
                // Vérifier si l'utilisateur qui clique est autorisé
                let canView = false;
                
                if (client.staff.includes(interaction.user.id) || 
                    client.config.buyers.includes(interaction.user.id) || 
                    client.db.get(`owner_${interaction.user.id}`) === true ||
                    interaction.user.id === invite.id) {
                    canView = true;
                } else {
                    const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
                    if (commandPerms.length > 0) {
                        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                        const userRoles = interaction.member.roles.cache.map(role => role.id);
                        canView = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
                    } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                        canView = true;
                    }
                }

                if (!canView) {
                    return interaction.reply({ 
                        content: 'Vous n\'avez pas la permission de voir cette information.', 
                        flags: MessageFlags.Ephemeral 
                    });
                }

                // Récupérer la liste des invités
                const invitedUsers = await client.db.get(`invited_by_${invite.id}_${message.guild.id}`) || [];
                
                if (invitedUsers.length === 0) {
                    const noInvitedEmbed = new EmbedBuilder()
                        .setColor(client.color)
                        .setTitle('👥 Utilisateurs invités')
                        .setDescription(`<@${invite.id}> n'a invité aucun utilisateur sur ce serveur.`)
                        .setFooter(client.footer);
                    
                    return interaction.reply({ embeds: [noInvitedEmbed], flags: MessageFlags.Ephemeral });
                }

                // Créer l'embed avec la liste des invités
                let invitedList = '';
                const maxUsersPerPage = 10;
                const totalUsers = invitedUsers.length;
                
                // Prendre les 10 premiers utilisateurs
                const usersToShow = invitedUsers.slice(0, maxUsersPerPage);
                
                for (let i = 0; i < usersToShow.length; i++) {
                    const userId = usersToShow[i];
                    const user = await client.users.fetch(userId).catch(() => null);
                    const member = message.guild.members.cache.get(userId);
                    
                    if (user) {
                        const status = member ? '✅' : '❌';
                        invitedList += `<@${userId}> (\`${user.id}\`)\n`;
                    }
                }

                const invitedEmbed = new EmbedBuilder()
                    .setColor(client.color)
                    .setTitle(`👥 Utilisateurs invités par ${invite.tag}`)
                    .setDescription(invitedList || 'Aucun utilisateur trouvé.')
                    .setFooter({ 
                        text: `${client.footer.text} • Page 1/${Math.ceil(totalUsers / maxUsersPerPage)} • Total: ${totalUsers}`,
                        iconURL: client.footer.iconURL
                    });

                await interaction.reply({ embeds: [invitedEmbed], flags: MessageFlags.Ephemeral });
            }
        });

        collector.on('end', () => {
            // Désactiver le bouton après expiration
            viewInvitedButton.setDisabled(true);
            sentMessage.edit({ embeds: [embed], components: [row] }).catch(() => {});
        });
    }
};