const { ActionRowBuilder, ButtonBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, EmbedBuilder, ButtonStyle, ComponentType } = require('discord.js');
const { example } = require('./delform');

module.exports = {
    name: "sendforum",
    description: "Envoie le formulaire configuré.",
    use: "<formId>",
    usages: "sendforum <formId>",
    example: "➜ sendforum 123456789012345678",

    run: async (client, message, args) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) || 
        client.db.get(`owner_global_${message.author.id}`) === true || 
        client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true) {          pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}
        if (!args[0]) {
            return message.channel.send("Veuillez fournir l'ID du formulaire que vous souhaitez envoyer.");
        }

        const guildId = message.guild.id;
        const forms = client.db.get(`forms_${guildId}`) || [];
        const form = forms.find(f => f.id === args[0]);

        if (!form) {
            return message.channel.send("Formulaire introuvable.");
        }

        const postChannel = message.guild.channels.cache.get(form.postChannelId);
        const logChannel = message.guild.channels.cache.get(form.logChannelId);

        if (!postChannel) {
            return message.channel.send("Le salon pour le formulaire est introuvable.");
        }

        if (!logChannel) {
            return message.channel.send("Le salon de logs est introuvable.");
        }

        // Créer le bouton avec le texte configuré
        const button = new ButtonBuilder()
            .setCustomId('open_form')
            .setLabel(form.buttonText)
            .setStyle(ButtonStyle.Primary);

        const row = new ActionRowBuilder().addComponents(button);

        // Créer l'embed avec le titre et le message configurés
        const embed = new EmbedBuilder()
            .setColor(client.color)
            .setTitle(form.title)
            .setDescription(form.formMessage)
            .setTimestamp();

        const sentMessage = await postChannel.send({ embeds: [embed], components: [row] });
        message.channel.send("Le formulaire a été envoyé avec succès !");

        // Gestion des interactions du bouton avec un collector
        const filter = i => i.customId === 'open_form';
        const collector = sentMessage.createMessageComponentCollector({ filter, componentType: ComponentType.Button });

        collector.on('collect', async i => {
            try {
                console.log("Bouton cliqué, affichage du modal.");

                // Créer le modal
                const modal = new ModalBuilder()
                    .setCustomId('response_modal')
                    .setTitle('Répondez aux questions');

                // Ajout des questions à partir des options configurées
                form.options.forEach((option, index) => {
                    const textInput = new TextInputBuilder()
                        .setCustomId(`response_input_${index}`)
                        .setLabel(`Question: ${option}`)
                        .setStyle(TextInputStyle.Short)
                        .setPlaceholder('Entrez votre réponse ici')
                        .setRequired(true);

                    const actionRow = new ActionRowBuilder().addComponents(textInput);
                    modal.addComponents(actionRow);
                });

                // Afficher le modal
                await i.showModal(modal);

                // Attendre la soumission du modal avec awaitModalSubmit
                const modalInteraction = await i.awaitModalSubmit({
                    filter: (modalSubmit) => modalSubmit.customId === 'response_modal' && modalSubmit.user.id === i.user.id,
                    time: 60000 // Temps d'attente pour la soumission (60 secondes)
                }).catch(error => {
                    console.error("Erreur lors de l'attente de la soumission du modal :", error);
                    i.followUp({ content: "Temps écoulé pour répondre au formulaire.", ephemeral: true });
                    return null;
                });

                if (modalInteraction) {
                    try {
                        console.log('Modal soumis.');

                        const responses = [];
                        form.options.forEach((option, index) => {
                            const response = modalInteraction.fields.getTextInputValue(`response_input_${index}`);
                            responses.push(`**${option}**: ${response}`);
                        });

                        // Mentionner l'utilisateur dans les logs
                        const userMention = modalInteraction.user.toString();

                        // Envoie les réponses dans le salon de logs
                        const logChannel = modalInteraction.guild.channels.cache.get(form.logChannelId);
                        if (logChannel) {
                            const logEmbed = new EmbedBuilder()
                                .setColor(client.color)
                                .setTitle(`Réponses au Formulaire: ${form.title}`)
                                .setDescription(`Réponses soumises par ${userMention}:\n${responses.join('\n')}`)
                                .setTimestamp();

                            await logChannel.send({ embeds: [logEmbed] });
                            console.log('Réponses envoyées au salon de logs.');
                        } else {
                            console.error("Salon de logs introuvable.");
                        }

                        // Répondre à l'utilisateur
                        await modalInteraction.reply({ content: "Vos réponses ont été envoyées avec succès !", ephemeral: true });
                    } catch (error) {
                        console.error("Erreur lors du traitement de la soumission du modal :", error);
                        await modalInteraction.followUp({ content: "Une erreur s'est produite lors du traitement de votre réponse.", ephemeral: true });
                    }
                }
            } catch (error) {
                console.error("Erreur lors de l'affichage ou du traitement du modal :", error);
                await i.followUp({ content: "Une erreur s'est produite lors de l'affichage du formulaire.", ephemeral: true });
            }
        });

        collector.on('end', (collected, reason) => {
            if (reason === 'time') {
                console.log("Collector de bouton terminé (timeout).");
                // Optionally disable the button here if needed
                const disabledButton = new ButtonBuilder()
                    .setCustomId('open_form')
                    .setLabel(form.buttonText)
                    .setStyle(ButtonStyle.Primary)
                    .setDisabled(true);

                const disabledRow = new ActionRowBuilder().addComponents(disabledButton);
                sentMessage.edit({ embeds: [embed], components: [disabledRow] });
            }
        });
    }
};