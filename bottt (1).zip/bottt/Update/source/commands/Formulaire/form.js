const { ActionRowBuilder, ButtonBuilder, StringSelectMenuBuilder, EmbedBuilder, ButtonStyle } = require('discord.js');
const { v4: uuidv4 } = require('uuid');

const COLOR_MAPPING = {
    'PRIMARY': ButtonStyle.Primary,
    'SECONDARY': ButtonStyle.Secondary,
    'SUCCESS': ButtonStyle.Success,
    'DANGER': ButtonStyle.Danger,
    'LINK': ButtonStyle.Link,
    '1': ButtonStyle.Primary,
    '2': ButtonStyle.Secondary,
    '3': ButtonStyle.Success,
    '4': ButtonStyle.Danger,
    '5': ButtonStyle.Link
};
const getButtonStyleName = (style) => {
    const styles = {
        [ButtonStyle.Primary]: 'PRIMARY',
        [ButtonStyle.Secondary]: 'SECONDARY',
        [ButtonStyle.Success]: 'SUCCESS',
        [ButtonStyle.Danger]: 'DANGER',
        [ButtonStyle.Link]: 'LINK'
    };
    return styles[style] || 'UNKNOWN';
};
module.exports = {
    name: "formulaire",
    description: "Crée et configure un formulaire interactif",
    usages: "formulaire",
    
    run: async (client, message, args) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) || 
        client.db.get(`owner_global_${message.author.id}`) === true || 
        client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true) {          pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${module.exports.name}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        const newForm = {
            id: uuidv4(),
            title: 'Formulaire sans titre',
            postChannelId: '',
            formMessage: 'Cliquez sur le bouton pour commencer',
            logChannelId: '',
            buttonText: 'Commencer',
            buttonColor: ButtonStyle.Primary,
            options: []
        };

        const generateConfigEmbed = (form) => {
            return new EmbedBuilder()
                .setTitle('Configuration du Formulaire')
                .setColor(client.color)
                .addFields(
                    { name: '🖊️ Titre', value: form.title || 'Non défini', inline: true },
                    { name: '📝 Message', value: form.formMessage.length > 50 ? form.formMessage.substring(0, 50) + '...' : form.formMessage || 'Non défini', inline: true },
                    { name: '📊 Options', value: form.options.length > 0 ? form.options.join(', ') : 'Aucune option', inline: false },
                    { name: '📌 Salon du formulaire', value: form.postChannelId ? `<#${form.postChannelId}>` : 'Non défini', inline: true },
                    { name: '📋 Salon des logs', value: form.logChannelId ? `<#${form.logChannelId}>` : 'Non défini', inline: true },
                    { name: '🔘 Texte du bouton', value: form.buttonText || 'Non défini', inline: true },
                    { name: '🎨 Couleur du bouton', value: getButtonStyleName(form.buttonColor) || 'Non défini', inline: true }
                )
                .setFooter(client.footer);
        };

        const configMenu = new StringSelectMenuBuilder()
            .setCustomId('form_config')
            .setPlaceholder('Sélectionnez une option de configuration')
            .addOptions([
                { label: 'Titre du formulaire', value: 'set_title' },
                { label: 'Message du formulaire', value: 'set_message' },
                { label: 'Ajouter une option', value: 'add_option' },
                { label: 'Supprimer une option', value: 'remove_option' },
                { label: 'Salon du formulaire', value: 'set_post_channel' },
                { label: 'Salon des logs', value: 'set_log_channel' },
                { label: 'Texte du bouton', value: 'set_button_text' },
                { label: 'Couleur du bouton', value: 'set_button_color' },
                { label: 'Terminer et publier', value: 'finish' }
            ]);

        const actionRow = new ActionRowBuilder().addComponents(configMenu);

        const configMessage = await message.channel.send({
            embeds: [generateConfigEmbed(newForm)],
            components: [actionRow]
        });

        const cleanUpMessages = async (interactionMsg, userResponse) => {
            try {
                if (interactionMsg && !interactionMsg.ephemeral) await interactionMsg.delete();
                if (userResponse) await userResponse.delete();
            } catch (error) {
                console.error("Erreur lors du nettoyage des messages:", error);
            }
        };

        const collector = configMessage.createMessageComponentCollector({ time: 600000 });

        collector.on('collect', async interaction => {
            if (interaction.user.id !== message.author.id) {
                return interaction.reply({ content: "Vous n'êtes pas autorisé à configurer ce formulaire.", ephemeral: true });
            }

            await interaction.deferUpdate();

            const selectedOption = interaction.values[0];
            const filter = m => m.author.id === message.author.id;

            switch (selectedOption) {
                case 'set_title': {
                    const instruction = await message.channel.send('Entrez le nouveau titre du formulaire:');
                    const responses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                    newForm.title = responses.first().content;
                    await cleanUpMessages(instruction, responses.first());
                    break;
                }

                case 'set_message': {
                    const instruction = await message.channel.send('Entrez le nouveau message du formulaire:');
                    const responses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                    newForm.formMessage = responses.first().content;
                    await cleanUpMessages(instruction, responses.first());
                    break;
                }

                case 'add_option': {
                    const instruction = await message.channel.send('Entrez la nouvelle option à ajouter:');
                    const responses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                    newForm.options.push(responses.first().content);
                    await cleanUpMessages(instruction, responses.first());
                    break;
                }

                case 'remove_option': {
                    if (newForm.options.length === 0) {
                        await interaction.followUp({ content: 'Aucune option à supprimer.', ephemeral: true });
                        break;
                    }
                    
                    const instruction = await message.channel.send(
                        `Quelle option souhaitez-vous supprimer ? (1-${newForm.options.length})\n${newForm.options.map((opt, i) => `${i + 1}. ${opt}`).join('\n')}`
                    );
                    const responses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                    const indexToRemove = parseInt(responses.first().content) - 1;
                    
                    if (indexToRemove >= 0 && indexToRemove < newForm.options.length) {
                        newForm.options.splice(indexToRemove, 1);
                    }
                    await cleanUpMessages(instruction, responses.first());
                    break;
                }

                case 'set_post_channel': {
                    const instruction = await message.channel.send('Mentionnez ou entrez l\'ID du salon où poster le formulaire:');
                    const responses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                    newForm.postChannelId = responses.first().content.replace(/[<#>]/g, '');
                    await cleanUpMessages(instruction, responses.first());
                    break;
                }

                case 'set_log_channel': {
                    const instruction = await message.channel.send('Mentionnez ou entrez l\'ID du salon pour les logs:');
                    const responses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                    newForm.logChannelId = responses.first().content.replace(/[<#>]/g, '');
                    await cleanUpMessages(instruction, responses.first());
                    break;
                }

                case 'set_button_text': {
                    const instruction = await message.channel.send('Entrez le nouveau texte du bouton:');
                    const responses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                    newForm.buttonText = responses.first().content;
                    await cleanUpMessages(instruction, responses.first());
                    break;
                }

                case 'set_button_color': {
                    const instruction = await message.channel.send('Choisissez la couleur du bouton (PRIMARY=1, SECONDARY=2, SUCCESS=3, DANGER=4, LINK=5):');
                    const responses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                    const colorInput = responses.first().content.toUpperCase();
                    
                    if (COLOR_MAPPING[colorInput]) {
                        newForm.buttonColor = COLOR_MAPPING[colorInput];
                    } else {
                        await message.channel.send('Couleur invalide. Utilisation de PRIMARY par défaut.').then(msg => setTimeout(() => msg.delete(), 3000));
                        newForm.buttonColor = ButtonStyle.Primary;
                    }
                    
                    await cleanUpMessages(instruction, responses.first());
                    break;
                }

                case 'finish':
                    collector.stop();
                    break;
            }

            await configMessage.edit({
                embeds: [generateConfigEmbed(newForm)],
                components: [actionRow]
            });
        });

        collector.on('end', async () => {
            const existingForms = client.db.get(`forms_${message.guild.id}`) || [];
            existingForms.push(newForm);
            client.db.set(`forms_${message.guild.id}`, existingForms);

            const formEmbed = new EmbedBuilder()
                .setTitle(newForm.title)
                .setDescription(newForm.formMessage)
                .setColor(client.color)

            const button = new ButtonBuilder()
                .setCustomId(`form_${newForm.id}`)
                .setLabel(newForm.buttonText)
                .setStyle(newForm.buttonColor);

            const row = new ActionRowBuilder().addComponents(button);

            try {
                const postChannel = message.guild.channels.cache.get(newForm.postChannelId);
                if (postChannel) {
                    await postChannel.send({
                        embeds: [formEmbed],
                        components: [row]
                    });
                }

                const successEmbed = new EmbedBuilder()
                .setColor(client.color)
                .setDescription(`Formulaire créé avec succès! ID: ${newForm.id}`);

                const successMsg = await message.channel.send({
                    embeds: [successEmbed, generateConfigEmbed(newForm)]
                });
                
                setTimeout(() => successMsg.delete().catch(console.error), 10000);
                
            } catch (error) {
                console.error(error);
                const errorEmbed = new EmbedBuilder()
                    .setColor(client.color)
                    .setDescription("Une erreur est survenue lors de la création du formulaire.");
                
                const errorMsg = await message.channel.send({ embeds: [errorEmbed] });
                setTimeout(() => errorMsg.delete().catch(console.error), 5000);
            }

            await configMessage.edit({ components: [] });
            setTimeout(() => configMessage.delete().catch(console.error), 10000);
        });
    }
};