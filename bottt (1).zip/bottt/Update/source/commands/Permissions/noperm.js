const { example } = require("../Owner/aliases");

module.exports = {
    name: "noperm",
    description: "Modifie le message de non-autorisation du bot.",
    use: "<message/reset/vent>",
    usage: "noperm <message/reset/vent>",
    example: "➜ noperm message\n➜ noperm reset\n➜ noperm vent",
    run: async (client, message, args, commandName) => {
        if (
            !client.config.buyers.includes(message.author.id) &&
            client.db.get(`owner_global_${message.author.id}`) !== true &&
            client.db.get(`owner_${message.guild.id}_${message.author.id}`) !== true
        ) {
            if (client.noperm && client.noperm.trim() !== '') {
                const sent = await message.channel.send(client.noperm);
                const delay = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
                if (delay > 0) setTimeout(() => sent.delete().catch(() => {}), delay * 1000);
            }
            return;
        }


        let pass = false
        let staff = client.staff
if (!staff.includes(message.author.id) && 
    !client.config.buyers.includes(message.author.id) && 
    !client.db.get(`owner_global_${message.author.id}`) !== true && 
    !client.db.get(`owner_${message.guild.id}_${message.author.id}`) !== true) {        } else pass = true;
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
} 
        let origine = await message.reply(await client.lang('noperm.originale'));
        const prefix = client.config.prefix;
        if (!args[0]) {
            return origine.edit(`Veuillez faire \`${prefix}noperm <message/reset/vent>\``);
        }

        if (args[0] === 'reset') {
            await client.db.delete(`noperm_${message.guild.id}`);
            return origine.edit(await client.lang('noperm.reset'));
        }
        
        if (args[0] === 'vent') {
            await client.db.set(`noperm_${message.guild.id}`, 'vent');
            return origine.edit("Le robot ne répondra pas lors des commandes");
        }

        const newMessage = args.join(' ');
        await client.db.set(`noperm_${message.guild.id}`, newMessage);
        return origine.edit(`${await client.lang('noperm.set')} \`${newMessage}\``);
    }
};
