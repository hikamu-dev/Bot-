// commands/utils/helpall.js
const Discord = require('discord.js');
const { bot } = require('../../structures/client'); // (non utilisé, laissé tel quel)

// Helpers
const uniq = (arr) => [...new Set(arr)];
const sanitize = (s) => String(s ?? '').trim();
const clamp = (s, n) => sanitize(s).slice(0, n);
const chunk = (arr, size) => {
  const out = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
};

module.exports = {
  name: "helpall",
  description: "Affiche la liste des commandes classées par permission",

  run: async (client, message, args) => {
    const commandName = module.exports.name; // indispensable

    let pass = false;

    // autorisations "fortes"
    if (client?.staff?.includes?.(message.author.id) ||
        client.config.buyers.includes(message.author.id) ||
        client.db.get(`owner_global_${message.author.id}`) === true ||
        client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true ||
        message.guild.ownerId === message.author.id) {
      pass = true;
    }

    // autorisations "custom" (setperm)
    if (!pass) {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(r => r.id);
        pass = commandPerms.some(perm => userPerms[perm]?.some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        pass = true;
      }
    }

    if (!pass) {
      if (client.noperm && client.noperm.trim() !== '') {
        const sent = await message.channel.send(client.noperm);
        const delay = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delay > 0) setTimeout(() => sent.delete().catch(() => {}), delay * 1000);
      }
      return;
    }

    // === Récupérer toutes les permissions disponibles ===
    const allPerms = client.db.get(`permissions.${message.guild.id}`) || {};
    const permNames = Object.keys(allPerms).map(p => p.toLowerCase());

    // === Organisation des commandes par permission ===
    const commandCategories = {
      public: { classic: [], custom: [] },
      ...Object.fromEntries(permNames.map(perm => [perm, { classic: [], custom: [] }]))
    };

    // Ajouter les commandes classiques
    client.commands.forEach((cmd) => {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${cmd.name}`) || [];
      if (client.db.get(`perm_${cmd.name}.${message.guild.id}`) === "public") {
        commandCategories.public.classic.push(cmd);
      } else if (commandPerms.length > 0) {
        commandPerms.forEach(perm => {
          const permKey = perm.toLowerCase();
          if (commandCategories[permKey]) {
            commandCategories[permKey].classic.push(cmd);
          }
        });
      }
    });

    // Ajouter les commandes personnalisées
    const customCommands = client.db.get(`custom_commands_${message.guild.id}`) || [];
    customCommands.forEach(cmd => {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${cmd.name}`) || [];
      if (cmd.permission === "public") {
        commandCategories.public.custom.push(cmd);
      } else if (commandPerms.length > 0) {
        commandPerms.forEach(perm => {
          const permKey = perm.toLowerCase();
          if (commandCategories[permKey]) {
            commandCategories[permKey].custom.push(cmd);
          }
        });
      }
    });

    // Diviser les commandes en plusieurs descriptions (anti 4096 chars)
    const splitDescription = (commands, type, maxLength = 4000) => {
      const descriptions = [];
      let currentDescription = `**Commande(s) ${type}(s) :**\n`;
      let currentLength = currentDescription.length;

      commands.forEach((cmd, i) => {
        const line = `**${i + 1}.** \`${cmd.name}\` - ${cmd.description || 'Aucune description'}\n`;
        if (currentLength + line.length > maxLength) {
          descriptions.push(currentDescription);
          currentDescription = `**Commande(s) ${type}(s) (suite) :**\n`;
          currentLength = currentDescription.length;
        }
        currentDescription += line;
        currentLength += line.length;
      });

      if (commands.length > 0) {
        descriptions.push(currentDescription);
      }

      return descriptions;
    };

    // Génère les embeds pour une page donnée
    async function generateEmbeds(page) {
      const categories = [
        { name: "Commandes Publiques", value: commandCategories.public, emoji: "🌐" },
        ...permNames.map((perm) => ({
          name: `Permission ${perm}`,
          value: commandCategories[perm],
          emoji: "" // on évite les emojis numériques qui peuvent casser
        }))
      ];

      const currentCategory = categories[page];
      const commands = currentCategory.value;
      const embeds = [];

      const classicDescriptions = commands.classic.length > 0
        ? splitDescription(commands.classic, "classique")
        : [];
      const customDescriptions = commands.custom.length > 0
        ? splitDescription(commands.custom, "personnalisée")
        : [];

      let title = `${currentCategory.emoji ? currentCategory.emoji + ' ' : ''}${currentCategory.name} (Page ${page + 1}/${categories.length})`;
      let currentEmbed = new Discord.EmbedBuilder()
        .setTitle(title)
        .setColor(client.color)
        .setFooter(client.footer);

      if (classicDescriptions.length === 0 && customDescriptions.length === 0) {
        currentEmbed.setDescription('Aucune commande dans cette catégorie');
        embeds.push(currentEmbed);
        return embeds;
      }

      let description = '';
      for (let i = 0; i < classicDescriptions.length; i++) {
        if (description.length + classicDescriptions[i].length > 4000) {
          currentEmbed.setDescription(description || 'Aucune commande');
          embeds.push(currentEmbed);
          currentEmbed = new Discord.EmbedBuilder()
            .setTitle(`${currentCategory.name} (Page ${page + 1}/${categories.length}, Partie ${embeds.length + 1})`)
            .setColor(client.color)
            .setFooter(client.footer);
          description = '';
        }
        description += classicDescriptions[i];
        if (i < classicDescriptions.length - 1 || customDescriptions.length > 0) {
          description += '\n';
        }
      }

      for (let i = 0; i < customDescriptions.length; i++) {
        if (description.length + customDescriptions[i].length > 4000) {
          currentEmbed.setDescription(description || 'Aucune commande');
          embeds.push(currentEmbed);
          currentEmbed = new Discord.EmbedBuilder()
            .setTitle(`${currentCategory.name} (Page ${page + 1}/${categories.length}, Partie ${embeds.length + 1})`)
            .setColor(client.color)
            .setFooter(client.footer);
          description = '';
        }
        description += customDescriptions[i];
        if (i < customDescriptions.length - 1) {
          description += '\n';
        }
      }

      if (description) {
        currentEmbed.setDescription(description);
        embeds.push(currentEmbed);
      }

      return embeds;
    }

    // === Navigation (boutons) – IDs STABLES ===
    const getButtons = (page, embedIndex, totalEmbeds, totalPages) => {
      return new Discord.ActionRowBuilder().addComponents(
        new Discord.ButtonBuilder()
          .setCustomId(`prev_page`)
          .setLabel('Précédent')
          .setStyle(Discord.ButtonStyle.Secondary)
          .setEmoji('⬅️')
          .setDisabled(page === 0 && embedIndex === 0),
        new Discord.ButtonBuilder()
          .setCustomId(`next_page`)
          .setLabel('Suivant')
          .setStyle(Discord.ButtonStyle.Secondary)
          .setEmoji('➡️')
          .setDisabled(page === totalPages - 1 && embedIndex === totalEmbeds - 1)
      );
    };

    // === Sélecteurs paginés (≤25 options / menu, ≤4 menus) ===
    const buildPageSelectors = (permNames) => {
      const safePerms = uniq(
        permNames.map((p) => clamp(`Permission ${sanitize(p).toLowerCase()}`, 100))
      );

      const allOptions = [
        { label: 'Commandes Publiques', value: '0' },
        ...safePerms.map((label, idx) => ({
          label,
          value: String(idx + 1), // 0 = publiques, 1.. = perms
        })),
      ];

      const groups = chunk(allOptions, 25);
      return groups.slice(0, 4).map((options, i) =>
        new Discord.ActionRowBuilder().addComponents(
          new Discord.StringSelectMenuBuilder()
            .setCustomId(`page_selector_${i}`)
            .setPlaceholder(
              clamp(`Sélectionnez une page ${groups.length > 1 ? `(partie ${i + 1}/${groups.length})` : ''}`, 150)
            )
            .addOptions(options)
        )
      );
    };

    // === État initial ===
    let currentPage = 0;
    const totalPages = permNames.length + 1;
    let embeds = await generateEmbeds(currentPage);
    let currentEmbedIndex = 0;

    const selectorRows = buildPageSelectors(permNames);

    const helpMessage = await message.channel.send({
      embeds: [embeds[currentEmbedIndex]],
      components: [getButtons(currentPage, currentEmbedIndex, embeds.length, totalPages), ...selectorRows]
    });

    const collector = helpMessage.createMessageComponentCollector({
      filter: i => i.user.id === message.author.id,
      time: 60000
    });

    collector.on('collect', async interaction => {
      try {
        if (interaction.isButton()) {
          if (interaction.customId === 'prev_page') {
            if (currentEmbedIndex > 0) {
              currentEmbedIndex--;
            } else if (currentPage > 0) {
              currentPage--;
              embeds = await generateEmbeds(currentPage);
              currentEmbedIndex = embeds.length - 1;
            }
          } else if (interaction.customId === 'next_page') {
            if (currentEmbedIndex < embeds.length - 1) {
              currentEmbedIndex++;
            } else if (currentPage < totalPages - 1) {
              currentPage++;
              embeds = await generateEmbeds(currentPage);
              currentEmbedIndex = 0;
            }
          }
        } else if (interaction.isStringSelectMenu() && interaction.customId.startsWith('page_selector_')) {
          const v = parseInt(interaction.values[0], 10);
          currentPage = Number.isNaN(v) ? 0 : v;
          embeds = await generateEmbeds(currentPage);
          currentEmbedIndex = 0;
        }

        await interaction.update({
          embeds: [embeds[currentEmbedIndex]],
          components: [getButtons(currentPage, currentEmbedIndex, embeds.length, totalPages), ...selectorRows]
        });
      } catch {
        // éviter les throw si collector expiré / message supprimé
      }
    });

    collector.on('end', () => {
      helpMessage.edit({ components: [] }).catch(() => {});
    });
  }
};
