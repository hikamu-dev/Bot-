const Discord = require('discord.js');
const { bot } = require('../../structures/client');

module.exports = {
    name: "delperm",
    description: "Supprime une permission existante",
    usage: "delperm <nom>",
    example: "➜ delperm admin",
run: async (client, message, args, commandName) => {
        if (
            !client.config.buyers.includes(message.author.id) &&
            client.db.get(`owner_global_${message.author.id}`) !== true &&
            client.db.get(`owner_${message.guild.id}_${message.author.id}`) !== true
        ) {
            if (client.noperm && client.noperm.trim() !== '') {
                const sent = await message.channel.send(client.noperm);
                const delay = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
                if (delay > 0) setTimeout(() => sent.delete().catch(() => {}), delay * 1000);
            }
            return;
        }


if (!client.config.buyers.includes(message.author.id) && 
    !client.db.get(`owner_global_${message.author.id}`) !== true && 
    !client.db.get(`owner_${message.guild.id}_${message.author.id}`) !== true) {
        
        if (client.noperm && client.noperm.trim() !== '') {
            const sentMessage = await message.channel.send(client.noperm);
            const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
            if (delayTime > 0) {
                setTimeout(() => {
                    sentMessage.delete().catch(() => {});
                }, delayTime * 1000);
            }
        } else {
            return message.channel.send("Vous n'avez pas la permission d'utiliser cette commande.");
        }
        return;
    }


        // Vérifier si un nom de permission est fourni
        const permName = args[0];
        if (!permName) {
            return message.channel.send("Veuillez spécifier un nom de permission à supprimer.");
        }

        // Vérifier si le nom de permission est valide (alphanumérique et sans espaces)
        if (!/^[a-zA-Z0-9]+$/.test(permName)) {
            return message.channel.send("Le nom de la permission doit être alphanumérique et sans espaces.");
        }

        // Récupérer les permissions du serveur
        const existingPerms = client.db.get(`permissions.${message.guild.id}`) || {};

        // Vérifier si la permission existe
        if (!existingPerms[permName]) {
            return message.channel.send("Cette permission n'existe pas.");
        }

        // Supprimer la permission
        delete existingPerms[permName];
        client.db.set(`permissions.${message.guild.id}`, existingPerms);

        // Mettre à jour les command_permissions pour supprimer les références à cette permission
        const commandPerms = client.db.get(`command_permissions.${message.guild.id}`) || {};
        for (const cmd in commandPerms) {
            const updatedPerms = commandPerms[cmd].filter(p => p !== permName);
            if (updatedPerms.length === 0) {
                delete commandPerms[cmd];
            } else {
                commandPerms[cmd] = updatedPerms;
            }
        }
        client.db.set(`command_permissions.${message.guild.id}`, commandPerms);

        // Confirmer la suppression
        return message.channel.send(
            `La permission \`\`${permName}\`\` a été supprimée avec succès.`
        );
    }
};