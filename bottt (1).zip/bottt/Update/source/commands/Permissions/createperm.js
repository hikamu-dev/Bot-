const Discord = require('discord.js');
const { bot } = require('../../structures/client');

module.exports = {
    name: "createperm",
    description: "Crée une nouvelle permission",
    usage: "createperm <nom> [@rôle1] [@rôle2] ...",
    example: "➜ createperm admin @Admin @Modérateur",
run: async (client, message, args, commandName) => {
        if (
            !client.config.buyers.includes(message.author.id) &&
            client.db.get(`owner_global_${message.author.id}`) !== true &&
            client.db.get(`owner_${message.guild.id}_${message.author.id}`) !== true
        ) {
            if (client.noperm && client.noperm.trim() !== '') {
                const sent = await message.channel.send(client.noperm);
                const delay = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
                if (delay > 0) setTimeout(() => sent.delete().catch(() => {}), delay * 1000);
            }
            return;
        }


if (!client.config.buyers.includes(message.author.id) && 
    !client.db.get(`owner_global_${message.author.id}`) !== true && 
    !client.db.get(`owner_${message.guild.id}_${message.author.id}`) !== true) {
        
        if (client.noperm && client.noperm.trim() !== '') {
            const sentMessage = await message.channel.send(client.noperm);
            const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
            if (delayTime > 0) {
                setTimeout(() => {
                    sentMessage.delete().catch(() => {});
                }, delayTime * 1000);
            }
        } else {
            return message.channel.send("Vous n'avez pas la permission d'utiliser cette commande.");
        }
        return;
    }


        const permName = args[0]?.trim();
        const roleMentions = message.mentions.roles;

        if (!permName) {
            return message.channel.send("Veuillez spécifier un nom pour la permission.");
        }

        if (!/^[a-zA-Z0-9]+$/.test(permName)) {
            return message.channel.send("Le nom de la permission doit être alphanumérique et sans espaces.");
        }

        const permissions = client.db.get(`permissions.${message.guild.id}`) || {};

        if (permissions[permName]) {
            return message.channel.send("Une permission avec ce nom existe déjà.");
        }

        // On autorise une permission vide (sans rôle)
        permissions[permName] = roleMentions.map(role => role.id);
        client.db.set(`permissions.${message.guild.id}`, permissions);

        return message.channel.send(
            `La permission \`${permName}\` a été créée.`
        );
    }
};
