// commands/utils/switch.js
const Discord = require('discord.js');
const { bot } = require('../../structures/client');

module.exports = {
    name: "switch",
    description: "Gérer les permissions d'accès aux commandes",
    usage: "switch <commande> <perm> | switch all <perm> | switch reset <perm>",
    use: "<commande> <perm> | all <perm> | reset <perm>",
    aliases: ["sw", "changeperm", "change"],
    example: "➜ switch kick admin\n➜ switch all admin\n➜ switch reset admin",

   run: async (client, message, args) => {
    const commandName = module.exports.name;

    // ===== Vérif d'accès UNIFIÉE =====
    let pass = false;

    // Accès forts (comme chez toi)
    if (
      client?.staff?.includes?.(message.author.id) ||
      client.config.buyers.includes(message.author.id) ||
      client.db.get(`owner_global_${message.author.id}`) === true ||
      client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true ||
      message.guild.ownerId === message.author.id
    ) {
      pass = true;
    }

    // Accès custom (setperm) ou public pour la commande 'switch' elle-même
    if (!pass) {
      const guildId = message.guild.id;
      const commandPerms = client.db.get(`command_permissions.${guildId}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${guildId}`) || {};
        const userRoles = message.member.roles.cache.map(r => r.id);
        pass = commandPerms.some(perm =>
          (userPerms[perm] || []).some(roleId => userRoles.includes(roleId))
        );
      } else if (client.db.get(`perm_${commandName}.${guildId}`) === "public") {
        pass = true;
      }
    }

    if (!pass) {
      if (client.noperm && client.noperm.trim() !== '') {
        const sent = await message.channel.send(client.noperm);
        const delay = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delay > 0) setTimeout(() => sent.delete().catch(() => {}), delay * 1000);
      }
      return;
    }
        // ======================================

        const subCommand = args[0];
        const secondArg = args[1];

        if (!subCommand || !secondArg) {
            return message.channel.send("Utilisation : `switch <commande> <perm>` | `switch all <perm>` | `switch reset <perm>`");
        }

        const existingPerms = client.db.get(`permissions.${message.guild.id}`) || {};

        // 🔁 switch all <perm> — ajoute la perm à TOUTES les commandes (sans doublon)
        if (subCommand.toLowerCase() === 'all') {
            const permName = secondArg;

            if (!existingPerms[permName]) {
                return message.channel.send("Cette permission n'existe pas.");
            }

            let updated = 0, skipped = 0, notFound = 0;

            for (const command of client.commands.values()) {
                if (!client.commands.has(command.name)) { // sécurités déjà présentes
                    notFound++;
                    continue;
                }
                const key = `command_permissions.${message.guild.id}.${command.name}`;
                let perms = client.db.get(key) || [];
                if (!Array.isArray(perms)) perms = [];

                // ajout sans doublon (case-insensitive)
                const hasIt = perms.some(p => String(p).toLowerCase() === permName.toLowerCase());
                if (!hasIt) {
                    perms.push(permName);
                    client.db.set(key, perms);
                    updated++;
                } else {
                    skipped++;
                }
            }

            return message.channel.send(
                `\`${permName}\` ajoutée à ${updated} commande(s). ` +
                `${skipped} déjà équipée(s).` +
                (notFound > 0 ? ` ${notFound} inconnue(s).` : "")
            );
        }

        // 🔄 switch reset <perm> — retire cette perm de TOUTES les commandes
        if (subCommand.toLowerCase() === 'reset') {
            const permName = secondArg;

            if (!existingPerms[permName]) {
                return message.channel.send("Cette permission n'existe pas.");
            }

            let removed = 0, untouched = 0;

            for (const command of client.commands.values()) {
                const key = `command_permissions.${message.guild.id}.${command.name}`;
                let perms = client.db.get(key) || [];
                if (!Array.isArray(perms) || perms.length === 0) { untouched++; continue; }

                const before = perms.length;
                perms = perms.filter(p => String(p).toLowerCase() !== permName.toLowerCase());
                if (perms.length !== before) {
                    client.db.set(key, perms);
                    removed++;
                } else {
                    untouched++;
                }
            }

            return message.channel.send(`\`${permName}\` retirée de ${removed} commande(s). ${untouched} inchangée(s).`);
        }

        // ➕ switch <commande> <perm> — AJOUTE la perm à cette commande (sans écraser)
        const cmd = args[0].toLowerCase();
        const perm = args[1];

        // commande existe ?
        if (!client.commands.has(cmd)) {
            return message.channel.send("Cette commande n'existe pas dans le bot.");
        }

        // perm existe ?
        const allPermKeys = Object.keys(existingPerms);
        const foundPerm = allPermKeys.find(p => p.toLowerCase() === String(perm).toLowerCase());
        if (!foundPerm) {
            return message.channel.send("Cette permission n'existe pas.");
        }

        const key = `command_permissions.${message.guild.id}.${cmd}`;
        let permsArr = client.db.get(key) || [];
        if (!Array.isArray(permsArr)) permsArr = [];

        const already = permsArr.some(p => String(p).toLowerCase() === foundPerm.toLowerCase());
        if (already) {
            return message.channel.send(`La commande \`${cmd}\` a déjà la permission \`${foundPerm}\`.`);
        }

        permsArr.push(foundPerm);
        client.db.set(key, permsArr);
        // DEBUG précédent : écrasait => client.db.set(..., [perm])  // :contentReference[oaicite:1]{index=1}

        return message.channel.send(`La permission \`${foundPerm}\` a été **ajoutée** à la commande \`${cmd}\` (les autres perms restent).`);
    }
};
