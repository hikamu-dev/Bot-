const Discord = require('discord.js');
const { bot } = require('../../structures/client');

module.exports = {
    name: "setperm",
    description: "Ajoute un rôle à une permission existante",
    usage: "setperm <nom> <@rôle>",
    example: "➜ setperm admin @AdminRole\n➜ setperm moderator @ModeratorRole",
run: async (client, message, args, commandName) => {
        if (
            !client.config.buyers.includes(message.author.id) &&
            client.db.get(`owner_global_${message.author.id}`) !== true &&
            client.db.get(`owner_${message.guild.id}_${message.author.id}`) !== true
        ) {
            if (client.noperm && client.noperm.trim() !== '') {
                const sent = await message.channel.send(client.noperm);
                const delay = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
                if (delay > 0) setTimeout(() => sent.delete().catch(() => {}), delay * 1000);
            }
            return;
        }


    if (    !client.config.buyers.includes(message.author.id) && 
    !client.db.get(`owner_global_${message.author.id}`) !== true && 
    !client.db.get(`owner_${message.guild.id}_${message.author.id}`) !== true) {
        
        if (client.noperm && client.noperm.trim() !== '') {
            const sentMessage = await message.channel.send(client.noperm);
            const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
            if (delayTime > 0) {
                setTimeout(() => {
                    sentMessage.delete().catch(() => {});
                }, delayTime * 1000);
            }
        } else {
            return message.channel.send("Vous n'avez pas la permission d'utiliser cette commande.");
        }
        return;
    }

        const permName = args[0]?.trim();
        const roleMention = message.mentions.roles.first();

        if (!permName) {
            return message.channel.send("Veuillez spécifier le nom de la permission.");
        }

        if (!/^[a-zA-Z0-9]+$/.test(permName)) {
            return message.channel.send("Le nom de la permission doit être alphanumérique et sans espaces.");
        }

        if (!roleMention) {
            return message.channel.send("Veuillez mentionner un rôle à ajouter.");
        }

        const permissions = client.db.get(`permissions.${message.guild.id}`) || {};

        if (!permissions[permName]) {
            return message.channel.send("Cette permission n'existe pas.");
        }

        if (permissions[permName].includes(roleMention.id)) {
            return message.channel.send("Ce rôle est déjà dans la permission.");
        }

        // Ajouter le rôle à la permission
        permissions[permName].push(roleMention.id);
        client.db.set(`permissions.${message.guild.id}`, permissions);

        return message.channel.send(`Le rôle <@&${roleMention.id}> a été ajouté à la permission \`${permName}\`.`);
    }
};
