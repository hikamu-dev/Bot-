const Discord = require('discord.js');
const { bot } = require('../../structures/client');

module.exports = {
    name: "perms",
    description: "Affiche la liste des rôles ayant des permissions sur le bot",
    usage: "perms",
run: async (client, message, args) => {
  const commandName = module.exports.name; // indispensable

  let pass = false;

  // autorisations "fortes"
  if (client?.staff?.includes?.(message.author.id) ||
      client.config.buyers.includes(message.author.id) ||
      client.db.get(`owner_global_${message.author.id}`) === true ||
      client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true ||
      message.guild.ownerId === message.author.id) {
    pass = true;
  }

  // autorisations "custom" (setperm)
  if (!pass) {
    const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
    if (commandPerms.length > 0) {
      const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
      const userRoles = message.member.roles.cache.map(r => r.id);
      pass = commandPerms.some(perm => userPerms[perm]?.some(roleId => userRoles.includes(roleId)));
    } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
      pass = true;
    }
  }

  if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
      const sent = await message.channel.send(client.noperm);
      const delay = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
      if (delay > 0) setTimeout(() => sent.delete().catch(() => {}), delay * 1000);
    }
    return;
  
}

        // Récupérer les permissions du serveur
        const existingPerms = client.db.get(`permissions.${message.guild.id}`) || {};

        // Créer un embed
        const embed = new Discord.EmbedBuilder()
            .setTitle("Permissions du bot")
            .setDescription("Liste des permissions et des rôles associés sur ce serveur")
            .setColor(client.color || '#0099ff')
            .setTimestamp()
            .setFooter(client.footer);
        // Vérifier s'il y a des permissions configurées
        if (Object.keys(existingPerms).length === 0) {
            embed.addFields({
                name: "Aucune permission",
                value: "Aucune permission n'est configurée sur ce serveur.",
                inline: false
            });
            return message.channel.send({ embeds: [embed] });
        }

        // Trouver la longueur maximale des noms de permissions pour l'alignement
        const maxPermLength = Math.max(...Object.keys(existingPerms).map(name => name.length));

        // Construire la liste des permissions et rôles
        let output = "";
        for (const [permName, roleIds] of Object.entries(existingPerms)) {
            // Aligner le nom de la permission avec des espaces
            const paddedPermName = permName.padEnd(maxPermLength, ' ');
            // Lister les rôles associés
            const roles = roleIds
                .map(roleId => {
                    const role = message.guild.roles.cache.get(roleId);
                    return role ? `<@&${roleId}>` : `(Rôle introuvable: ${roleId})`;
                })
                .join(", ");
            output += `> ${paddedPermName}   ${roles || "Aucun rôle"}\n`;
        }

        // Ajouter le champ à l'embed
        embed.addFields({
            name: "Permissions",
            value: output,
            inline: false
        });

        // Envoyer l'embed
        return message.channel.send({ embeds: [embed] });
    }
};