
const Discord = require('discord.js');
const { bot } = require('../../structures/client');

module.exports = {
    name: "infoperms",
    description: "Affiche les commandes liées à chaque permission personnalisée",

    run: async (client, message) => {
        const commandName = module.exports.name; // 🔧 indispensable pour que les perms marchent

        // Vérification des droits
        let pass = false;
        if (
            client.staff.includes(message.author.id) ||
            client.config.buyers.includes(message.author.id) ||
            client.db.get(`owner_global_${message.author.id}`) === true ||
            client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true ||
            message.guild.ownerId === message.author.id
        ) {
            pass = true;
        }

        const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
        const allPerms = client.db.get(`permissions.${message.guild.id}`) || {};

        for (const perm of commandPerms) {
            const roles = allPerms[perm];
            if (roles && message.member.roles.cache.some(r => roles.includes(r.id))) {
                pass = true;
                break;
            }
        }

        if (!pass) {
            if (client.noperm && client.noperm.trim() !== '') {
                const sentMessage = await message.channel.send(client.noperm);
                const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
                if (delayTime > 0) {
                    setTimeout(() => {
                        sentMessage.delete().catch(() => {});
                    }, delayTime * 1000);
                }
            }
            return;
        }

        const guildId = message.guild.id;
        const permissions = client.db.get(`permissions.${guildId}`) || {};
        const cmdPermissions = client.db.get(`command_permissions.${guildId}`) || {};

        if (Object.keys(permissions).length === 0) {
            return message.channel.send("Aucune permission personnalisée n'a été créée sur ce serveur.");
        }

        const embed = new Discord.EmbedBuilder()
            .setTitle("📘 Liste des Permissions et Commandes")
            .setColor(client.color || "#3498db")
            .setFooter(client.footer)
            .setTimestamp();

        for (const permName of Object.keys(permissions)) {
            const linkedCommands = Object.entries(cmdPermissions)
                .filter(([_, perms]) => perms.some(p => p.toLowerCase() === permName.toLowerCase()))
                .map(([cmdName]) => `\`${cmdName}\``);

            embed.addFields({
                name: `🔐 Permission \`${permName}\``,
                value: linkedCommands.length > 0
                    ? `Commandes liées : ${linkedCommands.join(", ")}`
                    : "Aucune commande liée.",
                inline: false
            });
        }

        return message.channel.send({ embeds: [embed] });
    }
};
