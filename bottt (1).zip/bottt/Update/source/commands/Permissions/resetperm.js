const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { bot } = require('../../structures/client');

module.exports = {
    name: "clearperms",
    description: "Permet de réinitialiser toutes les permissions",
    category: "botcontrol",
    usage: ["clearperms"],
    /**
     * 
     * @param {bot} client 
     * @param {Discord.Message} message 
     * @param {Array<>} args 
     * @param {*} color 
     * @param {*} prefix 
     * @param {*} footer 
     * @param {string} commandName 
     */
run: async (client, message, args, commandName) => {
        if (
            !client.config.buyers.includes(message.author.id) &&
            client.db.get(`owner_global_${message.author.id}`) !== true &&
            client.db.get(`owner_${message.guild.id}_${message.author.id}`) !== true
        ) {
            if (client.noperm && client.noperm.trim() !== '') {
                const sent = await message.channel.send(client.noperm);
                const delay = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
                if (delay > 0) setTimeout(() => sent.delete().catch(() => {}), delay * 1000);
            }
            return;
        }


if (!staff.includes(message.author.id) && 
    !client.config.buyers.includes(message.author.id) && 
    !client.db.get(`owner_global_${message.author.id}`) !== true && 
    !client.db.get(`owner_${message.guild.id}_${message.author.id}`) !== true) {
        
        if (client.noperm && client.noperm.trim() !== '') {
            const sentMessage = await message.channel.send(client.noperm);
            const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
            if (delayTime > 0) {
                setTimeout(() => {
                    sentMessage.delete().catch(() => {});
                }, delayTime * 1000);
            }
        } else {
            return message.channel.send("Vous n'avez pas la permission d'utiliser cette commande.");
        }
        return;
    }

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('confirmReset')
                    .setLabel('✅')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('cancelReset')
                    .setLabel('❌')
                    .setStyle(ButtonStyle.Secondary)
            );

        const resetMessage = await message.channel.send({
            content: "Es-tu sûr de vouloir réinitialiser toutes les permissions ?",
            components: [row]
        });

        const filter = i => ['confirmReset', 'cancelReset'].includes(i.customId) && i.user.id === message.author.id;
        const collector = resetMessage.createMessageComponentCollector({ filter, time: 15000 });

        collector.on('collect', async i => {
            if (i.customId === 'confirmReset') {
                await resetPermissions(client, message.guild.id);
                
                await i.update({ content: "✅ Toutes les permissions ont été réinitialisées avec succès.", components: [] });
            } else if (i.customId === 'cancelReset') {
                await i.update({ content: "❌ Réinitialisation des permissions annulée.", components: [] });
            }
        });

        collector.on('end', async collected => {
            if (!collected.size) {
                resetMessage.edit({ content: "⏲️ Temps écoulé. Réinitialisation annulée.", components: [] });
            }
        });
    }
}

/**
 * Fonction pour réinitialiser toutes les permissions en les supprimant de la base de données.
 * @param {bot} client 
 * @param {string} guildId 
 */
async function resetPermissions(client, guildId) {
    // Supprime le nouveau système de permissions personnalisées
    await client.db.delete(`permissions.${guildId}`);
    
    // Supprime les permissions par commande
    await client.db.delete(`command_permissions.${guildId}`);
    
    // Supprime les anciennes permissions pour la compatibilité
    await client.db.delete(`perm_ticket.${guildId}`);
    await client.db.delete(`perm_giveaway.${guildId}`);
    await client.db.delete(`perm1.${guildId}`);
    await client.db.delete(`perm2.${guildId}`);
    await client.db.delete(`perm3.${guildId}`);
    await client.db.delete(`perm4.${guildId}`);
    await client.db.delete(`perm5.${guildId}`);
    
    // Supprime toutes les permissions publiques pour toutes les commandes
    const allCommands = ['clearperms', 'perms', 'ticket', 'giveaway']; // Ajoutez d'autres commandes si nécessaire
    for (const commandName of allCommands) {
        await client.db.delete(`perm_${commandName}.${guildId}`);
    }
}