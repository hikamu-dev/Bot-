const Discord = require('discord.js');

module.exports = {
    name: "unswitch",
    description: "Retirer une permission d'accès à une commande",
    usage: "unswitch <commande> <perm>",
    run: async (client, message, args) => {

        if (
            !client.config.buyers.includes(message.author.id) &&
            client.db.get(`owner_global_${message.author.id}`) !== true &&
            client.db.get(`owner_${message.guild.id}_${message.author.id}`) !== true
        ) {
            if (client.noperm && client.noperm.trim() !== '') {
                const sent = await message.channel.send(client.noperm);
                const delay = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
                if (delay > 0) setTimeout(() => sent.delete().catch(() => {}), delay * 1000);
            }
            return;
        }

        const cmdName = args[0]?.toLowerCase();
        const permToRemove = args[1]?.toLowerCase();

        if (!cmdName || !permToRemove) {
            return message.channel.send("Usage : `+unswitch <commande> <perm>`");
        }

        if (!client.commands.has(cmdName)) {
            return message.channel.send("Cette commande n'existe pas dans le bot.");
        }

        const key = `command_permissions.${message.guild.id}.${cmdName}`;
        const currentPerms = client.db.get(key) || [];

        if (!currentPerms.includes(permToRemove)) {
            return message.channel.send(`La permission \`${permToRemove}\` n'était pas assignée à \`${cmdName}\`.`);
        }

        const updatedPerms = currentPerms.filter(p => p !== permToRemove);
        client.db.set(key, updatedPerms);

        return message.channel.send(`La permission \`${permToRemove}\` a été retirée de la commande \`${cmdName}\`.`);
    }
};
