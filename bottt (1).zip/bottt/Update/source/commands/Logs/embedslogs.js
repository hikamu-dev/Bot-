const Discord = require('discord.js');
const { bot } = require('../../structures/client');

module.exports = {
    name: "embedslogs",
    aliases: ["embedslog", "logsembeds", "logembed"],
    description: "Définit le salon de logs pour les actions sur les embeds",
    category: "logs",
    usage: ["embedslogs <channel/idchannel>", "embedslogs off"],
    /**
     * @param {bot} client 
     * @param {Discord.Message} message 
     */
    run: async (client, message, args, commandName) => {
        let pass = false;

        // Gestion des permissions (copie la logique de boostlog.js)
        if (
            client.staff.includes(message.author.id) ||
            client.config.buyers.includes(message.author.id) ||
            client.db.get(`owner_global_${message.author.id}`) === true ||
            client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true ||
            message.guild.ownerId === message.author.id
        ) {
            pass = true;
        } else {
            const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
            if (commandPerms.length > 0) {
                const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                const userRoles = message.member.roles.cache.map(role => role.id);
                pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
            } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                pass = true;
            }
        }

        if (!pass) {
            if (client.noperm && client.noperm.trim() !== '') {
                const sentMessage = await message.channel.send(client.noperm);
                const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
                if (delayTime > 0) {
                    setTimeout(() => {
                        sentMessage.delete().catch(() => {});
                    }, delayTime * 1000);
                }
            }
            return;
        }

        if (args[0] === "off") {
            client.db.delete(`embedslogs_${message.guild.id}`);
            return message.reply(`Les logs des embeds ont été désactivés.`);
        }

        let channel = message.mentions.channels.first() || message.guild.channels.cache.get(args[0]);
        if (!channel) return message.reply("Veuillez mentionner un salon ou fournir un ID de salon valide !");

        client.db.set(`embedslogs_${message.guild.id}`, channel.id);
        message.reply(`Les logs des embeds seront désormais envoyés dans le salon ${channel}.`);
    }
}