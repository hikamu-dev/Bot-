const Discord = require("discord.js");
const Astroia = require("../../structures/client");

module.exports = {
  name: "presetlogs",
  aliases: ["configlogs", "setlogs", "autoconfiglogs"],
  description: "Permet de preset et crée tous les logs.",
  run: async (client, message) => {
    let pass = false;

    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
        client.db.get(`owner_global_${message.author.id}`) === true || 
        client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
        message.guild.ownerId === message.author.id) {
        pass = true;
    } else {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.presetlogs`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_presetlogs.${message.guild.id}`) === "public") {
        pass = true;
      }
    }

    if (!pass) {
      if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
          setTimeout(() => {
            sentMessage.delete().catch(() => {});
          }, delayTime * 1000);
        }
      }
      return;
    }

    message.channel.send(await client.lang(`presetlog.message1`))

    let category = await message.guild.channels.create({
      name: '📚・Logs',
      type: 4,
      permissionOverwrites: [{
        id: message.guild.roles.everyone.id,
        allow: [Discord.PermissionFlagsBits.SendMessages, Discord.PermissionFlagsBits.ReadMessageHistory],
        deny: [Discord.PermissionFlagsBits.ViewChannel],
      }]
    })

    let channelInfo = [
      { name: '⚡・logs-raid', dbKey: 'raidlogs_' },
      { name: '📁・logs-roles', dbKey: 'rolelog_' },
      { name: '📁・logs-modération', dbKey: 'modlogs_' },
      { name: '📁・logs-message', dbKey: 'msglogs_' },
      { name: '📁・logs-vocal', dbKey: 'voicelogs_' },
      { name: '📁・logs-joinleave', dbKey: 'joinsleave_' },
      { name: '📁・logs-salons', dbKey: 'logschannel_' },
      { name: '📁・logs-boost', dbKey: 'logsboost_' },
      { name: '📁・logs-embeds', dbKey: 'embedslogs_' }
    ]

    for (let i = 0; i < channelInfo.length; i++) {
      let channel = await message.guild.channels.create({
        name: channelInfo[i].name,
        type: 0,
        parent: category.id,
        permissionOverwrites: [{
          id: message.guild.roles.everyone.id,
          allow: [Discord.PermissionFlagsBits.SendMessages, Discord.PermissionFlagsBits.ReadMessageHistory],
          deny: [Discord.PermissionFlagsBits.ViewChannel],
        }]
      })

      client.db.set(`${channelInfo[i].dbKey}${message.guild.id}`, channel.id)
    }

    message.channel.send(await client.lang(`presetlog.message2`))
  }
}
