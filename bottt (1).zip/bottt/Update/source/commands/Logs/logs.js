const Discord = require('discord.js');

module.exports = {
    name: "logs",
    aliases: ["log"],
    description: "Affiche le status des logs !",
    run: async (client, message, args, commandName) => {
        let pass = false;

        if (client.staff.includes(message.author.id) || 
            client.config.buyers.includes(message.author.id) ||
            client.db.get(`owner_global_${message.author.id}`) === true || 
            client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
            message.guild.ownerId === message.author.id) {
            pass = true;
        } else {
            const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
            if (commandPerms.length > 0) {
                const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                const userRoles = message.member.roles.cache.map(role => role.id);
                pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
            } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                pass = true;
            }
        }

        if (!pass) {
            if (client.noperm && client.noperm.trim() !== '') {
                const sentMessage = await message.channel.send(client.noperm);
                const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
                if (delayTime > 0) {
                    setTimeout(() => {
                        sentMessage.delete().catch(() => {});
                    }, delayTime * 1000);
                }
            }
            return;
        }

        let raid = message.guild.channels.cache.get(client.db.get(`raidlogs_${message.guild.id}`))
        if (!raid) raid = `[\`${await client.lang(`logs.message1`)}\`](${client.support})`

        let logmsg = message.guild.channels.cache.get(client.db.get(`msglogs_${message.guild.id}`))
        if (!logmsg) logmsg = `[\`${await client.lang(`logs.message1`)}\`](${client.support})`

        let logvc = message.guild.channels.cache.get(client.db.get(`voicelogs_${message.guild.id}`))
        if (!logvc) logvc = `[\`${await client.lang(`logs.message1`)}\`](${client.support})`

        let logmod = message.guild.channels.cache.get(client.db.get(`modlogs_${message.guild.id}`))
        if (!logmod) logmod = `[\`${await client.lang(`logs.message1`)}\`](${client.support})`

        let logsjoinleave = message.guild.channels.cache.get(client.db.get(`joinsleave_${message.guild.id}`))
        if (!logsjoinleave) logsjoinleave = `[\`${await client.lang(`logs.message1`)}\`](${client.support})`

        let logsrole = message.guild.channels.cache.get(client.db.get(`rolelog_${message.guild.id}`))
        if (!logsrole) logsrole = `[\`${await client.lang(`logs.message1`)}\`](${client.support})`

        let logschannel = message.guild.channels.cache.get(client.db.get(`logschannel_${message.guild.id}`))
        if (!logschannel) logschannel = `[\`${await client.lang(`logs.message1`)}\`](${client.support})`

        let logsboost = message.guild.channels.cache.get(client.db.get(`logsboost_${message.guild.id}`))
        if (!logsboost) logsboost = `[\`Aucun salon configuré\`](${client.support})`

        let logsembed = message.guild.channels.cache.get(client.db.get(`embedslogs_${message.guild.id}`))
        if (!logsembed) logsembed = `[\`Aucun salon configuré\`](${client.support})`

        const embed = new Discord.EmbedBuilder()
            .setColor(client.color)
            .setTitle('Logs')
            .setDescription(`Voici la configuration actuelle des logs`)
            .addFields(
                {
                    name: '🛡️ Logs Anti-Raid',
                    value: `${raid}`,
                    inline: true
                },
                {
                    name: '💬 Logs Messages',
                    value: `${logmsg}`,
                    inline: true
                },
                {
                    name: '🔊 Logs Vocaux',
                    value: `${logvc}`,
                    inline: true
                },
                {
                    name: '⚖️ Logs Modération',
                    value: `${logmod}`,
                    inline: true
                },
                {
                    name: '🚪 Logs Arrivées/Départs',
                    value: `${logsjoinleave}`,
                    inline: true
                },
                {
                    name: '🎭 Logs Rôles',
                    value: `${logsrole}`,
                    inline: true
                },
                {
                    name: '📝 Logs Salons',
                    value: `${logschannel}`,
                    inline: true
                },
                {
                    name: '🚀 Logs Boosts',
                    value: `${logsboost}`,
                    inline: true
                },
                {
                    name: '💬 Logs Embeds',
                    value: `${logsembed}`,
                    inline: true
                }
            )
            .setFooter(client.footer)

        return message.channel.send({ embeds: [embed] });
    }
}
