const Discord = require('discord.js');
const { example } = require('./boostlog');

module.exports = {
    name: "joinleavelog",
    aliases: ["joinleavelogs", "leavejoinlog", "leavejoinlogs"],
    description: "Permet de gérer les logs de modération",
    use: "on [channel], joinleavelog off",
    example: "➜ joinleavelog on #logs\n➜ joinleavelog on 1391870677929431081\n➜ joinleavelog off",

    run: async (client, message, args, commandName) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
        client.db.get(`owner_global_${message.author.id}`) === true || 
client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        let channel = message.mentions.channels.first() || message.guild.channels.cache.get(args[1]);
        if (!channel) channel = message.channel;

        let logs = client.db.get(`joinsleave_${message.guild.id}`);

        if (args[0] === "on") {
            client.db.set(`joinsleave_${message.guild.id}`, channel.id);
            message.channel.send(`${await client.lang(`joinleavelog.message1`)} ${channel}.`);
        }

        if (args[0] === "off") {
            client.db.delete(`joinsleave_${message.guild.id}`);
            message.channel.send(await client.lang(`joinleavelog.message2`));
        }
    }
}
