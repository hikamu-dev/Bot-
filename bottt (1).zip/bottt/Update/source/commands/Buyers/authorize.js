// commands/admin/autorise.js
const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "autorise",
  aliases: ["authorize", "authowner"],
  description: "Autoriser quelqu'un à utiliser la commande owner/unowner (here/all). Réservé aux buyers.",
  usages: "autorise <add|remove|list> [@user|id] [here|all]",
  example: "autorise add @User all\nautorise add 123456789 here\nautorise list\nautorise remove @User all",
  run: async (client, message, args) => {
    // --- réservé aux buyers ---
    if (!client.config?.buyers?.includes?.(message.author.id)) {
      if (client.noperm && client.noperm.trim() !== '') {
        const sent = await message.channel.send(client.noperm);
        const delayTime = client.db.get(`noperm_delay_${message.guild?.id}`) || 0;
        if (delayTime > 0) setTimeout(() => sent.delete().catch(() => {}), delayTime * 1000);
      }
      return;
    }

    const sub = (args[0] || "").toLowerCase();
    if (!["add", "remove", "list"].includes(sub)) {
      return message.channel.send("Utilisation : `autorise <add|remove|list> [@user|id] [here|all]`");
    }

    const scopeArg = (args[2] || "").toLowerCase();
    const scope = scopeArg === "here" ? "here" : (scopeArg === "all" ? "all" : null);

    const gId = message.guild?.id;

    // Clés :
    // - Global : owner_cmd_allow_global_<userId> = true
    // - Local  : owner_cmd_allow_<guildId>_<userId> = true
    const makeKey = (userId, sc) => sc === "all"
      ? `owner_cmd_allow_global_${userId}`
      : `owner_cmd_allow_${gId}_${userId}`;

    if (sub === "list") {
      // Liste globale
      const all = (await client.db.all())
        .filter(e => e.ID.startsWith("owner_cmd_allow_global_"));
      // Liste locale
      const here = gId
        ? (await client.db.all()).filter(e => e.ID.startsWith(`owner_cmd_allow_${gId}_`))
        : [];

      const mapLine = (arr, label) =>
        arr.length
          ? `**${label}**\n` + arr.map(e => {
              const id = e.ID.split("_").pop();
              return `• <@${id}> \`(${id})\``;
            }).join("\n")
          : `**${label}**\n• Aucun`;

      const embed = new EmbedBuilder()
        .setColor(client.color || 0x2f3136)
        .setTitle("Autorisations pour la commande `owner`")
        .setDescription(
          [mapLine(all, "Global (owner all)"), mapLine(here, "Ici (owner here)")].join("\n\n")
        )
        .setFooter(client.footer || null);

      return message.channel.send({ embeds: [embed] });
    }

    // add / remove
    const targetArg = args[1];
    if (!targetArg) return message.channel.send("Spécifie un utilisateur : `@mention` ou `id`.");
    const member = message.mentions.members.first()
      || (gId ? message.guild.members.cache.get(targetArg) : null);
    const userId = member?.id || targetArg;

    if (!/^\d{15,20}$/.test(userId)) {
      return message.channel.send("Utilisateur introuvable.");
    }

    if (!scope) {
      return message.channel.send("Précise le scope : `here` ou `all`.");
    }

    const key = makeKey(userId, scope);

    if (sub === "add") {
      if (client.db.get(key)) return message.channel.send("Cette personne est déjà autorisée.");
      client.db.set(key, true);
      return message.channel.send(
        `✅ <@${userId}> est maintenant **autorisé** à utiliser \`owner ${scope}\`.`
      );
    }

    if (sub === "remove") {
      if (!client.db.get(key)) return message.channel.send("Cette personne n'était pas autorisée.");
      client.db.delete(key);
      return message.channel.send(
        `🗑️ <@${userId}> **n'est plus autorisé** à utiliser \`owner ${scope}\`.`
      );
    }
  }
};
