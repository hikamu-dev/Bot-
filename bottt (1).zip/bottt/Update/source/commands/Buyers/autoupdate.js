// commands/utils/autoupdate.js
module.exports = {
  name: 'autoupdate',
  description: 'Active/désactive la vérification & update automatique (cron géré par l’event). DM buyers uniquement.',
  usage: 'autoupdate on|off',
  aliases: ['au', 'autoup'],

  run: async (client, message, args) => {
    // ===== ACCÈS : UNIQUEMENT staff OU buyers =====
    const isStaff  = Array.isArray(client?.staff) && client.staff.includes(message.author.id);
    const isBuyer  = Array.isArray(client?.config?.buyers) && client.config.buyers.includes(message.author.id);

    if (!isStaff && !isBuyer) {
      if (client.noperm && client.noperm.trim() !== '') {
        const sent = await message.channel.send(client.noperm);
        const delay = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delay > 0) setTimeout(() => sent.delete().catch(() => {}), delay * 1000);
      }
      return;
    }
    // ==============================================

    const sub = (args[0] || '').toLowerCase();
    if (!['on', 'off'].includes(sub)) {
      return message.channel.send({
        content: 'Utilisation : `autoupdate on|off`',
        allowedMentions: { parse: [] }
      });
    }

    const enable = sub === 'on';
    client.db.set('autoupdate.enabled', enable);

    // hooks de l’event pour effet immédiat (start/stop du cron sans reboot)
    let hooks;
    try { hooks = require('../../events/autoupdate_ready.js'); } catch { hooks = {}; }

    // DM à tous les buyers (IDs uniques)
    const buyers = Array.isArray(client?.config?.buyers) ? [...new Set(client.config.buyers)] : [];

    if (enable) {
      hooks.startCron?.(client);

      // DM buyers: activé
      for (const id of buyers) {
        try {
          const u = await client.users.fetch(id).catch(() => null);
          if (u) await u.send({ content: 'Auto Update : `activé`', allowedMentions: { parse: [] } });
        } catch {}
      }

      return message.channel.send({
        content: 'AutoUpdate **activé**.',
        allowedMentions: { parse: [] }
      });
    } else {
      hooks.stopCron?.();

      // DM buyers: désactivé
      for (const id of buyers) {
        try {
          const u = await client.users.fetch(id).catch(() => null);
          if (u) await u.send({ content: 'Auto Update : `désactivé`', allowedMentions: { parse: [] } });
        } catch {}
      }

      return message.channel.send({
        content: 'AutoUpdate **désactivé**.',
        allowedMentions: { parse: [] }
      });
    }
  }
};
