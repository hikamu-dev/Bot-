const { exec } = require('child_process');
const axios = require('axios');
const fs = require('fs');

function getCurrentTime() {
    const now = new Date();
    return `[${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}:${now.getSeconds().toString().padStart(2, '0')}]`;
}

function execPromise(command) {
    return new Promise((resolve, reject) => {
        exec(command, (err, stdout, stderr) => {
            if (err) return reject(err);
            resolve(stdout);
        });
    });
}

async function performUpdate(client, statusMessage) {
    try {
        const botPath = `/home/ubuntu/bot/${client.user.id}`;
        const updatePath = `/home/ubuntu/Update`;
        const versionFilePath = `${botPath}/version.js`;
        const apiConfig = require('/home/ubuntu/API/config.js');

        await execPromise(`cd ${botPath} && rm -r source lang && rm version.js index.js`);
        await execPromise(`cp -r ${updatePath}/* ${botPath}`);

        let botVersion = {};
        try {
            botVersion = require(versionFilePath);
        } catch (e) {}

        botVersion.version = apiConfig.version;

        await fs.promises.writeFile(
            versionFilePath,
            `module.exports = ${JSON.stringify(botVersion, null, 2)};`
        );

        await execPromise(`pm2 restart ${client.user.id}`);

        await statusMessage.edit(
            `\`${getCurrentTime()}\` ✅ Mise à jour terminée avec succès !\nNouvelle version : \`${apiConfig.version}\``
        );
    } catch (err) {
        console.error(err);
        await statusMessage.edit(`\`${getCurrentTime()}\` ❌ Une erreur est survenue pendant la mise à jour.`);
    }
}

module.exports = {
    name: 'update',
    description: 'Met à jour le bot personnel.',

    /**
     * @param {Astroia} client
     * @param {Discord.Message} message
     */
    run: async (client, message, args, commandName) => {
      
    let pass = false;

    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) || 
        client.db.get(`owner_global_${message.author.id}`) === true || 
        client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true) {
      pass = true;
    } else {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        pass = true;
      }
    }

    if (!pass) {
        if (client.noperm && client.noperm.trim() !== '') {
            const sentMessage = await message.channel.send(client.noperm);
            const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
            if (delayTime > 0) {
                setTimeout(() => {
                    sentMessage.delete().catch(() => {});
                }, delayTime * 1000);
            }
        }
        return;
    }
        try {
            const response = await axios.post(`http://${client.config.panel}/api/version`, {
                version: client.version,
            });

            const msg = response.data.message;

            if (msg === 'Mise à jour disponible en attente.') {
                const steps = [
                    '🔄 Lancement de la mise à jour',
                    '📥 Téléchargement des fichiers',
                    '⚙️ Application de la mise à jour',
                    '♻️ Redémarrage du bot en cours'
                ];

                let statusMessage = await message.channel.send(`\`${getCurrentTime()}\` ${steps[0]}`);

                for (let i = 1; i < steps.length; i++) {
                    await new Promise(resolve => setTimeout(resolve, 2000));
                    await statusMessage.edit(`\`${getCurrentTime()}\` ${steps[i]}`);
                }

                await performUpdate(client, statusMessage);

            } else if (msg === 'Aucune mise à jour disponible.') {
                message.channel.send(`Votre bot est déjà à jour !`);
            } else {
                message.channel.send(`\`${getCurrentTime()}\` ℹ️ ${msg}`);
            }

        } catch (error) {
            console.error(error);
            message.channel.send(`\`${getCurrentTime()}\` ❌ Une erreur est survenue lors de la vérification.`);
        }
    }
};
