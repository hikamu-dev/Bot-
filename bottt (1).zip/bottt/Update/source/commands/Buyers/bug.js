
// APRES
const {
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  PermissionsBitField,
  WebhookClient,              // ← ajouter ceci
} = require("discord.js");


// ⚠️ Remplace par l’URL de TON webhook (format complet)
const BUG_WEBHOOK = "https://discord.com/api/webhooks/1419010113892778014/S1mpK80X6nfI3W9Ya2KVUI_MWRjzp-mAQ_6mBCgA7giemz7hEJZC5sK-UmlwY2yoYAkS";
const hook = new WebhookClient({ url: BUG_WEBHOOK });

// Autorisation : owners / staff / buyers / perms (PAS public par défaut)
function passGate(client, message, commandName = "bug", defaultPublic = false) {
  const uid = message.author.id;
  const gid = message.guild.id;

  // 1) Staff / Buyers / Owners
  if (client?.staff?.includes?.(uid)) return true;
  if (client?.config?.buyers?.includes?.(uid)) return true;
  if (client.db?.get?.(`owner_global_${uid}`) === true) return true;
  if (client.db?.get?.(`owner_${gid}_${uid}`) === true) return true;
  if (message.guild.ownerId === uid) return true;

  // 2) Rôles autorisés via "perms" (groupes déclarés pour la commande)
  const commandPerms = client.db?.get?.(`command_permissions.${gid}.${commandName}`) || [];
  if (commandPerms.length > 0) {
    const userPerms = client.db?.get?.(`permissions.${gid}`) || {};
    const roles = new Set(message.member.roles.cache.map(r => r.id));
    const allowed = commandPerms.some(group =>
      Array.isArray(userPerms[group]) && userPerms[group].some(roleId => roles.has(roleId))
    );
    if (allowed) return true;
  }

  // 3) Fallback public si explicitement configuré
  if (client.db?.get?.(`perm_${commandName}.${gid}`) === "public") return true;

  // 4) Valeur par défaut (ici false)
  return defaultPublic;
}

const isLikelyImageUrl = (s) =>
  /^https?:\/\/\S+\.(png|jpe?g|gif|webp|bmp|tiff)(\?\S*)?$/i.test(s) ||
  /^https:\/\/cdn\.discord(app)?\.com\/attachments\/\d+\/\d+\/\S+$/i.test(s);

module.exports = {
  name: "bug",
  description: "Signalement de bug (commande + description obligatoires) — menus pour catégorie/image/envoi. Image garantie dans l’embed du webhook.",
  usages: "bug",
  example: "bug",

  /**
   * @param {import('discord.js').Client} client
   * @param {import('discord.js').Message} message
   */
  run: async (client, message) => {
    if (!message.guild) return;
    if (!BUG_WEBHOOK || !/^https:\/\/(discord(app)?\.com)\/api\/webhooks\/\d+\/[A-Za-z0-9_\-]+/.test(BUG_WEBHOOK)) {
      return message.channel.send("❌ Webhook non configuré dans le script. Édite `BUG_WEBHOOK`.");
    }
    // ⬇️ Restreint : owners / staff / buyers / perms (pas public)
    if (!passGate(client, message, "bug", false)) {
      if (client.noperm && client.noperm.trim() !== "") {
        const sent = await message.channel.send({ content: client.noperm, allowedMentions: { parse: [] } });
        const delayTime = client.db?.get?.(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) setTimeout(() => sent.delete().catch(() => {}), delayTime * 1000);
      } else {
        await message.channel.send({ content: "❌ Vous n’avez pas la permission d’utiliser cette commande." });
      }
      return;
    }

    const me = message.guild.members.me;
    if (!me.permissions.has(PermissionsBitField.Flags.SendMessages)) {
      return message.channel.send({ content: "❌ Je ne peux pas écrire ici." });
    }

    // État en mémoire pendant la session
    const state = {
      authorId: message.author.id,
      commandName: null,     // OBLIGATOIRE
      description: null,     // OBLIGATOIRE
      category: null,        // menu
      image: null,           // { kind:"file"|"url", name?:string, data?:Buffer, url?:string }
    };

    // Helper question (supprime question + réponse)
    const askOnce = async (question, { acceptAttachment = false, timeoutMs = 90_000 } = {}) => {
      const prompt = await message.channel.send({ content: question, allowedMentions: { parse: [] } });
      const filter = m => m.author.id === state.authorId;
      let collected = null;
      try {
        collected = await message.channel.awaitMessages({ filter, max: 1, time: timeoutMs });
      } catch {}
      const answer = collected?.first() || null;

      let text = answer?.content?.trim() || null;
      let image = null;

      if (acceptAttachment && answer?.attachments?.size) {
        const att = answer.attachments.first();
        if (att?.contentType?.startsWith?.("image/")) {
          try {
            // Télécharge l'image en Buffer AVANT de supprimer le message source
            const res = await fetch(att.url);
            const ab = await res.arrayBuffer();
            const buf = Buffer.from(ab);
            const ext = (att.contentType.split("/")[1] || "png").toLowerCase();
            const safeName = att.name && att.name.length <= 100 ? att.name : `image.${ext}`;
            image = { kind: "file", name: safeName, data: buf };
          } catch {
            // si échec, on n'enregistre rien
          }
        }
      }

      if (!image && text && isLikelyImageUrl(text)) {
        image = { kind: "url", url: text };
      }

      // Nettoyage
      setTimeout(() => prompt.delete().catch(()=>{}), 0);
      if (answer) setTimeout(() => answer.delete().catch(()=>{}), 0);

      // Retourne l'image si trouvée, sinon le texte (ou null)
      return image ? image : (text || null);
    };

    // ===== Étapes OBLIGATOIRES avant panel =====
    const cmd = await askOnce("✍️ Écris le **nom de la commande** qui bug (**obligatoire**) :", { timeoutMs: 60_000 });
    if (!cmd) return message.channel.send("❌ Temps dépassé. Relance la commande.");
    state.commandName = String(cmd).slice(0, 100);

    const desc = await askOnce("✍️ Décris **le problème** (**obligatoire**) :", { timeoutMs: 120_000 });
    if (!desc) return message.channel.send("❌ Temps dépassé. Relance la commande.");
    state.description = String(desc).slice(0, 1900);

    // ===== Panel + menus =====
    const buildEmbedPanel = () => {
      const authorUser = message.guild.members.cache.get(state.authorId)?.user || message.author;
      const emb = new EmbedBuilder()
        .setColor(client.color || 0x5865F2)
        .setTitle("🐞 Signalement de bug")
        .setAuthor({ name: authorUser.tag, iconURL: authorUser.displayAvatarURL({ size: 128 }) }) // QUI envoie
        .addFields(
          { name: "Commande concernée", value: `\`${state.commandName}\``, inline: false },
          { name: "Description (obligatoire)", value: state.description.length > 1024 ? state.description.slice(0, 1021) + "..." : state.description, inline: false },
          { name: "Catégorie", value: state.category ?? "_Non définie_", inline: false },
          { name: "Image", value: state.image ? (state.image.kind === "url" ? state.image.url : "✅ Image prête (réupload)") : "_Aucune_", inline: false },
          { name: "Bot", value: `${client.user.tag} (${client.user.id})`, inline: false } // QUEL bot
        )
        .setFooter({ text: `via ${client.user.tag}`, iconURL: client.user.displayAvatarURL({ size: 128 }) })
        .setTimestamp();

      // Dans le panel : si URL, on peut pré-visualiser ; si fichier (Buffer), on ne peut pas sans renvoyer un fichier → on n'affiche pas ici
      if (state.image && state.image.kind === "url") {
        emb.setImage(state.image.url);
      }
      return emb;
    };

    const buildMenus = () => {
      // Menu 1: catégorie + modifier description + ajouter/retirer image
      const row1 = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId(`bug:${message.id}:cat`)
          .setPlaceholder("C’est quoi qui bug…")
          .addOptions(
            { label: "Ne répond pas / plante", value: "Ne répond pas / plante" },
            { label: "Permissions / accès", value: "Permissions / accès" },
            { label: "Erreur en console", value: "Erreur en console" },
            { label: "Base de données", value: "Base de données" },
            { label: "Interface / panel", value: "Interface / panel" },
            { label: "Autre", value: "Autre" },
            { label: "✍️ Modifier la description…", value: "__describe", description: "Réécrire le problème (obligatoire pour envoyer)" },
            { label: state.image ? "🗑️ Retirer l’image" : "➕ Ajouter une image…", value: "__image", description: state.image ? "Supprimer l’image du brouillon" : "Joindre un fichier ou coller un lien" },
          )
      );

      // Menu 2: actions (envoyer / reset)
      const row2 = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId(`bug:${message.id}:act`)
          .setPlaceholder("Action…")
          .addOptions(
            { label: "📨 Envoyer le rapport", value: "send", description: "Publier l’embed dans le webhook" },
            { label: "🧹 Réinitialiser (catégorie/image)", value: "reset", description: "Ne touche pas à la commande/description obligatoires" },
          )
      );
      return [row1, row2];
    };

    const panel = await message.channel.send({ embeds: [buildEmbedPanel()], components: buildMenus() });
    const collector = panel.createMessageComponentCollector({ time: 15 * 60 * 1000 });

    collector.on("collect", async (i) => {
      if (i.user.id !== state.authorId) return i.reply({ content: "Seul l’initiateur peut utiliser ces menus.", ephemeral: true });
      const [prefix, msgId, kind] = i.customId.split(":");
      if (prefix !== "bug" || msgId !== message.id) return;
      await i.deferUpdate().catch(()=>{});

      try {
        if (kind === "cat") {
          const pick = i.values?.[0];

          if (pick === "__describe") {
            const newDesc = await askOnce("✍️ Réécris la **description du problème** (obligatoire) :", { timeoutMs: 120_000 });
            if (newDesc) state.description = String(newDesc).slice(0, 1900);
          }
          else if (pick === "__image") {
            if (state.image) {
              // Retirer l'image actuelle
              state.image = null;
              const ok = await message.channel.send("🗑️ Image retirée du rapport.");
              setTimeout(() => ok.delete().catch(()=>{}), 3000);
            } else {
              const resp = await askOnce("🖼️ Envoie **une image** (fichier) **ou** colle un **lien direct** :", { acceptAttachment: true, timeoutMs: 120_000 });
              if (resp && typeof resp === "object" && (resp.kind === "file" || resp.kind === "url")) {
                state.image = resp;
                const ok = await message.channel.send("✅ Image ajoutée au rapport.");
                setTimeout(() => ok.delete().catch(()=>{}), 3000);
              } else if (resp && typeof resp === "string" && isLikelyImageUrl(resp)) {
                state.image = { kind: "url", url: resp };
                const ok = await message.channel.send("✅ Image ajoutée au rapport (URL).");
                setTimeout(() => ok.delete().catch(()=>{}), 3000);
              } else {
                const warn = await message.channel.send("❌ Aucune image valide détectée.");
                setTimeout(() => warn.delete().catch(()=>{}), 4000);
              }
            }
          }
          else {
            state.category = pick;
          }
        }

        if (kind === "act") {
          const pick = i.values?.[0];

          if (pick === "reset") {
            state.category = null;
            state.image = null;
            const ok = await message.channel.send("🧹 Réinitialisé : catégorie et image. (Commande & description restent.)");
            setTimeout(() => ok.delete().catch(()=>{}), 3000);
          }

          if (pick === "send") {
            // Sécurité : commande + description obligatoires
            if (!state.commandName || !state.description) {
              const warn = await message.channel.send("❌ Impossible d’envoyer : **commande** et **description** sont obligatoires.");
              setTimeout(() => warn.delete().catch(()=>{}), 5000);
            } else {
              try {
                const authorUser = message.guild.members.cache.get(state.authorId)?.user || message.author;

                const out = new EmbedBuilder()
                  .setColor(0xED4245)
                  .setTitle("🐞 Nouveau bug signalé")
                  .setAuthor({ name: authorUser.tag, iconURL: authorUser.displayAvatarURL({ size: 128 }) }) // QUI envoie
                  .addFields(
                    { name: "Bot", value: `${client.user.tag} (${client.user.id})`, inline: false }, // QUEL bot
                    { name: "Serveur", value: `${message.guild.name} (${message.guild.id})`, inline: false },
                    { name: "Salon", value: `#${message.channel.name} (${message.channel.id})`, inline: false },
                    { name: "Commande", value: `\`${state.commandName}\``, inline: false },
                    { name: "Catégorie", value: state.category || "_non définie_", inline: false },
                    { name: "Description", value: state.description, inline: false },
                  )
                  .setFooter({ text: `via ${client.user.tag}`, iconURL: client.user.displayAvatarURL({ size: 128 }) })
                  .setTimestamp();

                let files = undefined;
                if (state.image) {
                  if (state.image.kind === "file" && state.image.data) {
                    // Réupload depuis le Buffer
                    const safeName = state.image.name && state.image.name.length <= 100 ? state.image.name : "image.png";
                    out.setImage(`attachment://${safeName}`);
                    files = [{ attachment: state.image.data, name: safeName }];
                  } else if (state.image.kind === "url") {
                    out.setImage(state.image.url);
                  }
                }

                await hook.send({ embeds: [out], files });
                const done = await message.channel.send("✅ Rapport envoyé au webhook !");
                setTimeout(() => done.delete().catch(()=>{}), 4000);
                collector.stop("sent");
              } catch (e) {
                const err = await message.channel.send(`❌ Échec d’envoi au webhook : ${String(e.message || e).slice(0, 1800)}`);
                setTimeout(() => err.delete().catch(()=>{}), 8000);
              }
            }
          }
        }

        // MAJ du panel
        await panel.edit({ embeds: [buildEmbedPanel()], components: buildMenus() }).catch(()=>{});
      } catch (e) {
        const err = await message.channel.send("❌ Erreur lors du traitement du menu.");
        setTimeout(() => err.delete().catch(()=>{}), 5000);
      }
    });

    collector.on("end", async () => {
      try { await panel.edit({ components: [] }); } catch {}
    });
  }
};
