const { ActivityType } = require('discord.js');
const db = require('quick.db');

module.exports = {
  name: "stream",
  description: "Définit l’activité Streaming.>",
  usage: "stream [url_optionnelle] <texte…>",
  category: "status",
  run: async (client, message, args, commandName = "stream") => {
    if (!message.guild) return;

    // PERMS: staff, buyers, owner_global (+ systeme perm DB optionnel)
    const hasPerms = () => {
      if (client.staff?.includes(message.author.id)) return true;
      if (client.config?.buyers?.includes(message.author.id)) return true;
      if (client.db.get(`owner_global_${message.author.id}`) === true) return true;
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member?.roles?.cache?.map(r => r.id) || [];
        return commandPerms.some(perm => userPerms[perm]?.some?.(rid => userRoles.includes(rid)));
      }
      if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") return true;
      return false;
    };
    if (!hasPerms()) {
      if (client.noperm && client.noperm.trim() !== "") {
        const sent = await message.channel.send(client.noperm);
        const delay = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delay > 0) setTimeout(()=>sent.delete().catch(()=>{}), delay*1000);
      }
      return;
    }

    if (!args.length) return message.reply("Utilisation : `+stream [url_optionnelle] <texte…>`");

    // URL optionnelle en premier argument
    let streamURL = null;
    if (/^https?:\/\//i.test(args[0])) streamURL = args.shift();
    const rawText = args.join(" ").trim();
    if (!rawText) return message.reply("Donne un texte d’activité.");

    // Placeholders FiveM
    const last = client.db.get(`fivem_last_${message.guild.id}`) || {count:"unknown",max:"unknown",host:"unknown",gametype:"unknown",map:"unknown",status:"unknown"};
    const resolve = (txt) => String(txt)
      .replace(/\{FivemMembersCount\}/g, String(last.count ?? 'unknown'))
      .replace(/\{FivemMaxMembers\}/g,   String(last.max ?? 'unknown'))
      .replace(/\{FivemHostName\}/g,     String(last.host ?? 'unknown'))
      .replace(/\{FivemGameType\}/g,     String(last.gametype ?? 'unknown'))
      .replace(/\{FivemMapName\}/g,      String(last.map ?? 'unknown'))
      .replace(/\{FivemStatus\}/g,       String(last.status ?? 'unknown'));

    const presence = client.db.get('presence') || 'online';
    const textResolved = resolve(rawText);

    // Sauvegarde au même endroit que botconfig
    db.set('type', 'STREAMING');
    db.set('nomstatut', textResolved);
    if (streamURL) db.set('streamURL', streamURL);
    const urlToUse = streamURL || db.get('streamURL') || undefined;

    await client.user.setPresence({
      activities: [{ name: textResolved, type: ActivityType.Streaming, url: urlToUse }],
      status: presence
    });

    // Auto-refresh toutes les 60s si {Fivem...} présent
    if (/\{Fivem/i.test(rawText)) {
      if (client._presenceTimer) clearInterval(client._presenceTimer);
      client._presenceTemplate = rawText;
      client._presenceType = 'STREAMING';
      client._presenceGuild = message.guild.id;

      client._presenceTimer = setInterval(async () => {
        try {
          const ref = client.db.get(`fivem_last_${client._presenceGuild}`) || {};
          const again = String(client._presenceTemplate)
            .replace(/\{FivemMembersCount\}/g, String(ref.count ?? 'unknown'))
            .replace(/\{FivemMaxMembers\}/g,   String(ref.max ?? 'unknown'))
            .replace(/\{FivemHostName\}/g,     String(ref.host ?? 'unknown'))
            .replace(/\{FivemGameType\}/g,     String(ref.gametype ?? 'unknown'))
            .replace(/\{FivemMapName\}/g,      String(ref.map ?? 'unknown'))
            .replace(/\{FivemStatus\}/g,       String(ref.status ?? 'unknown'));
          db.set('nomstatut', again);
          await client.user.setPresence({
            activities: [{ name: again, type: ActivityType.Streaming, url: db.get('streamURL') }],
            status: client.db.get('presence') || 'online'
          });
        } catch {}
      }, 60_000);
    } else if (client._presenceTimer) { clearInterval(client._presenceTimer); client._presenceTimer = null; }

    return message.reply(`Activité **Streaming** définie${streamURL ? ` (URL mise à jour)` : ''}.`);
  }
};
