const { EmbedBuilder } = require('discord.js')
const { Astroia } = require('../../structures/client')

module.exports = {
    name: "clearowners",
    description: "Supprime les owners (locaux ou globaux)",
    use: "<here/all>",
    category: "owner",
    example: "➜ clearowners here\n➜ clearowners all",

    run: async (client, message, args) => {
        let pass = false

        if (client.config.buyers.includes(message.author.id)) {
            pass = true
        }

        if (!pass) {
            if (client.noperm && client.noperm.trim() !== '') {
                const sentMessage = await message.channel.send(client.noperm)
                const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0
                if (delayTime > 0) {
                    setTimeout(() => {
                        sentMessage.delete().catch(() => {})
                    }, delayTime * 1000)
                }
            }
            return
        }

        const scope = args[0]
        if (!scope || !['here', 'all'].includes(scope)) {
        return message.channel.send(`Utilisation : \`${client.prefix}clearowners <here/all>\``)
        }

        const data = await client.db.all()
        const toDelete = data.filter(entry => {
            if (scope === 'here') return entry.ID.startsWith(`owner_${message.guild.id}_`)
            if (scope === 'all') return entry.ID.startsWith('owner_global_')
        })

        for (let i = 0; i < toDelete.length; i++) {
            client.db.delete(toDelete[i].ID)
        }

        const txt = scope === 'all' ? 'tous les serveurs' : 'ce serveur'
        message.channel.send(`${toDelete.length} owner(s) supprimé(s) pour ${txt}`)
    }
}
