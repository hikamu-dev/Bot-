// commands/admin/owner.js
const Discord = require('discord.js')
const { Astroia } = require('../../structures/client')

module.exports = {
    name: "owner",
    description: "Permet d'ajouter ou de lister les owners",
    use: "<here/all> <@utilisateur/id>",
    usages: "owner <here/all> <@utilisateur/id>",
    example: "➜ owner here @Phebo\n➜ owner all 123456789012345678",

    run: async (client, message, args) => {
        let pass = false

        // Accès buyers (existant)
        if (client?.staff?.includes?.(message.author.id)) pass = true;
        if (client.config.buyers.includes(message.author.id)) {
            pass = true
        }

        // === BYPASS AUTORISE (ajouté) ===
        // Autorisé global -> peut utiliser owner here & owner all
        // Autorisé local  -> peut utiliser owner here dans ce serveur
        if (
          client.db.get(`owner_cmd_allow_global_${message.author.id}`) === true ||
          client.db.get(`owner_cmd_allow_${message.guild.id}_${message.author.id}`) === true
        ) {
          pass = true
        }

        if (!pass) {
            if (client.noperm && client.noperm.trim() !== '') {
                const sentMessage = await message.channel.send(client.noperm)
                const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0
                if (delayTime > 0) {
                    setTimeout(() => {
                        sentMessage.delete().catch(() => {})
                    }, delayTime * 1000)
                }
            }
            return
        }

        if (!args[0]) {
            let data = await client.db.all()
            let ownerList = data.filter(entry => {
                return entry.ID.startsWith('owner_global_') || entry.ID.startsWith(`owner_${message.guild.id}_`)
            }).map(entry => {
                const id = entry.ID.includes('global') ? entry.ID.split('_')[2] : entry.ID.split('_')[2]
                const type = entry.ID.includes('global') ? '(Global)' : '(Serveur)'
                return `<@${id}> ${type}`
            }).join('\n') || "Aucun"

            let embed = new Discord.EmbedBuilder()
                .setColor(client.color)
                .setTitle(await client.lang("owner.titre"))
                .setDescription(ownerList)
                .setFooter(client.footer)

            message.channel.send({ embeds: [embed] })
        }

        else if (args[0].toLowerCase() === 'here' || args[0].toLowerCase() === 'all') {
            const scope = args[0].toLowerCase()
            const target = args[1]

            if (!target) return message.channel.send("Veuillez spécifier un utilisateur ou un ID.")

            let member = message.mentions.members.first() || message.guild.members.cache.get(target)
            if (!member) return message.channel.send("Utilisateur introuvable.")

            const ownerKey = scope === 'all' ? `owner_global_${member.id}` : `owner_${message.guild.id}_${member.id}`

            if (client.db.get(ownerKey)) {
                return message.channel.send(`${member.user.username} est déjà owner.`)
            }

            client.db.set(ownerKey, true)
            const scopeText = scope === 'all' ? 'tous les serveurs' : 'ce serveur'
            message.channel.send(`${member.user.username} a été ajouté comme owner sur ${scopeText}`)

            // === DM aux buyers (ajouté) ===
            try {
              const buyers = Array.isArray(client.config?.buyers) ? client.config.buyers : []
              const addedBy = `${message.author.tag} (${message.author.id})`
              const addedUser = `${member.user.tag} (${member.id})`
              const guildInfo = `${message.guild.name} (${message.guild.id})`
              const scopeLabel = scope === 'all' ? 'GLOBAL (owner all)' : 'LOCAL (owner here)'

              for (const buyerId of buyers) {
                try {
                  const user = await client.users.fetch(buyerId).catch(() => null)
                  if (!user) continue
                  await user.send(
                    `✅ **NOUVEL OWNER AJOUTÉ**\n` +
                    `• **Ajouté par :** ${addedBy}\n` +
                    `• **Utilisateur :** ${addedUser}\n` +
                    `• **Portée :** ${scopeLabel}\n` +
                    `• **Serveur :** ${guildInfo}\n` +
                    `• **Date :** <t:${Math.floor(Date.now()/1000)}:F>`
                  ).catch(() => {})
                } catch {}
              }
            } catch {}
        }

        else {
            message.channel.send("Argument invalide. Utilisez `here` ou `all`.")
        }
    }
}
