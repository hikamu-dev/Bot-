// commands/admin/unowner.js
const { example } = require("../Owner/aliases");

module.exports = {
  name: "unowner",
  description: "Permet d'enlever un owner",
  use: "<here/all> <@utilisateur/id>",
  usages: "unowner <here/all> <@utilisateur/id>",
  example: "➜ unowner here @Phebo\n➜ unowner all 123456789012345678",

  run: async (client, message, args, commandName) => {
    let pass = false;

    // Buyers
    if (client.config.buyers.includes(message.author.id)) {
      pass = true;
    }

    // --- BYPASS via autorise.js (ajouté) ---
    if (
      client.db.get(`owner_cmd_allow_global_${message.author.id}`) === true ||
      client.db.get(`owner_cmd_allow_${message.guild.id}_${message.author.id}`) === true
    ) {
      pass = true;
    }

    if (!pass) {
      if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
          setTimeout(() => {
            sentMessage.delete().catch(() => {});
          }, delayTime * 1000);
        }
      } else {
        return message.channel.send("Vous n'avez pas la permission d'utiliser cette commande.");
      }
      return;
    }

    if (!args[0]) return message.channel.send(await client.lang("unowner.erreur"));

    if (args[0].toLowerCase() === 'here' || args[0].toLowerCase() === 'all') {
      const scope = args[0].toLowerCase();
      const target = args[1];

      if (!target) return message.channel.send(await client.lang("unowner.erreur"));

      let member = message.mentions.members.first() || message.guild.members.cache.get(target);
      if (!member) return message.channel.send(await client.lang("unowner.erreur"));

      const ownerKey = scope === 'all' ? `owner_global_${member.id}` : `owner_${message.guild.id}_${member.id}`;
      
      if (!client.db.get(ownerKey)) {
        return message.channel.send(`${member.user.username} n'est pas owner sur ${scope === 'all' ? 'tous les serveurs' : 'ce serveur'}.`);
      }

      client.db.delete(ownerKey);
      const scopeText = scope === 'all' ? 'tous les serveurs' : 'ce serveur';
      message.channel.send(`\`${member.user.username}\` n'est plus owner sur ${scopeText}`);
    } else {
      message.channel.send(await client.lang("unowner.erreur"));
    }
  }
};
