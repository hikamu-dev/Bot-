const Discord = require('discord.js');
const fs = require('fs');
const { Astroia } = require('../../structures/client/index.js');

module.exports = {
    name: "timestamp",
    description: "Affiche le temps sous différents formats de timestamp à partir d'une durée",
    use: "timestamp <durée>",
    usage: "timestamp 10m",
    example: "➜ +timestamp 1h",
    /**
     * @param {Astroia} client
     * @param {Discord.Message} message
     * @param {string[]} args
     * @returns
     */
    run: async (client, message, args, commandName) => {
        try {
            let pass = false;

            // Autoriser automatiquement les staff, buyers, et owners
            if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
        client.db.get(`owner_global_${message.author.id}`) === true || 
client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {                   pass = true;
            } else {
                const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
                if (commandPerms.length > 0) {
                    const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                    const userRoles = message.member.roles.cache.map(role => role.id);
                    pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
                } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                    pass = true;
                }
            }

            if (!pass) {
                if (client.noperm && client.noperm.trim() !== '') {
                    const sentMessage = await message.channel.send(client.noperm);
                    const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
                    if (delayTime > 0) {
                        setTimeout(() => sentMessage.delete().catch(() => {}), delayTime * 1000);
                    }
                }
                return;
            }

            if (!args[0]) {
                return message.channel.send("Veuillez entrer une durée (ex: 10m, 1h, 2d)");
            }

            const durationStr = args[0].toLowerCase();
            const timeMatch = durationStr.match(/(\d+)([mhd])/);
            if (!timeMatch) {
                return message.channel.send("Format invalide. Utilisez ex: 10m (minutes), 1h (heures), 2d (jours)");
            }

            const value = parseInt(timeMatch[1]);
            const unit = timeMatch[2];
            let milliseconds = 0;

            switch (unit) {
                case 'm': milliseconds = value * 60 * 1000; break; // Minutes
                case 'h': milliseconds = value * 60 * 60 * 1000; break; // Heures
                case 'd': milliseconds = value * 24 * 60 * 60 * 1000; break; // Jours
            }

            const now = new Date();
            const futureDate = new Date(now.getTime() + milliseconds);

            const embed = new Discord.EmbedBuilder()
                .setColor(client.color)
                .setTitle("Timestamps")
                .setDescription(`Durée: ${value}${unit}`)
                .addFields(
                    { name: "Heure actuelle", value: `<t:${Math.floor(now / 1000)}>` },
                    { name: "Heure future", value: `<t:${Math.floor(futureDate / 1000)}>`, inline: true },
                    { name: "Date (DD/MM/YYYY)", value: `<t:${Math.floor(futureDate / 1000)}:d>`, inline: true },
                    { name: "Heure (HH:mm)", value: `<t:${Math.floor(futureDate / 1000)}:t>`, inline: true },
                    { name: "Date + Heure", value: `<t:${Math.floor(futureDate / 1000)}:f>`, inline: true },
                    { name: "Relatif (ex: dans 1 heure)", value: `<t:${Math.floor(futureDate / 1000)}:R>`, inline: true }
                )
                .setFooter(client.footer);

            await message.channel.send({ embeds: [embed] });

        } catch (error) {
            console.error('Erreur lors de l\'exécution de la commande timestamp:', error);
            await message.channel.send('Une erreur est survenue lors de l\'exécution de la commande.');
        }
    }
};