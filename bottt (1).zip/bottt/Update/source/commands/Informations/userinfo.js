const Discord = require('discord.js');
const ms = require("ms");
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ComponentType } = require("discord.js");
const { example } = require('./help');

const Badges = {
    'HypeSquadOnlineHouse1': "HypeSquad Bravery",
    'HypeSquadOnlineHouse2': "HypeSquad Brilliance",
    'HypeSquadOnlineHouse3': "HypeSquad Balance",
    'HypeSquadEvents': "HypeSquad Events",
    'ActiveDeveloper': 'Active Developer',
    'BugHunterLevel1': 'Bug Hunter Level 1',
    'EarlySupporter': 'Early Supporter',
    'VerifiedBotDeveloper': 'Verified Bot Developer',
    'EarlyVerifiedBotDeveloper': "Early Verified Bot Developer",
    'VerifiedBot': "Verified Bot",
    'PartneredServerOwner': "Partnered Server Owner",
    'Staff': "Discord Staff",
    'System': "Discord System",
    'BugHunterLevel2': 'Bug Hunter Level 2',
    'BugHunterLevel3': 'Bug Hunter Level 3',
};

module.exports = {
    name: "userinfo",
    aliases: ["ui"],
    description: "Affiche les informations d'un utilisateur.",
    usage: "<@user/id>",
    example: "➜ userinfo @tokyru\n➜ userinfo 123456789012345678",

    run: async (client, message, args, commandName) => {
        let pass = false;

        if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
        client.db.get(`owner_global_${message.author.id}`) === true || 
client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {               pass = true;
        } else {
            const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
            if (commandPerms.length > 0) {
                const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                const userRoles = message.member.roles.cache.map(role => role.id);
                pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
            } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                pass = true;
            }
        }

if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        let target;

        if (args[0]) {
            target = message.mentions.members.first() || await message.guild.members.fetch(args[0]).catch(() => null);
            if (!target || !(target instanceof Discord.GuildMember)) {
                return message.channel.send("❌ Utilisateur introuvable ou invalide.");
            }
        } else {
            target = message.member;
        }

        const member = target;
        const user = await target.user.fetch({ force: true }); // <-- pour premiumType avec force refresh

        let roles = member.roles.cache.size > 0 ? member.roles.cache.map(r => r.toString()).join(" ") : "Aucun rôle";
        if (member.roles.cache.size > 5) roles = "Trop de rôles pour les afficher ici 😅";
        let rolebutton = member.roles.cache.size > 0 ? member.roles.cache.map(r => r.toString()).join(" ") : "Aucun rôle";

        const badges = user.flags?.toArray?.() || [];
        let userBadges = badges.map(b => Badges[b]).filter(Boolean);

        // DEBUG: Ajoutons des logs pour voir ce qui se passe

        // 🎖️ Nitro selon premiumType (CORRIGÉ)
        switch (user.premiumType) {
            case 1:
                userBadges.push("💎 Nitro Classic");
                //console.log(`[DEBUG] Ajouté: Nitro Classic`);
                break;
            case 2:
                userBadges.push("💎 Nitro");
                //console.log(`[DEBUG] Ajouté: Nitro`);
                break;
            case 3:
                userBadges.push("💎 Nitro Basic");
                //console.log(`[DEBUG] Ajouté: Nitro Basic`);
                break;
            default:
                //console.log(`[DEBUG] Aucun Nitro détecté (type: ${user.premiumType})`);
                break;
        }

        // 🎖️ Méthode alternative : Vérifier via l'avatar animé ou la bannière
        if (user.premiumType === undefined || user.premiumType === null) {
            //console.log(`[DEBUG] Tentative de détection alternative...`);
            
            // Si l'utilisateur a une bannière ou un avatar animé, il a probablement Nitro
            if (user.banner || (user.avatar && user.avatar.startsWith('a_'))) {
                userBadges.push("💎 Nitro");
                //console.log(`[DEBUG] Nitro détecté via banner/avatar animé`);
            }
        }

        // 🚀 Boost serveur
        if (member.premiumSince) {
            userBadges.push("🚀 Server Booster");
            //console.log(`[DEBUG] Ajouté: Server Booster`);
        }

        //console.log(`[DEBUG] User Badges final: ${JSON.stringify(userBadges)}`);
        //console.log(`[DEBUG] User Badges length: ${userBadges.length}`);

        if (userBadges.length === 0) userBadges.push("Aucun badge");

        let status = member.presence?.status || "offline";
        status = {
            online: "🟢 En ligne",
            idle: "🌙 Inactif",
            dnd: "⛔ Ne pas déranger",
            offline: "⚫ Hors ligne"
        }[status];

        let statusperso = member.presence?.activities[0]?.state || "Aucune activité";

        const platforms = Object.keys(member.presence?.clientStatus || {});
        const platformString = platforms.map(p => ({
            desktop: "🖥️ Ordinateur",
            mobile: "📱 Mobile",
            web: "🌐 Web"
        }[p])).join(", ") || "Inconnu";

        const embed = new EmbedBuilder()
            .setColor(client.color)
            .setAuthor({ name: `${user.username}`, iconURL: user.displayAvatarURL({ dynamic: true }) })
            .setThumbnail(user.displayAvatarURL({ dynamic: true }))
            .setDescription(`📋 Voici les informations sur **<@${user.id}>**`)
            .addFields(
                { name: "🆔 Identifiant", value: `\`${user.id}\``, inline: true },
                { name: "🤖 Bot", value: user.bot ? "✅ Oui" : "❌ Non", inline: true },
                { name: "📶 Statut", value: status, inline: true },
                { name: "💻 Plateforme", value: platformString, inline: true },
                { name: "📝 Statut personnalisé", value: `\`${statusperso}\``, inline: false },
                { name: `🎖️ Badges [${userBadges.length}]`, value: userBadges.map(b => `• ${b}`).join("\n"), inline: false },
                { name: "📅 Création du compte", value: `<t:${Math.floor(user.createdAt / 1000)}:F>`, inline: true },
                { name: "📥 Rejoint le serveur", value: `<t:${Math.floor(member.joinedAt / 1000)}:F>`, inline: true },
                { name: `🎭 Rôles [${member.roles.cache.size}]`, value: roles || "Aucun rôle", inline: false }
            )
            .setImage(user.bannerURL({ format: 'png', size: 4096 }) || null)
            .setFooter({ text: client.footer?.text || "Informations utilisateur", iconURL: client.user.displayAvatarURL() })
            .setTimestamp();

        if (member.premiumSince) {
            embed.addFields({
                name: "🚀 Server Boost",
                value: `Depuis le <t:${Math.floor(member.premiumSince / 1000)}:F>`,
                inline: true
            });
        }

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId(`userinfo_allrole_${message.id}`)
                .setLabel("📜 Voir tous les rôles")
                .setStyle(Discord.ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId(`userinfo_badge_${message.id}`)
                .setLabel("🎖️ Voir tous les badges")
                .setStyle(Discord.ButtonStyle.Success),
            new ButtonBuilder()
                .setLabel("🔗 Voir le profil")
                .setStyle(Discord.ButtonStyle.Link)
                .setURL(`https://discord.com/users/${user.id}`)
        );

        const msg = await message.reply({ embeds: [embed], components: [row] });

        const collectuser = message.channel.createMessageComponentCollector({
            filter: m => m.user.id === message.author.id,
            componentType: ComponentType.Button,
            time: ms("2m")
        });

        collectuser.on("collect", async (i) => {
            if (i.customId === `userinfo_allrole_${message.id}`) {
                const roleEmbed = new EmbedBuilder()
                    .setColor(client.color)
                    .setTitle(`🎭 Rôles de ${user.username}`)
                    .setDescription(rolebutton || "Aucun rôle")
                    .setFooter({ text: client.footer?.text })
                    .setTimestamp();
                return i.reply({ embeds: [roleEmbed], ephemeral: true });
            }

            if (i.customId === `userinfo_badge_${message.id}`) {
                const badgeEmbed = new EmbedBuilder()
                    .setColor(client.color)
                    .setTitle(`🎖️ Badges de ${user.username}`)
                    .setDescription(userBadges.length > 0 ? userBadges.map(b => `• ${b}`).join("\n") : "Aucun badge")
                    .setFooter({ text: client.footer?.text })
                    .setTimestamp();
                return i.reply({ embeds: [badgeEmbed], ephemeral: true });
            }
        });

        collectuser.on("end", () => {
            msg.edit({ components: [] });
        });
    },
};