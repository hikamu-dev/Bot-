const { EmbedBuilder, PermissionsBitField } = require('discord.js');
const { example } = require('./help');

module.exports = {
  name: 'roleinfo',
  description: "Affiche les informations détaillées d'un rôle donné",
  use: "<@role/id>",
  usage: "roleinfo <@role/id>",
  example: "➜ roleinfo @Admin\n➜ roleinfo 123456789012345678",
  /**
   * 
   * @param {Astroia} client 
   * @param {Discord.Message} message
   * @param {string[]} args 
   */
  run: async (client, message, args, commandName) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
        client.db.get(`owner_global_${message.author.id}`) === true || 
client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

    // Vérifier si un rôle est fourni
    if (!args[0]) {
      return message.channel.send({ content: await client.lang('roleinfo.norole') || "Veuillez mentionner un rôle ou fournir son ID." });
    }

    // Trouver le rôle
    const role = message.mentions.roles.first() || message.guild.roles.cache.get(args[0]) || message.guild.roles.cache.find(r => r.name === args.join(' '));
    if (!role) {
      return message.channel.send({ content: await client.lang('roleinfo.erreurrole') || "Rôle introuvable. Veuillez vérifier la mention ou l'ID." });
    }

    // Calculer les permissions clés
    const permissions = new PermissionsBitField(role.permissions);
    const hasAdminPerm = permissions.has(PermissionsBitField.Flags.Administrator);
    
    const keyPermissions = [
      { name: "Administrateur", value: hasAdminPerm },
      { name: "Gérer le serveur", value: permissions.has(PermissionsBitField.Flags.ManageGuild) },
      { name: "Gérer les rôles", value: permissions.has(PermissionsBitField.Flags.ManageRoles) },
      { name: "Gérer les canaux", value: permissions.has(PermissionsBitField.Flags.ManageChannels) },
      { name: "Expulser des membres", value: permissions.has(PermissionsBitField.Flags.KickMembers) },
      { name: "Bannir des membres", value: permissions.has(PermissionsBitField.Flags.BanMembers) },
      { name: "Mentionner @everyone", value: hasAdminPerm || role.mentionable }
    ];

    // Créer l'embed avec les informations du rôle
    const embed = new EmbedBuilder()
      .setColor(role.hexColor || client.color)
      .setFooter(client.footer)
      .setTitle(`Informations du rôle : ${role.name}`)
      .addFields(
        { name: 'Nom', value: role.name, inline: true },
        { name: 'ID', value: role.id, inline: true },
        { name: 'Couleur', value: role.hexColor, inline: true },
        { name: 'Position', value: `${role.position}/${message.guild.roles.cache.size - 1}`, inline: true },
        { name: 'Mentionnable', value: role.mentionable ? 'Oui' : 'Non', inline: true },
        { name: 'Affiché séparément', value: role.hoist ? 'Oui' : 'Non', inline: true },
        { name: 'Membres', value: `${role.members.size}`, inline: true },
        { name: 'Date de création', value: `<t:${Math.floor(role.createdTimestamp / 1000)}:F>`, inline: true },
        {
          name: 'Permissions clés',
          value: keyPermissions.map(perm => `${perm.name}: ${perm.value ? '✅' : '❌'}`).join('\n') || 'Aucune',
          inline: false
        }
      )
      .setThumbnail(role.icon ? role.iconURL() : null);

    // Envoyer l'embed
    message.channel.send({ embeds: [embed] });
  }
};