const axios = require('axios');
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require('discord.js');
const ms = require('ms');
const { example } = require('./help');

module.exports = {
  name: 'prevname',
  description: 'Affiche vos anciens pseudos',
  use: "<@utilisateur/id>",
  usages: 'prevname <@utilisateur/id>',
  example: '➜ prevname @tokyru\n➜ prevname 123456789012345678',

  run: async (client, message, args, commandName) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
        client.db.get(`owner_global_${message.author.id}`) === true || 
client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

    const original = await message.channel.send({ content: await client.lang('prevname.recherche') });
    let target;

    if (message.mentions.members.first()) {
      target = message.mentions.members.first();
    } else if (args[0]) {
      try {
        target = await client.users.fetch(args[0]);
      } catch (error) {
        return original.edit(await client.lang('prevname.nouser'));
      }
    } else {
      target = message.member;
    }

    const userId = target.id;

    try {
      const response = await axios.get(`http://localhost:3002/prevnames/${userId}`);
      const pseudonyms = response.data.pseudonyms;

      if (pseudonyms.length === 0) {
        return original.edit(await client.lang('prevname.nopseudo'));
      }

      const embed = new EmbedBuilder()
      .setColor(client.color)
      .setTitle(`📜 Historique des pseudos de ${target.username || target.user.username}`)
      .setThumbnail(target.displayAvatarURL({ dynamic: true }))
      .setDescription(
        pseudonyms
          .map((entry, index) => {
            const timestamp = Math.floor(entry.timestamp); // Pas besoin de diviser par 1000
            return `> **#${index + 1}**\n> Pseudo : \`${entry.old_name}\`\n> 📆 <t:${timestamp}:F>`;
          })
          .join('\n\n')
      )
      .setFooter({ text: `${await client.lang('prevname.footer')} ${pseudonyms.length}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
      .setTimestamp();
    

      const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId(`prevname_button_${message.id}`)
            .setLabel('Supprimer')
            .setEmoji('🗑️')
            .setStyle(ButtonStyle.Danger)
        );

      const reply = await original.edit({ embeds: [embed], components: [row], content: null });

      const collector = reply.createMessageComponentCollector({
        filter: i => i.user.id === target.user?.id || target.id,
        componentType: ComponentType.Button,
        time: ms('2m')
      });

      collector.on('collect', async (interaction) => {
        if (interaction.customId === `prevname_button_${message.id}`) {
          await interaction.reply({ content: await client.lang('prevname.buttonreply'), ephemeral: true });
          reply.delete().catch(console.error);
        }
      });

      collector.on('end', collected => {
        if (collected.size === 0) {
          reply.delete().catch(console.error);
        }
      });

    } catch (error) {
      console.error('Error fetching pseudonyms:', error);
      original.edit(await client.lang('erreur'));
    }
  }
};
