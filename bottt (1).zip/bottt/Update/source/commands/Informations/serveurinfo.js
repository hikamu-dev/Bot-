const Discord = require('discord.js');
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ComponentType } = require('discord.js');
const ms = require('ms');

module.exports = {
    name: 'serveurinfo',
    aliases: ['si'],
    description: 'Affiche les informations du serveur.',
    usage: '',

    run: async (client, message, args, commandName) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
        client.db.get(`owner_global_${message.author.id}`) === true || 
client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        // Collecte des informations du serveur
        const membersGuild = await message.guild.members.fetch();
        const channelsGuild = message.guild.channels.cache;
        const rolesGuild = message.guild.roles.cache.sort((a, b) => b.position - a.position);
        const emojisGuild = message.guild.emojis.cache;
        const owner = await client.users.fetch(message.guild.ownerId);

        const humains = membersGuild.filter(h => !h.user.bot).size;
        const bots = membersGuild.filter(b => b.user.bot).size;
        const totalmembre = membersGuild.size;
        const textChannels = channelsGuild.filter(channel => channel.type === 0).size;
        const voiceChannels = channelsGuild.filter(channel => channel.type === 2).size;

        // Création de l'embed principal
        const embed = new EmbedBuilder()
            .setColor(client.color)
            .setAuthor({ name: `${message.guild.name}`, iconURL: message.guild.iconURL({ dynamic: true }) })
            .setThumbnail(message.guild.iconURL({ dynamic: true, size: 1024 }))
            .setDescription(`📋 Voici les informations sur **${message.guild.name}**`)
            .addFields(
                { name: '👑 Propriétaire', value: `<@${owner.id}>`, inline: true },
                { name: '📅 Création', value: `<t:${Math.floor(message.guild.createdAt / 1000)}:F>`, inline: true },
                { name: '👤 Membres', value: `\`${totalmembre}\` Total\n\`${humains}\` Humain(s)\n\`${bots}\` Robot(s)`, inline: true },
                { name: '🎭 Rôles', value: `\`${rolesGuild.size}\``, inline: true },
                { name: '⚪ Emojis', value: `\`${emojisGuild.size}\``, inline: true },
                { name: '📜 Salons', value: `\`${textChannels}\` Textuel(s)\n\`${voiceChannels}\` Vocal(s)`, inline: true },
                { name: '💎 Boosts', value: `\`${message.guild.premiumSubscriptionCount || '0'}\` (Niveau ${message.guild.premiumTier || '0'})`, inline: true }
            )
            .setImage(message.guild.bannerURL({ format: 'png', size: 4096 }) || null)
            .setFooter({ text: client.footer?.text || 'Informations serveur', iconURL: client.user.displayAvatarURL() })
            .setTimestamp();

        // Création des boutons interactifs
        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId(`serveurinfo_roles_${message.id}`)
                .setLabel('📜 Voir tous les rôles')
                .setStyle(Discord.ButtonStyle.Secondary),
            new ButtonBuilder()
                .setCustomId(`serveurinfo_emojis_${message.id}`)
                .setLabel('⚪ Voir tous les emojis')
                .setStyle(Discord.ButtonStyle.Secondary)
        );

        // Envoi du message avec l'embed et les boutons
        const msg = await message.reply({ embeds: [embed], components: [row] });

        // Collecteur pour les interactions avec les boutons
        const collectServer = message.channel.createMessageComponentCollector({
            filter: m => m.user.id === message.author.id,
            componentType: ComponentType.Button,
            time: ms('2m')
        });

        collectServer.on('collect', async (i) => {
            if (i.customId === `serveurinfo_roles_${message.id}`) {
                const roleList = rolesGuild.size > 0 ? rolesGuild.map(r => r.toString()).join(' ') : 'Aucun rôle';
                const roleEmbed = new EmbedBuilder()
                    .setColor(client.color)
                    .setTitle(`🎭 Rôles de ${message.guild.name}`)
                    .setDescription(roleList.length > 4000 ? 'Trop de rôles pour les afficher ici 😅' : roleList)
                    .setFooter({ text: client.footer?.text })
                    .setTimestamp();
                return i.reply({ embeds: [roleEmbed], ephemeral: true });
            }

            if (i.customId === `serveurinfo_emojis_${message.id}`) {
                const emojiList = emojisGuild.size > 0 ? emojisGuild.map(e => e.toString()).join(' ') : 'Aucun emoji';
                const emojiEmbed = new EmbedBuilder()
                    .setColor(client.color)
                    .setTitle(`⚪ Emojis de ${message.guild.name}`)
                    .setDescription(emojiList.length > 4000 ? 'Trop d\'emojis pour les afficher ici 😅' : emojiList)
                    .setFooter({ text: client.footer?.text })
                    .setTimestamp();
                return i.reply({ embeds: [emojiEmbed], ephemeral: true });
            }
        });

        collectServer.on('end', () => {
            msg.edit({ components: [] });
        });
    }
};