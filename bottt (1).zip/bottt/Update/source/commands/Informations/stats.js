const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags } = require('discord.js');

module.exports = {
    name: 'stats',
    description: 'Affiche les statistiques détaillées d\'un membre.',
    use: "<@user>",
    usage: "<@user>",
    example: "➜ stats @tokyru\n➜ stats 123456789012345678",
    run: async (client, message, args, commandName) => {
        let pass = false;

        // Autoriser automatiquement les staff, buyers, et owners
        if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
        client.db.get(`owner_global_${message.author.id}`) === true || 
client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {               pass = true;
        } else {
            // Vérifier les permissions personnalisées pour la commande
            const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
            if (commandPerms.length > 0) {
                const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                const userRoles = message.member.roles.cache.map(role => role.id);
                // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
                pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
            } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                // Conserver la compatibilité avec le mode "public"
                pass = true;
            }
        }

        // Refuser l'accès si pas de permission
        if (!pass) {
            if (client.noperm && client.noperm.trim() !== '') {
                const sentMessage = await message.channel.send(client.noperm);
                // Récupérer le délai configuré pour ce serveur
                const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
                if (delayTime > 0) {
                    setTimeout(() => {
                        sentMessage.delete().catch(() => {});
                    }, delayTime * 1000);
                }
            }
            return;
        }

        const member = message.mentions.users.first() || await client.users.fetch(args[0]).catch(() => null) || message.author;
        if (!member) return message.reply('🚫 Membre introuvable.');

        const guildId = message.guild.id;
        const userId = member.id;
        const guildMember = message.guild.members.cache.get(userId);

        const messageCount = client.db.get(`message_${guildId}_${userId}`) || 0;
        const vocalTime = client.db.get(`vocal_${guildId}_${userId}`) || 0;
        const invitesData = client.db.get(`invites_${userId}_${guildId}`) || {
            total: 0,
            valid: 0,
            left: 0,
            bonus: 0
        };

        const vocalFormatted = formatTime(vocalTime);
        const memberJoinPosition = guildMember ? await calculateMemberRank(message.guild, userId) : 'Non membre';

        const description = 
            `**Informations :**\n` +
            `• **Pseudo :** <@${member.id}> \`(${member.username})\`\n` +
            `• **ID :** \`${member.id}\`\n` +
            `• **Rôles :** ${guildMember ? (guildMember.roles.cache.size > 1 ? `${guildMember.roles.cache.size - 1} rôle(s)` : 'Aucun rôle') : 'Membre non trouvé'}\n` +
            `• **Message total :** \`${messageCount.toLocaleString()}\`\n\n` +

            `**Activité textuelle :**\n` +
            `• ${message.channel} - \`${messageCount}\` message(s)\n\n` +

            `**Implication serveur :**\n` +
            `• **Invitations totales :** \`${invitesData.total.toLocaleString()}\`\n` +
            `• **Invitations valides :** \`${invitesData.valid.toLocaleString()}\`\n` +
            `• **Invitations invalides :** \`${invitesData.left.toLocaleString()}\`\n\n` +

            `**Temps vocal :** \`${vocalFormatted}\`\n` +
            `**Membre depuis :** <t:${Math.floor((guildMember?.joinedTimestamp || Date.now()) / 1000)}:R>\n` +
            `**Compte créé le :** <t:${Math.floor(member.createdTimestamp / 1000)}:R>\n\n` +

            `Tu es le **${memberJoinPosition === 'Non membre' ? 'non membre du serveur' : `${memberJoinPosition}${getOrdinalSuffix(memberJoinPosition)} membre du serveur`}**`;

        const embed = new EmbedBuilder()
            .setColor(client.color)
            .setTitle(`Profil de ${member.username}`)
            .setThumbnail(member.displayAvatarURL({ dynamic: true, size: 256 }))
            .setDescription(description)
            .setFooter(client.footer);

        const viewInvitedButton = new ButtonBuilder()
            .setCustomId(`view_invited_${userId}_${guildId}`)
            .setLabel('Voir les invités')
            .setEmoji('🔎')
            .setStyle(ButtonStyle.Secondary);

        const viewRolesButton = new ButtonBuilder()
            .setCustomId(`view_roles_${userId}_${guildId}`)
            .setLabel('Voir les rôles')
            .setEmoji('🎭')
            .setStyle(ButtonStyle.Secondary);

        const row = new ActionRowBuilder()
            .addComponents(viewInvitedButton, viewRolesButton);

        const sentMessage = await message.channel.send({ embeds: [embed], components: [row] });

        const collector = sentMessage.createMessageComponentCollector({ time: 300000 });

        collector.on('collect', async (interaction) => {
            let canView = false;

            if (client.staff.includes(interaction.user.id) || 
                client.config.buyers.includes(interaction.user.id) || 
                client.db.get(`owner_${interaction.user.id}`) === true ||
                interaction.user.id === userId ||
                client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                canView = true;
            }

            if (!canView) {
                return interaction.reply({ 
                    content: 'Vous n\'avez pas la permission de voir cette information.', 
                    flags: MessageFlags.Ephemeral 
                });
            }

            if (interaction.customId === `view_invited_${userId}_${guildId}`) {
                const invitedUsers = await client.db.get(`invited_by_${userId}_${guildId}`) || [];

                if (invitedUsers.length === 0) {
                    const noInvitedEmbed = new EmbedBuilder()
                        .setColor(client.color)
                        .setTitle('👥 Utilisateurs invités')
                        .setDescription(`<@${userId}> n'a invité aucun utilisateur sur ce serveur.`)
                        .setFooter(client.footer);

                    return interaction.reply({ embeds: [noInvitedEmbed], flags: MessageFlags.Ephemeral });
                }

                let invitedList = '';
                const maxUsersPerPage = 10;
                const totalUsers = invitedUsers.length;
                const usersToShow = invitedUsers.slice(0, maxUsersPerPage);

                for (let i = 0; i < usersToShow.length; i++) {
                    const invitedUserId = usersToShow[i];
                    const user = await client.users.fetch(invitedUserId).catch(() => null);
                    const memberStatus = message.guild.members.cache.get(invitedUserId);
                    if (user) {
                        const status = memberStatus ? '✅' : '❌';
                        invitedList += `${status} <@${invitedUserId}> (\`${user.id}\`)\n`;
                    }
                }

                const invitedEmbed = new EmbedBuilder()
                    .setColor(client.color)
                    .setTitle(`👥 Utilisateurs invités par ${member.tag}`)
                    .setDescription(invitedList || 'Aucun utilisateur trouvé.')
                    .setFooter({ 
                        text: `${client.footer.text} • Page 1/${Math.ceil(totalUsers / maxUsersPerPage)} • Total: ${totalUsers}`,
                        iconURL: client.footer.iconURL
                    });

                await interaction.reply({ embeds: [invitedEmbed], flags: MessageFlags.Ephemeral });

            } else if (interaction.customId === `view_roles_${userId}_${guildId}`) {
                if (!guildMember) {
                    const noMemberEmbed = new EmbedBuilder()
                        .setColor(client.color)
                        .setTitle('🎭 Rôles du membre')
                        .setDescription('Membre non trouvé sur le serveur.')
                        .setFooter(client.footer);
                    
                    return interaction.reply({ embeds: [noMemberEmbed], flags: MessageFlags.Ephemeral });
                }

                const roles = guildMember.roles.cache
                    .filter(role => role.id !== message.guild.id)
                    .sort((a, b) => b.position - a.position)
                    .map(role => `<@&${role.id}>`)
                    .join('\n');

                const rolesEmbed = new EmbedBuilder()
                    .setColor(client.color)
                    .setTitle(`🎭 Rôles de ${member.tag}`)
                    .setDescription(roles || 'Aucun rôle attribué.')
                    .setFooter({ 
                        text: `${client.footer.text} • Total: ${guildMember.roles.cache.size - 1} rôle(s)`,
                        iconURL: client.footer.iconURL
                    });

                await interaction.reply({ embeds: [rolesEmbed], flags: MessageFlags.Ephemeral });
            }
        });

        collector.on('end', () => {
            viewInvitedButton.setDisabled(true);
            viewRolesButton.setDisabled(true);
            sentMessage.edit({ embeds: [embed], components: [row] }).catch(() => {});
        });
    },
};

function formatTime(temps) {
    let time;

    if (temps < 60) {
        time = `${temps} sec`;
    } else if (temps < 3600) {
        const minutes = Math.floor(temps / 60);
        const seconds = temps % 60;
        time = `${minutes}m ${seconds}s`;
    } else if (temps < 86400) {
        const heures = Math.floor(temps / 3600);
        const minutes = Math.floor((temps % 3600) / 60);
        time = `${heures}h ${minutes}m`;
    } else if (temps < 31536000) {
        const jours = Math.floor(temps / 86400);
        const heures = Math.floor((temps % 86400) / 3600);
        time = `${jours}j ${heures}h`;
    } else {
        const années = Math.floor(temps / 31536000);
        const jours = Math.floor((temps % 31536000) / 86400);
        time = `${années}an ${jours}j`;
    }

    return time;
}

function getOrdinalSuffix(n) {
    if (typeof n !== 'number') return '';
    const lastDigit = n % 10;
    const lastTwoDigits = n % 100;
    if (lastTwoDigits >= 11 && lastTwoDigits <= 13) return 'e';
    if (lastDigit === 1) return 'er';
    return 'e';
}

async function calculateMemberRank(guild, userId) {
    try {
        const guildMember = guild.members.cache.get(userId);
        if (!guildMember) {
            return 'Non membre';
        }

        // Récupérer tous les membres et convertir la Collection en tableau
        const members = await guild.members.fetch();
        if (!members || members.size === 0) {
            console.warn(`Aucun membre récupéré pour le serveur ${guild.id}`);
            return 'Erreur lors du calcul du rang';
        }

        // Convertir la Collection en tableau et trier
        const sortedMembers = Array.from(members.values()).sort((a, b) => a.joinedTimestamp - b.joinedTimestamp);
        const memberIndex = sortedMembers.findIndex(member => member.id === userId);

        return memberIndex !== -1 ? memberIndex + 1 : 'Non membre';
    } catch (error) {
        console.error(`Erreur dans calculateMemberRank pour userId ${userId}:`, error);
        return 'Erreur lors du calcul du rang';
    }
}