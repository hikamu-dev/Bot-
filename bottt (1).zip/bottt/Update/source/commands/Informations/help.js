const Discord = require('discord.js');
const fs = require('fs');
const { Astroia } = require('../../structures/client/index.js');
const { example } = require('../Owner/changelimit.js');

module.exports = {
    name: "help",
    description: "Affiche les commandes du bot",
    use: "help [commande]",
    usage: "help [commande]",
    example: "➜ help ban",
    
    /**
     * 
     * @param {Astroia} client 
     * @param {Discord.Message} message 
     * @param {string[]} args 
     * @returns 
     */
    run: async (client, message, args, commandName) => {
        try {
            let pass = false;

            // Autoriser automatiquement les staff, buyers, et owners
            if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
        client.db.get(`owner_global_${message.author.id}`) === true || 
client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {                   pass = true;
            } else {
                // Vérifier les permissions personnalisées pour la commande
                const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
                if (commandPerms.length > 0) {
                    const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                    const userRoles = message.member.roles.cache.map(role => role.id);
                    // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
                    pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
                } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                    // Conserver la compatibilité avec le mode "public"
                    pass = true;
                }
            }

            // Refuser l'accès si pas de permission
            if (!pass) {
                if (client.noperm && client.noperm.trim() !== '') {
                    const sentMessage = await message.channel.send(client.noperm);
                    // Récupérer le délai configuré pour ce serveur
                    const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
                    if (delayTime > 0) {
                        setTimeout(() => {
                            sentMessage.delete().catch(() => {});
                        }, delayTime * 1000);
                    }
                }
                return;
            }

            const prefix = client.prefix;
            const helpMode = client.db.get(`sethelp_${message.guild.id}`) || 'menu';

            const commandFolders = fs.readdirSync('./source/commands').filter(folder => folder !== 'DEV');
            let totalCommands = 0;
            
            const categoriesData = commandFolders.map(folder => {
                const commandFiles = fs.readdirSync(`./source/commands/${folder}`).filter(file => file.endsWith('.js'));
                totalCommands += commandFiles.length;
                return {
                    name: folder,
                    count: commandFiles.length,
                    commands: commandFiles.map(file => {
                        const command = require(`../${folder}/${file}`);
                        return command;
                    })
                };
            });

            const paramsNote = `*Les paramètres peuvent être des noms, des mentions, ou des ID.\nSi ce ne sont pas des mentions ils doivent être séparés par \`,,\`\nLes arguments entre \`<...>\` sont obligatoires, alors que ceux entre \`[...]\` sont optionnels.*`;

            const categoryEmojis = {
 Informations: '🔍',
    Giveaways: '🎁',
    Buyers: '🔰',
    Owner: '👑',
    Moderation: '🔨',
    Contact: '🎫',
    Gestion: '⚙️',
    Logs: '📜',
    Antiraid: '🚨',
    Fun: '🚀',
    Invitations: '✉️',
    Utilitaires: '💡',
    Formulaire: '📋',
    Custom: '🎯',
    Vocal: '🔊',
    Permissions: '🃏',
    Salons: '📁',
    Prison: '🏛️',
    Rôles: '🎭'


            };

            if (args.length === 0) {
                if (helpMode === 'boutton') {
                    let currentCategoryIndex = 0;

                    function createButtons(currentIndex, totalCategories) {
                        return new Discord.ActionRowBuilder().addComponents(
                            new Discord.ButtonBuilder()
                                .setCustomId('previous')
                                .setLabel('◀')
                                .setStyle(Discord.ButtonStyle.Primary)
                                .setDisabled(currentIndex === 0),
                            new Discord.ButtonBuilder()
                                .setCustomId('category_display')
                                .setLabel(`${currentIndex + 1}/${totalCategories}`)
                                .setStyle(Discord.ButtonStyle.Secondary)
                                .setDisabled(true),
                            new Discord.ButtonBuilder()
                                .setCustomId('next')
                                .setLabel('▶')
                                .setStyle(Discord.ButtonStyle.Primary)
                                .setDisabled(currentIndex === totalCategories - 1)
                        );
                    }

                    function displayCommands(categoryIndex) {
                        const category = categoriesData[categoryIndex];
                        
                        // Amélioration esthétique pour l'affichage des commandes
                        const commandsList = category.commands.map(command => {
                            const commandName = command.name;
                            const commandUse = command.name !== "help" ? (command.use || '') : '';
                            const commandDesc = command.description || "Pas de description";
                            
                            return `\`✦ ${prefix}${command.name} ${command.name !== "help" ? (command.use || '') : ''}\`\n↬ ${command.description || "Pas de description"}`;
                        }).join('\n\n');

                        const embed = new Discord.EmbedBuilder()
                            .setColor(client.color)
                            .setTitle(`${categoryEmojis[category.name] || '❓'} ▸ ${category.name} — (\`${category.count} Commandes\`)`)
                            .setDescription(`${paramsNote}\n\n${commandsList.length > 4096 ? commandsList.substring(0, 4096) : commandsList}`)
                            .setFooter(client.footer);

                        return embed;
                    }

                    const embed = displayCommands(currentCategoryIndex);
                    const buttons = createButtons(currentCategoryIndex, categoriesData.length);

                    const reply = await message.reply({ 
                        embeds: [embed], 
                        components: [buttons] 
                    });

                    const filter = i => i.user.id === message.author.id;
                    const collector = reply.createMessageComponentCollector({ filter, time: 60000 });

                    collector.on('collect', async (interaction) => {
                        if (!interaction.isButton()) return;
                        if (interaction.user.id !== message.author.id) {
                            return interaction.reply({ content: "Ce bouton ne t'est pas destiné.", ephemeral: true }).catch(() => {});
                        }
                    
                        try {
                            await interaction.deferUpdate();
                    
                            if (interaction.customId === 'previous') {
                                currentCategoryIndex = Math.max(currentCategoryIndex - 1, 0);
                            } else if (interaction.customId === 'next') {
                                currentCategoryIndex = Math.min(currentCategoryIndex + 1, categoriesData.length - 1);
                            }
                    
                            const updatedEmbed = displayCommands(currentCategoryIndex);
                            const updatedButtons = createButtons(currentCategoryIndex, categoriesData.length);
                    
                            await interaction.editReply({
                                embeds: [updatedEmbed],
                                components: [updatedButtons]
                            });
                    
                        } catch (error) {
                            console.error('Erreur dans l\'interaction du bouton help :', error);
                            if (!interaction.replied && !interaction.deferred) {
                                await interaction.reply({ content: 'Une erreur est survenue.', ephemeral: true }).catch(() => {});
                            }
                        }
                    });

                    collector.on('end', async () => {
                        try {
                            // Vérifier si le message existe encore avant de tenter de l'éditer
                            const fetchedMessage = await message.channel.messages.fetch(reply.id).catch(() => null);
                            if (!fetchedMessage) {
                                console.log('Message help supprimé, impossible de désactiver les boutons');
                                return;
                            }

                            const disabledButtons = new Discord.ActionRowBuilder().addComponents(
                                new Discord.ButtonBuilder()
                                    .setCustomId('previous')
                                    .setLabel('◀')
                                    .setStyle(Discord.ButtonStyle.Primary)
                                    .setDisabled(true),
                                new Discord.ButtonBuilder()
                                    .setCustomId('category_display')
                                    .setLabel(`${currentCategoryIndex + 1}/${categoriesData.length}`)
                                    .setStyle(Discord.ButtonStyle.Secondary)
                                    .setDisabled(true),
                                new Discord.ButtonBuilder()
                                    .setCustomId('next')
                                    .setLabel('▶')
                                    .setStyle(Discord.ButtonStyle.Primary)
                                    .setDisabled(true)
                            );

                            await reply.edit({
                                embeds: [displayCommands(currentCategoryIndex)],
                                components: [disabledButtons]
                            });
                        } catch (error) {
                            console.error('Erreur lors de la désactivation des boutons:', error);
                        }
                    });
                    
                } else if (helpMode === 'menu') {
                    const selectMenu = new Discord.StringSelectMenuBuilder()
                        .setCustomId('help_category_select')
                        .setPlaceholder('Sélectionnez une catégorie à parcourir ici')
                        .addOptions(
                            categoriesData.map(category => ({
                                label: `${category.name} • (${category.count} commandes)`,
                                value: category.name,
                                emoji: categoryEmojis[category.name] || '❓',
                                description: `Voir les commandes de ${category.name}`.substring(0, 50)
                            }))
                        );

                    const row1 = new Discord.ActionRowBuilder()
                        .addComponents(selectMenu);

                    const row2 = new Discord.ActionRowBuilder()
                        .addComponents(
                            new Discord.ButtonBuilder()
                                .setLabel(`Inviter le bot ${client.user.username}`)
                                .setEmoji('➕')
                                .setStyle(Discord.ButtonStyle.Link)
                                .setURL(`https://discord.com/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`),
                            new Discord.ButtonBuilder()
                                .setLabel('Rejoindre le support')
                                .setEmoji('🪄')
                                .setStyle(Discord.ButtonStyle.Link)
                                .setURL(`${client.support}`)
                       );

                   // const imageEmbed = new Discord.EmbedBuilder()
                    //     .setImage('https://media.discordapp.net/attachments/1391180983830843554/1391747032489791589/shelia_banner3.png?ex=686d04ed&is=686bb36d&hm=6131ca7768c5e6b1e7a0e534938bb34d7e994e88b06b403c84f0bcf154a57493&=&format=webp&quality=lossless')
                      //   .setColor(client.color);

const initialEmbed = new Discord.EmbedBuilder()
  .setColor(client.color)
  .setTitle("🌌 Centre d’aide")
  .setThumbnail(client.user.displayAvatarURL())
  .setImage("https://cdn.discordapp.com/attachments/1395514989158076508/1402647259862012065/9196EA17-4F7E-4569-A0AD-F296E558D355.png")
  .setDescription(`📖 Bienvenue ${message.author} ! Voici le guide des fonctionnalités de **Lyna**.`)
  .addFields(
{
  name: "> ↬ Information",
  value:
    `↬ Préfixe : \`${prefix}\`\n` +
    `↬ Commandes : \`${totalCommands}\`\n` +
    `↬ Version : \`${client.version || "1.4"}\``,
  inline: true
},
{
  name: "> ↬ Accès rapide",
  value:
    `↬ \`${prefix}set <propriété>\`\n` +
    `↬ \`${prefix}sethelp <type>\`\n` +
    `↬ \`${prefix}help <commande>\``,
  inline: true
},
{
  name: "> ↬ À savoir",
  value:
    "↬ Les paramètres notés `<...>` sont obligatoires, tandis que ceux entre `[...]` sont facultatifs.",
  inline: false
}
  )
  .setFooter({
    text: "Utilise le menu ci-dessous pour parcourir les catégories du bot."
  });





                    const reply = await message.reply({
                        embeds: [initialEmbed],
                        components: [row1, row2]
                    });

                    const filter = i => i.user.id === message.author.id;
                    const collector = reply.createMessageComponentCollector({ filter, time: 60000 });

                    collector.on('collect', async (interaction) => {
                        if (!interaction.isStringSelectMenu()) return;
                        if (interaction.user.id !== message.author.id) {
                            return interaction.reply({ content: "Ce menu ne t'est pas destiné.", ephemeral: true }).catch(() => {});
                        }

                        try {
                            await interaction.deferUpdate();

                            const selectedCategory = categoriesData.find(cat => cat.name === interaction.values[0]);
                            
                            // Amélioration esthétique pour l'affichage des commandes dans le menu
                            const commandsList = selectedCategory.commands.map(command => {
                                const commandName = command.name;
                                const commandUse = command.name !== "help" ? (command.use || '') : '';
                                const commandDesc = command.description || "Pas de description";
                                
                            return `\`★ ${prefix}${command.name} ${command.name !== "help" ? (command.use || '') : ''}\`\n↬ ${command.description || "Pas de description"}`;
                            }).join('\n\n');

                            const embed = new Discord.EmbedBuilder()
                                .setColor(client.color)
                                .setTitle(`${categoryEmojis[selectedCategory.name] || '❓'} ▸ ${selectedCategory.name} — (\`${selectedCategory.count} Commandes\`)`)
                                .setDescription(`${paramsNote}\n\n${commandsList.replace(/\s+$/, '')}`)
                                .setFooter(client.footer);

                            await interaction.editReply({
                                embeds: [embed],
                                components: [row1]
                            });

                        } catch (error) {
                            console.error('Erreur dans l\'interaction du menu help :', error);
                            if (!interaction.replied && !interaction.deferred) {
                                await interaction.reply({ content: 'Une erreur est survenue.', ephemeral: true }).catch(() => {});
                            }
                        }
                    });

                    collector.on('end', async () => {
                        try {
                            // Vérifier si le message existe encore avant de tenter de l'éditer
                            const fetchedMessage = await message.channel.messages.fetch(reply.id).catch(() => null);
                            if (!fetchedMessage) {
                                //console.log('Message help supprimé, impossible de désactiver le menu');
                                return;
                            }

                            const disabledMenu = new Discord.StringSelectMenuBuilder()
                                .setCustomId('help_category_select')
                                .setPlaceholder('Sélectionnez une catégorie à parcourir ici')
                                .setDisabled(true)
                                .addOptions({
                                    label: 'Menu expiré',
                                    value: 'expired',
                                    description: 'Le temps d\'interaction est écoulé.'
                                });

                            const disabledRow = new Discord.ActionRowBuilder()
                                .addComponents(disabledMenu);

                            await reply.edit({
                                components: [disabledRow]
                            });
                        } catch (error) {
                            console.error('Erreur lors de la désactivation du menu:', error);
                        }
                    });

                } else {
                    const formattedCategories = categoriesData.map(category => {
                        // Amélioration esthétique pour l'affichage classique
                        const commandsList = category.commands.map(cmd => `\`${cmd.name}\``).join(', ');
                        return {
                            name: `${categoryEmojis[category.name] || '❓'} ▸ ${category.name} — (\`${category.count} Commandes\`)`,
                            value: commandsList,
                            inline: false
                        };
                    });
                
                    const embeds = [];
                    let currentEmbed = new Discord.EmbedBuilder()
                        .setColor(client.color)
                        .setTitle(`${client.user.username} ${client.version || '4.5.1'}`)
                        .setThumbnail(client.user.displayAvatarURL())
                        .setDescription(`Mon préfixe sur ce serveur est \`${prefix}\`\nNombre total de commandes : \`${totalCommands}\``)
                        .setFooter(client.footer);
                    let fieldCount = 0;
                
                    for (const category of formattedCategories) {
                        if (fieldCount >= 25) {
                            embeds.push(currentEmbed);
                            currentEmbed = new Discord.EmbedBuilder()
                                .setColor(client.color)
                                .setTitle(`${client.user.username} ${client.version || '4.5.1'} (Suite)`)
                                .setThumbnail(client.user.displayAvatarURL())
                                .setDescription(`Mon préfixe sur ce serveur est \`${prefix}\``);
                            fieldCount = 0;
                        }
                
                        const value = category.value.length > 1024 ? `${category.value.substring(0, 1021)}...` : category.value;
                        currentEmbed.addFields({ name: category.name, value: value, inline: category.inline });
                        fieldCount++;
                    }
                
                    if (fieldCount > 0) {
                        embeds.push(currentEmbed);
                    }
                
                    embeds.forEach(embed => {
                        message.channel.send({ embeds: [embed] });
                    });
                }
            } else {
                // Section pour afficher les détails d'une commande spécifique
                const cmdname = args[0];
                const command = client.commands.get(cmdname) || client.commands.find(cmd => cmd.aliases && cmd.aliases.includes(cmdname));
                
                if (!command) {
                    return message.reply(`Cette commande n'existe pas. Utilisez \`${prefix}help\` pour voir la liste des commandes.`);
                }

                // Trouver la catégorie de la commande
                let commandCategory = 'Inconnue';
                for (const category of categoriesData) {
                    if (category.commands.some(cmd => cmd.name === command.name)) {
                        commandCategory = category.name;
                        break;
                    }
                }

                async function getLimitInfo(client, commandName, guild) {
                    const commandLimit = client.db.get(`command_limit_${guild.id}_${commandName}`);
                    if (!commandLimit) return "Aucune limite";

                    const max = commandLimit.maxUse || commandLimit.max || 0;
                    let timeText = "";
                    if (commandLimit.timeLimit) {
                        const ms = commandLimit.timeLimit;
                        if (ms >= 86400000) timeText = ` / ${ms / 86400000}j`;
                        else if (ms >= 3600000) timeText = ` / ${ms / 3600000}h`;
                        else if (ms >= 60000) timeText = ` / ${ms / 60000}m`;
                        else if (ms >= 1000) timeText = ` / ${ms / 1000}s`;
                    }

                    return `${max} utilisations${timeText}`;
                }

                // Récupérer les aliases
                const guildAliases = client.db.get(`aliases.${message.guild.id}`) || {};
                const aliasesForCommand = guildAliases[command.name] || [];
                const aliasText = aliasesForCommand.length > 0
                    ? aliasesForCommand.join(', ')
                    : (command.aliases && command.aliases.length > 0 ? command.aliases.join(', ') : 'Aucun aliases');

                // Récupérer les permissions
                const permissions = await permsDisplay(client, command.name, message.guild);
                const limitInfo = await getLimitInfo(client, command.name, message.guild);
                const examples = command.examples || command.exemple || [];
                const exampleText = examples.length > 0
                    ? (Array.isArray(examples) 
                        ? examples.map(example => `\`${prefix}${example}\``).join('\n')
                        : `\`${prefix}${examples}\``)
                    : 'Aucun exemple disponible';
                
                // Créer l'embed détaillé style Discord avec amélioration esthétique
                const detailedEmbed = new Discord.EmbedBuilder()
                    .setColor(client.color)
                    .setAuthor({
                        name: message.author.username,
                        iconURL: message.author.displayAvatarURL()
                    })
                    .setTitle(`📋 Commande: ${command.name}`)
                    .setDescription(`> **${command.description || "Aucune description disponible"}**`)
.addFields(
    {
        name: '🔗 • Aliases',
        value: `\`${aliasText}\``,
        inline: true
    },
    {
        name: '📁 • Catégorie',
        value: `\`${commandCategory}\``,
        inline: true
    },
    {
        name: '⏱️ • Limite',
        value: `\`${limitInfo}\``,
        inline: true
    },
    {
        name: '💡 • Utilisation',
        value: `\`\`\`\n${command.usage || 'Aucun exemple recommandé'}\n\`\`\``,
        inline: false
    },
    {
        name: '📝 • Exemple',
        value: `\`\`\`\n${command.example || 'Aucun exemple recommandé'}\n\`\`\``,
        inline: false
    },
    {
        name: '🔐 • Permissions',
        value: `\`\`\`\n${permissions}\n\`\`\``,
        inline: false
    }
)

                    .setFooter({
                        text: `Module: ${commandCategory} • ${categoryEmojis[commandCategory] || '❓'}`,
                        iconURL: client.user.displayAvatarURL()
                    })
                    .setTimestamp();

                // Créer les boutons d'action
                const actionRow = new Discord.ActionRowBuilder()
                    .addComponents(
                        new Discord.ButtonBuilder()
                            .setLabel('Support')
                            .setEmoji('🪄')
                            .setStyle(Discord.ButtonStyle.Link)
                            .setURL(`${client.support}`),
                        new Discord.ButtonBuilder()
                            .setLabel('Supprimer')
                            .setEmoji('🗑️')
                            .setStyle(Discord.ButtonStyle.Danger)
                            .setCustomId('delete_help_embed')
                    );

                const reply = await message.reply({
                    embeds: [detailedEmbed],
                    components: [actionRow]
                });

                // Créer le collector pour le bouton de suppression
                const filter = i => i.customId === 'delete_help_embed' && i.user.id === message.author.id;
                const collector = reply.createMessageComponentCollector({ filter, time: 60000 });

                collector.on('collect', async (interaction) => {
                    try {
                        await interaction.deferUpdate();
                        await reply.delete();
                    } catch (error) {
                        console.error('Erreur lors de la suppression du message help:', error);
                        if (!interaction.replied && !interaction.deferred) {
                            await interaction.reply({ content: 'Erreur lors de la suppression.', ephemeral: true }).catch(() => {});
                        }
                    }
                });

                collector.on('end', async () => {
                    try {
                        // Vérifier si le message existe encore avant de tenter de l'éditer
                        const fetchedMessage = await message.channel.messages.fetch(reply.id).catch(() => null);
                        if (!fetchedMessage) {
                            console.log('Message help supprimé, impossible de désactiver les boutons');
                            return;
                        }

                        await reply.edit({
                            components: [
                                new Discord.ActionRowBuilder()
                                    .addComponents(
                                        new Discord.ButtonBuilder()
                                            .setLabel('Support')
                                            .setEmoji('🪄')
                                            .setStyle(Discord.ButtonStyle.Link)
                                            .setURL(`${client.support}`),
                                        new Discord.ButtonBuilder()
                                            .setLabel('Supprimer')
                                            .setEmoji('🗑️')
                                            .setStyle(Discord.ButtonStyle.Danger)
                                            .setCustomId('delete_help_embed')
                                            .setDisabled(true)
                                    )
                            ]
                        });
                    } catch (error) {
                        if (error.code === 10008) return;
                        console.error('Erreur lors de la désactivation des boutons:', error);
                    }
                });
            }
        } catch (error) {
            console.error('Error executing help command:', error);
            message.channel.send('Une erreur est survenue lors de l\'exécution de la commande.');
        }
    }
};

async function permsDisplay(client, commandName, guild) {
    const commandPerms = client.db.get(`command_permissions.${guild.id}.${commandName}`) || [];

    if (commandPerms.length === 0) {
        const legacyPerm = client.db.get(`perm_${commandName}.${guild.id}`);
        if (legacyPerm === "public") return "Public (accessible à tous)";
        return "Aucune";
    }

    return commandPerms.join(", ");
}

async function getLimitInfo(client, commandName, guild) {
    const commandLimits = client.db.get(`command_limits.${guild.id}.${commandName}`);
    if (!commandLimits) return "Aucune limite";
    
    return `${commandLimits.uses}/${commandLimits.max} utilisations`;
}