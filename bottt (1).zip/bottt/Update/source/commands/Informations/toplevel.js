// commands/levels/toplevel.js
const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require("discord.js");

// Clé DB (même logique que level.js / levelsEngine.js)
const kUser = (g, u) => `levels_user_${g}_${u}`;

// Accès: staff / buyers / owners / setperm / public (par défaut OUI)
function passGate(client, message, commandName = "toplevel", defaultPublic = true) {
  const uid = message.author.id;
  if (client?.staff?.includes?.(uid)) return true;
  if (client?.config?.buyers?.includes?.(uid)) return true;
  if (client?.db?.get?.(`owner_global_${uid}`) === true) return true;
  if (client?.db?.get?.(`owner_${message.guild.id}_${uid}`) === true) return true;

  const commandPerms = client?.db?.get?.(`command_permissions.${message.guild.id}.${commandName}`) || [];
  if (commandPerms.length > 0) {
    const userPerms = client?.db?.get?.(`permissions.${message.guild.id}`) || {};
    const roles = message.member.roles.cache.map(r => r.id);
    return commandPerms.some(perm => (userPerms[perm] || []).some(id => roles.includes(id)));
  }
  if (client?.db?.get?.(`perm_${commandName}.${message.guild.id}`) === "public") return true;
  return defaultPublic;
}

const PER_PAGE = 10;

function paginate(list, page, per = PER_PAGE) {
  const totalPages = Math.max(1, Math.ceil(list.length / per));
  const p = Math.min(Math.max(0, page), totalPages - 1);
  const start = p * per;
  return {
    page: p,
    totalPages,
    slice: list.slice(start, start + per),
  };
}

function renderEmbed(client, message, data, page, totalPages, userRank, totalCount) {
  const color = client.color || 0xffc107;
  const lines = data.map((e, i) => {
    const rank = page * PER_PAGE + i + 1;
    const mention = `<@${e.id}>`; // affiché sans ping via allowedMentions
    return `**${rank}.** ${mention} — **L${e.level}**`;
  }).join("\n") || "_Aucun membre classé pour le moment._";

  const emb = new EmbedBuilder()
    .setColor(color)
    .setTitle("🏆 Classement des niveaux")
    .setDescription(lines)
    .setFooter({ text: `Page ${page + 1}/${totalPages} • Total: ${totalCount}` });

  if (typeof userRank === "number") {
    emb.addFields({ name: "Votre position", value: `\`#${userRank + 1}\`` });
  }
  return emb;
}

function buildRow(disablePrev, disableNext) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId("top_prev")
      .setStyle(ButtonStyle.Secondary)
      .setEmoji("⬅️")
      .setLabel("Précédent")
      .setDisabled(disablePrev),
    new ButtonBuilder()
      .setCustomId("top_next")
      .setStyle(ButtonStyle.Secondary)
      .setEmoji("➡️")
      .setLabel("Suivant")
      .setDisabled(disableNext),
    new ButtonBuilder()
      .setCustomId("top_close")
      .setStyle(ButtonStyle.Danger)
      .setLabel("Fermer")
  );
}

module.exports = {
  name: "toplevel",
  description: "Affiche le classement des niveaux du serveur (paginé).",
  usage: "toplevel",
  category: "utils",

  run: async (client, message) => {
    if (!message.guild) return;
    if (!passGate(client, message, "toplevel", true)) {
      if (client.noperm && client.noperm.trim() !== "") {
        const m = await message.channel.send(client.noperm);
        const d = client.db?.get?.(`noperm_delay_${message.guild.id}`) || 0;
        if (d > 0) setTimeout(() => m.delete().catch(() => {}), d * 1000);
      }
      return;
    }

    // Récup des membres (fetch pour éviter un cache incomplet)
    let members;
    try {
      members = await message.guild.members.fetch();
    } catch {
      members = message.guild.members.cache; // fallback
    }

    // Construire la liste (exclut bots, garde ceux avec un niveau >0 ou xp>0)
    const list = [];
    for (const [, m] of members) {
      if (!m || !m.user || m.user.bot) continue;
      const state = client.db?.get?.(kUser(message.guild.id, m.id));
      if (!state || (Number(state.level) <= 0 && Number(state.xp) <= 0)) continue;
      list.push({ id: m.id, level: Number(state.level) || 0, xp: Number(state.xp) || 0 });
    }

    if (list.length === 0) {
      return message.channel.send({ content: "Personne n'a encore de niveau sur ce serveur.", allowedMentions: { parse: [] } });
    }

    // Tri: niveau DESC, puis XP DESC (pour départager), mais on n'affiche que le niveau
    list.sort((a, b) => (b.level - a.level) || (b.xp - a.xp));

    // Rang de l'auteur s'il est classé
    const authorIdx = list.findIndex(e => e.id === message.author.id);
    const userRank = authorIdx >= 0 ? authorIdx : undefined;

    // Page initiale
    let page = 0;
    const { slice, totalPages } = paginate(list, page, PER_PAGE);
    const embed = renderEmbed(client, message, slice, page, totalPages, userRank, list.length);
    const row = buildRow(page === 0, page >= totalPages - 1);

    const msg = await message.channel.send({
      embeds: [embed],
      components: [row],
      allowedMentions: { parse: [] }, // pas de ping
    });

    // Collector boutons
    const collector = msg.createMessageComponentCollector({
      filter: i => i.user.id === message.author.id && ["top_prev", "top_next", "top_close"].includes(i.customId),
      time: 2 * 60 * 1000
    });

    collector.on("collect", async (i) => {
      if (i.customId === "top_close") {
        collector.stop("closed");
        try { await i.update({ components: [] }); } catch {}
        return;
      }

      if (i.customId === "top_prev" && page > 0) page--;
      if (i.customId === "top_next" && page < totalPages - 1) page++;

      const { slice: newSlice } = paginate(list, page, PER_PAGE);
      const newEmbed = renderEmbed(client, message, newSlice, page, totalPages, userRank, list.length);
      const newRow = buildRow(page === 0, page >= totalPages - 1);

      try {
        await i.update({ embeds: [newEmbed], components: [newRow], allowedMentions: { parse: [] } });
      } catch {}
    });

    collector.on("end", async () => {
      try { await msg.edit({ components: [] }); } catch {}
    });
  }
};
