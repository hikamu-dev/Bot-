const Discord = require('discord.js');const fs = require('fs');const { Astroia } = require('../../structures/client/index.js');
module.exports = {    name: "onepage",    description: "Affiche toutes les commandes du bot en une seule page",    use: "onepage",    usage: "onepage",    example: "➜ onepage",
/**
 * 
 * @param {Astroia} client 
 * @param {Discord.Message} message 
 * @param {string[]} args 
 * @returns 
 */
run: async (client, message, args, commandName) => {
    try {
        let pass = false;

        // Autoriser automatiquement les staff, buyers, et owners
        if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
        client.db.get(`owner_global_${message.author.id}`) === true || 
client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {               pass = true;
        } else {
            // Vérifier les permissions personnalisées pour la commande
            const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
            if (commandPerms.length > 0) {
                const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                const userRoles = message.member.roles.cache.map(role => role.id);
                // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
                pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
            } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                // Conserver la compatibilité avec le mode "public"
                pass = true;
            }
        }

        // Refuser l'accès si pas de permission
        if (!pass) {
            if (client.noperm && client.noperm.trim() !== '') {
                const sentMessage = await message.channel.send(client.noperm);
                // Récupérer le délai configuré pour ce serveur
                const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
                if (delayTime > 0) {
                    setTimeout(() => {
                        sentMessage.delete().catch(() => {});
                    }, delayTime * 1000);
                }
            }
            return;
        }

        const prefix = client.prefix;

        // Charger les commandes depuis le dossier commands, en excluant DEV
        const commandFolders = fs.readdirSync('./source/commands').filter(folder => folder !== 'DEV');
        let totalCommands = 0;

        // Créer les données des catégories
        const categoriesData = commandFolders.map(folder => {
            const commandFiles = fs.readdirSync(`./source/commands/${folder}`).filter(file => file.endsWith('.js'));
            totalCommands += commandFiles.length;
            return {
                name: folder,
                count: commandFiles.length,
                commands: commandFiles.map(file => {
                    const command = require(`../${folder}/${file}`);
                    return command;
                })
            };
        });

        // Emojis pour les catégories
        const categoryEmojis = {
            Informations: '🔍',
            Giveaways: '🎁',
            Buyers: '🔰',
            Owner: '👑',
            Moderation: '🔨',
            Contact: '🎫',
            Gestion: '⚙️',
            Logs: '📜',
            Antiraid: '🚨',
            Fun: '🚀',
            Invitations: '✉️',
            Utilitaires: '💡',
            Formulaire: '📋',
            Custom: '🎯',
            Vocal: '🔊',
            Permissions: '🃏',
            Rôles: '🎭',
            Salons: '📁',
            Prison: '🏛️'
        };

        // Formater les catégories avec uniquement les noms des commandes
        const formattedCategories = categoriesData.map(category => {
            const commandsList = category.commands.map(cmd => `\`${cmd.name}\``).join(', ');
            return {
                name: `${categoryEmojis[category.name] || '❓'} ▸ ${category.name} — (\`${category.count} Commandes\`)`,
                value: commandsList,
                inline: false
            };
        });

        // Créer une liste d'embeds pour respecter les limites
        const embeds = [];
        let currentEmbed = new Discord.EmbedBuilder()
            .setColor(client.color)
            .setTitle(`${client.user.username} ${client.version || '4.5.1'}`)
            .setThumbnail(client.user.displayAvatarURL())
            .setDescription(`Mon préfixe sur ce serveur est \`${prefix}\`\nNombre total de commandes : \`${totalCommands}\``)
            .setFooter(client.footer);
        let currentCharCount = 0;
        let fieldCount = 0;
        let embedCount = 1;

        for (const category of formattedCategories) {
            // Estimer la taille du champ
            const fieldSize = category.name.length + (category.value.length > 1024 ? 1024 : category.value.length);

            // Vérifier si l'ajout dépasse les limites (6000 caractères ou 25 champs)
            if (currentCharCount + fieldSize > 5500 || fieldCount >= 25) { // Marge de 500
                embeds.push(currentEmbed);
                embedCount++;
                currentEmbed = new Discord.EmbedBuilder()
                    .setColor(client.color)
                    .setTitle(`${client.user.username}`)
                    .setThumbnail(client.user.displayAvatarURL())
                    .setDescription(`Mon préfixe sur ce serveur est \`${prefix}\``)
                    .setFooter(client.footer);
                currentCharCount = 0;
                fieldCount = 0;
            }

            const value = category.value.length > 1024 ? `${category.value.substring(0, 1021)}...` : category.value;
            currentEmbed.addFields({ name: category.name, value: value, inline: category.inline });
            currentCharCount += fieldSize;
            fieldCount++;
        }

        // Ajouter le dernier embed s'il contient des champs
        if (fieldCount > 0) {
            embeds.push(currentEmbed);
        }

        // Envoyer tous les embeds
        for (const embed of embeds) {
            await message.channel.send({ embeds: [embed] });
        }

    } catch (error) {
        console.error('Erreur lors de l\'exécution de la commande onepage:', error);
        await message.channel.send('Une erreur est survenue lors de l\'exécution de la commande.');
    }
}

};