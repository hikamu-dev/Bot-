const Astroia = require('../../structures/client/index');
const axios = require('axios');
const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'mybot',
  description: 'Affiche la liste de vos bots enregistrés.',

  /**
   * @param {Astroia} client 
   * @param {Discord.Message} message
   * @param {string[]} args
   */
  run: async (client, message, args) => {
    const user_id = message.author.id;

    try {
      const response = await axios.get(`http://localhost:3003/API/bot/${user_id}`);
      const bots = response.data;

      if (Array.isArray(bots) && bots.length > 0) {
        const embed = new EmbedBuilder()
          .setColor(client.config.default_color)
          .setTitle('🤖 Vos Bots')
          .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
          .setFooter({ text: client.footer?.text || 'Gestion des bots', iconURL: client.footer?.iconURL })
          .setTimestamp();

        let description = '';

        bots.forEach((bot, index) => {
          const botUser = client.users.cache.get(bot.bot_id);
          const botName = botUser?.tag || 'Bot introuvable';
          const botLink = `https://discord.com/api/oauth2/authorize?client_id=${bot.bot_id}&permissions=8&scope=bot%20applications.commands`;

          const timestamp = Math.floor(bot.temps / 1000);
          const isExpired = bot.temps - Date.now() < 1000;
          const expirationText = isExpired
            ? `🛑 **Expiré** <t:${timestamp}:R>`
            : `⏳ Expire <t:${timestamp}:R>`;

            description += `**${index + 1} - **<@${bot.bot_id}>\n> ${expirationText}\n> [👉 Inviter le robot](${botLink})\n\n`;
          });

        embed.setDescription(description);
        return message.reply({ embeds: [embed] });

      } else {
        const noBotsEmbed = new EmbedBuilder()
          .setColor('FF0000')
          .setTitle('🚫 Aucun Bot Trouvé')
          .setDescription("Vous n'avez actuellement **aucun bot enregistré**.")
          .setFooter({ text: client.footer?.text || 'Gestion des bots', iconURL: client.footer?.iconURL })
          .setTimestamp();

        return message.reply({ embeds: [noBotsEmbed] });
      }
    } catch (error) {
      console.error(error);

      const errorEmbed = new EmbedBuilder()
        .setColor(client.config.error_color || '#FF0000')
        .setTitle('❌ Erreur')
        .setDescription("Une erreur est survenue lors de la récupération de vos bots. Merci de réessayer plus tard.")
        .setFooter({ text: client.footer?.text || 'Gestion des bots', iconURL: client.footer?.iconURL })
        .setTimestamp();

      return message.reply({ embeds: [errorEmbed] });
    }
  },
};
