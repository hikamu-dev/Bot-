const Discord = require('discord.js')
const Astroia = require('../../structures/client/index');
const { example } = require('./help');

module.exports = {
    name: 'inviteinfo',
    description: "Affiche les informations d\'une invitation personnalisée !",
    use: "<url>",
    usage: 'inviteinfo <url>',
    example: '➜ inviteinfo https://discord.gg/shelia\n➜ inviteinfo shelia',
    /**
* 
* @param {Astroia} client 
* @param {Discord.Message} message 
* @param {string[]} args 
*/
    run: async (client, message, args) => {
            let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
        client.db.get(`owner_global_${message.author.id}`) === true || 
client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}
        const url = args[0]
        try {
            const invite = await client.fetchInvite(url);
            if(!invite) return message.reply('Erreur, serveur invalide');
            const server = invite.guild;
            const embed = new Discord.EmbedBuilder()
                .setTitle(server.name)
                .setColor(client.color)
                .setDescription(server.description || 'Aucune description disponible')
                .setThumbnail(server.iconURL())
                .addFields({ name: 'Nombre de membres', value: `\`${invite.memberCount.toLocaleString()} membres\``, inline: false })
                .addFields({ name: 'Nombre de membres en ligne', value: `\`${invite.presenceCount.toLocaleString()} membres\``, inline: false })
                .addFields({ name: 'Nombre de boosts', value: `\`${server.premiumSubscriptionCount.toString()} boost\``, inline: false })
                .addFields({ name: 'Vérification level', value: `**niveau** \`${server.verificationLevel}\``, inline: false })
                .addFields({ name: 'Date de création', value: `<t:${Math.round(server.createdAt / 1000)}:F> (<t:${Math.round(server.createdAt / 1000)}:R>)`, inline: false })
                .setFooter(client.footer);
            if (server.bannerURL() && server.iconURL()) {
                embed.setImage(server.bannerURL({ dynamic: true, size: 4096 }))
            }
            await message.reply({ embeds: [embed] });

        } catch (error) {
            await message.reply('Erreur, serveur invalide');
            console.log('Erreur, serveur invalide');
        }



    },
};