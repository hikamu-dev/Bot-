const ms = require('ms');
const Discord = require('discord.js');
const { StringSelectMenuBuilder, ActionRowBuilder, EmbedBuilder, ComponentType } = require('discord.js');

module.exports = {
    name: 'variable',
    aliases: ['variables'],
    description: 'Permet de voir les variables du bot !',
    run: async (client, message, args, commandName) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
        client.db.get(`owner_global_${message.author.id}`) === true || 
client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        const embed = new EmbedBuilder()
            .setTitle('📌 Variables disponibles')
            .setColor(client.color)
            .setFooter(client.footer)
            .addFields(
                { name: '📨 Invite', value: 'Voir les variables pour les invitations.' },
                { name: '📊 Counter', value: 'Voir les variables pour le compteur.' },
                { name: '🔮 Boost', value: 'Voir les variables pour les boosts.' }
            );

        const select = new StringSelectMenuBuilder()
            .setCustomId(`variable_${message.id}`)
            .setPlaceholder('Sélectionnez une catégorie')
            .addOptions([
                { label: 'Invite', value: `invite_${message.id}`, emoji: '📨' },
                { label: 'Counter', value: `counter_${message.id}`, emoji: '📊' },
                { label: 'Boost', value: `boost_${message.id}`, emoji: '🔮' }
            ]);

        const row = new ActionRowBuilder().addComponents(select);
        message.channel.send({ embeds: [embed], components: [row] });

        const collector = message.channel.createMessageComponentCollector({
            filter: i => i.user.id === message.author.id,
            componentType: ComponentType.StringSelect,
            time: ms('2m')
        });

        collector.on('collect', async i => {
            let embedResponse;
            if (i.values[0] === `invite_${message.id}`) {
                embedResponse = new EmbedBuilder()
                    .setColor(client.color)
                    .setTitle('📨 Variables Invite')
                    .setFooter(client.footer)
                    .addFields(
                        { name: '`{user.id}`', value: 'ID du membre qui a rejoint.', inline: false },
                        { name: '`{user.tag}`', value: 'Tag du membre.', inline: false },
                        { name: '`{user.username}`', value: 'Nom d’utilisateur du membre.', inline: false },
                        { name: '`{user}`', value: 'Mention du membre.', inline: false },
                        { name: '`{inviter.id}`', value: 'ID de l’invitant.', inline: false },
                        { name: '`{inviter.username}`', value: 'Nom d’utilisateur de l’invitant.', inline: false },
                        { name: '`{inviter.tag}`', value: 'Tag de l’invitant.', inline: false },
                        { name: '`{inviter}`', value: 'Mention de l’invitant.', inline: false },
                        { name: '`{inviter.total}`', value: 'Total d’invitations.', inline: false },
                        { name: '`{guild.name}`', value: 'Nom du serveur.', inline: false },
                        { name: '`{guild.id}`', value: 'ID du serveur.', inline: false },
                        { name: '`{guild.count}`', value: 'Nombre total de membres.', inline: false }
                    );
            } else if (i.values[0] === `counter_${message.id}`) {
                embedResponse = new EmbedBuilder()
                    .setColor(client.color)
                    .setTitle('📊 Variables Counter')
                    .setFooter(client.footer)
                    .addFields(
                        { name: '`[server.name]`', value: 'Nom du serveur.', inline: false },
                        { name: '`[server.memberCount]`', value: 'Nombre total de membres.', inline: false },
                        { name: '`[server.boosts]`', value: 'Nombre de boosts.', inline: false },
                        { name: '`[server.onlines]`', value: 'Membres en ligne.', inline: false },
                        { name: '`[server.idle]`', value: 'Membres inactifs.', inline: false },
                        { name: '`[server.dnd]`', value: 'Membres en "Ne pas déranger".', inline: false },
                        { name: '`[server.offlines]`', value: 'Membres hors ligne.', inline: false },
                        { name: '`[server.human]`', value: 'Nombre d’humains.', inline: false },
                        { name: '`[server.bots]`', value: 'Nombre de bots.', inline: false },
                        { name: '`[server.voice]`', value: 'Nombre en vocal.', inline: false },
                        { name: '`[server.channels]`', value: 'Nombre total de salons.', inline: false },
                        { name: '`[server.roles]`', value: 'Nombre de rôles.', inline: false }
                    );
            } else if (i.values[0] === `boost_${message.id}`) {
                embedResponse = new EmbedBuilder()
                    .setColor(client.color)
                    .setTitle('🔮 Variables Boost')
                    .setFooter(client.footer)
                    .addFields(
                        { name: '`{user}`', value: 'Mention du membre qui a boosté.', inline: false },
                        { name: '`{server}`', value: 'Nom du serveur.', inline: false },
                        { name: '`{boostcount}`', value: 'Nombre total de boosts du serveur.', inline: false },
                        { name: '`{boost}`', value: 'Emoji ou texte personnalisé pour représenter un boost.', inline: false }
                    );
            }

            i.update({ embeds: [embedResponse], components: [] });
        });
    }
};
