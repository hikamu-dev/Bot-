// commands/level.js
const { EmbedBuilder } = require("discord.js");

// === DB KEYS ===
const kCfg  = g => `levels_config_${g}`;
const kUser = (g,u) => `levels_user_${g}_${u}`;

// === PERMS: owner / buyer / staff / perms custom (public par défaut) ===
function passGate(client, message, commandName = "level", defaultPublic = true) {
  const uid = message.author.id;
  if (client?.staff?.includes?.(uid)) return true;
  if (client?.config?.buyers?.includes?.(uid)) return true;
  if (client.db.get?.(`owner_global_${uid}`) === true) return true;
  if (client.db.get?.(`owner_${message.guild.id}_${uid}`) === true) return true;

  const commandPerms = client.db.get?.(`command_permissions.${message.guild.id}.${commandName}`) || [];
  if (commandPerms.length > 0) {
    const userPerms = client.db.get?.(`permissions.${message.guild.id}`) || {};
    const roles = message.member.roles.cache.map(r => r.id);
    return commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(id => roles.includes(id)));
  }
  if (client.db.get?.(`perm_${commandName}.${message.guild.id}`) === "public") return true;
  return defaultPublic;
}

function getCfg(client, guildId) {
  return client.db.get?.(kCfg(guildId)) || {
    diff: "moyen",
    xpMin: 8, xpMax: 12,
    cooldown: 35,
    voiceXpPerMin: 1,
    maxLevel: 0
  };
}
function triangular(n){ return (n*(n+1))/2; }
function needFor(cfg, level) {
  const L = Math.max(0, level);
  switch ((cfg.diff||"moyen").toLowerCase()) {
    case "facile":     return 100 + 20*L;
    case "moyen":      return 120 + 30*L + 5*L*L;
    case "difficile":  return 150 + 50*triangular(L);
    case "ultrahard":  return 200 + 100*triangular(L);
    default:           return 120 + 30*L + 5*L*L;
  }
}

// UI
function bar(current, total, size = 22) {
  if (total <= 0) total = 1;
  const ratio = Math.max(0, Math.min(1, current / total));
  const filled = Math.round(ratio * size);
  return "▰".repeat(filled) + "▱".repeat(size - filled);
}

module.exports = {
  name: "level",
  description: "Affiche votre niveau et la progression vers le prochain palier.",
  usage: "level [@membre]",
  category: "utils",

  run: async (client, message, args) => {
    if (!message.guild) return;
    if (!passGate(client, message, "level", true)) {
      if (client.noperm && client.noperm.trim() !== "") {
        const m = await message.channel.send(client.noperm);
        const d = client.db.get?.(`noperm_delay_${message.guild.id}`) || 0;
        if (d > 0) setTimeout(() => m.delete().catch(() => {}), d * 1000);
      }
      return;
    }

    const color = client.color || 0x5865F2;
    const member = message.mentions.members.first() || message.member;
    const cfg = getCfg(client, message.guild.id);
    const state = client.db.get?.(kUser(message.guild.id, member.id)) || { xp: 0, level: 0 };
    const maxLevel = (!cfg.maxLevel || cfg.maxLevel <= 0) ? Infinity : cfg.maxLevel;

    const need = needFor(cfg, state.level);
    const remaining = Math.max(0, need - state.xp);
    const isMax = state.level >= maxLevel && maxLevel !== Infinity;

    const emb = new EmbedBuilder()
      .setColor(color)
      .setAuthor({ name: member.user.username, iconURL: member.user.displayAvatarURL({ size: 128 }) })
      .setThumbnail(member.user.displayAvatarURL({ size: 256 }))
      .setTitle(`🎯 Profil de niveau`)
      .addFields(
        { name: "Niveau", value: `**${state.level}**${isMax ? "  🔒" : ""}`, inline: true },
        { name: "Difficulté", value: `**${cfg.diff}**`, inline: true },
        { name: "XP", value: `**${state.xp}** / ${isMax ? "MAX" : need}`, inline: true },
      );

    if (!isMax) {
      emb.addFields(
        { name: "Progression", value: "`" + bar(state.xp, need) + "`" },
        { name: "Prochain palier", value: `➡️ **L${state.level + 1}** • il manque **${remaining} XP**` }
      ).setFooter({ text: "Astuce: utilise +setlevel pour changer la difficulté ou le mode d’annonce" });
    } else {
      emb.addFields({ name: "Statut", value: "Niveau maximum atteint." });
    }

    return void message.channel.send({ embeds: [emb] });
  }
};
