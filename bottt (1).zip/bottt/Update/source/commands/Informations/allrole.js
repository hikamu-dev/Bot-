const Discord = require('discord.js');
const Snoway = require('../../structures/client/index');

module.exports = {
    name: 'allroles',
    description: 'Affiche tous les rôles du serveur',

    /**
     * @param {Snoway} client 
     * @param {Discord.Message} message 
     * @param {string[]} args 
     */
    run: async (client, message, args, commandName) => {
        let pass = false;

        if (client.staff.includes(message.author.id) || 
            client.config.buyers.includes(message.author.id) ||
            client.db.get(`owner_global_${message.author.id}`) === true || 
            client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
            message.guild.ownerId === message.author.id) {
            pass = true;
        } else {
            const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
            if (commandPerms.length > 0) {
                const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                const userRoles = message.member.roles.cache.map(role => role.id);
                pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
            } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                pass = true;
            }
        }

        if (!pass) {
            if (client.noperm && client.noperm.trim() !== '') {
                const sentMessage = await message.channel.send(client.noperm);
                const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
                if (delayTime > 0) {
                    setTimeout(() => {
                        sentMessage.delete().catch(() => {});
                    }, delayTime * 1000);
                }
            }
            return;
        }

        try {
            const color = parseInt(client.color.replace("#", ""), 16);
            const allRoles = message.guild.roles.cache
                .sort((a, b) => b.position - a.position)
                .filter(role => role.id !== message.guild.id); // exclut @everyone

            const rolesPerPage = 20;
            const roleList = allRoles.map(role => `<@&${role.id}> (ID: \`${role.id}\`)`);

            const pages = [];
            for (let i = 0; i < roleList.length; i += rolesPerPage) {
                pages.push(roleList.slice(i, i + rolesPerPage));
            }

            const row = new Discord.ActionRowBuilder()
                .addComponents(
                    new Discord.ButtonBuilder()
                        .setCustomId('previous')
                        .setLabel('◄')
                        .setStyle(Discord.ButtonStyle.Primary)
                        .setDisabled(true),
                    new Discord.ButtonBuilder()
                        .setCustomId('next')
                        .setLabel('►')
                        .setStyle(Discord.ButtonStyle.Primary)
                        .setDisabled(pages.length <= 1)
                );

            const getEmbed = (pageIndex) => {
                return {
                    color: color,
                    footer: {
                        text: `Page ${pageIndex + 1}/${pages.length} - Rôle(s) total : ${allRoles.size}\n${message.guild.name} - ${client.footer.text}`
                    },
                    title: `Liste des rôles sur ${message.guild.name}`,
                    description: pages[pageIndex].join('\n') || 'Aucun rôle trouvé.',
                };
            };

            const sentMessage = await message.channel.send({
                embeds: [getEmbed(0)],
                components: [row]
            });

            const collector = sentMessage.createMessageComponentCollector({
                filter: (interaction) => interaction.user.id === message.author.id,
                time: 60000
            });

            let currentPage = 0;

            collector.on('collect', async (interaction) => {
                await interaction.deferUpdate();

                if (interaction.customId === 'previous' && currentPage > 0) {
                    currentPage--;
                } else if (interaction.customId === 'next' && currentPage < pages.length - 1) {
                    currentPage++;
                }

                row.components[0].setDisabled(currentPage === 0);
                row.components[1].setDisabled(currentPage === pages.length - 1);

                await interaction.editReply({
                    embeds: [getEmbed(currentPage)],
                    components: [row]
                });
            });

            collector.on('end', async () => {
                row.components.forEach(button => button.setDisabled(true));
                await sentMessage.edit({
                    components: [row]
                });
            });

        } catch (error) {
            console.error('Erreur dans la commande allroles :', error);
            message.channel.send('Une erreur est survenue. Réessaye plus tard.');
        }
    },
};