const Discord = require('discord.js');
const Snoway = require('../../structures/client/index');

module.exports = {
    name: 'allchannel',
    description: 'Affiche tous les salons & catégories du serveur',

    /**
     * @param {Snoway} client 
     * @param {Discord.Message} message 
     * @param {string[]} args 
     */
    run: async (client, message, args, commandName) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
        client.db.get(`owner_global_${message.author.id}`) === true || 
client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        try {
            const color = parseInt(client.color.replace("#", ""), 16);
            const allChannels = message.guild.channels.cache;
            const channelsPerPage = 20; // Number of channels per page

            // Create channel list
            const channelList = allChannels.map((channel) => {
                let text = "";
                switch (channel.type) {
                    case 0:
                        text = "Text";
                        break;
                    case 2:
                        text = "Vocal";
                        break;
                    case 4:
                        text = "Catégorie";
                        break;
                    default:
                        text = "Inconnu";
                }
                return `${channel.type === 4 ? `\`#${channel.name}\`` : `<#${channel.id}>`} (Type: **${text}**)`;
            });

            // Split channels into pages
            const pages = [];
            for (let i = 0; i < channelList.length; i += channelsPerPage) {
                pages.push(channelList.slice(i, i + channelsPerPage));
            }

            // Create buttons
            const row = new Discord.ActionRowBuilder()
                .addComponents(
                    new Discord.ButtonBuilder()
                        .setCustomId('previous')
                        .setLabel('◄')
                        .setStyle(Discord.ButtonStyle.Primary)
                        .setDisabled(true),
                    new Discord.ButtonBuilder()
                        .setCustomId('next')
                        .setLabel('►')
                        .setStyle(Discord.ButtonStyle.Primary)
                        .setDisabled(pages.length <= 1)
                );

            // Create initial embed
            const getEmbed = (pageIndex) => {
                return {
                    color: color,
                    footer: {
                        text: `Page ${pageIndex + 1}/${pages.length} - Résultat(s) : ${allChannels.size}\n${message.guild.name} - ${client.footer.text}`
                    },
                    title: `Liste des salons sur ${message.guild.name}`,
                    description: pages[pageIndex].join('\n') || 'Aucun salon disponible',
                };
            };

            // Send initial message
            const sentMessage = await message.channel.send({
                embeds: [getEmbed(0)],
                components: [row]
            });

            // Create collector for button interactions
            const collector = sentMessage.createMessageComponentCollector({
                filter: (interaction) => interaction.user.id === message.author.id,
                time: 60000 // 1 minute timeout
            });

            let currentPage = 0;

            collector.on('collect', async (interaction) => {
                await interaction.deferUpdate();

                if (interaction.customId === 'previous' && currentPage > 0) {
                    currentPage--;
                } else if (interaction.customId === 'next' && currentPage < pages.length - 1) {
                    currentPage++;
                }

                // Update button states
                row.components[0].setDisabled(currentPage === 0);
                row.components[1].setDisabled(currentPage === pages.length - 1);

                // Update message
                await interaction.editReply({
                    embeds: [getEmbed(currentPage)],
                    components: [row]
                });
            });

            collector.on('end', async () => {
                // Disable buttons after collector ends
                row.components.forEach(button => button.setDisabled(true));
                await sentMessage.edit({
                    components: [row]
                });
            });

        } catch (error) {
            console.error('Erreur dans la commande allchannel :', error);
            message.channel.send('Une erreur inattendue s\'est produite. Veuillez réessayer plus tard.');
        }
    },
};