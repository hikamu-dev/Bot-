const { Astroia } = require("../../structures/client/index");
const Discord = require('discord.js');

module.exports = {
    name: 'leaderboard',
    description: 'Affiche le classement des membres en fonction du nombre de messages, invitations ou temps vocal.',
    run: async (client, message, args, commandName) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
                client.db.get(`owner_global_${message.author.id}`) === true || 

client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        const guildId = message.guild.id;

        const selectMenu = new Discord.StringSelectMenuBuilder()
            .setCustomId('leaderboard_select')
            .setPlaceholder('✨ Choisis ton classement !')
            .addOptions([
                {
                    label: 'Messages',
                    description: 'Top des plus bavards !',
                    value: 'messages',
                    emoji: '💬',
                },
                {
                    label: 'Invitations',
                    description: 'Les meilleurs recruteurs !',
                    value: 'invites',
                    emoji: '📩',
                },
                {
                    label: 'Temps Vocal',
                    description: 'Les rois du micro !',
                    value: 'vocal',
                    emoji: '🎙️',
                },
            ]);

        const row = new Discord.ActionRowBuilder().addComponents(selectMenu);

        const initialEmbed = new Discord.EmbedBuilder()
            .setColor(client.color)
            .setTitle('🏆 Leaderboard du Serveur')
            .setDescription('Explore les classements et découvre les champions !\nSélectionne une catégorie ci-dessous pour commencer.')
            .setThumbnail(message.guild.iconURL({ dynamic: true }))
            .setFooter({ text: client.footer.text, iconURL: client.user.displayAvatarURL() })
            .setTimestamp();

        const reply = await message.channel.send({
            embeds: [initialEmbed],
            components: [row],
        });

        const collector = reply.createMessageComponentCollector({
            filter: i => i.user.id === message.author.id,
            time: 60000,
        });

        collector.on('collect', async interaction => {
            const selectedValue = interaction.values[0];
            let leaderboardEmbed;

            if (selectedValue === 'messages') {
                const leaderboard = [];
                message.guild.members.cache.forEach(member => {
                    const userId = member.user.id;
                    const messageCount = client.db.get(`message_${guildId}_${userId}`) || 0;
                    leaderboard.push({ id: userId, messages: messageCount });
                });

                leaderboard.sort((a, b) => b.messages - a.messages);
                let leaderboardMessage = '';
                for (let i = 0; i < leaderboard.length && i < 20; i++) {
                    const member = await client.users.fetch(leaderboard[i].id);
                    leaderboardMessage += `[ ${i + 1} ] ${member.tag} • 💬 ${leaderboard[i].messages.toLocaleString()} messages\n`;
                }

                leaderboardEmbed = new Discord.EmbedBuilder()
                    .setColor(client.color)
                    .setTitle('💬 Top Messages')
                    .setDescription(leaderboardMessage ? `\`\`\`\n${leaderboardMessage}\`\`\`` : '🌌 Aucun message pour le moment.')
                    .setFooter(client.footer)
            }

            if (selectedValue === 'invites') {
                const leaderboard = [];
                message.guild.members.cache.forEach(member => {
                    const userId = member.user.id;
                    const invitesData = client.db.get(`invites_${userId}_${guildId}`);
                    const totalInvites = invitesData?.total || 0;
                    leaderboard.push({ id: userId, invites: totalInvites });
                });

                leaderboard.sort((a, b) => b.invites - a.invites);
                let leaderboardMessage = '';
                for (let i = 0; i < leaderboard.length && i < 20; i++) {
                    const member = await client.users.fetch(leaderboard[i].id);
                    leaderboardMessage += `[ ${i + 1} ]  ${member.tag} • 📩 ${leaderboard[i].invites.toLocaleString()} invitations\n`;
                }

                leaderboardEmbed = new Discord.EmbedBuilder()
                    .setColor(client.color)
                    .setTitle('📩 Top Invitations')
                    .setDescription(leaderboardMessage ? `\`\`\`\n${leaderboardMessage}\`\`\`` : '🌌 Aucune invitation pour le moment.')
                    .setFooter(client.footer)
            }

            if (selectedValue === 'vocal') {
                const leaderboard = [];
                message.guild.members.cache.forEach(member => {
                    const userId = member.user.id;
                    const vocalTime = client.db.get(`vocal_${guildId}_${userId}`) || 0;
                    leaderboard.push({ id: userId, vocal: vocalTime });
                });

                leaderboard.sort((a, b) => b.vocal - a.vocal);
                let leaderboardMessage = '';
                for (let i = 0; i < leaderboard.length && i < 20; i++) {
                    const member = await client.users.fetch(leaderboard[i].id);
                    leaderboardMessage += `[ ${i + 1} ] ${member.tag} • 🎙️ ${formatTime(leaderboard[i].vocal)}\n`;
                }

                leaderboardEmbed = new Discord.EmbedBuilder()
                    .setColor(client.color)
                    .setTitle('🎙️ Top Temps Vocal')
                    .setDescription(leaderboardMessage ? `\`\`\`\n${leaderboardMessage}\`\`\`` : '🌌 Aucun temps vocal pour le moment.')
                    .setFooter(client.footer)
            }

            await interaction.update({
                embeds: [leaderboardEmbed],
                components: [row],
            });
        });

        collector.on('end', (collected, reason) => {
            if (reason === 'time') {
                const disabledRow = new Discord.ActionRowBuilder().addComponents(
                    selectMenu.setDisabled(true)
                );
                reply.edit({
                    components: [disabledRow],
                });
            }
        });

        function formatTime(temps) {
            let time;
            if (temps < 60) {
                time = `${temps} sec`;
            } else if (temps < 3600) {
                const minutes = Math.floor(temps / 60);
                const seconds = temps % 60;
                time = `${minutes}m ${seconds}s`;
            } else if (temps < 86400) {
                const heures = Math.floor(temps / 3600);
                const minutes = Math.floor((temps % 3600) / 60);
                time = `${heures}h ${minutes}m`;
            } else if (temps < 31536000) {
                const jours = Math.floor(temps / 86400);
                const heures = Math.floor((temps % 86400) / 3600);
                time = `${jours}j ${heures}h`;
            } else {
                const années = Math.floor(temps / 31536000);
                const jours = Math.floor((temps % 31536000) / 86400);
                time = `${années}an ${jours}j`;
            }
            return time;
        }
    },
};