const Discord = require("discord.js");

module.exports = {
  name: "afk",
  use: "<raison>",
  usage: "afk <raison>",
  description: "Permet d'être en mode afk et l'indiquer aux autres membres",
  run: async (client, message, args) => {
                  let pass = false;

    if (
      client.staff.includes(message.author.id) ||
      client.config.buyers.includes(message.author.id) ||
      client.db.get(`owner_global_${message.author.id}`) === true || 
      client.db.get(`owner_${message.author.id}`) === true
    ) {
      pass = true;
    } else {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map((role) => role.id);
        pass = commandPerms.some((perm) => userPerms[perm] && userPerms[perm].some((roleId) => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        pass = true;
      }
    }

    if (!pass) {
      if (client.noperm && client.noperm.trim() !== "") {
        const sentMessage = await message.channel.send(client.noperm);
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
          setTimeout(() => {
            sentMessage.delete().catch(() => {});
          }, delayTime * 1000);
        }
      }
      return;
    }
    const reason = args.join(" ") || "AFK";

    client.db.set(`afk_${message.author.id}`, {
      reason,
      timestamp: Date.now()
    });

    message.reply(`Tu es maintenant en mode AFK : ${reason}`);
  }
};