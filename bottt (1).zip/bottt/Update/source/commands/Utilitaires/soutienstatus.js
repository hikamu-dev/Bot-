const Discord = require("discord.js");

module.exports = {
    name: "setsoutien",
    description: "Gérer les statuts de soutien autorisés (admin only)",
    usage: "setsoutien <add|remove|list> <texte>",
    run: async (client, message, args, commandName) => {
        const guildId = message.guild.id;
        const whitelistDB = client.db.get(`wl.${guildId}`) || [];

        // === BYPASS (comme ban.js) ===
        const isBypass = (
            client.staff.includes(message.author.id) ||
            client.config.buyers.includes(message.author.id) ||
            client.db.get(`owner_${message.author.id}`) === true ||
            client.db.get(`owner_global_${message.author.id}`) === true ||
            whitelistDB.includes(message.author.id) 
        );

        // === PERM SYSTEM (comme ban.js) ===
        let pass = false;
        if (isBypass) {
            pass = true;
        } else {
            const commandPerms = client.db.get(`command_permissions.${guildId}.${commandName}`) || [];
            if (commandPerms.length > 0) {
                const userPerms = client.db.get(`permissions.${guildId}`) || {};
                const userRoles = message.member.roles.cache.map(r => r.id);
                pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
            } else if (client.db.get(`perm_${commandName}.${guildId}`) === "public") {
                pass = true;
            }
        }

        if (!pass) {
            if (client.noperm && client.noperm.trim() !== "") {
                const sentMessage = await message.channel.send(client.noperm);
                const delayTime = client.db.get(`noperm_delay_${guildId}`) || 0;
                if (delayTime > 0) {
                    setTimeout(() => sentMessage.delete().catch(() => {}), delayTime * 1000);
                }
            }
            return;
        }

        const action = args[0]?.toLowerCase();
        const key = `soutiens_keywords_${guildId}`;
        let keywords = client.db.get(key) || [];

        if (!action) return message.reply("⚙️ Utilisation : `setsoutien <add|remove|list> <texte>`");

        if (action === "add") {
            if (!isBypass) return message.reply("❌ Seuls les owners/admins peuvent ajouter.");
            const text = args.slice(1).join(" ").toLowerCase();
            if (!text) return message.reply("Merci d’indiquer un texte.");
            if (keywords.includes(text)) return message.reply("❌ Déjà présent.");
            keywords.push(text);
            client.db.set(key, keywords);
            return message.reply(`✅ Ajouté : \`${text}\``);
        }

        if (action === "remove") {
            if (!isBypass) return message.reply("❌ Seuls les owners/admins peuvent retirer.");
            const text = args.slice(1).join(" ").toLowerCase();
            if (!text) return message.reply("Merci d’indiquer un texte.");
            if (!keywords.includes(text)) return message.reply("❌ Pas trouvé.");
            keywords = keywords.filter(k => k !== text);
            client.db.set(key, keywords);
            return message.reply(`🗑️ Retiré : \`${text}\``);
        }

        if (action === "list") {
            if (keywords.length === 0) return message.reply("⚠️ Aucun statut défini.");
            const embed = new Discord.EmbedBuilder()
                .setColor(client.color || "#2f3136")
                .setTitle("📋 Statuts autorisés")
                .setDescription(keywords.map((k, i) => `\`${i+1}\` ・ ${k}`).join("\n"));
            return message.channel.send({ embeds: [embed] });
        }
    }
};
