const Discord = require('discord.js');
const Astroia = require('../../structures/client/index');

module.exports = {
    name: "wordreaction",
    description: "Gère les réactions automatiques basées sur des mots dans les messages.",
    use: "<add/list/del> <mot> <emoji>",
    usage: "wordreaction <add/list/del> [mot] [emoji]",
    example: "➜ wordreaction add bonjour 😀\n➜ wordreaction list\n➜ wordreaction del bonjour",
    run: async (client, message, args, commandName) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
                client.db.get(`owner_global_${message.author.id}`) === true || 
 
client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        // Vérifier les permissions du bot
        const botMember = message.guild.members.cache.get(client.user.id);
        if (!botMember.permissions.has(Discord.PermissionsBitField.Flags.AddReactions)) {
            return message.channel.send("Je n'ai pas la permission d'ajouter des réactions. Veuillez vérifier mes permissions.");
        }

        if (!args[0]) {
            return message.channel.send("Utilisation incorrecte : wordreaction <add/list/del> [mot] [emoji]");
        }

        const action = args[0].toLowerCase();
        const dbKey = `wordreactions_${message.guild.id}`;
        let wordReactions = client.db.get(dbKey) || {};

        if (action === 'add') {
            if (args.length < 3) {
                return message.channel.send("Utilisation incorrecte : wordreaction add <mot> <emoji>");
            }

            const word = args[1].toLowerCase();
            const emoji = args[2];

            // Vérifier si l'emoji est valide
            const emojiRegex = /^(?:<a?:\w+:\d+>|[\uD800-\uDBFF][\uDC00-\uDFFF]|\d+)$/;
            if (!emojiRegex.test(emoji)) {
                return message.channel.send("L'emoji fourni n'est pas valide. Utilisez un emoji Unicode ou un emoji personnalisé.");
            }

            // Vérifier si le mot existe déjà
            if (wordReactions[word]) {
                return message.channel.send(`Le mot \`${word}\` est déjà associé à l'emoji ${wordReactions[word]}.`);
            }

            // Ajouter le mot et l'emoji à la base de données
            wordReactions[word] = emoji;
            client.db.set(dbKey, wordReactions);

            return message.channel.send(`Réaction automatique ajoutée : le mot \`${word}\` déclenchera l'emoji ${emoji}.`);

        } else if (action === 'list') {
            if (Object.keys(wordReactions).length === 0) {
                return message.channel.send("Aucune réaction automatique configurée pour ce serveur.");
            }

            const embed = new Discord.EmbedBuilder()
                .setColor(client.color)
                .setTitle("Réactions automatiques configurées")
                .setDescription(
                    Object.entries(wordReactions)
                        .map(([word, emoji]) => `**Mot** : \`${word}\`\n **Emoji** : ${emoji}`)
                        .join('\n')
                )
                .setFooter(client.footer)
            return message.channel.send({ embeds: [embed] });

        } else if (action === 'del') {
            if (args.length < 2) {
                return message.channel.send("Utilisation incorrecte : wordreaction del <mot>");
            }

            const word = args[1].toLowerCase();

            // Vérifier si le mot existe
            if (!wordReactions[word]) {
                return message.channel.send(`Le mot \`${word}\` n'est pas configuré pour une réaction automatique.`);
            }

            // Supprimer le mot de la base de données
            delete wordReactions[word];
            client.db.set(dbKey, wordReactions);

            return message.channel.send(`Réaction automatique supprimée pour le mot \`${word}\`.`);

        } else {
            return message.channel.send("Action non reconnue. Utilisez : `add`, `list` ou `del`.");
        }
    }
};