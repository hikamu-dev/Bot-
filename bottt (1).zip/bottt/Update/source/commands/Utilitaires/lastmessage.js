const { EmbedBuilder, ChannelType, PermissionsBitField, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  name: 'lastmessage',
  description: 'Affiche le dernier message d\'un utilisateur dans un salon',
  usage: 'lastmessage [@user/ID] [channelID/mention]',
  use: '[@user/ID] [channelID/mention]',
  example: "➜ lastmessage 1392239258898534430 #general\n➜ lastmessage @tokyru 1390056098047856804",
  run: async (client, message, args) => {
      let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
                client.db.get(`owner_global_${message.author.id}`) === true || 

client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}
    // Vérifier si la commande est exécutée dans un serveur
    if (!message.guild) {
      return message.channel.send('Cette commande fonctionne uniquement dans un serveur.');
    }

    // Vérifier les permissions du bot
    if (!message.guild.members.me.permissionsIn(message.channel).has(PermissionsBitField.Flags.ViewChannel)) {
      return message.channel.send('Je n\'ai pas la permission de voir les messages dans ce salon.');
    }

    // Résoudre l'utilisateur cible
    let user;
    if (args[0]) {
      const userId = args[0].replace(/[<@!>]*/g, ''); // Extraire l'ID de la mention
      try {
        user = await message.guild.members.fetch(userId);
      } catch {
        user = message.mentions.members.first();
      }
    }
    if (!user) user = message.member; // Par défaut, utiliser l'auteur du message

    // Résoudre le salon cible
    let channel = message.channel;
    if (args[1]) {
      const channelId = args[1].replace(/[<#>]*/g, ''); // Extraire l'ID de la mention
      channel = message.guild.channels.cache.get(channelId) || message.mentions.channels.first();
      if (!channel || channel.type !== ChannelType.GuildText) {
        return message.channel.send('Salon invalide ou introuvable (doit être un salon textuel).');
      }
    }

    // Vérifier les permissions du bot dans le salon cible
    if (!message.guild.members.me.permissionsIn(channel).has(PermissionsBitField.Flags.ReadMessageHistory)) {
      return message.channel.send(`Je n'ai pas la permission de lire l'historique des messages dans ${channel}.`);
    }

    try {
      let lastMsg = null;
      let beforeId = null;
      let searchedCount = 0;
      const limitSearch = 1000; // Limite de recherche pour éviter les abus

      // Boucle pour récupérer les messages par lots de 100
      while (searchedCount < limitSearch) {
        const fetchedMessages = await channel.messages.fetch({ limit: 100, before: beforeId });
        if (fetchedMessages.size === 0) break; // Aucun message restant

        // Trouver le premier message de l'utilisateur dans ce lot
        for (const msg of fetchedMessages.values()) {
          if (msg.author.id === user.id) {
            lastMsg = msg;
            break;
          }
        }
        if (lastMsg) break; // Sortir si un message est trouvé

        beforeId = fetchedMessages.last().id; // Continuer à partir du dernier message du lot
        searchedCount += fetchedMessages.size;
      }

      // Si aucun message n'est trouvé
      if (!lastMsg) {
        return message.channel.send(`Aucun message trouvé de ${user.user.tag} dans ${channel} (limite de ${limitSearch} messages).`);
      }

      // Créer l'embed pour afficher le message
      const embed = new EmbedBuilder()
        .setAuthor({ name: user.user.tag, iconURL: user.user.displayAvatarURL({ dynamic: true }) })
.setDescription(lastMsg.content ? `\`${lastMsg.content}\`` : '*Message sans contenu (peut-être une image ou un fichier)*')
        .addFields(
          { name: 'Salon', value: `${channel}`, inline: true },
          { name: 'Date', value: `<t:${Math.floor(lastMsg.createdTimestamp / 1000)}:R>`, inline: true }
        )
        .setFooter({ text: `Message ID: ${lastMsg.id}` })
        .setTimestamp(lastMsg.createdAt)
        .setColor(client.color || '#00FF00')
        .setFooter(client.footer)

      // Créer un bouton pour aller au message
      const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setLabel('Aller au message')
            .setStyle(ButtonStyle.Link)
            .setURL(lastMsg.url)
        );

      return message.channel.send({ embeds: [embed], components: [row] });
    } catch (error) {
      console.error('Erreur lors de la récupération des messages :', error);
      return message.channel.send('Une erreur s\'est produite lors de la récupération des messages.');
    }
  },
};