const Discord = require('discord.js')

const parseDuration = (duration) => {
  const regex = /^(\d+)([smhd])$/
  const match = duration.match(regex)
  if (!match) return null

  const value = parseInt(match[1])
  const unit = match[2]

  switch (unit) {
    case 's': return value * 1000
    case 'm': return value * 60 * 1000
    case 'h': return value * 60 * 60 * 1000
    case 'd': return value * 24 * 60 * 60 * 1000
    default: return null
  }
}

module.exports = {
  name: 'reminder',
  description: 'Crée, liste ou supprime un rappel envoyé en message privé.',
  use: "add/list/del <temps> <rappel>",
  usage: "reminder add/list/del <temps> <rappel>",
  example: "➜ reminder add 5m Réunion\n➜ reminder list\n➜ reminder del 1",
  run: async (client, message, args, commandName) => {
    let pass = false

    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
                client.db.get(`owner_global_${message.author.id}`) === true || 

client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true
    } else {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || []
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {}
        const userRoles = message.member.roles.cache.map(role => role.id)
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)))
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        pass = true
      }
    }

    if (!pass) {
      if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm)
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0
        if (delayTime > 0) {
          setTimeout(() => {
            sentMessage.delete().catch(() => {})
          }, delayTime * 1000)
        }
      }
      return
    }

    if (!args[0]) {
      return message.channel.send('Utilisation : `reminder add/list/del <temps> <rappel>` (ex: `reminder add 5m Réunion`)')
    }

    const action = args[0].toLowerCase()

    if (action === 'add') {
      if (!args[1] || !args[2]) {
        return message.channel.send('Veuillez fournir un temps et un message de rappel (ex: `reminder add 5m Réunion`).')
      }

      const duration = parseDuration(args[1])
      if (!duration) {
        return message.channel.send('Format de temps invalide. Utilisez un nombre suivi de s, m, h ou d. Exemples: `5m`, `2h`, `1d`.')
      }

      const remindAt = Math.floor((Date.now() + duration) / 1000)
      const reminderMessage = args.slice(2).join(' ')
      const reminderKey = `reminders_${message.guild.id}`
      const reminders = client.db.get(reminderKey) || []
      const reminderId = reminders.length ? reminders[reminders.length - 1].id + 1 : 1

      reminders.push({
        id: reminderId,
        userId: message.author.id,
        remindAt,
        message: reminderMessage
      })

      client.db.set(reminderKey, reminders)

      return message.channel.send(`Rappel créé (ID: ${reminderId}) pour <t:${remindAt}:F>. Tu le recevras en message privé.`)

    } else if (action === 'list') {
      const reminderKey = `reminders_${message.guild.id}`
      const reminders = client.db.get(reminderKey) || []

      if (reminders.length === 0) {
        return message.channel.send('Aucun rappel configuré sur ce serveur.')
      }

      const embed = new Discord.EmbedBuilder()
        .setColor(client.color)
        .setFooter(client.footer)
        .setTitle('Liste des rappels')
        .setDescription(
          reminders.map(r => 
            `**ID: ${r.id}** | <@${r.userId}> | <t:${r.remindAt}:F> | ${r.message}`
          ).join('\n')
        )
        .setTimestamp()

      return message.channel.send({ embeds: [embed] })

    } else if (action === 'del') {
      if (!args[1]) {
        return message.channel.send('Veuillez fournir l\'ID du rappel à supprimer (ex: `reminder del 1`).')
      }

      const reminderId = parseInt(args[1])
      if (isNaN(reminderId)) {
        return message.channel.send('L\'ID du rappel doit être un nombre.')
      }

      const reminderKey = `reminders_${message.guild.id}`
      let reminders = client.db.get(reminderKey) || []
      const reminder = reminders.find(r => r.id === reminderId)

      if (!reminder) {
        return message.channel.send(`Aucun rappel trouvé avec l'ID ${reminderId}.`)
      }

      if (reminder.userId !== message.author.id && !client.staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
        return message.channel.send('Vous ne pouvez supprimer que vos propres rappels.')
      }

      reminders = reminders.filter(r => r.id !== reminderId)
      client.db.set(reminderKey, reminders)

      return message.channel.send(`Rappel ID ${reminderId} supprimé.`)
    }

    return message.channel.send('Action invalide. Utilisez `add`, `list` ou `del`.')
  }
}
