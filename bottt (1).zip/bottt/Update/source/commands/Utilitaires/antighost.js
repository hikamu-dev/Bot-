// commands/moderation/antighost.js
// Panel AntiGhost avec auto-refresh (embed+boutons se mettent à jour après chaque action).
//
// DB :
//  antighost_enabled_<gId> : true|false
//  antighost_list_<gId>    : [userId,...]
//  antighost_msg_<gId>     : string (placeholders: {author} {user} {guild})

const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  StringSelectMenuBuilder
} = require("discord.js");

function uniq(arr) { return [...new Set(arr)]; }
function parseUserIds(input = "") {
  const ids = [];
  for (const tok of input.split(/\s+/).filter(Boolean)) {
    // mention <@123> ou <@!123> ou ID nu
    const m = tok.match(/\d{15,20}/);
    if (m) ids.push(m[0]);
  }
  return uniq(ids).slice(0, 25);
}
function nameOf(guild, uid) {
  const m = guild.members.cache.get(uid);
  if (!m) return `Unknown#${uid}`;
  return m.user?.tag || m.displayName || uid;
}

module.exports = {
  name: "antighost",
  description: "Ouvre le panel AntiGhost (protéger des personnes contre le ghost ping).",
  usages: "antighost",
  example: "antighost",
  /**
   * @param {import('discord.js').Client} client
   * @param {import('discord.js').Message} message
   * @param {string[]} args
   */
  run: async (client, message, args, commandName = "antighost") => {
    try {
      if (!message.guild) return;

      // ---- Permissions (même style que tes autres cmd) ----
      const whitelistDB = client.db.get(`wl.${message.guild.id}`) || [];
      const isBypassHard =
        client.staff?.includes?.(message.author.id) ||
        client.config?.buyers?.includes?.(message.author.id) ||
        client.db.get(`owner_${message.author.id}`) === true ||
        client.db.get(`owner_global_${message.author.id}`) === true ||
        whitelistDB.includes(message.author.id) ||
        message.guild.ownerId === message.author.id;

      let pass = isBypassHard;
      if (!pass) {
        const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
        if (commandPerms.length > 0) {
          const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
          const userRoles = message.member.roles.cache.map(r => r.id);
          pass = commandPerms.some(perm => userPerms[perm]?.some?.(roleId => userRoles.includes(roleId)));
        } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") pass = true;
      }
      if (!pass) {
        if (client.noperm && client.noperm.trim() !== "") {
          const sent = await message.channel.send({ content: client.noperm, allowedMentions: { parse: [] } });
          const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
          if (delayTime > 0) setTimeout(() => sent.delete().catch(() => {}), delayTime * 1000);
        }
        return;
      }

      const gId = message.guild.id;
      const kEnabled = `antighost_enabled_${gId}`;
      const kList   = `antighost_list_${gId}`;
      const kMsg    = `antighost_msg_${gId}`;

      // --- Helpers DB
      const getEnabled = () => !!client.db.get(kEnabled);
      const getList = () => uniq(client.db.get(kList) || []);
      const getMsg = () => client.db.get(kMsg) || "⚠️ {author} a essayé de ghost ping {user} sur {guild}.";

      // --- View builders (lisent l'état ACTUEL)
      const fmtListPreview = () => {
        const list = getList();
        if (!list.length) return "_Aucune personne protégée._";
        return list.slice(0, 10).map((id, i) => `#${i+1} • <@${id}> \`${nameOf(message.guild, id)}\``).join("\n");
      };

      const makeEmbed = () => {
        const enabled = getEnabled();
        const list = getList();
        const msgTpl = getMsg();
        return new EmbedBuilder()
          .setColor(enabled ? 0x57F287 : 0xED4245)
          .setTitle("🛡️ AntiGhost — Panel")
          .setDescription([
            `**Statut :** ${enabled ? "🟢 Activé" : "🔴 Désactivé"}`,
            `**Protégés :** ${list.length}`,
            "",
            "**Aperçu :**",
            fmtListPreview(),
            "",
            "**Message d’alerte :**",
            "```",
            msgTpl,
            "```",
            "Placeholders : `{author}` `{user}` `{guild}`"
          ].join("\n"));
      };

      const panelId = `ag_${message.id}_${Date.now()}`;
      const makeRows = () => {
        const enabled = getEnabled();
        const row1 = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId(`${panelId}:toggle`).setLabel(enabled ? "Désactiver" : "Activer").setStyle(enabled ? ButtonStyle.Danger : ButtonStyle.Success),
          new ButtonBuilder().setCustomId(`${panelId}:add`).setLabel("➕ Ajouter").setStyle(ButtonStyle.Primary),
          new ButtonBuilder().setCustomId(`${panelId}:remove`).setLabel("➖ Retirer").setStyle(ButtonStyle.Secondary),
        );
        const row2 = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId(`${panelId}:list`).setLabel("📋 Lister").setStyle(ButtonStyle.Secondary),
          new ButtonBuilder().setCustomId(`${panelId}:msg`).setLabel("📝 Message").setStyle(ButtonStyle.Secondary),
          new ButtonBuilder().setCustomId(`${panelId}:clear`).setLabel("♻️ Vider").setStyle(ButtonStyle.Danger),
          new ButtonBuilder().setCustomId(`${panelId}:close`).setLabel("❌ Fermer").setStyle(ButtonStyle.Secondary),
        );
        return [row1, row2];
      };

      // --- Envoi + utilitaire refresh
      const panelMsg = await message.channel.send({
        embeds: [makeEmbed()],
        components: makeRows(),
        allowedMentions: { parse: [] }
      });

      async function refresh() {
        try {
          await panelMsg.edit({ embeds: [makeEmbed()], components: makeRows() });
        } catch {}
      }

      // --- Collector boutons
      const collector = panelMsg.createMessageComponentCollector({ time: 10 * 60 * 1000 });

      collector.on("collect", async (i) => {
        if (i.user.id !== message.author.id) return i.reply({ content: "Seul l'initiateur peut utiliser ce panel.", ephemeral: true });
        const [pid, action] = (i.customId || "").split(":");
        if (pid !== panelId) return;

        if (action === "toggle") {
          client.db.set(kEnabled, !getEnabled());
          await i.deferUpdate();
          await refresh();
          return;
        }

        if (action === "list") {
          const lines = getList().map((id, idx) => `${idx+1}. <@${id}> \`${nameOf(message.guild, id)}\``).join("\n") || "Aucun protégé.";
          return i.reply({ content: lines.slice(0, 1900), ephemeral: true, allowedMentions: { parse: [] } });
        }

        if (action === "add") {
          const modal = new ModalBuilder().setCustomId(`${panelId}:addmodal`).setTitle("Ajouter des protégés");
          const inp = new TextInputBuilder()
            .setCustomId("users")
            .setLabel("Mentions ou IDs (séparés par espaces)")
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(true);
          modal.addComponents(new ActionRowBuilder().addComponents(inp));
          await i.showModal(modal);
          return;
        }

        if (action === "remove") {
          const current = getList();
          if (!current.length) return i.reply({ content: "Aucun protégé à retirer.", ephemeral: true });
          const menu = new StringSelectMenuBuilder()
            .setCustomId(`${panelId}:removemenu`)
            .setPlaceholder("Choisis les personnes à retirer")
            .setMinValues(1)
            .setMaxValues(Math.min(25, current.length))
            .addOptions(
              current.slice(0, 25).map(uid => ({
                label: nameOf(message.guild, uid).slice(0, 100),
                value: uid,
                description: `ID: ${uid}`.slice(0, 100)
              }))
            );
          return i.reply({ components: [new ActionRowBuilder().addComponents(menu)], ephemeral: true });
        }

        if (action === "msg") {
          const modal = new ModalBuilder().setCustomId(`${panelId}:msgmodal`).setTitle("Message d’alerte");
          const inp = new TextInputBuilder()
            .setCustomId("msg")
            .setLabel("Texte (placeholders: {author} {user} {guild})")
            .setStyle(TextInputStyle.Paragraph)
            .setValue(getMsg())
            .setRequired(true);
          modal.addComponents(new ActionRowBuilder().addComponents(inp));
          await i.showModal(modal);
          return;
        }

        if (action === "clear") {
          client.db.set(kList, []);
          await i.deferUpdate();
          await refresh();
          return;
        }

        if (action === "close") {
          collector.stop("closed");
          return i.update({ components: [] });
        }
      });

      // --- Gestion modales & menus (avec refresh)
      const onInteraction = async (i) => {
        const [pid, what] = (i.customId || "").split(":");
        if (pid !== panelId) return;
        if (i.user.id !== message.author.id) return i.reply({ content: "Seul l'initiateur peut utiliser ce panel.", ephemeral: true });

        if (i.isModalSubmit() && what === "addmodal") {
          const raw = i.fields.getTextInputValue("users") || "";
          const ids = parseUserIds(raw);
          if (!ids.length) return i.reply({ content: "Aucun ID valide détecté.", ephemeral: true });

          const cur = getList();
          const merged = uniq(cur.concat(ids));
          client.db.set(kList, merged);

          await i.reply({ content: `✅ Ajouté : ${ids.map(id => `<@${id}>`).join(", ")}`, ephemeral: true, allowedMentions: { parse: [] } });
          await refresh();
          return;
        }

        if (i.isStringSelectMenu() && what === "removemenu") {
          const vals = i.values || [];
          if (!vals.length) return i.reply({ content: "Rien de sélectionné.", ephemeral: true });
          const set = new Set(getList());
          for (const v of vals) set.delete(v);
          client.db.set(kList, [...set]);
          await i.update({ content: `🗑️ Retiré : ${vals.map(v => `<@${v}>`).join(", ")}`, components: [], ephemeral: true, allowedMentions: { parse: [] } });
          await refresh();
          return;
        }

        if (i.isModalSubmit() && what === "msgmodal") {
          const txt = i.fields.getTextInputValue("msg")?.trim();
          if (!txt) return i.reply({ content: "Message vide.", ephemeral: true });
          client.db.set(kMsg, txt);
          await i.reply({ content: "✅ Message d’alerte mis à jour.", ephemeral: true });
          await refresh();
          return;
        }
      };

      client.on("interactionCreate", onInteraction);

      collector.on("end", async () => {
        try { await panelMsg.edit({ components: [] }); } catch {}
        client.removeListener("interactionCreate", onInteraction);
      });

    } catch (e) {
      console.error(e);
      message.channel.send({ content: "❌ Impossible d’ouvrir le panel AntiGhost.", allowedMentions: { parse: [] } });
    }
  }
};
