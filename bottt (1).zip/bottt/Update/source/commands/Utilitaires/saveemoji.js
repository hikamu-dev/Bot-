const Discord = require("discord.js");

module.exports = {
  name: "saveemoji",
  use: "",
  usage: "saveemoji",
  description: "Crée une backup d'émojis du serveur",
  run: async (client, message, args) => {
                let pass = false;

    if (
      client.staff.includes(message.author.id) ||
      client.config.buyers.includes(message.author.id) ||
              client.db.get(`owner_global_${message.author.id}`) === true || 

      client.db.get(`owner_${message.author.id}`) === true
    ) {
      pass = true;
    } else {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map((role) => role.id);
        pass = commandPerms.some((perm) => userPerms[perm] && userPerms[perm].some((roleId) => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        pass = true;
      }
    }

    if (!pass) {
      if (client.noperm && client.noperm.trim() !== "") {
        const sentMessage = await message.channel.send(client.noperm);
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
          setTimeout(() => {
            sentMessage.delete().catch(() => {});
          }, delayTime * 1000);
        }
      }
      return;
    }
    if (!message.guild) return message.reply("Cette commande doit être utilisée dans un serveur.");

    const emojis = message.guild.emojis.cache.map(e => ({
      name: e.name,
      url: e.url,
      id: e.id,
      animated: e.animated
    }));

    if (emojis.length === 0) return message.reply("Ce serveur ne contient aucun émoji.");

    client.db.set(`emojiBackup_${message.guild.id}`, emojis);

    try {
      await message.author.send({
        content: `Backup des ${emojis.length} émojis du serveur **${message.guild.name}** :`,
        files: [
          {
            attachment: Buffer.from(JSON.stringify(emojis, null, 2), "utf-8"),
            name: `emojiBackup_${message.guild.id}.json`
          }
        ]
      });
      message.reply("Backup envoyée en message privé.");
    } catch {
      message.reply("Impossible de t'envoyer la backup en message privé, vérifie tes paramètres de confidentialité.");
    }
  }
};
