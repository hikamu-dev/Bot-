const Discord = require('discord.js')

module.exports = {
  name: 'pin',
  description: 'Gère les épingles de messages (add/remove/clear)',
  usage: 'pin <add/remove/clear> [messageID] [salon]',
  use: '<add/remove/clear> [messageID] [salon]',
  example: "➜ pin add 1392239258898534430 #general\n➜ pin remove 1392239258898534430 #general\n➜ pin clear #general",
  run: async (client, message, args) => {
        let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
                client.db.get(`owner_global_${message.author.id}`) === true || 

client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}
    if (!message.guild) return message.channel.send('Cette commande fonctionne uniquement en serveur.')

    const action = args[0]?.toLowerCase()
    if (!['add', 'remove', 'clear'].includes(action)) {
      return message.channel.send('Action invalide. Utilisez : add, remove ou clear.')
    }

    let channel = message.channel
    if (args[2]) {
      channel = message.guild.channels.cache.get(args[2]) || message.mentions.channels.first()
      if (!channel || channel.type !== Discord.ChannelType.GuildText) {
        return message.channel.send('Salon invalide ou introuvable.')
      }
    }

    if (action === 'clear') {
      try {
        await channel.bulkUnpin()
        return message.channel.send(`Toutes les épingles ont été supprimées dans ${channel}.`)
      } catch {
        return message.channel.send('Je n\'ai pas la permission de gérer les épingles dans ce salon.')
      }
    }

    const messageId = args[1]
    if (!messageId) return message.channel.send('Veuillez fournir l\'ID du message.')

    let targetMessage
    try {
      targetMessage = await channel.messages.fetch(messageId)
    } catch {
      return message.channel.send('Message introuvable avec cet ID dans ce salon.')
    }

    if (action === 'add') {
      try {
        await targetMessage.pin()
        return message.channel.send(`Message épinglé dans ${channel}.`)
      } catch {
        return message.channel.send('Je n\'ai pas la permission d\'épingler ce message.')
      }
    }

    if (action === 'remove') {
      try {
        await targetMessage.unpin()
        return message.channel.send(`Épinglage supprimé du message dans ${channel}.`)
      } catch {
        return message.channel.send('Je n\'ai pas la permission de désépingler ce message.')
      }
    }
  }
}
