const Discord = require('discord.js')

module.exports = {
  name: 'listemoji',
  description: 'Liste tous les émojis du serveur dans un embed',
  usage: 'listemoji',
  run: async (client, message, args) => {
        let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
                client.db.get(`owner_global_${message.author.id}`) === true || 

client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}
    if (!message.guild) return message.channel.send('Cette commande fonctionne uniquement en serveur.')

    const emojis = message.guild.emojis.cache
    if (emojis.size === 0) {
      return message.channel.send('Ce serveur ne possède aucun émoji.')
    }
    const total = emojis.size

    const emojisPerEmbed = 50
    const emojiChunks = []
    const emojiArray = emojis.map(e => `${e} \`:${e.name}:\``)

    for (let i = 0; i < emojiArray.length; i += emojisPerEmbed) {
      emojiChunks.push(emojiArray.slice(i, i + emojisPerEmbed))
    }

    for (const chunk of emojiChunks) {
      const embed = new Discord.EmbedBuilder()
        .setTitle(`Émojis du serveur (${total})`)
        .setColor(client.color || '#00FF00')
        .setDescription(chunk.join(' '))
        .setFooter(client.footer)

      await message.channel.send({ embeds: [embed] })
    }
  }
  }
