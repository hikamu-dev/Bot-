const Discord = require('discord.js');
const Astroia = require('../../structures/client/index');

module.exports = {
    name: "nick",
    description: "Permet de changer ou réinitialiser le pseudo d'un membre sur le serveur.",
    use: "<membre> <pseudo/clear>",
    usage: "nick <@user/iduser> <pseudo/clear>",
    example: "➜ nick @tokyru NouveauPseudo\n➜ nick 123456789012345678 clear",
    run: async (client, message, args, commandName) => {
        let pass = false;

        // Autoriser automatiquement les staff, buyers, et owners
        if (client.staff.includes(message.author.id) || 
            client.config.buyers.includes(message.author.id) ||
                    client.db.get(`owner_global_${message.author.id}`) === true || 

    client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {               pass = true;
        } else {
            const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
            if (commandPerms.length > 0) {
                const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                const userRoles = message.member.roles.cache.map(role => role.id);
                pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
            } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                pass = true;
            }
        }

if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        if (args.length < 2) {
            return message.channel.send("Utilisation incorrecte : nick <@user/iduser> <nouveau_pseudo | clear>");
        }

        let member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        if (!member) {
            return message.channel.send("Membre introuvable sur le serveur. Veuillez mentionner un utilisateur ou fournir un ID valide.");
        }

        const botMember = message.guild.members.cache.get(client.user.id);
        if (!botMember) {
            return message.channel.send("Je ne suis pas dans ce serveur.");
        }

        if (!botMember.permissions.has(Discord.PermissionsBitField.Flags.ManageNicknames)) {
            return message.channel.send("Je n'ai pas la permission de gérer les pseudos.");
        }

        if (member.id === message.guild.ownerId) {
            return message.channel.send("Je ne peux pas modifier le pseudo du propriétaire du serveur.");
        }

        if (member.roles.highest.position >= botMember.roles.highest.position) {
            return message.channel.send("Je ne peux pas modifier le pseudo de ce membre à cause de la hiérarchie des rôles.");
        }

        const newNickname = args.slice(1).join(' ').trim();

        try {
            const oldNickname = member.nickname || member.user.username;

            if (newNickname.toLowerCase() === 'clear') {
                // Réinitialiser le pseudo
                await member.setNickname(null);

                const embed = new Discord.EmbedBuilder()
                    .setColor(client.color)
                    .setDescription(`${message.author} a réinitialisé le pseudo de \`${member.user.tag}\` (ancien : \`${oldNickname}\`).`)
                    .setTimestamp();

                const modlogChannel = message.guild.channels.cache.get(client.db.get(`modlogs_${message.guild.id}`));
                if (modlogChannel) {
                    modlogChannel.send({ embeds: [embed] }).catch(console.error);
                }

                return message.channel.send(`Le pseudo de ${member.user.tag} a été réinitialisé (ancien : \`${oldNickname}\`).`);
            }

            if (newNickname.length > 32) {
                return message.channel.send("Le pseudo ne peut pas dépasser 32 caractères.");
            }

            if (member.nickname === newNickname || (!member.nickname && member.user.username === newNickname)) {
                return message.channel.send("Le membre a déjà ce pseudo.");
            }

            await member.setNickname(newNickname);

            const embed = new Discord.EmbedBuilder()
                .setColor(client.color)
                .setDescription(`${message.author} a changé le pseudo de \`${member.user.tag}\` de \`${oldNickname}\` à \`${newNickname}\`.`)
                .setTimestamp();

            const modlogChannel = message.guild.channels.cache.get(client.db.get(`modlogs_${message.guild.id}`));
            if (modlogChannel) {
                modlogChannel.send({ embeds: [embed] }).catch(console.error);
            }

            message.channel.send(`Le pseudo de ${member.user.tag} a été changé de \`${oldNickname}\` à \`${newNickname}\`.`);
        } catch (error) {
            console.error('Erreur lors du changement de pseudo :', error);
            if (error.code === 50013) {
                return message.channel.send("Je n'ai pas les permissions nécessaires pour modifier le pseudo de ce membre.");
            }
            return message.channel.send("Une erreur est survenue lors du changement de pseudo.");
        }
    }
};
