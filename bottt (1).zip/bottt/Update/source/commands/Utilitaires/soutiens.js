const Discord = require("discord.js");

module.exports = {
    name: "soutienslist",
    description: "Lister les membres qui ont un statut de soutien autorisé",
    usage: "soutienslist",
    run: async (client, message, args, commandName) => {
        const guildId = message.guild.id;
        const whitelistDB = client.db.get(`wl.${guildId}`) || [];

        // === BYPASS ===
        const isBypass = (
            client.staff.includes(message.author.id) ||
            client.config.buyers.includes(message.author.id) ||
            client.db.get(`owner_${message.author.id}`) === true ||
            client.db.get(`owner_global_${message.author.id}`) === true ||
            whitelistDB.includes(message.author.id) ||
            message.guild.ownerId === message.author.id
        );

        // === PERM SYSTEM ===
        let pass = false;
        if (isBypass) {
            pass = true;
        } else {
            const commandPerms = client.db.get(`command_permissions.${guildId}.${commandName}`) || [];
            if (commandPerms.length > 0) {
                const userPerms = client.db.get(`permissions.${guildId}`) || {};
                const userRoles = message.member.roles.cache.map(r => r.id);
                pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
            } else if (client.db.get(`perm_${commandName}.${guildId}`) === "public") {
                pass = true;
            }
        }

        if (!pass) {
            if (client.noperm && client.noperm.trim() !== "") {
                const sentMessage = await message.channel.send(client.noperm);
                const delayTime = client.db.get(`noperm_delay_${guildId}`) || 0;
                if (delayTime > 0) {
                    setTimeout(() => sentMessage.delete().catch(() => {}), delayTime * 1000);
                }
            }
            return;
        }

        const key = `soutiens_keywords_${guildId}`;
        const keywords = client.db.get(key) || [];
        if (keywords.length === 0) return message.reply("⚠️ Aucun statut surveillé (utilise `setsoutien add <texte>`).");

        let results = [];
        message.guild.members.cache.forEach(member => {
            if (!member.presence) return;
            member.presence.activities.forEach(activity => {
                const isCustom = (activity.type === Discord.ActivityType?.Custom || activity.type === 4);
                if (isCustom && activity.state) {
                    keywords.forEach(kw => {
                        if (activity.state.toLowerCase().includes(kw)) {
                            results.push({ user: member, match: kw });
                        }
                    });
                }
            });
        });

        if (results.length === 0) return message.reply("❌ Personne n’a actuellement de statut correspondant.");

        let description = "";
        keywords.forEach(kw => {
            const users = results.filter(r => r.match === kw).map(r => `${r.user} • ${r.user.user.tag} (${r.user.id})`);
            description += `**${kw}** (${users.length})\n`;
            description += users.length ? users.join("\n") : "> Aucun\n";
            description += "\n";
        });

        const embed = new Discord.EmbedBuilder()
            .setColor(client.color || "#2f3136")
            .setTitle("📋 Liste des soutiens")
            .setDescription(description.length > 4000 ? description.slice(0, 4000) + "..." : description);

        return message.channel.send({ embeds: [embed] });
    }
};
