const Discord = require('discord.js');

module.exports = {
  name: 'get',
  description: 'Permet d\'obtenir l\'ID d\'un élément mentionné (utilisateur, rôle, salon, emoji)',
  usage: 'get <@élément>',
  use: '<@élément>',
  example: '➜ get @User\n➜ get #salon\n➜ get @Rôle\n➜ get :emoji:',
  run: async (client, message, args, commandName) => {
    let pass = false;
    if (
      client.staff.includes(message.author.id) ||
      client.config.buyers.includes(message.author.id) ||
      client.db.get(`owner_global_${message.author.id}`) === true ||
      client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true ||
      message.guild.ownerId === message.author.id
    ) {
      pass = true;
    } else {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === 'public') {
        pass = true;
      }
    }
    if (!pass) {
      if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
          setTimeout(() => {
            sentMessage.delete().catch(() => {});
          }, delayTime * 1000);
        }
      }
      return;
    }

    if (!args[0]) {
      return message.channel.send('Veuillez mentionner un utilisateur, un rôle, un salon ou un emoji.');
    }

    // Chercher utilisateur
    const user = message.mentions.users.first();
    if (user) {
      const embed = new Discord.EmbedBuilder()
        .setTitle(`ID de l'utilisateur : ${user.username}`)
        .setDescription(`L'ID de l'utilisateur <@${user.id}> est \`${user.id}\``)
        .setFooter(client.footer)
        .setColor(client.color || '#2b2d31');
      const row = new Discord.ActionRowBuilder().addComponents(
        new Discord.ButtonBuilder()
          .setCustomId(`copy_id_${user.id}`)
          .setLabel('Copier l\'ID')
          .setStyle(Discord.ButtonStyle.Secondary)
          .setDisabled(false)
      );
      return message.channel.send({ embeds: [embed], components: [row] });
    }
    // Chercher membre
    const member = message.mentions.members.first();
    if (member) {
      const embed = new Discord.EmbedBuilder()
        .setTitle(`ID du membre : ${member.user.username}`)
        .setDescription(`L'ID du membre <@${member.id}> est \`${member.id}\``)
        .setFooter(client.footer)
        .setColor(client.color || '#2b2d31');
      const row = new Discord.ActionRowBuilder().addComponents(
        new Discord.ButtonBuilder()
          .setCustomId(`copy_id_${member.id}`)
          .setLabel('Copier l\'ID')
          .setStyle(Discord.ButtonStyle.Secondary)
          .setDisabled(false)
      );
      return message.channel.send({ embeds: [embed], components: [row] });
    }
    // Chercher rôle
    const role = message.mentions.roles.first();
    if (role) {
      const embed = new Discord.EmbedBuilder()
        .setTitle(`ID du rôle : ${role.name}`)
        .setDescription(`L'ID du rôle <@&${role.id}> est \`${role.id}\``)
        .setFooter(client.footer)
        .setColor(client.color || '#2b2d31');
      const row = new Discord.ActionRowBuilder().addComponents(
        new Discord.ButtonBuilder()
          .setCustomId(`copy_id_${role.id}`)
          .setLabel('Copier l\'ID')
          .setStyle(Discord.ButtonStyle.Secondary)
          .setDisabled(false)
      );
      return message.channel.send({ embeds: [embed], components: [row] });
    }
    // Chercher salon
    const channel = message.mentions.channels.first();
    if (channel) {
      const embed = new Discord.EmbedBuilder()
        .setTitle(`ID du salon : ${channel.name}`)
        .setDescription(`L'ID du salon <#${channel.id}> est \`${channel.id}\``)
        .setFooter(client.footer)
        .setColor(client.color || '#2b2d31');
      const row = new Discord.ActionRowBuilder().addComponents(
        new Discord.ButtonBuilder()
          .setCustomId(`copy_id_${channel.id}`)
          .setLabel('Copier l\'ID')
          .setStyle(Discord.ButtonStyle.Secondary)
          .setDisabled(false)
      );
      return message.channel.send({ embeds: [embed], components: [row] });
    }
    // Chercher emoji
    const emojiRegex = /<a?:\w+:(\d+)>/;
    const emojiMatch = args[0].match(emojiRegex);
    if (emojiMatch) {
      const emojiId = emojiMatch[1];
      const embed = new Discord.EmbedBuilder()
        .setTitle(`ID de l'emoji`)
        .setDescription(`L'ID de l'emoji est \`${emojiId}\``)
        .setFooter({ text: `Demander par ${message.author.tag}` })
        .setColor(client.color || '#2b2d31');
      const row = new Discord.ActionRowBuilder().addComponents(
        new Discord.ButtonBuilder()
          .setCustomId(`copy_id_${emojiId}`)
          .setLabel('Copier l\'ID')
          .setStyle(Discord.ButtonStyle.Secondary)
          .setDisabled(false)
      );
      return message.channel.send({ embeds: [embed], components: [row] });
    }

    return message.channel.send('Aucun élément valide trouvé. Veuillez mentionner un utilisateur, un rôle, un salon ou un emoji.');
  }
}; 