// commands/setlevel.js (sélection de salon par mention/ID + suppression du message utilisateur)
const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  ChannelType,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
} = require("discord.js");

// === KEYS DB ===
const kEnabled = g => `levels_enabled_${g}`;
const kChan    = g => `levels_channel_${g}`;
const kMode    = g => `levels_mode_${g}`;        // "dm" | "channel" | "both"
const kCfg     = g => `levels_config_${g}`;      // { diff, xpMin,xpMax,cooldown,voiceXpPerMin,maxLevel }
const kMsgTpl  = g => `levels_msgtpl_${g}`;      // string
const kFmt     = g => `levels_format_${g}`;      // "embed" | "message"

// === Defaults / Presets ===
function getCfg(client, guildId) {
  return client.db.get?.(kCfg(guildId)) || {
    diff: "moyen",
    xpMin: 8, xpMax: 12,
    cooldown: 35,
    voiceXpPerMin: 1,
    maxLevel: 0
  };
}
function diffPreset(diff) {
  switch ((diff || "moyen").toLowerCase()) {
    case "facile":     return { diff: "facile",    xpMin: 10, xpMax: 15, cooldown: 30, voiceXpPerMin: 2, maxLevel: 0 };
    case "moyen":      return { diff: "moyen",     xpMin: 8,  xpMax: 12, cooldown: 35, voiceXpPerMin: 1, maxLevel: 0 };
    case "difficile":  return { diff: "difficile", xpMin: 6,  xpMax: 10, cooldown: 45, voiceXpPerMin: 1, maxLevel: 0 };
    case "ultrahard":  return { diff: "ultrahard", xpMin: 5,  xpMax: 8,  cooldown: 60, voiceXpPerMin: 1, maxLevel: 0 };
    default:           return { diff: "moyen",     xpMin: 8,  xpMax: 12, cooldown: 35, voiceXpPerMin: 1, maxLevel: 0 };
  }
}

// === PERMS: owner / buyer / staff / perms custom ===
function passGate(client, message, commandName = "setlevel", defaultPublic = false) {
  const uid = message.author.id;
  if (client?.staff?.includes?.(uid)) return true;
  if (client?.config?.buyers?.includes?.(uid)) return true;
  if (client.db.get?.(`owner_global_${uid}`) === true) return true;
  if (client.db.get?.(`owner_${message.guild.id}_${uid}`) === true) return true;

  const commandPerms = client.db.get?.(`command_permissions.${message.guild.id}.${commandName}`) || [];
  if (commandPerms.length > 0) {
    const userPerms = client.db.get?.(`permissions.${message.guild.id}`) || {};
    const roles = message.member.roles.cache.map(r => r.id);
    return commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(id => roles.includes(id)));
  }
  if (client.db.get?.(`perm_${commandName}.${message.guild.id}`) === "public") return true;
  return defaultPublic; // panel non public par défaut
}

// === UI helpers ===
function buildEmbed(client, guild) {
  const color = client.color || 0x5865F2;
  const enabled = !!client.db.get?.(kEnabled(guild.id));
  const chId = client.db.get?.(kChan(guild.id));
  const ch = chId ? (guild.channels.cache.get(chId) || `#${chId}`) : "—";
  const mode = client.db.get?.(kMode(guild.id)) || "channel";
  const cfg = getCfg(client, guild.id);
  const msgTpl = client.db.get?.(kMsgTpl(guild.id)) || "🎉 {mention} est maintenant **niveau {level}** !";
  const fmt = (client.db.get?.(kFmt(guild.id)) || "embed").toLowerCase();

  return new EmbedBuilder()
    .setColor(color)
    .setTitle("📈 Panel Niveaux")
    .setDescription("Configurez le système : difficulté, annonces, vocal, etc.")
    .addFields(
      { name: "Statut", value: enabled ? "✅ Actif" : "❌ Inactif", inline: true },
      { name: "Annonce", value: `mode: \`${mode}\` • format: \`${fmt}\` • salon: ${ch}`, inline: true },
      { name: "Difficulté / Réglages", value: `\`${cfg.diff}\` • msg: \`${cfg.xpMin}-${cfg.xpMax}\` • cd: \`${cfg.cooldown}s\` • vocal: \`${cfg.voiceXpPerMin}/min\` • max: \`${cfg.maxLevel===0?"∞":cfg.maxLevel}\`` },
      { name: "Message d'annonce", value: msgTpl },
      { name: "Placeholders", value: "`{mention}`, `{user}`, `{level}`" }
    );
}

function buildRows(guild) {
  // Row 1: boutons (4 boutons max, dont "Définir le salon")
  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`lvl:${guild.id}:toggle`).setStyle(ButtonStyle.Success).setLabel("Activer / Désactiver"),
    new ButtonBuilder().setCustomId(`lvl:${guild.id}:advanced`).setStyle(ButtonStyle.Secondary).setLabel("Réglages avancés"),
    new ButtonBuilder().setCustomId(`lvl:${guild.id}:msgtpl`).setStyle(ButtonStyle.Primary).setLabel("Message d'annonce"),
    new ButtonBuilder().setCustomId(`lvl:${guild.id}:setchannel`).setStyle(ButtonStyle.Secondary).setLabel("Définir le salon"),
  );

  // Row 2: select "mode d'annonce"
  const row2 = new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(`lvl:${guild.id}:mode`)
      .setPlaceholder("Mode d'annonce")
      .addOptions(
        { label: "Salon", value: "channel", description: "Annonce dans un salon" },
        { label: "DM", value: "dm", description: "Annonce en message privé" },
        { label: "Both", value: "both", description: "DM + salon" },
      )
  );

  // Row 3: select "format d'annonce"
  const rowFmt = new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(`lvl:${guild.id}:fmt`)
      .setPlaceholder("Format d'annonce")
      .addOptions(
        { label: "Embed", value: "embed", description: "Annonce en embed" },
        { label: "Message", value: "message", description: "Annonce en texte simple" },
      )
  );

  // Row 4: select "difficulté"
  const row4 = new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(`lvl:${guild.id}:diff`)
      .setPlaceholder("Difficulté")
      .addOptions(
        { label: "Facile", value: "facile", description: "Progression douce" },
        { label: "Moyen", value: "moyen", description: "Équilibré" },
        { label: "Difficile", value: "difficile", description: "Écarts +50, +100, +150..." },
        { label: "UltraHard", value: "ultrahard", description: "Écarts +100, +200, +300..." },
      )
  );

  // ✅ 4 lignes (on a retiré la row du select de salon)
  return [row1, row2, rowFmt, row4];
}

// === Commande ===
module.exports = {
  name: "setlevel",
  description: "Ouvre le panel interactif des niveaux.",
  usage: "setlevel",
  category: "owner",

  run: async (client, message) => {
    if (!message.guild) return;
    if (!passGate(client, message, "setlevel", false)) {
      if (client.noperm && client.noperm.trim() !== "") {
        const m = await message.channel.send(client.noperm);
        const d = client.db.get?.(`noperm_delay_${message.guild.id}`) || 0;
        if (d > 0) setTimeout(() => m.delete().catch(() => {}), d * 1000);
      }
      return;
    }

    const guild = message.guild;
    const panelId = `lvl:${guild.id}`;
    const emb = buildEmbed(client, guild);
    const rows = buildRows(guild);
    const msg = await message.channel.send({ embeds: [emb], components: rows });

    const collector = msg.createMessageComponentCollector({ time: 15 * 60 * 1000 });

    const onModal = async (interaction) => {
      if (!interaction.isModalSubmit()) return;
      if (!interaction.customId.startsWith(`${panelId}:`)) return;
      if (interaction.user.id !== message.author.id)
        return interaction.reply({ content: "Seul l'initiateur peut modifier.", ephemeral: true });

      const sub = interaction.customId.split(":")[2];
      if (sub === "msgtplset") {
        const val = interaction.fields.getTextInputValue("tpl_input").slice(0, 2000) || "🎉 {mention} est maintenant **niveau {level}** !";
        client.db.set?.(kMsgTpl(guild.id), val);
        await interaction.reply({ content: "✅ Message d'annonce mis à jour.", ephemeral: true });
        await msg.edit({ embeds: [buildEmbed(client, guild)], components: buildRows(guild) }).catch(() => {});
      }
      if (sub === "advancedset") {
        const xpMin  = Math.max(1, parseInt(interaction.fields.getTextInputValue("xpmin") || "0") || 0);
        const xpMax  = Math.max(xpMin, parseInt(interaction.fields.getTextInputValue("xpmax") || "0") || xpMin);
        const cd     = Math.max(5, parseInt(interaction.fields.getTextInputValue("cooldown") || "0") || 35);
        const vx     = Math.max(0, parseInt(interaction.fields.getTextInputValue("voicexp") || "0") || 1);
        let maxLevel = parseInt(interaction.fields.getTextInputValue("maxlevel") || "0") || 0;
        if (maxLevel < 0) maxLevel = 0;

        const cfg = getCfg(client, guild.id);
        Object.assign(cfg, { xpMin, xpMax, cooldown: cd, voiceXpPerMin: vx, maxLevel });
        client.db.set?.(kCfg(guild.id), cfg);

        await interaction.reply({ content: "✅ Réglages avancés mis à jour.", ephemeral: true });
        await msg.edit({ embeds: [buildEmbed(client, guild)], components: buildRows(guild) }).catch(() => {});
      }
    };
    client.on("interactionCreate", onModal);

    collector.on("collect", async (i) => {
      if (i.user.id !== message.author.id)
        return i.reply({ content: "Seul l'initiateur peut modifier ce panel.", ephemeral: true });

      const [, gid, action] = i.customId.split(":"); // lvl:<gid>:action

      try {
        if (action === "toggle") {
          const curr = !!client.db.get?.(kEnabled(guild.id));
          client.db.set?.(kEnabled(guild.id), !curr);
          await i.reply({ content: `Statut: ${!curr ? "✅ Activé" : "🛑 Désactivé"}`, ephemeral: true });
          await msg.edit({ embeds: [buildEmbed(client, guild)], components: buildRows(guild) }).catch(() => {});
        }

        else if (action === "mode" && i.isStringSelectMenu()) {
          const val = i.values?.[0];
          client.db.set?.(kMode(guild.id), val);
          await i.reply({ content: `Mode d'annonce: \`${val}\``, ephemeral: true });
          await msg.edit({ embeds: [buildEmbed(client, guild)], components: buildRows(guild) }).catch(() => {});
        }

        else if (action === "fmt" && i.isStringSelectMenu()) {
          const val = i.values?.[0]; // "embed" | "message"
          client.db.set?.(kFmt(guild.id), val);
          await i.reply({ content: `Format d'annonce: \`${val}\``, ephemeral: true });
          await msg.edit({ embeds: [buildEmbed(client, guild)], components: buildRows(guild) }).catch(() => {});
        }

        else if (action === "diff" && i.isStringSelectMenu()) {
          const val = i.values?.[0];
          const preset = diffPreset(val);
          const cfg = getCfg(client, guild.id);
          Object.assign(cfg, preset);
          client.db.set?.(kCfg(guild.id), cfg);
          await i.reply({ content: `Difficulté: \`${preset.diff}\` (msg ${preset.xpMin}-${preset.xpMax}, cd ${preset.cooldown}s, vocal ${preset.voiceXpPerMin}/min)`, ephemeral: true });
          await msg.edit({ embeds: [buildEmbed(client, guild)], components: buildRows(guild) }).catch(() => {});
        }

        else if (action === "msgtpl") {
          const modal = new ModalBuilder().setCustomId(`lvl:${guild.id}:msgtplset`).setTitle("Message d'annonce");
          const input = new TextInputBuilder()
            .setCustomId("tpl_input")
            .setLabel("Ex: 🎉 {mention} passe niveau {level} !")
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(true)
            .setPlaceholder("{mention} / {user} / {level}");
          modal.addComponents(new ActionRowBuilder().addComponents(input));
          await i.showModal(modal);
        }

        // === NOUVEAU: définir le salon par mention/ID ===
        else if (action === "setchannel") {
          await i.reply({ content: "🔎 Mentionne ou donne **l'ID** du salon textuel dans les **30 secondes**.", ephemeral: true });

          const filter = m => m.author.id === message.author.id;
          let collected;
          try {
            collected = await message.channel.awaitMessages({ filter, max: 1, time: 30_000 });
          } catch {
            collected = null;
          }
          if (!collected || !collected.size) {
            return; // rien reçu (on laisse le panel ouvert)
          }

          const m = collected.first();
          const mentioned = m.mentions.channels.first();
          const id = (mentioned?.id) || m.content.trim();
          const ch = id ? i.guild.channels.cache.get(id) : null;

          if (!ch || ch.type !== ChannelType.GuildText) {
            const warn = await message.channel.send("❌ Salon invalide. Merci de mentionner un **salon textuel** ou de fournir un **ID** valide.");
            setTimeout(() => warn.delete().catch(()=>{}), 5000);
          } else {
            client.db.set?.(kChan(guild.id), ch.id);
            const ok = await message.channel.send(`✅ Salon d'annonce défini sur ${ch}.`);
            setTimeout(() => ok.delete().catch(()=>{}), 5000);
            await msg.edit({ embeds: [buildEmbed(client, guild)], components: buildRows(guild) }).catch(() => {});
          }

          // Supprimer le message de l'utilisateur pour garder propre
          m.delete().catch(()=>{});
        }

        else if (action === "advanced") {
          const cfg = getCfg(client, guild.id);
          const modal = new ModalBuilder().setCustomId(`lvl:${guild.id}:advancedset`).setTitle("Réglages avancés");
          const f1 = new TextInputBuilder().setCustomId("xpmin").setLabel("XP Min par message").setStyle(TextInputStyle.Short).setValue(String(cfg.xpMin)).setRequired(true);
          const f2 = new TextInputBuilder().setCustomId("xpmax").setLabel("XP Max par message").setStyle(TextInputStyle.Short).setValue(String(cfg.xpMax)).setRequired(true);
          const f3 = new TextInputBuilder().setCustomId("cooldown").setLabel("Cooldown (secondes)").setStyle(TextInputStyle.Short).setValue(String(cfg.cooldown)).setRequired(true);
          const f4 = new TextInputBuilder().setCustomId("voicexp").setLabel("XP par minute (vocal)").setStyle(TextInputStyle.Short).setValue(String(cfg.voiceXpPerMin)).setRequired(true);
          const f5 = new TextInputBuilder().setCustomId("maxlevel").setLabel("Niveau max (0 = illimité)").setStyle(TextInputStyle.Short).setValue(String(cfg.maxLevel || 0)).setRequired(true);
          modal.addComponents(
            new ActionRowBuilder().addComponents(f1),
            new ActionRowBuilder().addComponents(f2),
            new ActionRowBuilder().addComponents(f3),
            new ActionRowBuilder().addComponents(f4),
            new ActionRowBuilder().addComponents(f5)
          );
          await i.showModal(modal);
        }

        else if (action === "close") {
          collector.stop("closed");
          await i.reply({ content: "Panel fermé.", ephemeral: true });
          await msg.edit({ components: [] }).catch(() => {});
        }

      } catch {
        try { await i.reply({ content: "❌ Erreur.", ephemeral: true }); } catch {}
      }
    });

    collector.on("end", () => {
      client.removeListener("interactionCreate", onModal);
    });
  }
};
