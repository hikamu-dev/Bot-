const Discord = require('discord.js');

module.exports = {
  name: 'piconly',
  description: 'Configure un salon pour n\'accepter que les messages avec des images.',
  use: "add/list/del <#salon/id>",
  example: "➜ piconly add #images\n➜ piconly list\n➜ piconly del #images",
  /**
   * 
   * @param {Astroia} client 
   * @param {Discord.Message} message
   * @param {string[]} args 
   */
  run: async (client, message, args, commandName) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
                client.db.get(`owner_global_${message.author.id}`) === true || 

client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

    // Vérifier les arguments
    if (!args[0]) {
      return message.channel.send('Utilisation : `piconly add/list/del <#salon/id>`');
    }

    const action = args[0].toLowerCase();

    if (action === 'add') {
      if (!args[1]) {
        return message.channel.send('Veuillez fournir un salon avec `piconly add <#salon/id>`');
      }

      // Vérifier le salon
      const channelId = args[1].replace(/[^0-9]/g, '');
      const channel = message.guild.channels.cache.get(channelId);
      if (!channel || channel.type !== Discord.ChannelType.GuildText) {
        return message.channel.send('Veuillez fournir un ID de salon textuel valide.');
      }

      // Vérifier les permissions du bot
      if (!channel.permissionsFor(message.guild.members.me).has(Discord.PermissionsBitField.Flags.ManageMessages)) {
        return message.channel.send(`Je n'ai pas la permission de gérer les messages dans <#${channel.id}>.`);
      }

      // Ajouter le salon à la liste
      const piconlyKey = `piconly_${message.guild.id}`;
      let piconlyChannels = client.db.get(piconlyKey) || [];
      if (piconlyChannels.includes(channel.id)) {
        return message.channel.send(`Le salon <#${channel.id}> est déjà configuré comme image-only.`);
      }

      piconlyChannels.push(channel.id);
      client.db.set(piconlyKey, piconlyChannels);

      return message.channel.send(`Le salon <#${channel.id}> a été configuré comme image-only. Seuls les messages avec des images seront autorisés.`);

    } else if (action === 'list') {
      const piconlyKey = `piconly_${message.guild.id}`;
      const piconlyChannels = client.db.get(piconlyKey) || [];

      if (piconlyChannels.length === 0) {
        return message.channel.send('Aucun salon n\'est configuré comme image-only sur ce serveur.');
      }

      const embed = new Discord.EmbedBuilder()
        .setColor(client.color)
        .setFooter(client.footer)
        .setTitle('Salons Image-Only')
        .setDescription(piconlyChannels.map(id => `<#${id}>`).join('\n') || 'Aucun salon configuré.')
        .setTimestamp();

      return message.channel.send({ embeds: [embed] });

    } else if (action === 'del') {
      if (!args[1]) {
        return message.channel.send('Veuillez fournir un salon avec `piconly del <#salon/id>`');
      }

      // Vérifier le salon
      const channelId = args[1].replace(/[^0-9]/g, '');
      const channel = message.guild.channels.cache.get(channelId);
      if (!channel || channel.type !== Discord.ChannelType.GuildText) {
        return message.channel.send('Veuillez fournir un ID de salon textuel valide.');
      }

      // Supprimer le salon de la liste
      const piconlyKey = `piconly_${message.guild.id}`;
      let piconlyChannels = client.db.get(piconlyKey) || [];
      if (!piconlyChannels.includes(channel.id)) {
        return message.channel.send(`Le salon <#${channel.id}> n'est pas configuré comme image-only.`);
      }

      piconlyChannels = piconlyChannels.filter(id => id !== channel.id);
      client.db.set(piconlyKey, piconlyChannels);

      return message.channel.send(`Le salon <#${channel.id}> a été retiré de la liste des salons image-only.`);
    } else {
      return message.channel.send('Action invalide. Utilisez `add`, `list` ou `del`.');
    }
  }
};