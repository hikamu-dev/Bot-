// commands/rewardsync.js
const { PermissionsBitField } = require("discord.js");

const kUser    = (g,u) => `levels_user_${g}_${u}`;   // { xp, level }
const kRewards = g => `levels_rewards_${g}`;         // [{ level, roleId }]

function passGate(client, message, commandName = "rewardsync", defaultPublic = false) {
  const uid = message.author.id;
  if (client?.staff?.includes?.(uid)) return true;
  if (client?.config?.buyers?.includes?.(uid)) return true;
  if (client.db.get?.(`owner_global_${uid}`) === true) return true;
  if (client.db.get?.(`owner_${message.guild.id}_${uid}`) === true) return true;

  const commandPerms = client.db.get?.(`command_permissions.${message.guild.id}.${commandName}`) || [];
  if (commandPerms.length > 0) {
    const userPerms = client.db.get?.(`permissions.${message.guild.id}`) || {};
    const roles = message.member.roles.cache.map(r => r.id);
    return commandPerms.some(perm => userPerms[perm]?.some?.(id => roles.includes(id)));
  }
  if (client.db.get?.(`perm_${commandName}.${message.guild.id}`) === "public") return true;
  return defaultPublic;
}

module.exports = {
  name: "rewardsync",
  description: "Attribue immédiatement les rôles de récompense à tous les membres déjà au bon niveau.",
  usage: "rewardsync",
  category: "owner",
  run: async (client, message) => {
    if (!message.guild) return;
    if (!passGate(client, message)) {
      if (client.noperm && client.noperm.trim() !== "") {
        const m = await message.channel.send(client.noperm);
        const d = client.db.get?.(`noperm_delay_${message.guild.id}`) || 0;
        if (d > 0) setTimeout(() => m.delete().catch(() => {}), d * 1000);
      }
      return;
    }

    const me = message.guild.members.me;
    if (!me.permissions.has(PermissionsBitField.Flags.ManageRoles)) {
      return void message.channel.send("❌ Il me manque la permission **Gérer les rôles**.");
    }

    const rewards = (client.db.get?.(kRewards(message.guild.id)) || []).filter(r => r && typeof r.level === "number" && r.roleId);
    if (!rewards.length) {
      return void message.channel.send("ℹ️ Aucun palier configuré pour le moment.");
    }

    const notice = await message.channel.send(`⏳ Synchronisation des récompenses…`);
    await message.guild.members.fetch().catch(()=>{}); // au cas où

    let given = 0, skipped = 0;
    for (const [, member] of message.guild.members.cache) {
      if (!member || member.user.bot) continue;

      const state = client.db.get?.(kUser(message.guild.id, member.id)) || { xp: 0, level: 0 };
      for (const r of rewards) {
        if (state.level >= r.level) {
          const role = message.guild.roles.cache.get(r.roleId);
          if (!role) { skipped++; continue; }
          if (member.roles.cache.has(role.id)) { continue; }
          // éviter de se bloquer si le rôle est au-dessus du bot
          const meHighest = me.roles.highest?.position ?? 0;
          if (role.position >= meHighest) { skipped++; continue; }

          try {
            await member.roles.add(role, `rewardsync L${r.level}`);
            given++;
          } catch {
            skipped++;
          }
        }
      }
    }

    await notice.edit(`✅ Sync terminée — rôles attribués: **${given}**, ignorés: **${skipped}**.`);
  }
};
