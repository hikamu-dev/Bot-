// commands/rewardlvl.js
const {
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ChannelType,
  PermissionsBitField,
} = require("discord.js");

// ==== DB KEYS (aligné sur ton moteur de niveaux) ====
const kRewards = g => `levels_rewards_${g}`;

// ==== PERMS: comme tes autres commandes (owner/buyer/staff/perms custom) ====
function passGate(client, message, commandName = "rewardlvl", defaultPublic = false) {
  const uid = message.author.id;
  if (client?.staff?.includes?.(uid)) return true;
  if (client?.config?.buyers?.includes?.(uid)) return true;
  if (client.db.get?.(`owner_global_${uid}`) === true) return true;
  if (client.db.get?.(`owner_${message.guild.id}_${uid}`) === true) return true;

  const commandPerms = client.db.get?.(`command_permissions.${message.guild.id}.${commandName}`) || [];
  if (commandPerms.length > 0) {
    const userPerms = client.db.get?.(`permissions.${message.guild.id}`) || {};
    const roles = message.member.roles.cache.map(r => r.id);
    return commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(id => roles.includes(id)));
  }
  if (client.db.get?.(`perm_${commandName}.${message.guild.id}`) === "public") return true;
  return defaultPublic; // par défaut non public
}

function getRewards(client, guildId) {
  const arr = client.db.get?.(kRewards(guildId)) || [];
  // normaliser { level:Number, roleId:String }
  return Array.isArray(arr)
    ? arr.filter(x => x && typeof x.level === "number" && typeof x.roleId === "string")
    : [];
}

function setRewards(client, guildId, list) {
  client.db.set?.(kRewards(guildId), list);
}

function buildEmbed(client, guild) {
  const color = client.color || 0x5865F2;
  const rewards = getRewards(client, guild.id)
    .sort((a,b) => a.level - b.level);

  const lines = rewards.length
    ? rewards.map((r, i) => {
        const role = guild.roles.cache.get(r.roleId);
        return `\`${String(i+1).padStart(2,"0")}\` • **L${r.level}** → ${role ? role : `@role(${r.roleId})`}`;
      }).join("\n")
    : "_Aucun palier défini. Utilise le menu ci-dessous pour en créer._";

  return new EmbedBuilder()
    .setColor(color)
    .setTitle("🎁 Récompenses de niveaux")
    .setDescription("Associe des **rôles** à des **paliers de niveau**.\nQuand un membre atteint un niveau, il reçoit automatiquement le rôle configuré.")
    .addFields({ name: "Paliers actifs", value: lines })
    .setFooter({ text: "Astuce: Ajouter → saisie du niveau puis rôle (mention/ID/nom). Les messages seront effacés automatiquement." });
}

function buildMenu(guild) {
  return new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(`rewardlvl:${guild.id}:menu`)
      .setPlaceholder("Choisis une action…")
      .addOptions(
        { label: "➕ Ajouter un palier (niveau → rôle)", value: "add", description: "Demande d’abord le niveau, puis le rôle." },
        { label: "🗑️ Supprimer un palier", value: "del", description: "Choisir un palier par son niveau pour le retirer." },
        { label: "📜 Lister les paliers", value: "list", description: "Réaffiche l’état actuel des récompenses." },
        { label: "❌ Vider (tout supprimer)", value: "clear", description: "Efface tous les paliers après confirmation." },
      )
  );
}

module.exports = {
  name: "rewardlvl",
  description: "Configure des récompenses (rôles) pour des paliers de niveaux — tout via menu déroulant.",
  usage: "rewardlvl",
  category: "owner",

  /**
   * @param {import('discord.js').Client} client
   * @param {import('discord.js').Message} message
   */
  run: async (client, message) => {
    if (!message.guild) return;
    if (!passGate(client, message, "rewardlvl", false)) {
      if (client.noperm && client.noperm.trim() !== "") {
        const m = await message.channel.send(client.noperm);
        const d = client.db.get?.(`noperm_delay_${message.guild.id}`) || 0;
        if (d > 0) setTimeout(() => m.delete().catch(() => {}), d * 1000);
      }
      return;
    }

    // Vérif basique : le bot doit pouvoir voir et lire ici, et gérer les rôles lors de l’attribution (mais pas requis pour configurer)
    const me = message.guild.members.me;
    if (!me.permissions.has(PermissionsBitField.Flags.ViewChannel) || !me.permissions.has(PermissionsBitField.Flags.SendMessages)) {
      return message.channel.send({ content: "❌ Je ne peux pas écrire ici." });
    }

    const guild = message.guild;
    const panel = await message.channel.send({
      embeds: [buildEmbed(client, guild)],
      components: [buildMenu(guild)]
    });

    const collector = panel.createMessageComponentCollector({ time: 15 * 60 * 1000 });

    // Helper pour poser une question (dans le channel), récupérer UNE réponse de l’auteur, et supprimer les deux messages
    const askOnce = async (questionText, timeoutMs = 30_000) => {
      const prompt = await message.channel.send({ content: questionText, allowedMentions: { parse: [] } });
      const filter = m => m.author.id === message.author.id;
      let collected;
      try {
        collected = await message.channel.awaitMessages({ filter, max: 1, time: timeoutMs });
      } catch {
        collected = null;
      }

      let answer = null;
      if (collected && collected.size) {
        answer = collected.first();
      }
      // On nettoie
      setTimeout(() => prompt.delete().catch(()=>{}), 0);
      if (answer) setTimeout(() => answer.delete().catch(()=>{}), 0);

      return answer?.content?.trim() || null;
    };

    const updatePanel = async () => {
      await panel.edit({ embeds: [buildEmbed(client, guild)], components: [buildMenu(guild)] }).catch(() => {});
    };

    collector.on("collect", async (i) => {
      if (!i.isStringSelectMenu()) return;
      if (i.user.id !== message.author.id) {
        return i.reply({ content: "Seul l’initiateur peut modifier ces récompenses.", ephemeral: true });
      }
      const [prefix, gid, tag] = i.customId.split(":"); // rewardlvl:<gid>:menu
      if (prefix !== "rewardlvl" || gid !== guild.id || tag !== "menu") return;

      const choice = i.values?.[0];
      await i.deferUpdate().catch(()=>{});

      try {
        if (choice === "list") {
          // Juste refresh de l’embed
          await updatePanel();
        }

        else if (choice === "add") {
          // 1) Demander le niveau
          const lvlStr = await askOnce("🧩 Entre le **niveau** (nombre entier ≥ 1) pour le palier :", 30_000);
          if (!lvlStr) return; // rien reçu
          const level = parseInt(lvlStr, 10);
          if (!Number.isFinite(level) || level < 1 || level > 100000) {
            const warn = await message.channel.send("❌ Niveau invalide. Utilise un entier ≥ 1.");
            setTimeout(() => warn.delete().catch(()=>{}), 5000);
            return;
          }

          // 2) Demander le rôle (mention, ID, nom)
          const roleStr = await askOnce("🎭 Mentionne le **rôle** concerné ou fournis son **ID** (ou son **nom** exact) :", 30_000);
          if (!roleStr) return;
          let role = null;

          // essai mention
          const mentionMatch = roleStr.match(/<@&(\d{15,20})>/);
          if (mentionMatch) {
            role = guild.roles.cache.get(mentionMatch[1]) || null;
          }
          // essai id direct
          if (!role && /^\d{15,20}$/.test(roleStr)) {
            role = guild.roles.cache.get(roleStr) || null;
          }
          // essai nom exact puis partiel
          if (!role) {
            const byName = roleStr.toLowerCase();
            role = guild.roles.cache.find(r => r.name.toLowerCase() === byName) ||
                   guild.roles.cache.find(r => r.name.toLowerCase().includes(byName)) ||
                   null;
          }

          if (!role) {
            const warn = await message.channel.send("❌ Rôle introuvable. Réessaie avec une **mention** ou un **ID** valide.");
            setTimeout(() => warn.delete().catch(()=>{}), 5000);
            return;
          }

          // 3) Enregistrer / Mettre à jour
          const list = getRewards(client, guild.id);
          const idx = list.findIndex(x => x.level === level);
          if (idx >= 0) list[idx].roleId = role.id;        // update
          else list.push({ level, roleId: role.id });      // add
          // tri par niveau
          list.sort((a,b) => a.level - b.level);
          setRewards(client, guild.id, list);

          const ok = await message.channel.send(`✅ Palier **L${level}** → ${role} enregistré.`);
          setTimeout(() => ok.delete().catch(()=>{}), 5000);

          await updatePanel();
        }

        else if (choice === "del") {
          // Demander niveau à supprimer
          const lvlStr = await askOnce("🗑️ Entre le **niveau** du palier à supprimer :", 30_000);
          if (!lvlStr) return;
          const level = parseInt(lvlStr, 10);
          if (!Number.isFinite(level) || level < 1) {
            const warn = await message.channel.send("❌ Niveau invalide.");
            setTimeout(() => warn.delete().catch(()=>{}), 5000);
            return;
          }
          const list = getRewards(client, guild.id);
          const before = list.length;
          const newList = list.filter(x => x.level !== level);
          setRewards(client, guild.id, newList);

          const txt = (before !== newList.length)
            ? `✅ Palier **L${level}** supprimé.`
            : `ℹ️ Aucun palier **L${level}** n’existait.`;
          const info = await message.channel.send(txt);
          setTimeout(() => info.delete().catch(()=>{}), 5000);

          await updatePanel();
        }

        else if (choice === "clear") {
          // confirmation simple via question
          const confirm = await askOnce("❗ Tape **OUI** pour **supprimer tous** les paliers de récompenses :", 20_000);
          if (!confirm) return;
          if (confirm.toLowerCase() === "oui") {
            setRewards(client, guild.id, []);
            const ok = await message.channel.send("✅ Tous les paliers ont été supprimés.");
            setTimeout(() => ok.delete().catch(()=>{}), 5000);
            await updatePanel();
          } else {
            const no = await message.channel.send("❎ Annulé.");
            setTimeout(() => no.delete().catch(()=>{}), 4000);
          }
        }

      } catch (e) {
        const err = await message.channel.send("❌ Erreur pendant l’opération.");
        setTimeout(() => err.delete().catch(()=>{}), 5000);
      }
    });

    collector.on("end", async () => {
      try { await panel.edit({ components: [] }); } catch {}
    });
  }
};
