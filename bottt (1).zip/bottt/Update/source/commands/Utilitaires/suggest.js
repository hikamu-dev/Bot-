const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, TextInputBuilder, ModalBuilder, TextInputStyle, ComponentType } = require('discord.js');
const ms = require('ms');


module.exports = {
    name: 'suggest',
    description: 'Soumet une suggestion au salon configuré',
    aliases: 'suggestion',
    usage: 'suggest <suggestion>',
    use: '<suggestion>',
    example: '➜ suggest Ajouter une nouvelle fonctionnalité pour les suggestions\n➜ suggest Améliorer le système de modération',
    run: async (client, message, args, commandName) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
                client.db.get(`owner_global_${message.author.id}`) === true || 

client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        const suggestion = args.join(' ');
        if (!suggestion) {
            return message.channel.send('Veuillez fournir une suggestion.');
        }

        const suggestionsChannelId = client.db.get(`suggestions_channel_${message.guild.id}`);
        if (!suggestionsChannelId) {
            return message.channel.send('Le salon des suggestions n\'a pas été configuré.');
        }

        const suggestionsChannel = message.guild.channels.cache.get(suggestionsChannelId);
        if (!suggestionsChannel) {
            return message.channel.send('Le salon configuré pour les suggestions est invalide.');
        }

const suggestionEmbed = new EmbedBuilder()
    .setTitle('Suggestion en attente de validation')
    .setDescription(`${suggestion}`)
    .setColor(client.color)
    .setAuthor({
        name: `${message.author.tag} (${message.author.id})`,
        iconURL: message.author.displayAvatarURL()
    })
    .setTimestamp();


        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('suggest_accept')
                .setLabel('Valider')
                .setStyle(ButtonStyle.Success),
            new ButtonBuilder()
                .setCustomId('suggest_refuse')
                .setLabel('Rejeter')
                .setStyle(ButtonStyle.Danger),
            new ButtonBuilder()
                .setCustomId('suggest_delete')
                .setLabel('🗑️')
                .setStyle(ButtonStyle.Secondary)
        );

        const suggestionMessage = await suggestionsChannel.send({ embeds: [suggestionEmbed], components: [row] });

        // Ajout des réactions ✅ et ❌
        await suggestionMessage.react('✅');
        await suggestionMessage.react('❌');
const thread = await suggestionMessage.startThread({
    name: "Aimez-vous cette suggestion ?",
    autoArchiveDuration: 1440, // 24 heures
    reason: `Fil pour la suggestion de ${message.author.tag}`
});
        // Envoie un message de confirmation à l'utilisateur
        await message.channel.send(`Votre suggestion a bien été effectuée dans ce salon : ${suggestionsChannel}.`);
    }
};