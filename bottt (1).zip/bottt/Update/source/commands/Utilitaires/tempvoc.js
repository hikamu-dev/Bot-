const { ChannelType, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, EmbedBuilder } = require('discord.js');
const Astroia = require('../../structures/client/index');

module.exports = {
    name: "tempvoc",
    description: "Crée un salon vocal temporaire pour chaque utilisateur qui rejoint le salon spécifié via un bouton.",
    usage: "Utilisez le bouton 'Ajouter' pour configurer, ou 'Supprimer' pour retirer la configuration.",

    /**
     * 
     * @param {Astroia} client 
     * @param {Discord.Message} message 
     * @param {String[]} args 
     */
    run: async (client, message, args, commandName) => {
        let pass = false;

        // Autoriser automatiquement les staff, buyers, et owners
        if (client.staff.includes(message.author.id) || 
            client.config.buyers.includes(message.author.id) ||
                    client.db.get(`owner_global_${message.author.id}`) === true || 

    client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {               pass = true;
        } else {
            // Vérifier les permissions personnalisées pour la commande
            const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
            if (commandPerms.length > 0) {
                const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                const userRoles = message.member.roles.cache.map(role => role.id);
                pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
            } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                pass = true;
            }
        }

        // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        // Récupérer les canaux à partir des IDs stockés
        const categoryId = client.db.get(`tempvoc_${message.guild.id}_categoryId`);
        const targetChannelId = client.db.get(`tempvoc_${message.guild.id}_targetChannelId`);
        const category = message.guild.channels.cache.get(categoryId);
        const targetChannel = message.guild.channels.cache.get(targetChannelId);

        // Créer l'embed initial
        const embed = new EmbedBuilder()
            .setColor(client.color)
            .setTitle('Configuration des salons vocaux temporaires')
            .setDescription('Utilisez les boutons ci-dessous pour configurer ou supprimer la configuration.')
            .addFields(
                { name: 'Catégorie', value: category ? `<#${category.id}>` : 'Aucune configuration active', inline: true },
                { name: 'Salon Vocal', value: targetChannel ? `<#${targetChannel.id}>` : 'Aucune configuration active', inline: true }
            )
            .setFooter(client.footer);
        // Créer les boutons "Ajouter" et "Supprimer"
        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('tempvoc_add')
                    .setLabel('Ajouter')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('tempvoc_remove')
                    .setLabel('Supprimer')
                    .setStyle(ButtonStyle.Danger)
            );

        // Envoyer le message avec l'embed et les boutons
        const sentMessage = await message.channel.send({ embeds: [embed], components: [row] });

        // Créer un collecteur pour les interactions des boutons
        const filter = i => i.customId === 'tempvoc_add' || i.customId === 'tempvoc_remove';
        const collector = message.channel.createMessageComponentCollector({ filter });

        collector.on('collect', async i => {
            if (i.customId === 'tempvoc_add') {
                // Créer un modal pour l'ajout
                const modal = new ModalBuilder()
                    .setCustomId('tempvoc_add_modal')
                    .setTitle('Configurer un salon vocal temporaire')
                    .addComponents(
                        new ActionRowBuilder().addComponents(
                            new TextInputBuilder()
                                .setCustomId('category_id')
                                .setLabel('ID de la catégorie')
                                .setStyle(TextInputStyle.Short)
                                .setRequired(true)
                        ),
                        new ActionRowBuilder().addComponents(
                            new TextInputBuilder()
                                .setCustomId('channel_id')
                                .setLabel('ID du salon vocal')
                                .setStyle(TextInputStyle.Short)
                                .setRequired(true)
                        )
                    );

                // Afficher le modal
                await i.showModal(modal);
            } else if (i.customId === 'tempvoc_remove') {
                // Créer un modal pour la suppression
                const modal = new ModalBuilder()
                    .setCustomId('tempvoc_remove_modal')
                    .setTitle('Supprimer la configuration')
                    .addComponents(
                        new ActionRowBuilder().addComponents(
                            new TextInputBuilder()
                                .setCustomId('delete_input')
                                .setLabel('Entrez "all" pour tout supprimer')
                                .setStyle(TextInputStyle.Short)
                                .setRequired(true)
                        )
                    );

                // Afficher le modal
                await i.showModal(modal);
            }
        });

        // Gérer la soumission des modals
        client.on('interactionCreate', async interaction => {
            if (!interaction.isModalSubmit()) return;

            if (interaction.customId === 'tempvoc_add_modal') {
                const categoryId = interaction.fields.getTextInputValue('category_id');
                const targetChannelId = interaction.fields.getTextInputValue('channel_id');

                const category = interaction.guild.channels.cache.get(categoryId);
                if (!(category && category.type === ChannelType.GuildCategory)) {
                    return interaction.reply({ content: "Catégorie introuvable ou invalide.", ephemeral: true });
                }

                const targetChannel = interaction.guild.channels.cache.get(targetChannelId);
                if (!(targetChannel && targetChannel.type === ChannelType.GuildVoice)) {
                    return interaction.reply({ content: "Salon vocal introuvable ou invalide.", ephemeral: true });
                }

                // Enregistrer les IDs dans la base de données
                client.db.set(`tempvoc_${interaction.guild.id}_categoryId`, categoryId);
                client.db.set(`tempvoc_${interaction.guild.id}_targetChannelId`, targetChannelId);

                // Mettre à jour l'embed avec les mentions
                const updatedEmbed = new EmbedBuilder()
                    .setColor(client.color)
                    .setTitle('Configuration des salons vocaux temporaires')
                    .setDescription('Utilisez les boutons ci-dessous pour configurer ou supprimer la configuration.')
                    .addFields(
                        { name: 'Catégorie', value: `<#${category.id}>`, inline: true },
                        { name: 'Salon Vocal', value: `<#${targetChannel.id}>`, inline: true }
                    )
                    .setFooter(client.footer)

                await interaction.update({ embeds: [updatedEmbed], components: [row] });
                await interaction.followUp({ content: `Configuration enregistrée pour le salon : ${targetChannel}.`, ephemeral: true });
            } else if (interaction.customId === 'tempvoc_remove_modal') {
                const input = interaction.fields.getTextInputValue('delete_input');

                if (input.toLowerCase() === 'all') {
                    client.db.delete(`tempvoc_${interaction.guild.id}_categoryId`);
                    client.db.delete(`tempvoc_${interaction.guild.id}_targetChannelId`);

                    // Mettre à jour l'embed
                    const updatedEmbed = new EmbedBuilder()
                        .setColor(client.color)
                        .setTitle('Configuration des salons vocaux temporaires')
                        .setDescription('Utilisez les boutons ci-dessous pour configurer ou supprimer la configuration.')
                        .addFields(
                            { name: 'Catégorie', value: 'Aucune configuration active', inline: true },
                            { name: 'Salon Vocal', value: 'Aucune configuration active', inline: true }
                        )
                        .setFooter(client.footer)
                    await interaction.update({ embeds: [updatedEmbed], components: [row] });
                    //await interaction.followUp({ content: 'Toutes les configurations de salons vocaux temporaires ont été supprimées.', ephemeral: true });
                } else {
                    await interaction.reply({ content: 'Entrée invalide. Veuillez entrer "all" pour supprimer la configuration.', ephemeral: true });
                }
            }
        });
    }
};