const { ActionRowBuilder, StringSelectMenuBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    name: "customdel",
    description: "Supprime une commande personnalisée",
    usages: "customdel",
    
    run: async (client, message, args) => {
        try {

            // Vérification des permissions
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) || 
        client.db.get(`owner_global_${message.author.id}`) === true || 
        client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true) {          pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${module.exports.name}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

            // Récupérer les commandes personnalisées depuis la base de données
            const customCommands = client.db.get(`custom_commands_${message.guild.id}`) || [];

            if (customCommands.length === 0) {
                return message.channel.send("Aucune commande personnalisée à supprimer.").then(msg => setTimeout(() => msg.delete(), 5000)).catch(err => {
                    console.error(`[ERROR] Failed to send no commands message: ${err.message}`);
                });
            }

            // Générer l'embed avec la liste des commandes
            const generateListEmbed = () => {
                const embed = new EmbedBuilder()
                    .setTitle('Suppression d’une commande personnalisée')
                    .setDescription('Sélectionnez une commande à supprimer dans le menu ci-dessous.')
                    .setColor(client.color)
                    .addFields({
                        name: 'Commandes personnalisées',
                        value: customCommands.length > 0 
                            ? customCommands.map((cmd, index) => `${index + 1}. ${cmd.name}`).join('\n')
                            : 'Aucune commande disponible',
                        inline: false
                    })
                    .setFooter(client.footer);
                return embed;
            };

            // Créer le menu de sélection des commandes (utiliser l'index comme value pour éviter les doublons)
            const commandMenu = new StringSelectMenuBuilder()
                .setCustomId('delete_command')
                .setPlaceholder('Sélectionner une commande à supprimer')
                .addOptions(
                    customCommands.map((cmd, index) => ({
                        label: cmd.name,
                        value: index.toString(), // Utiliser l'index comme valeur unique
                        description: `Supprimer la commande ${cmd.name}`,
                        emoji: '🗑️' // Emoji pour la suppression
                    }))
                );

            const actionRow = new ActionRowBuilder().addComponents(commandMenu);

            // Envoyer l'embed avec le menu
            const deleteMessage = await message.channel.send({
                embeds: [generateListEmbed()],
                components: [actionRow]
            }).catch(err => {
                console.error(`[ERROR] Failed to send delete message: ${err.message}`);
                throw err;
            });


            // Créer un collecteur pour les interactions du menu
            const collector = deleteMessage.createMessageComponentCollector({ time: 600000 });

            collector.on('collect', async interaction => {
                if (interaction.user.id !== message.author.id) {
                    return interaction.reply({ content: "Vous n'êtes pas autorisé à supprimer cette commande.", ephemeral: true }).catch(err => {
                        console.error(`[ERROR] Failed to send unauthorized reply: ${err.message}`);
                    });
                }

                await interaction.deferUpdate().catch(err => {
                    console.error(`[ERROR] Failed to defer update: ${err.message}`);
                });

                if (interaction.isStringSelectMenu()) {
                    const selectedIndex = parseInt(interaction.values[0]);
                    const selectedCommandName = customCommands[selectedIndex]?.name;

                    // Récupérer à nouveau les commandes pour s'assurer qu'elles n'ont pas changé
                    const updatedCommands = client.db.get(`custom_commands_${message.guild.id}`) || [];
                    
                    // Vérifier si l'index est toujours valide
                    if (!updatedCommands[selectedIndex]) {
                        await interaction.followUp({ content: `La commande \`${selectedCommandName}\` n'existe plus.`, ephemeral: true }).catch(err => {
                            console.error(`[ERROR] Failed to send command not found message: ${err.message}`);
                        });
                        collector.stop();
                        return;
                    }

                    // Supprimer la commande
                    updatedCommands.splice(selectedIndex, 1);
                    client.db.set(`custom_commands_${message.guild.id}`, updatedCommands);



                    // Si plus de commandes, désactiver le menu
                    if (updatedCommands.length === 0) {
                        await deleteMessage.edit({
                            embeds: [new EmbedBuilder()
                                .setTitle('Suppression d’une commande personnalisée')
                                .setDescription('Aucune commande personnalisée restante.')
                                .setColor(client.color)
                                .setFooter(client.footer)],
                            components: []
                        }).catch(err => {
                            console.error(`[ERROR] Failed to edit message (no commands left): ${err.message}`);
                        });
                        collector.stop();
                        return;
                    }

                    // Mettre à jour le menu avec les commandes restantes
                    const updatedMenu = new StringSelectMenuBuilder()
                        .setCustomId('delete_command')
                        .setPlaceholder('Sélectionner une commande à supprimer')
                        .addOptions(
                            updatedCommands.map((cmd, index) => ({
                                label: cmd.name,
                                value: index.toString(), // Utiliser l'index comme valeur unique
                                description: `Supprimer la commande ${cmd.name}`,
                                emoji: '🗑️' // Emoji pour la suppression
                            }))
                        );

                    const updatedActionRow = new ActionRowBuilder().addComponents(updatedMenu);

                    await deleteMessage.edit({
                        embeds: [new EmbedBuilder()
                            .setTitle('Suppression d’une commande personnalisée')
                            .setDescription('Sélectionnez une commande à supprimer dans le menu ci-dessous.')
                            .setColor(client.color)
                            .addFields({
                                name: 'Commandes personnalisées',
                                value: updatedCommands.map((cmd, index) => `${index + 1}. ${cmd.name}`).join('\n'),
                                inline: false
                            })
                            .setFooter(client.footer)],
                        components: [updatedActionRow]
                    }).catch(err => {
                        console.error(`[ERROR] Failed to edit message with updated menu: ${err.message}`);
                    });

                }
            });

            collector.on('end', async () => {
                await deleteMessage.edit({ components: [] }).catch(err => {
                    console.error(`[ERROR] Failed to disable components on collector end: ${err.message}`);
                });
            });
        } catch (error) {
            console.error(`[ERROR] An unexpected error occurred in customdelete: ${error.message}`);
            await message.channel.send("Une erreur s'est produite lors de l'exécution de la commande. Veuillez réessayer plus tard.").catch(err => {
            });
        }
    }
};