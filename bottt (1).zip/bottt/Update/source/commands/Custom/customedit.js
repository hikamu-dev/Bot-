const { ActionRowBuilder, ButtonBuilder, StringSelectMenuBuilder, EmbedBuilder } = require('discord.js');
const { example } = require('../Owner/changelimit');

module.exports = {
    name: "customedit",
    description: "Modifie une commande personnalisée existante",
    usages: "customedit <nom de la commande>",
    example: "➜ customedit tokyru",
    
    run: async (client, message, args) => {
        // Vérification des permissions
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) || 
        client.db.get(`owner_global_${message.author.id}`) === true || 
        client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true) {          pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${module.exports.name}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        // Vérifier si un nom de commande est fourni
        if (!args[0]) {
            return message.channel.send("Veuillez fournir le nom de la commande à modifier.").then(msg => setTimeout(() => msg.delete(), 5000));
        }

        // Récupérer les commandes existantes
        const existingCommands = client.db.get(`custom_commands_${message.guild.id}`) || [];
        const commandName = args[0].toLowerCase();
        const commandIndex = existingCommands.findIndex(cmd => cmd.name.toLowerCase() === commandName);

        if (commandIndex === -1) {
            return message.channel.send(`Aucune commande nommée \`${commandName}\` n'a été trouvée.`).then(msg => setTimeout(() => msg.delete(), 5000));
        }

        // Cloner la commande pour modification
        const commandToEdit = { ...existingCommands[commandIndex] };

        // Générer l'embed de configuration
        const generateConfigEmbed = (command) => {
            return new EmbedBuilder()
                .setTitle(`Modification de la commande : ${command.name}`)
                .setDescription('Modifiez les paramètres de votre commande.')
                .setColor(client.color)
                .addFields(
                    { name: '🇦🇹 Nom', value: command.name || 'Non défini', inline: true },
                    { name: '🔒 Permission', value: command.permission || 'Non défini', inline: true },
                    { name: '🎯 Cible (module rôle unique)', value: command.target || 'Non défini', inline: true },
                    { 
                        name: '📦 Modules', 
                        value: command.modules.length > 0 
                            ? command.modules.map((mod, index) => `${index + 1}. ${mod.type}`).join('\n') 
                            : 'Aucun module ajouté', 
                        inline: false 
                    }
                )
                .setFooter(client.footer);
        };

        // Menu de configuration
        const configMenu = new StringSelectMenuBuilder()
            .setCustomId('custom_config')
            .setPlaceholder('Sélectionnez un paramètre à modifier')
            .addOptions([
                { label: 'Nom de la commande', value: 'set_name', emoji: '🇦🇹' },
                { label: 'Permission', value: 'set_permission', emoji: '🔒' },
                { label: 'Cible', value: 'set_target', emoji: '🎯' },
                { label: 'Ajouter un module', value: 'add_module', emoji: '➕' },
                { label: 'Supprimer un module', value: 'remove_module', emoji: '➖' },
            ]);

        const actionRow = new ActionRowBuilder().addComponents(configMenu);

        // Boutons "Valider" et "Annuler"
        const buttonsRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('save_command')
                .setLabel('Valider les modifications')
                .setStyle('Success'),
            new ButtonBuilder()
                .setCustomId('cancel_command')
                .setLabel('Annuler')
                .setStyle('Danger')
        );

        const configMessage = await message.channel.send({
            embeds: [generateConfigEmbed(commandToEdit)],
            components: [actionRow, buttonsRow]
        });

        const collector = configMessage.createMessageComponentCollector({ time: 600000 });

        collector.on('collect', async interaction => {
            if (interaction.user.id !== message.author.id) {
                return interaction.reply({ content: "Vous n'êtes pas autorisé à modifier cette commande.", ephemeral: true });
            }

            await interaction.deferUpdate();

            if (interaction.isStringSelectMenu()) {
                const selectedOption = interaction.values[0];
                const filter = m => m.author.id === message.author.id;

                switch (selectedOption) {
                    case 'set_name': {
                        const instruction = await message.channel.send('Entrez le nouveau nom de la commande :');
                        const responses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                        commandToEdit.name = responses.first().content;
                        await instruction.delete();
                        await responses.first().delete();
                        break;
                    }

case 'set_permission': {
                        if (permNames.length === 0) {
                            await message.channel.send('Aucune permission personnalisée n\'est définie. La permission sera définie sur "public".').then(msg => setTimeout(() => msg.delete(), 3000));
                            newCommand.permission = 'public';
                            break;
                        }

                        const permOptions = [
                            { label: 'Public', value: 'public', emoji: '🌐' },
                            ...permNames.map(perm => ({ label: perm, value: perm, emoji: '🔒' }))
                        ];

                        const permMenu = new StringSelectMenuBuilder()
                            .setCustomId('perm_select')
                            .setPlaceholder('Choisissez une permission')
                            .addOptions(permOptions);

                        const permRow = new ActionRowBuilder().addComponents(permMenu);

                        const permInstruction = await message.channel.send({
                            content: 'Choisissez une permission pour la commande :',
                            components: [permRow]
                        });

                        const permCollector = permInstruction.createMessageComponentCollector({
                            filter: i => i.user.id === message.author.id,
                            time: 30000
                        });

                        permCollector.on('collect', async permInteraction => {
                            newCommand.permission = permInteraction.values[0];
                            await permInteraction.update({
                                content: `Permission définie sur \`${newCommand.permission}\`.`,
                                components: []
                            });
                            await configMessage.edit({
                                embeds: [generateConfigEmbed(newCommand)],
                                components: [actionRow, buttonsRow]
                            });
                            permCollector.stop();
                        });

                        permCollector.on('end', async (collected) => {
                            if (collected.size === 0) {
                                await permInstruction.edit({ content: 'Aucune permission sélectionnée. Permission par défaut : public.', components: [] });
                                newCommand.permission = 'public';
                                await configMessage.edit({
                                    embeds: [generateConfigEmbed(newCommand)],
                                    components: [actionRow, buttonsRow]
                                });
                            }
                        });

                        break;
                    }

                    case 'set_target': {
                        const instruction = await message.channel.send('Quelle est la nouvelle cible ? (soi/utilisateur) :');
                        const responses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                        const targetInput = responses.first().content.toLowerCase();
                        if (["soi", "utilisateur"].includes(targetInput)) {
                            commandToEdit.target = targetInput;
                        } else {
                            await message.channel.send('Cible invalide. Utilisation de "soi" par défaut.').then(msg => setTimeout(() => msg.delete(), 3000));
                            commandToEdit.target = "soi";
                        }
                        await instruction.delete();
                        await responses.first().delete();
                        break;
                    }

                    case 'add_module': {
                        const instruction = await message.channel.send('Quel type de module souhaitez-vous ajouter ? (message, embed, role) :');
                        const responses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                        const moduleType = responses.first().content.toLowerCase();
                        await instruction.delete();
                        await responses.first().delete();

                        if (moduleType === 'embed') {
                            const channelInstruction = await message.channel.send("Entre l'ID du salon contenant l'embed :");
                            const channelResponses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                            const sourceChannelId = channelResponses.first().content.replace(/[<#>|]/g, '');
                            await channelInstruction.delete();
                            await channelResponses.first().delete();

                            const messageInstruction = await message.channel.send("Entre l'ID du message contenant l'embed :");
                            const messageResponses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                            const messageId = messageResponses.first().content;
                            await messageInstruction.delete();
                            await messageResponses.first().delete();

                            const sendChannelInstruction = await message.channel.send("Souhaitez-vous spécifier un salon pour envoyer cet embed ? (oui/non) :");
                            const sendChannelResponses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                            const sendChannelChoice = sendChannelResponses.first().content.toLowerCase();
                            await sendChannelInstruction.delete();
                            await sendChannelResponses.first().delete();

                            let destinationChannelId = null;
                            if (sendChannelChoice === 'oui') {
                                const destinationInstruction = await message.channel.send("Veuillez fournir l'ID ou mentionner le salon :");
                                const destinationResponses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                                destinationChannelId = destinationResponses.first().content.replace(/[<#>|]/g, '');
                                await destinationInstruction.delete();
                                await destinationResponses.first().delete();

                                const destinationChannel = message.guild.channels.cache.get(destinationChannelId);
                                if (destinationChannel) {
                                    await message.channel.send(`L'embed a été ajouté et sera envoyé dans le salon ${destinationChannel.toString()}.`).then(msg => setTimeout(() => msg.delete(), 3000));
                                } else {
                                    await message.channel.send('Salon invalide. L\'embed sera envoyé dans le salon actuel.').then(msg => setTimeout(() => msg.delete(), 3000));
                                    destinationChannelId = null;
                                }
                            } else {
                                await message.channel.send('L\'embed sera envoyé dans le salon actuel.').then(msg => setTimeout(() => msg.delete(), 3000));
                            }

                            commandToEdit.modules.push({
                                type: 'embed',
                                sourceChannelId,
                                messageId,
                                destinationChannelId
                            });
                        } else if (moduleType === 'message') {
                            const contentInstruction = await message.channel.send("Entrez le contenu du message :");
                            const contentResponses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                            const messageContent = contentResponses.first().content;
                            await contentInstruction.delete();
                            await contentResponses.first().delete();

                            const sendChannelInstruction = await message.channel.send("Souhaitez-vous spécifier un salon pour envoyer ce message ? (oui/non) :");
                            const sendChannelResponses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                            const sendChannelChoice = sendChannelResponses.first().content.toLowerCase();
                            await sendChannelInstruction.delete();
                            await sendChannelResponses.first().delete();

                            let destinationChannelId = null;
                            if (sendChannelChoice === 'oui') {
                                const destinationInstruction = await message.channel.send("Veuillez fournir l'ID ou mentionner le salon :");
                                const destinationResponses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                                destinationChannelId = destinationResponses.first().content.replace(/[<#>|]/g, '');
                                await destinationInstruction.delete();
                                await destinationResponses.first().delete();

                                const destinationChannel = message.guild.channels.cache.get(destinationChannelId);
                                if (destinationChannel) {
                                    await message.channel.send(`Le message a été ajouté et sera envoyé dans le salon ${destinationChannel.toString()}.`).then(msg => setTimeout(() => msg.delete(), 3000));
                                } else {
                                    await message.channel.send('Salon invalide. Le message sera envoyé dans le salon actuel.').then(msg => setTimeout(() => msg.delete(), 3000));
                                    destinationChannelId = null;
                                }
                            } else {
                                await message.channel.send('Le message sera envoyé dans le salon actuel.').then(msg => setTimeout(() => msg.delete(), 3000));
                            }

                            commandToEdit.modules.push({
                                type: 'message',
                                content: messageContent,
                                destinationChannelId
                            });
                        } else if (moduleType === 'role') {
                            const actionInstruction = await message.channel.send("Souhaitez-vous ajouter ou retirer un rôle ? (ajouter/retirer) :");
                            const actionResponses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                            const actionChoice = actionResponses.first().content.toLowerCase();
                            await actionInstruction.delete();
                            await actionResponses.first().delete();

                            if (!["ajouter", "retirer"].includes(actionChoice)) {
                                await message.channel.send('Action invalide. Aucun module ajouté.').then(msg => setTimeout(() => msg.delete(), 3000));
                                break;
                            }

                            const roleInstruction = await message.channel.send("Mentionnez le rôle ou fournissez son ID :");
                            const roleResponses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                            const roleId = roleResponses.first().content.replace(/[<@&>|]/g, '');
                            await roleInstruction.delete();
                            await roleResponses.first().delete();

                            const role = message.guild.roles.cache.get(roleId);
                            if (!role) {
                                await message.channel.send('Rôle invalide. Aucun module ajouté.').then(msg => setTimeout(() => msg.delete(), 3000));
                                break;
                            }

                            const sendChannelInstruction = await message.channel.send("Souhaitez-vous spécifier un salon pour envoyer les messages de confirmation ? (oui/non) :");
                            const sendChannelResponses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                            const sendChannelChoice = sendChannelResponses.first().content.toLowerCase();
                            await sendChannelInstruction.delete();
                            await sendChannelResponses.first().delete();

                            let destinationChannelId = null;
                            if (sendChannelChoice === 'oui') {
                                const destinationInstruction = await message.channel.send("Veuillez fournir l'ID ou mentionner le salon :");
                                const destinationResponses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                                destinationChannelId = destinationResponses.first().content.replace(/[<#>|]/g, '');
                                await destinationInstruction.delete();
                                await destinationResponses.first().delete();

                                const destinationChannel = message.guild.channels.cache.get(destinationChannelId);
                                if (destinationChannel) {
                                    await message.channel.send(`Le module rôle a été ajouté et les confirmations seront envoyées dans le salon ${destinationChannel.toString()}.`).then(msg => setTimeout(() => msg.delete(), 3000));
                                } else {
                                    await message.channel.send('Salon invalide. Les confirmations seront envoyées dans le salon actuel.').then(msg => setTimeout(() => msg.delete(), 3000));
                                    destinationChannelId = null;
                                }
                            } else {
                                await message.channel.send('Les confirmations seront envoyées dans le salon actuel.').then(msg => setTimeout(() => msg.delete(), 3000));
                            }

                            commandToEdit.modules.push({
                                type: 'role',
                                action: actionChoice,
                                roleId,
                                destinationChannelId
                            });
                        } else {
                            await message.channel.send('Type de module invalide. Aucun module ajouté.').then(msg => setTimeout(() => msg.delete(), 3000));
                        }
                        break;
                    }

                    case 'remove_module': {
                        if (commandToEdit.modules.length === 0) {
                            await interaction.followUp({ content: 'Aucun module à supprimer.', ephemeral: true });
                            break;
                        }
                        const instruction = await message.channel.send(
                            `Quel module souhaitez-vous supprimer ? (1-${commandToEdit.modules.length})\n${commandToEdit.modules.map((mod, i) => `${i + 1}. ${mod.type}`).join('\n')}`
                        );
                        const responses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                        const indexToRemove = parseInt(responses.first().content) - 1;
                        if (indexToRemove >= 0 && indexToRemove < commandToEdit.modules.length) {
                            commandToEdit.modules.splice(indexToRemove, 1);
                        }
                        await instruction.delete();
                        await responses.first().delete();
                        break;
                    }
                }

                await configMessage.edit({
                    embeds: [generateConfigEmbed(commandToEdit)],
                    components: [actionRow, buttonsRow]
                });
            } else if (interaction.isButton()) {
                if (interaction.customId === 'save_command') {
                    // Vérifier si le nom est "Non défini"
                    if (commandToEdit.name === 'Non défini') {
                        await interaction.followUp({ content: 'Veuillez définir un nom pour la commande avant de la sauvegarder.', ephemeral: true });
                        return;
                    }

                    // Vérifier si une autre commande avec le même nom existe (sauf celle qu'on modifie)
                    const otherCommands = existingCommands.filter((cmd, idx) => idx !== commandIndex);
                    const nameExists = otherCommands.some(cmd => cmd.name.toLowerCase() === commandToEdit.name.toLowerCase());

                    if (nameExists) {
                        await interaction.followUp({ content: `Une autre commande nommée \`${commandToEdit.name}\` existe déjà. Veuillez choisir un autre nom.`, ephemeral: true });
                        return;
                    }

                    // Vérifier si au moins un module est présent
                    if (commandToEdit.modules.length === 0) {
                        await interaction.followUp({ content: 'Vous devez avoir au moins un module pour sauvegarder la commande.', ephemeral: true });
                        return;
                    }

                    // Sauvegarder les modifications
                    existingCommands[commandIndex] = commandToEdit;
                    client.db.set(`custom_commands_${message.guild.id}`, existingCommands);

                    await interaction.followUp({ content: `Commande personnalisée \`${commandToEdit.name}\` modifiée avec succès !` });
                    collector.stop();
                } else if (interaction.customId === 'cancel_command') {
                    await interaction.followUp({ content: 'Modification annulée.' });
                    collector.stop();
                }
            }
        });

        collector.on('end', async () => {
            await configMessage.edit({ components: [] });
        });
    }
};