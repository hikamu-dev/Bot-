const { ActionRowBuilder, ButtonBuilder, StringSelectMenuBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    name: "custom",
    description: "Crée une commande personnalisée",
    usages: "custom",
    
    run: async (client, message, args) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) || 
        client.db.get(`owner_global_${message.author.id}`) === true || 
        client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true) {            
      pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${module.exports.name}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${module.exports.name}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        // Initialisation de la nouvelle commande personnalisée
        const newCommand = {
            name: 'Non défini',
            permission: 'public',
            target: 'soi',
            modules: []
        };

        // Générer l'embed de configuration
        const generateConfigEmbed = (command) => {
            return new EmbedBuilder()
                .setTitle('Création d’une commande personnalisée')
                .setDescription('Configurez votre commande pas à pas.')
                .setColor(client.color)
                .addFields(
                    { name: '🇦🇹 Nom', value: command.name || 'Non défini', inline: true },
                    { name: '🔒 Permission', value: command.permission || 'Non défini', inline: true },
                    { name: '🎯 Cible (module rôle unique)', value: command.target || 'Non défini', inline: true },
                    { 
                        name: '📦 Modules', 
                        value: command.modules.length > 0 
                            ? command.modules.map((mod, index) => `${index + 1}. ${mod.type}`).join('\n') 
                            : 'Aucun module ajouté', 
                        inline: false 
                    }
                )
                .setFooter(client.footer);
        };

        // Menu de configuration
        const configMenu = new StringSelectMenuBuilder()
            .setCustomId('custom_config')
            .setPlaceholder('Configurer une option')
            .addOptions([
                { label: 'Nom de la commande', value: 'set_name', emoji: '🇦🇹' },
                { label: 'Permission', value: 'set_permission', emoji: '🔒' },
                { label: 'Cible', value: 'set_target', emoji: '🎯' },
                { label: 'Ajouter un module', value: 'add_module', emoji: '➕' },
                { label: 'Supprimer un module', value: 'remove_module', emoji: '➖' },
            ]);

        const actionRow = new ActionRowBuilder().addComponents(configMenu);

        // Boutons "Créer" et "Annuler"
        const buttonsRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('create_command')
                .setLabel('Créer la commande')
                .setStyle('Success'),
            new ButtonBuilder()
                .setCustomId('cancel_command')
                .setLabel('Annuler')
                .setStyle('Danger')
        );

        const configMessage = await message.channel.send({
            embeds: [generateConfigEmbed(newCommand)],
            components: [actionRow, buttonsRow]
        });

        const collector = configMessage.createMessageComponentCollector({ time: 600000 });

        collector.on('collect', async interaction => {
            if (interaction.user.id !== message.author.id) {
                return interaction.reply({ content: "Vous n'êtes pas autorisé à configurer cette commande.", ephemeral: true });
            }

            await interaction.deferUpdate();

            if (interaction.isStringSelectMenu()) {
                const selectedOption = interaction.values[0];
                const filter = m => m.author.id === message.author.id;

                switch (selectedOption) {
                    case 'set_name': {
                        const instruction = await message.channel.send('Entrez le nom de la commande :');
                        const responses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                        newCommand.name = responses.first().content;
                        await instruction.delete();
                        await responses.first().delete();
                        break;
                    }

case 'set_permission': {
                        const instruction = await message.channel.send('Entrez le nom de la permission pour cette commande (ex: Shelia) :');
                        const responses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                        const permName = responses.first().content;
                        if (/^[a-zA-Z0-9]+$/.test(permName)) {
                            newCommand.permission = permName;
                        } else {
                            await message.channel.send('Nom de permission invalide. Utilisation de "public" par défaut.').then(msg => setTimeout(() => msg.delete(), 3000));
                            newCommand.permission = "public";
                        }
                        await instruction.delete();
                        await responses.first().delete();
                        break;
                    }

                    case 'set_target': {
                        const instruction = await message.channel.send('Quelle est la cible ? (soi/utilisateur) :');
                        const responses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                        const targetInput = responses.first().content.toLowerCase();
                        if (["soi", "utilisateur"].includes(targetInput)) {
                            newCommand.target = targetInput;
                        } else {
                            await message.channel.send('Cible invalide. Utilisation de "soi" par défaut.').then(msg => setTimeout(() => msg.delete(), 3000));
                            newCommand.target = "soi";
                        }
                        await instruction.delete();
                        await responses.first().delete();
                        break;
                    }
                    case 'set_delete': {
                        const instruction = await message.channel.send('Voulez-vous que le message de commande soit supprimé automatiquement ? (oui/non) :');
                        const responses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                        const deleteChoice = responses.first().content.toLowerCase();
                        if (["oui", "yes", "true", "1"].includes(deleteChoice)) {
                            newCommand.deleteMessage = true;
                            await message.channel.send('✅ Le message de commande sera supprimé automatiquement.').then(msg => setTimeout(() => msg.delete(), 3000));
                        } else if (["non", "no", "false", "0"].includes(deleteChoice)) {
                            newCommand.deleteMessage = false;
                            await message.channel.send('❌ Le message de commande ne sera pas supprimé.').then(msg => setTimeout(() => msg.delete(), 3000));
                        } else {
                            await message.channel.send('Réponse invalide. Le message ne sera pas supprimé par défaut.').then(msg => setTimeout(() => msg.delete(), 3000));
                            newCommand.deleteMessage = false;
                        }
                        await instruction.delete();
                        await responses.first().delete();
                        break;
                    }
                    case 'add_module': {
                        const instruction = await message.channel.send('Quel type de module souhaitez-vous ajouter ? (message, embed, role) :');
                        const responses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                        const moduleType = responses.first().content.toLowerCase();
                        await instruction.delete();
                        await responses.first().delete();

                        if (moduleType === 'embed') {
                            // Étape 1 : Demander l'ID du salon contenant l'embed
                            const channelInstruction = await message.channel.send("Entre l'ID du salon contenant l'embed :");
                            const channelResponses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                            const sourceChannelId = channelResponses.first().content.replace(/[<#>|]/g, '');
                            await channelInstruction.delete();
                            await channelResponses.first().delete();

                            // Étape 2 : Demander l'ID du message contenant l'embed
                            const messageInstruction = await message.channel.send("Entre l'ID du message contenant l'embed :");
                            const messageResponses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                            const messageId = messageResponses.first().content;
                            await messageInstruction.delete();
                            await messageResponses.first().delete();

                            // Étape 3 : Demander si un salon spécifique doit être utilisé pour envoyer l'embed
                            const sendChannelInstruction = await message.channel.send("Souhaitez-vous spécifier un salon pour envoyer cet embed ? (oui/non) :");
                            const sendChannelResponses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                            const sendChannelChoice = sendChannelResponses.first().content.toLowerCase();
                            await sendChannelInstruction.delete();
                            await sendChannelResponses.first().delete();

                            let destinationChannelId = null;
                            if (sendChannelChoice === 'oui') {
                                const destinationInstruction = await message.channel.send("Veuillez fournir l'ID ou mentionner le salon :");
                                const destinationResponses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                                destinationChannelId = destinationResponses.first().content.replace(/[<#>|]/g, '');
                                await destinationInstruction.delete();
                                await destinationResponses.first().delete();

                                // Confirmation
                                const destinationChannel = message.guild.channels.cache.get(destinationChannelId);
                                if (destinationChannel) {
                                    await message.channel.send(`L'embed a été ajouté et sera envoyé dans le salon ${destinationChannel.toString()}.`).then(msg => setTimeout(() => msg.delete(), 3000));
                                } else {
                                    await message.channel.send('Salon invalide. L\'embed sera envoyé dans le salon actuel.').then(msg => setTimeout(() => msg.delete(), 3000));
                                    destinationChannelId = null;
                                }
                            } else {
                                await message.channel.send('L\'embed sera envoyé dans le salon actuel.').then(msg => setTimeout(() => msg.delete(), 3000));
                            }

                            // Ajouter le module embed avec ses informations
                            newCommand.modules.push({
                                type: 'embed',
                                sourceChannelId,
                                messageId,
                                destinationChannelId
                            });
                        } else if (moduleType === 'message') {
                            // Étape 1 : Demander le contenu du message
                            const contentInstruction = await message.channel.send("Entrez le contenu du message :");
                            const contentResponses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                            const messageContent = contentResponses.first().content;
                            await contentInstruction.delete();
                            await contentResponses.first().delete();

                            // Étape 2 : Demander si un salon spécifique doit être utilisé pour envoyer le message
                            const sendChannelInstruction = await message.channel.send("Souhaitez-vous spécifier un salon pour envoyer ce message ? (oui/non) :");
                            const sendChannelResponses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                            const sendChannelChoice = sendChannelResponses.first().content.toLowerCase();
                            await sendChannelInstruction.delete();
                            await sendChannelResponses.first().delete();

                            let destinationChannelId = null;
                            if (sendChannelChoice === 'oui') {
                                const destinationInstruction = await message.channel.send("Veuillez fournir l'ID ou mentionner le salon :");
                                const destinationResponses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                                destinationChannelId = destinationResponses.first().content.replace(/[<#>|]/g, '');
                                await destinationInstruction.delete();
                                await destinationResponses.first().delete();

                                // Confirmation
                                const destinationChannel = message.guild.channels.cache.get(destinationChannelId);
                                if (destinationChannel) {
                                    await message.channel.send(`Le message a été ajouté et sera envoyé dans le salon ${destinationChannel.toString()}.`).then(msg => setTimeout(() => msg.delete(), 3000));
                                } else {
                                    await message.channel.send('Salon invalide. Le message sera envoyé dans le salon actuel.').then(msg => setTimeout(() => msg.delete(), 3000));
                                    destinationChannelId = null;
                                }
                            } else {
                                await message.channel.send('Le message sera envoyé dans le salon actuel.').then(msg => setTimeout(() => msg.delete(), 3000));
                            }

                            // Ajouter le module message avec ses informations
                            newCommand.modules.push({
                                type: 'message',
                                content: messageContent,
                                destinationChannelId
                            });
                        } else if (moduleType === 'role') {
                            // Étape 1 : Demander si le rôle doit être ajouté ou retiré
                            const actionInstruction = await message.channel.send("Souhaitez-vous ajouter ou retirer un rôle ? (ajouter/retirer) :");
                            const actionResponses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                            const actionChoice = actionResponses.first().content.toLowerCase();
                            await actionInstruction.delete();
                            await actionResponses.first().delete();

                            if (!["ajouter", "retirer"].includes(actionChoice)) {
                                await message.channel.send('Action invalide. Aucun module ajouté.').then(msg => setTimeout(() => msg.delete(), 3000));
                                break;
                            }

                            // Étape 2 : Demander l'ID du rôle
                            const roleInstruction = await message.channel.send("Mentionnez le rôle ou fournissez son ID :");
                            const roleResponses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                            const roleId = roleResponses.first().content.replace(/[<@&>|]/g, '');
                            await roleInstruction.delete();
                            await roleResponses.first().delete();

                            // Vérifier si le rôle existe
                            const role = message.guild.roles.cache.get(roleId);
                            if (!role) {
                                await message.channel.send('Rôle invalide. Aucun module ajouté.').then(msg => setTimeout(() => msg.delete(), 3000));
                                break;
                            }

                            // Étape 3 : Demander si un salon spécifique doit être utilisé pour les messages de confirmation
                            const sendChannelInstruction = await message.channel.send("Souhaitez-vous spécifier un salon pour envoyer les messages de confirmation ? (oui/non) :");
                            const sendChannelResponses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                            const sendChannelChoice = sendChannelResponses.first().content.toLowerCase();
                            await sendChannelInstruction.delete();
                            await sendChannelResponses.first().delete();

                            let destinationChannelId = null;
                            if (sendChannelChoice === 'oui') {
                                const destinationInstruction = await message.channel.send("Veuillez fournir l'ID ou mentionner le salon :");
                                const destinationResponses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                                destinationChannelId = destinationResponses.first().content.replace(/[<#>|]/g, '');
                                await destinationInstruction.delete();
                                await destinationResponses.first().delete();

                                // Confirmation
                                const destinationChannel = message.guild.channels.cache.get(destinationChannelId);
                                if (destinationChannel) {
                                    await message.channel.send(`Le module rôle a été ajouté et les confirmations seront envoyées dans le salon ${destinationChannel.toString()}.`).then(msg => setTimeout(() => msg.delete(), 3000));
                                } else {
                                    await message.channel.send('Salon invalide. Les confirmations seront envoyées dans le salon actuel.').then(msg => setTimeout(() => msg.delete(), 3000));
                                    destinationChannelId = null;
                                }
                            } else {
                                await message.channel.send('Les confirmations seront envoyées dans le salon actuel.').then(msg => setTimeout(() => msg.delete(), 3000));
                            }

                            // Ajouter le module rôle avec ses informations
                            newCommand.modules.push({
                                type: 'role',
                                action: actionChoice,
                                roleId,
                                destinationChannelId
                            });
                        } else {
                            await message.channel.send('Type de module invalide. Aucun module ajouté.').then(msg => setTimeout(() => msg.delete(), 3000));
                        }
                        break;
                    }

                    case 'remove_module': {
                        if (newCommand.modules.length === 0) {
                            await interaction.followUp({ content: 'Aucun module à supprimer.', ephemeral: true });
                            break;
                        }
                        const instruction = await message.channel.send(
                            `Quel module souhaitez-vous supprimer ? (1-${newCommand.modules.length})\n${newCommand.modules.map((mod, i) => `${i + 1}. ${mod.type}`).join('\n')}`
                        );
                        const responses = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
                        const indexToRemove = parseInt(responses.first().content) - 1;
                        if (indexToRemove >= 0 && indexToRemove < newCommand.modules.length) {
                            newCommand.modules.splice(indexToRemove, 1);
                        }
                        await instruction.delete();
                        await responses.first().delete();
                        break;
                    }
                }

                await configMessage.edit({
                    embeds: [generateConfigEmbed(newCommand)],
                    components: [actionRow, buttonsRow]
                });
            } else if (interaction.isButton()) {
                if (interaction.customId === 'create_command') {
                    // Vérifier si le nom est "Non défini"
                    if (newCommand.name === 'Non défini') {
                        await interaction.followUp({ content: 'Veuillez définir un nom pour la commande avant de la créer.', ephemeral: true });
                        return;
                    }

                    // Vérifier si une commande avec le même nom existe déjà
                    const existingCommands = client.db.get(`custom_commands_${message.guild.id}`) || [];
                    const nameExists = existingCommands.some(cmd => cmd.name.toLowerCase() === newCommand.name.toLowerCase());

                    if (nameExists) {
                        await interaction.followUp({ content: `Une commande nommée \`${newCommand.name}\` existe déjà. Veuillez choisir un autre nom.`, ephemeral: true });
                        return;
                    }

                    // Vérifier si au moins un module est ajouté
                    if (newCommand.modules.length === 0) {
                        await interaction.followUp({ content: 'Vous devez ajouter au moins un module pour créer la commande.', ephemeral: true });
                        return;
                    }

                    // Sauvegarde de la commande
                    existingCommands.push(newCommand);
                    client.db.set(`custom_commands_${message.guild.id}`, existingCommands);

                    await interaction.followUp({ content: `Commande personnalisée \`${newCommand.name}\` créée avec succès !` });
                    collector.stop();
                } else if (interaction.customId === 'cancel_command') {
                    await interaction.followUp({ content: 'Création annulée.' });
                    collector.stop();
                }
            }
        });

        collector.on('end', async () => {
            await configMessage.edit({ components: [] });
        });
    }
};