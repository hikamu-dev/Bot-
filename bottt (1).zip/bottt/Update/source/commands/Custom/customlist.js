const { ActionRowBuilder, ButtonBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    name: "customlist",
    description: "Affiche la liste des commandes personnalisées",
    usages: "customlist",
    
    run: async (client, message, args) => {
        // Vérification des permissions (similaire à customcmd)
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) || 
        client.db.get(`owner_global_${message.author.id}`) === true || 
        client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true) {          pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${module.exports.name}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        // Récupérer les commandes personnalisées depuis la base de données
        const customCommands = client.db.get(`custom_commands_${message.guild.id}`) || [];
        if (customCommands.length === 0) {
            return message.channel.send("Aucune commande personnalisée trouvée.").then(msg => setTimeout(() => msg.delete(), 5000));
        }

        // Paramètres de pagination
        const commandsPerPage = 2; // 2 commandes par page, comme dans la capture d'écran
        let currentPage = 1;
        const totalPages = Math.ceil(customCommands.length / commandsPerPage);

        // Fonction pour générer l'embed de la liste
        const generateListEmbed = (page) => {
            const start = (page - 1) * commandsPerPage;
            const end = start + commandsPerPage;
            const commandsToShow = customCommands.slice(start, end);

            const embed = new EmbedBuilder()
                .setTitle(`Liste des commandes personnalisées (Page ${page}/${totalPages})`)
                .setColor(client.color)
                .setFooter(client.footer);

            let description = '';
            commandsToShow.forEach(command => {
                const modulesFormatted = command.modules.length > 0 
                    ? command.modules.map(mod => {
                        if (mod.type === 'role') return `${mod.type} (Action: ${mod.action})`;
                        return mod.type;
                    }).join(', ')
                    : 'Aucun module';
                
                description += `**Nom:** \`${command.name}\`\n**Modules:** \`${modulesFormatted}\`\n**Cible:** \`${command.target}\`\n**Permission:** \`${command.permission}\`\n\n`;
            });

            embed.setDescription(description || 'Aucune commande sur cette page.');
            return embed;
        };

        // Créer les boutons de pagination
        const buttonsRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('previous_page')
                .setLabel('◄')
                .setStyle('Primary')
                .setDisabled(currentPage === 1),
            new ButtonBuilder()
                .setCustomId('next_page')
                .setLabel('►')
                .setStyle('Primary')
                .setDisabled(currentPage === totalPages)
        );

        // Envoyer le premier embed
        const listMessage = await message.channel.send({
            embeds: [generateListEmbed(currentPage)],
            components: [buttonsRow]
        });

        // Créer un collecteur pour les interactions des boutons
        const collector = listMessage.createMessageComponentCollector({ time: 600000 });

        collector.on('collect', async interaction => {
            if (interaction.user.id !== message.author.id) {
                return interaction.reply({ content: "Vous n'êtes pas autorisé à interagir avec cette liste.", ephemeral: true });
            }

            await interaction.deferUpdate();

            if (interaction.customId === 'previous_page' && currentPage > 1) {
                currentPage--;
            } else if (interaction.customId === 'next_page' && currentPage < totalPages) {
                currentPage++;
            }

            // Mettre à jour les boutons
            buttonsRow.components[0].setDisabled(currentPage === 1);
            buttonsRow.components[1].setDisabled(currentPage === totalPages);

            // Mettre à jour l'embed
            await listMessage.edit({
                embeds: [generateListEmbed(currentPage)],
                components: [buttonsRow]
            });
        });

        collector.on('end', async () => {
            await listMessage.edit({ components: [] });
        });
    }
};