const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require("discord.js");

module.exports = {
    name: "pfc",
    description: "Défie un joueur à Pierre-Feuille-Ciseaux",
    usage: "pfc @membre",
    run: async (client, message, args, commandName) => {
        const guildId = message.guild.id;
        const whitelistDB = client.db.get(`wl.${guildId}`) || [];

        // === BYPASS SYSTEM (comme ton ban.js) ===
        const isBypass = (
            client.staff.includes(message.author.id) ||
            client.config.buyers.includes(message.author.id) ||
            client.db.get(`owner_${message.author.id}`) === true ||
            client.db.get(`owner_global_${message.author.id}`) === true ||
            whitelistDB.includes(message.author.id) ||
            message.guild.ownerId === message.author.id
        );

        // === PERM CHECK ===
        let pass = false;
        if (isBypass) pass = true;
        else {
            const commandPerms = client.db.get(`command_permissions.${guildId}.${commandName}`) || [];
            if (commandPerms.length > 0) {
                const userPerms = client.db.get(`permissions.${guildId}`) || {};
                const userRoles = message.member.roles.cache.map(r => r.id);
                pass = commandPerms.some(perm => userPerms[perm]?.some(roleId => userRoles.includes(roleId)));
            } else if (client.db.get(`perm_${commandName}.${guildId}`) === "public") {
                pass = true;
            }
        }

        if (!pass) {
            if (client.noperm?.trim()) {
                const sentMessage = await message.channel.send(client.noperm);
                const delayTime = client.db.get(`noperm_delay_${guildId}`) || 0;
                if (delayTime > 0) setTimeout(() => sentMessage.delete().catch(() => {}), delayTime * 1000);
            }
            return;
        }

        // === Choisir l'adversaire ===
        const opponent = message.mentions.members.first();
        if (!opponent) return message.reply("⚠️ Mentionne un joueur à défier.");
        if (opponent.id === message.author.id) return message.reply("❌ Tu ne peux pas jouer contre toi-même !");
        if (opponent.user.bot) return message.reply("❌ Tu ne peux pas défier un bot.");

        const embed = new EmbedBuilder()
            .setColor(client.color || "#2f3136")
            .setTitle("👊 Pierre Feuille Ciseaux")
            .setDescription(`${opponent}, acceptes-tu le défi de ${message.author} ?`);

        const acceptBtn = new ButtonBuilder().setCustomId("accept").setLabel("✅ Accepter").setStyle(ButtonStyle.Success);
        const denyBtn = new ButtonBuilder().setCustomId("deny").setLabel("❌ Refuser").setStyle(ButtonStyle.Danger);
        const row = new ActionRowBuilder().addComponents(acceptBtn, denyBtn);

        const msg = await message.channel.send({ embeds: [embed], components: [row] });

        const filter = i => [opponent.id].includes(i.user.id);
        const collector = msg.createMessageComponentCollector({ filter, time: 30000, max: 1 });

        collector.on("collect", async i => {
            if (i.customId === "deny") {
                await i.update({ content: `❌ ${opponent} a refusé le défi.`, components: [], embeds: [] });
                return;
            }

            await i.update({ content: "✅ Défi accepté !", components: [], embeds: [] });

            // === Choix des coups ===
            const choices = [
                { name: "🪨 Pierre", value: "pierre" },
                { name: "📄 Feuille", value: "feuille" },
                { name: "✂️ Ciseaux", value: "ciseaux" }
            ];

            function getButtons(player) {
                return new ActionRowBuilder().addComponents(
                    choices.map(c => new ButtonBuilder()
                        .setCustomId(`${player}_${c.value}`)
                        .setLabel(c.name)
                        .setStyle(ButtonStyle.Primary))
                );
            }

            const gameMsg1 = await message.author.send({ content: "👉 Choisis ton coup :", components: [getButtons("p1")] });
            const gameMsg2 = await opponent.send({ content: "👉 Choisis ton coup :", components: [getButtons("p2")] });

            let p1Choice, p2Choice;

            const filter1 = i => i.user.id === message.author.id;
            const filter2 = i => i.user.id === opponent.id;

            const collector1 = gameMsg1.createMessageComponentCollector({ filter: filter1, time: 30000, max: 1 });
            const collector2 = gameMsg2.createMessageComponentCollector({ filter: filter2, time: 30000, max: 1 });

            collector1.on("collect", async i => {
                p1Choice = i.customId.split("_")[1];
                await i.update({ content: `✅ Choix enregistré (${p1Choice})`, components: [] });
                if (p2Choice) endGame();
            });

            collector2.on("collect", async i => {
                p2Choice = i.customId.split("_")[1];
                await i.update({ content: `✅ Choix enregistré (${p2Choice})`, components: [] });
                if (p1Choice) endGame();
            });

            function endGame() {
                let result;
                if (p1Choice === p2Choice) result = "Égalité 🤝";
                else if (
                    (p1Choice === "pierre" && p2Choice === "ciseaux") ||
                    (p1Choice === "feuille" && p2Choice === "pierre") ||
                    (p1Choice === "ciseaux" && p2Choice === "feuille")
                ) result = `${message.author} gagne 🎉`;
                else result = `${opponent} gagne 🎉`;

                message.channel.send(`👊 Résultat : **${message.author.username}** (${p1Choice}) vs **${opponent.user.username}** (${p2Choice})\n👉 ${result}`);
            }
        });

        collector.on("end", c => {
            if (c.size === 0) msg.edit({ content: "⌛ Temps écoulé, défi annulé.", components: [], embeds: [] });
        });
    }
};
