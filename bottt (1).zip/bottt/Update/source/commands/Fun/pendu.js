const Discord = require('discord.js');

module.exports = {
    name: 'pendu',
    description: "Joue au jeu du pendu en devinant un mot.",
    /**
     * 
     * @param {Astroia} client 
     * @param {Message} message 
     * @param {string[]} args 
     */
    run: async (client, message, args, commandName) => {
    let pass = false;

    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) || 
        client.db.get(`owner_global_${message.author.id}`) === true || 
        client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true) {          pass = true;
    } else {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        pass = true;
      }
    }

if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

const words = [
        'maison', 'jardin', 'voiture', 'bureau', 'ecole', 'livre', 'table', 'chaise',
        'ordinateur', 'telephone', 'musique', 'cinema', 'restaurant', 'hopital', 'magasin',
        'police', 'pompier', 'docteur', 'professeur', 'etudiant', 'travail', 'vacances',
        'famille', 'amis', 'enfant', 'parent', 'frere', 'soeur', 'grand', 'petit',
        'rouge', 'bleu', 'vert', 'jaune', 'noir', 'blanc', 'orange', 'violet',
        'manger', 'boire', 'dormir', 'marcher', 'courir', 'jouer', 'chanter', 'danser',
        'lire', 'ecrire', 'dessiner', 'cuisiner', 'nettoyer', 'ranger', 'acheter', 'vendre',
        'soleil', 'lune', 'etoile', 'nuage', 'pluie', 'neige', 'vent', 'orage',
        'montagne', 'ocean', 'riviere', 'foret', 'desert', 'plage', 'ville', 'campagne'
];
        const word = words[Math.floor(Math.random() * words.length)].toLowerCase();
        let guessed = Array(word.length).fill('_');
        let attempts = 6;
        let guessedLetters = [];

        const hangmanStages = [
            '```\n  +---+\n  |   |\n      |\n      |\n      |\n      |\n=========```',
            '```\n  +---+\n  |   |\n  O   |\n      |\n      |\n      |\n=========```',
            '```\n  +---+\n  |   |\n  O   |\n  |   |\n      |\n      |\n=========```',
            '```\n  +---+\n  |   |\n  O   |\n /|   |\n      |\n      |\n=========```',
            '```\n  +---+\n  |   |\n  O   |\n /|\\  |\n      |\n      |\n=========```',
            '```\n  +---+\n  |   |\n  O   |\n /|\\  |\n /    |\n      |\n=========```',
            '```\n  +---+\n  |   |\n  O   |\n /|\\  |\n / \\  |\n      |\n=========```'
        ];

        const embed = new Discord.EmbedBuilder()
            .setColor(client.color || 0x00FF00)
            .setTitle('Jeu du Pendu')
            .setDescription(`${hangmanStages[0]}\n**Mot :** ${guessed.join(' ')}\n**Tentatives restantes :** ${attempts}\n**Lettres devinées :** ${guessedLetters.join(', ') || 'Aucune'}`)
            .setFooter(client.footer)
        const msg = await message.channel.send({ embeds: [embed] });

        const filter = m => m.author.id === message.author.id;
        const collector = message.channel.createMessageCollector({ filter, time: 60000 });

        collector.on('collect', async m => {
            const guess = m.content.toLowerCase();
            if (guessedLetters.includes(guess) || guessed.join('') === word) {
                await m.delete().catch(() => {});
                return;
            }

            if (guess.length === 1) {
                if (word.includes(guess)) {
                    for (let i = 0; i < word.length; i++) {
                        if (word[i] === guess) guessed[i] = guess;
                    }
                } else {
                    attempts--;
                    guessedLetters.push(guess);
                }
            } else if (guess === word) {
                guessed = word.split('');
            }

            embed.setDescription(`${hangmanStages[6 - attempts]}\n**Mot :** ${guessed.join(' ')}\n**Tentatives restantes :** ${attempts}\n**Lettres devinées :** ${guessedLetters.join(', ') || 'Aucune'}`);
            await msg.edit({ embeds: [embed] });
            await m.delete().catch(() => {});

            if (attempts <= 0) {
                embed.setDescription(`${hangmanStages[6]}\n**Perdu !** Le mot était : ${word}`);
                await msg.edit({ embeds: [embed] });
                collector.stop();
            } else if (!guessed.includes('_')) {
                embed.setDescription(`${hangmanStages[0]}\n**Gagné !** Le mot était : ${word}`);
                await msg.edit({ embeds: [embed] });
                collector.stop();
            }
        });

        collector.on('end', () => {
            if (!msg.deleted) message.channel.send('Le jeu du pendu est terminé. Merci d\'avoir joué !');
        });
    }
};