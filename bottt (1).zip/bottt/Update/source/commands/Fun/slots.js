const { EmbedBuilder, Colors, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    name: 'slots',
    description: "Permet de jouer à Slots avec un bouton",
    run: async (client, message, args, commandName) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) || 
        client.db.get(`owner_global_${message.author.id}`) === true || 
        client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true) {          pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}
                const symbols = ['🍒', '🍋', '🍊', '🍉', '🍇', '⭐', '💎'];

        const embed = new EmbedBuilder()
            .setTitle("🎰 Machine à Slots 🎰")
            .setDescription("Clique sur **Jouer** pour tenter ta chance !")
            .setColor(client.color)
            .setFooter(client.footer)
            .setTimestamp();

        const playButton = new ButtonBuilder()
            .setCustomId('play_slots')
            .setLabel('Jouer')
            .setStyle(ButtonStyle.Secondary);

        const row = new ActionRowBuilder().addComponents(playButton);

        const sentMessage = await message.channel.send({ embeds: [embed], components: [row] });

        const filter = i => i.isButton() && i.customId === 'play_slots' && i.user.id === message.author.id;

        const collector = sentMessage.createMessageComponentCollector({ filter, time: 60000 });

        collector.on('collect', async interaction => {
            // Tirage des symboles
            const slot1 = symbols[Math.floor(Math.random() * symbols.length)];
            const slot2 = symbols[Math.floor(Math.random() * symbols.length)];
            const slot3 = symbols[Math.floor(Math.random() * symbols.length)];

            const result = `${slot1} | ${slot2} | ${slot3}`;

            let messageResult = '';
            let color = Colors.Red;

            if (slot1 === slot2 && slot2 === slot3) {
                messageResult = "🎉 Jackpot ! Tu as gagné gros !";
                color = Colors.Green;
            } else if (slot1 === slot2 || slot2 === slot3 || slot1 === slot3) {
                messageResult = "👍 Bien joué ! Tu as gagné un petit prix.";
                color = Colors.Yellow;
            } else {
                messageResult = "😞 Dommage, retente ta chance !";
                color = Colors.Red;
            }

            const resultEmbed = new EmbedBuilder()
                .setTitle("🎰 Machine à Slots 🎰")
                .setDescription(result)
                .addFields({ name: "Résultat", value: messageResult })
                .setColor(color)
                .setFooter(client.footer)
                .setTimestamp();

            await interaction.update({ embeds: [resultEmbed], components: [] });

            collector.stop();
        });

        collector.on('end', async (_, reason) => {
            if (reason === 'time') {
                playButton.setDisabled(true);
                const disabledRow = new ActionRowBuilder().addComponents(playButton);
                await sentMessage.edit({ components: [disabledRow] });
            }
        });
    }
};
