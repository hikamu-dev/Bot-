const Discord = require('discord.js');

class Game2048 {
    constructor() {
        this.grid = [
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ];
        this.addRandom();
        this.addRandom();
    }

    addRandom() {
        let empty = [];
        for (let y = 0; y < 4; y++) {
            for (let x = 0; x < 4; x++) {
                if (this.grid[y][x] === 0) empty.push([y, x]);
            }
        }
        if (empty.length === 0) return false;
        let [y, x] = empty[Math.floor(Math.random() * empty.length)];
        this.grid[y][x] = Math.random() < 0.9 ? 2 : 4;
        return true;
    }

    toString() {
        return this.grid.map(row => row.map(n => n === 0 ? '⬜' : this.getEmojiForNumber(n)).join('')).join('\n');
    }

    getEmojiForNumber(n) {
        const map = {
            2: '2️⃣',
            4: '4️⃣',
            8: '8️⃣',
            16: '1️⃣6️⃣',
            32: '3️⃣2️⃣',
            64: '6️⃣4️⃣',
            128: '1️⃣2️⃣8️⃣',
            256: '2️⃣5️⃣6️⃣',
            512: '5️⃣1️⃣2️⃣',
            1024: '1️⃣0️⃣2️⃣4️⃣',
            2048: '2️⃣0️⃣4️⃣8️⃣',
        };
        return map[n] || '❓';
    }

    moveLeft() {
        let moved = false;
        for (let y = 0; y < 4; y++) {
            let row = this.grid[y].filter(n => n !== 0);
            for (let i = 0; i < row.length - 1; i++) {
                if (row[i] === row[i + 1]) {
                    row[i] *= 2;
                    row.splice(i + 1, 1);
                    moved = true;
                }
            }
            while (row.length < 4) row.push(0);
            if (!this.arrEqual(row, this.grid[y])) moved = true;
            this.grid[y] = row;
        }
        return moved;
    }

    moveRight() {
        this.reflectGridHorizontally();
        let moved = this.moveLeft();
        this.reflectGridHorizontally();
        return moved;
    }

    moveUp() {
        this.transposeGrid();
        let moved = this.moveLeft();
        this.transposeGrid();
        return moved;
    }

    moveDown() {
        this.transposeGrid();
        let moved = this.moveRight();
        this.transposeGrid();
        return moved;
    }

    reflectGridHorizontally() {
        for (let y = 0; y < 4; y++) {
            this.grid[y].reverse();
        }
    }

    transposeGrid() {
        let newGrid = [
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ];
        for (let y = 0; y < 4; y++) {
            for (let x = 0; x < 4; x++) {
                newGrid[x][y] = this.grid[y][x];
            }
        }
        this.grid = newGrid;
    }

    arrEqual(a, b) {
        for (let i = 0; i < a.length; i++) {
            if (a[i] !== b[i]) return false;
        }
        return true;
    }

    isGameOver() {
        // Check for any zero
        for (let y = 0; y < 4; y++) {
            for (let x = 0; x < 4; x++) {
                if (this.grid[y][x] === 0) return false;
            }
        }
        // Check for possible merges
        for (let y = 0; y < 4; y++) {
            for (let x = 0; x < 4; x++) {
                if (x < 3 && this.grid[y][x] === this.grid[y][x+1]) return false;
                if (y < 3 && this.grid[y][x] === this.grid[y+1][x]) return false;
            }
        }
        return true;
    }
}

module.exports = {
    name: '2048',
    description: 'Joue à 2048 dans Discord',
    run: async (client, message, args, commandName) => {
           let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) || 
        client.db.get(`owner_global_${message.author.id}`) === true || 
        client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true) {          pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}
           const game = new Game2048();

        const directions = {
            '⬅️': 'left',
            '➡️': 'right',
            '⬆️': 'up',
            '⬇️': 'down'
        };

        const filter = (reaction, user) => Object.keys(directions).includes(reaction.emoji.name) && user.id === message.author.id;

        const embed = new Discord.EmbedBuilder()
            .setTitle('2048 - Utilise les réactions pour jouer !')
            .setDescription(game.toString())
            .setColor(client.color)
            .setFooter(client.footer);

        const gameMessage = await message.channel.send({ embeds: [embed] });

        for (const emoji of Object.keys(directions)) {
            await gameMessage.react(emoji);
        }

        const collector = gameMessage.createReactionCollector({ filter, time: 120000 });

        collector.on('collect', async (reaction, user) => {
            let moved = false;
            switch(directions[reaction.emoji.name]) {
                case 'left': moved = game.moveLeft(); break;
                case 'right': moved = game.moveRight(); break;
                case 'up': moved = game.moveUp(); break;
                case 'down': moved = game.moveDown(); break;
            }
            if (moved) {
                game.addRandom();
                embed.setDescription(game.toString());
                await gameMessage.edit({ embeds: [embed] });
                if (game.isGameOver()) {
                    embed.setTitle('Fin du jeu !');
                    await gameMessage.edit({ embeds: [embed] });
                    collector.stop();
                }
            }
            await reaction.users.remove(user.id);
        });

        collector.on('end', () => {
            gameMessage.reactions.removeAll().catch(() => {});
        });
    }
};
