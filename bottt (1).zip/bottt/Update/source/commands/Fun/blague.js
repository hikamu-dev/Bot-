const Discord = require('discord.js');

module.exports = {
    name: 'blague',
    description: "Affiche une blague aléatoire.",
    /**
     * 
     * @param {Astroia} client 
     * @param {Message} message 
     * @param {string[]} args 
     */
    run: async (client, message, args, commandName) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) || 
        client.db.get(`owner_global_${message.author.id}`) === true || 
        client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true) {          pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        // Liste de blagues aléatoires
        const blagues = [
            "Pourquoi les oiseaux ne se perdent jamais ? Parce qu'ils ont un tweet de navigation !",
            "Qu'est-ce qui est jaune et qui attend ? Jonathan !",
            "Pourquoi les plongeurs divorcent souvent ? Parce qu'ils se noient dans leurs problèmes !",
            "Comment appelle-t-on un fromage qui n'est pas à toi ? Un fromage 'nacho' !",
            "Pourquoi les mathématiciens ne boivent jamais de thé ? Parce qu'ils ne savent pas sortir la tasse de l'équation !",
            "Qu'est-ce qu'une imprimante a dit à l'autre ? Tu veux qu'on imprime une feuille ensemble ?",
            "Pourquoi le livre de maths était triste ? Parce qu'il avait trop de problèmes !"
        ];

        // Sélection aléatoire d'une blague
        const randomIndex = Math.floor(Math.random() * blagues.length);
        const blague = blagues[randomIndex];

        // Réponse avec la blague
        message.reply(`Voici une blague pour toi : ${blague}`);
    }
};