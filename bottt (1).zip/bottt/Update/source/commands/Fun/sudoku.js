const Discord = require('discord.js');

module.exports = {
    name: 'sudoku',
    description: "Joue au jeu du sudoku en devinant les chiffres.",
    /**
     * 
     * @param {Astroia} client 
     * @param {Message} message 
     * @param {string[]} args 
     */
    run: async (client, message, args, commandName) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) || 
        client.db.get(`owner_global_${message.author.id}`) === true || 
        client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true) {          pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        // Générer une grille 4x4 simple
        let grid = Array(4).fill().map(() => Array(4).fill(0));
        const solution = grid.map(row => [...row]);
        const numbers = [1, 2, 3, 4];

        // Remplir la grille avec une solution de base
        for (let i = 0; i < 4; i++) {
            for (let j = 0; j < 4; j++) {
                solution[i][j] = numbers[(i * 4 + j) % 4 + 1];
            }
        }

        // Retirer quelques chiffres pour créer le puzzle
        const positions = [[0, 0], [1, 1], [2, 2], [3, 3]];
        for (let [i, j] of positions.sort(() => Math.random() - 0.5).slice(0, 5)) {
            grid[i][j] = 0;
        }

        let userGrid = grid.map(row => [...row]);
        let attempts = 3;

        const embed = new Discord.EmbedBuilder()
            .setColor(client.color || 0x00FF00)
            .setTitle('Jeu du Sudoku (4x4)')
            .setDescription(
                `**Grille :**\n\`\`\`${userGrid.map(row => row.join(' ')).join('\n')}\`\`\`\n` +
                `**Instructions :** Envoie une position (ex: 1 1 2) pour placer le chiffre 2 à la ligne 1, colonne 1.\n` +
                `**Tentatives restantes :** ${attempts}`
            )
            .setFooter({ text: `Demandé par ${message.author.tag}`, iconURL: message.author.displayAvatarURL() });

        const msg = await message.channel.send({ embeds: [embed] });

        const filter = m => m.author.id === message.author.id;
        const collector = message.channel.createMessageCollector({ filter, time: 120000 });

        collector.on('collect', async m => {
            await m.delete().catch(() => {});
            const input = m.content.split(' ');
            if (input.length !== 3 || input.some(x => isNaN(Number(x)))) {
                attempts = 0; // Forcer la perte si l'entrée est invalide (lettres ou mauvais format)
            }

            const [row, col, num] = input.map(Number);
            if (row < 0 || row >= 4 || col < 0 || col >= 4 || num < 1 || num > 4) {
                attempts = 0; // Forcer la perte si les indices ou chiffres sont hors plage
            }

            if (userGrid[row][col] === 0) {
                if (solution[row][col] === num) {
                    userGrid[row][col] = num;
                    if (!userGrid.some(row => row.includes(0))) {
                        embed.setDescription(
                            `**Grille :**\n\`\`\`${userGrid.map(row => row.join(' ')).join('\n')}\`\`\`\n` +
                            `**Gagné ! Tu as complété le sudoku !**`
                        );
                        await msg.edit({ embeds: [embed] });
                        collector.stop();
                        return;
                    }
                } else {
                    attempts--;
                    if (attempts <= 0) {
                        embed.setDescription(
                            `**Grille :**\n\`\`\`${userGrid.map(row => row.join(' ')).join('\n')}\`\`\`\n` +
                            `**Perdu !** La solution était :\n\`\`\`${solution.map(row => row.join(' ')).join('\n')}\`\`\``
                        );
                        await msg.edit({ embeds: [embed] });
                        collector.stop();
                        return;
                    }
                }
            }

            embed.setDescription(
                `**Grille :**\n\`\`\`${userGrid.map(row => row.join(' ')).join('\n')}\`\`\`\n` +
                `**Instructions :** Envoie une position (ex: 1 1 2).\n` +
                `**Tentatives restantes :** ${attempts}`
            );
            await msg.edit({ embeds: [embed] });
        });

        collector.on('end', () => {
            if (!msg.deleted) message.channel.send('Temps écoulé ! La partie est terminée.');
        });
    }
};