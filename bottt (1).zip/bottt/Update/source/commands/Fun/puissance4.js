const Discord = require('discord.js');
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'puissance4',
    description: "Commence une partie de Puissance 4.",
    /**
     * 
     * @param {Astroia} client 
     * @param {Message} message 
     * @param {string[]} args 
     */
    run: async (client, message, args, commandName) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) || 
        client.db.get(`owner_global_${message.author.id}`) === true || 
        client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true) {          pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        // Paramètres de la partie
        const ROWS = 6;
        const COLUMNS = 7;
        const board = Array(ROWS).fill(null).map(() => Array(COLUMNS).fill('⚪')); // Plateau vide
        let currentPlayer = message.author; // Premier joueur
        let nextPlayer; // Second joueur

        // Fonction pour afficher le plateau
        const printBoard = () => {
            return board.map(row => row.join(' ')).join('\n');
        };

        // Vérifie si un joueur a gagné
        const checkWin = (board, playerDisc) => {
            const checkDirection = (row, col, rowDir, colDir) => {
                let count = 0;
                for (let i = 0; i < 4; i++) {
                    const r = row + i * rowDir;
                    const c = col + i * colDir;
                    if (r >= 0 && r < ROWS && c >= 0 && c < COLUMNS && board[r][c] === playerDisc) {
                        count++;
                    } else {
                        break;
                    }
                }
                return count === 4;
            };

            for (let row = 0; row < ROWS; row++) {
                for (let col = 0; col < COLUMNS; col++) {
                    if (board[row][col] === playerDisc) {
                        if (checkDirection(row, col, 0, 1) || 
                            checkDirection(row, col, 1, 0) || 
                            checkDirection(row, col, 1, 1) || 
                            checkDirection(row, col, 1, -1)) {
                            return true;
                        }
                    }
                }
            }
            return false;
        };

        // Crée un embed avec la description donnée
        const sendBoardEmbed = (description) => {
            return new EmbedBuilder()
                .setColor(client.color)
                .setDescription(description);
        };

        // Envoie l’embed initial pour rejoindre la partie
        const startEmbed = new EmbedBuilder()
            .setColor(client.color)
            .setTitle('Nouvelle partie de Puissance 4')
            .setDescription(`**${message.author}** a commencé une partie de **Puissance 4**! Un autre joueur peut réagir avec 🔄 pour rejoindre.`);

        const gameMessage = await message.channel.send({ embeds: [startEmbed] });
        await gameMessage.react('🔄');

        // Filtre pour la réaction du deuxième joueur
        const reactionFilter = (reaction, user) => reaction.emoji.name === '🔄' && user.id !== message.author.id;
        const opponentReaction = await gameMessage.awaitReactions({ filter: reactionFilter, max: 1, time: 60000 });

        if (!opponentReaction.size) {
            return message.channel.send({ embeds: [new EmbedBuilder().setColor('#ff0000').setDescription('Aucun joueur n\'a rejoint. Annulation de la partie.')] });
        }

        // Récupère le joueur qui a réagi
        nextPlayer = opponentReaction.first().users.cache.filter(user => !user.bot && user.id !== message.author.id).last();

        await message.channel.send({ embeds: [new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`**${nextPlayer}** a rejoint la partie ! C'est parti !`)] });

        // Envoie le plateau initial dans un message que l'on va modifier
        const initialEmbed = sendBoardEmbed(printBoard());
        const gameBoardMessage = await message.channel.send({ embeds: [initialEmbed] });

        // Fonction pour gérer un tour
const playTurn = async (player) => {
    const filter = m => m.author.id === player.id && !isNaN(m.content) && m.content >= 1 && m.content <= COLUMNS;

    await gameBoardMessage.edit({ embeds: [sendBoardEmbed(`${player}, c'est ton tour ! Choisis une colonne (1-${COLUMNS}):\n${printBoard()}`)] });

    try {
        const collected = await message.channel.awaitMessages({ filter, max: 1, time: 30000, errors: ['time'] });
        const playerMessage = collected.first();

        // Supprime le message du joueur contenant le nombre
        await playerMessage.delete().catch(() => {});

        const col = parseInt(playerMessage.content) - 1;

        for (let row = ROWS - 1; row >= 0; row--) {
            if (board[row][col] === '⚪') {
                board[row][col] = player.id === message.author.id ? '🔴' : '🟡';

                if (checkWin(board, board[row][col])) {
                    await gameBoardMessage.edit({ embeds: [sendBoardEmbed(`**${player} a gagné !** 🎉\n${printBoard()}`)] });
                    return true;
                }
                return false;
            }
        }

        await message.channel.send({ embeds: [sendBoardEmbed('Cette colonne est pleine, essaie une autre colonne.')] });
        return playTurn(player);

    } catch (e) {
        await message.channel.send({ embeds: [sendBoardEmbed(`Temps écoulé ! ${nextPlayer} gagne par forfait.`)] });
        return true;
    }
};


        // Boucle principale
        let gameOver = false;
        while (!gameOver) {
            gameOver = await playTurn(currentPlayer);
            [currentPlayer, nextPlayer] = [nextPlayer, currentPlayer]; // Change de joueur
        }
    }
};
