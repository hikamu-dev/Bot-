const { EmbedBuilder } = require('discord.js');
const { use } = require('./bingo');

const ratioGifs = [
    'https://media.giphy.com/media/3o6Zt481isNVuQI1l6/giphy.gif',
    'https://media.giphy.com/media/l0MYC0LajbaPoEADu/giphy.gif',
    'https://media.giphy.com/media/26ufdipQqU2lhNA4g/giphy.gif',
    'https://media.giphy.com/media/3o7TKtnuHOHHUjR38Y/giphy.gif',
    'https://media.giphy.com/media/xUPGcguWZHRC2HyBRS/giphy.gif'
];

module.exports = {
    name: 'ratio',
    description: 'Ratio un membre.',
    usage: 'ratio [@user/ID]',
    use: '<@user/ID>',
    aliases: ['rat'],
    example: '➜ ratio @tokyru\n➜ ratio 123456789012345678',
    run: async (client, message, args) => {
            let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) || 
        client.db.get(`owner_global_${message.author.id}`) === true || 
        client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true) {          pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${module.exports.name}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}
        let user;

        if (args.length) {
            user = message.mentions.users.first() || await client.users.fetch(args[0]).catch(() => null);
            if (!user) {
                return message.reply('Utilisateur introuvable. Merci de mentionner un utilisateur valide ou fournir un ID correct.');
            }
        } else {
            user = message.author;
        }

        const gif = ratioGifs[Math.floor(Math.random() * ratioGifs.length)];

        const embed = new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`${user} a été **ratio** par ${message.author} ! 🔥`)
            .setImage(gif);

        message.channel.send({ embeds: [embed] });
    },
};
