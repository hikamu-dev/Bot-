const Discord = require("discord.js");

module.exports = {
    name: "de",
    description: "Lance un dé (1-6). Invite un joueur pour un duel !",
    usage: "de [@user]",
    run: async (client, message, args, commandName) => {
        const guildId = message.guild.id;
        const whitelistDB = client.db.get(`wl.${guildId}`) || [];

        // === BYPASS (staff / buyers / owner / wl / owner serveur) ===
        const isBypass = (
            client.staff.includes(message.author.id) ||
            client.config.buyers.includes(message.author.id) ||
            client.db.get(`owner_${message.author.id}`) === true ||
            client.db.get(`owner_global_${message.author.id}`) === true ||
            whitelistDB.includes(message.author.id) ||
            message.guild.ownerId === message.author.id
        );

        // === PERM SYSTEM ===
        let pass = false;
        if (isBypass) pass = true;
        else {
            const commandPerms = client.db.get(`command_permissions.${guildId}.${commandName}`) || [];
            if (commandPerms.length > 0) {
                const userPerms = client.db.get(`permissions.${guildId}`) || {};
                const userRoles = message.member.roles.cache.map(r => r.id);
                pass = commandPerms.some(perm => userPerms[perm]?.some(roleId => userRoles.includes(roleId)));
            } else if (client.db.get(`perm_${commandName}.${guildId}`) === "public") {
                pass = true;
            }
        }

        if (!pass) {
            if (client.noperm?.trim()) {
                const sentMessage = await message.channel.send(client.noperm);
                const delayTime = client.db.get(`noperm_delay_${guildId}`) || 0;
                if (delayTime > 0) setTimeout(() => sentMessage.delete().catch(() => {}), delayTime * 1000);
            }
            return;
        }

        // === Jeu du dé ===
        const opponent = message.mentions.users.first();

        if (!opponent) {
            // Mode solo
            const roll = Math.floor(Math.random() * 6) + 1;
            return message.reply(`🎲 Tu as lancé un dé et obtenu **${roll}** !`);
        }

        if (opponent.bot) return message.reply("❌ Tu ne peux pas jouer contre un bot.");
        if (opponent.id === message.author.id) return message.reply("❌ Tu ne peux pas jouer contre toi-même.");

        const embed = new Discord.EmbedBuilder()
            .setColor(client.color || "#2f3136")
            .setTitle("🎲 Duel de Dé")
            .setDescription(`${opponent}, acceptes-tu le duel lancé par ${message.author} ?\nRéagis avec ✅ pour accepter.`);

        const duelMsg = await message.channel.send({ embeds: [embed] });
        await duelMsg.react("✅");

        const filter = (reaction, user) => reaction.emoji.name === "✅" && user.id === opponent.id;
        const collector = duelMsg.createReactionCollector({ filter, time: 15000, max: 1 });

        collector.on("collect", async () => {
            const roll1 = Math.floor(Math.random() * 6) + 1;
            const roll2 = Math.floor(Math.random() * 6) + 1;

            let result;
            if (roll1 > roll2) result = `🏆 ${message.author} gagne avec **${roll1}** contre **${roll2}** !`;
            else if (roll2 > roll1) result = `🏆 ${opponent} gagne avec **${roll2}** contre **${roll1}** !`;
            else result = `🤝 Égalité ! Les deux ont fait **${roll1}**.`;

            const resultEmbed = new Discord.EmbedBuilder()
                .setColor(client.color || "#5865F2")
                .setTitle("🎲 Résultat du Duel")
                .setDescription(result);

            await duelMsg.edit({ embeds: [resultEmbed] });
        });

        collector.on("end", c => {
            if (c.size === 0) {
                embed.setDescription(`⏱️ ${opponent} n'a pas accepté le duel à temps.`);
                duelMsg.edit({ embeds: [embed] }).catch(() => {});
            }
        });
    }
};
