const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'rate',
    description: 'Note quelque chose sur 10.',
    use: '<texte>',
    aliases: ['note', 'noter'],
    example: '➜ rate Bonjour le monde',
    run: async (client, message, args, commandName) => {
        let pass = false;

        if (client.staff.includes(message.author.id) || 
            client.config.buyers.includes(message.author.id) || 
        client.db.get(`owner_global_${message.author.id}`) === true || 
        client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true) {                pass = true;
        } else {
            const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
            if (commandPerms.length > 0) {
                const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                const userRoles = message.member.roles.cache.map(role => role.id);
                pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
            } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                pass = true;
            }
        }

if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        if (!args.length) {
            return message.reply('Merci de fournir un texte à noter. Usage : `rate <texte>`');
        }

        const mentionedUser = message.mentions.users.first();
        const cleanArgs = args.filter(arg => !arg.startsWith('<@') && !arg.startsWith('<@!'));
        const textToRate = cleanArgs.join(' ').trim();

        if (!textToRate) {
            return message.reply('Merci de fournir un texte valide à noter après la mention.');
        }

        const note = (Math.random() * 10).toFixed(1);

        const embed = new EmbedBuilder()
            .setColor(client.color)
            .setTitle('Note sur 10')
            .setDescription(
                mentionedUser
                    ? `Je note **${mentionedUser.username}** à **${note}/10**`
                    : `Je note **${textToRate}** à **${note}/10**`
            )
            .setFooter(client.footer);

        message.channel.send({ embeds: [embed] });
    },
};
