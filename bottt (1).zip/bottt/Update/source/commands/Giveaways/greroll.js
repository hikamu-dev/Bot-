const Discord = require('discord.js');
const { EmbedBuilder } = require('discord.js');
const { example } = require('./gend');

module.exports = {
    name: 'greroll',
    aliases: ["giveawayreroll"],
    description: 'Permet de re-tirer au sort des gagnants pour un giveaway terminé.',
    use: "<code> [nombre]",
    usage: "greroll <code> [nombre]",
    example: "➜ greroll ABC123 2\n➜ greroll ABC123",
    run: async (client, message, args, commandName) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
        client.db.get(`owner_global_${message.author.id}`) === true || 
client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        if (!args[0]) {
            return message.reply({ content: "❌ Veuillez fournir le code du giveaway (ex: `greroll ABC123`)." });
        }

        const giveawayCode = args[0];
        const giveawayKey = `giveaway_${message.guild.id}_${giveawayCode}`;
        let giveaway = client.db.get(giveawayKey);
        
        if (!giveaway) {
            const allKeys = client.db.all().filter(k => k.ID.startsWith(`giveaway_${message.guild.id}_`));
            const foundKey = allKeys.find(k => k.ID.toLowerCase() === giveawayKey.toLowerCase());
            
            if (foundKey) {
                giveaway = client.db.get(foundKey.ID);
            } else {
                return message.reply({ content: `❌ Aucun giveaway trouvé avec le code \`${giveawayCode}\`.` });
            }
        }

        if (!giveaway.ended) {
            return message.reply({ content: "❌ Ce giveaway n'est pas encore terminé. Utilisez `gend` pour le terminer." });
        }

        const giveawayChannel = message.guild.channels.cache.get(giveaway.channel);
        if (!giveawayChannel) {
            return message.reply({ content: "❌ Le salon du giveaway n'existe plus." });
        }

        let giveawayMessage;
        try {
            giveawayMessage = await giveawayChannel.messages.fetch(giveaway.messageid);
        } catch (e) {
            return message.reply({ content: "❌ Le message du giveaway n'existe plus." });
        }

        const winnerCount = parseInt(args[1]) || giveaway.gagnant || 1;

        let participants = giveaway.participant || [];
        
        if (giveaway.vocal) {
            participants = participants.filter(userId => {
                const member = message.guild.members.cache.get(userId);
                return member?.voice?.channel;
            });
        }

        const previousWinners = giveaway.winners || [];
        participants = participants.filter(userId => !previousWinners.includes(userId));

        let newWinners = [];
        if (giveaway.predef?.length > 0) {
            const remainingPredef = giveaway.predef.filter(id => !previousWinners.includes(id));
            newWinners = remainingPredef.slice(0, winnerCount);
        } else if (participants.length > 0) {
            for (let i = 0; i < Math.min(winnerCount, participants.length); i++) {
                const randomIndex = Math.floor(Math.random() * participants.length);
                newWinners.push(participants[randomIndex]);
                participants.splice(randomIndex, 1);
            }
        }

        const allWinners = [...previousWinners, ...newWinners];
        
        const updatedEmbed = new EmbedBuilder()
            .setTitle("🎉 Giveaway Terminé (Re-tirage)")
            .setDescription(
                `**Prix:** \`${giveaway.prix}\`\n` +
                `**Gagnants:** ${allWinners.length > 0 ? allWinners.map(w => `<@${w}>`).join(', ') : "Aucun participant valide"}\n` +
                `**Lancée par:** <@${giveaway.host}>\n` +
                `**Code:** \`${giveawayCode}\`\n` +
                `**Participants:** ${giveaway.participant?.length || 0}`
            )
            .setColor(client.color)
            .setFooter(client.footer)
            .setTimestamp();

        // Édition du message original
        await giveawayMessage.edit({ embeds: [updatedEmbed] })
            .catch(e => console.error("Erreur lors de l'édition du message:", e));

        // Annonce des nouveaux gagnants
        if (newWinners.length > 0) {
            await giveawayChannel.send({
                content: `🎉 Nouveaux gagnants du giveaway **${giveaway.prix}** : ${newWinners.map(w => `<@${w}>`).join(', ')} !`
            }).catch(e => console.error("Erreur lors de l'envoi du message:", e));
        } else {
            await giveawayChannel.send({
                content: `❌ Aucun nouveau gagnant n'a pu être sélectionné pour le giveaway **${giveaway.prix}**.`
            }).catch(e => console.error("Erreur lors de l'envoi du message:", e));
        }

        client.db.set(giveawayKey, { 
            ...giveaway, 
            winners: allWinners,
            rerolledAt: Date.now()
        });

    }
};