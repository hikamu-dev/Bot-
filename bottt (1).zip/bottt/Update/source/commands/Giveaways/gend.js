const Discord = require('discord.js');
const { EmbedBuilder, ButtonStyle, ActionRowBuilder, ButtonBuilder } = require('discord.js');
const { example } = require('../Owner/changelimit');

module.exports = {
    name: 'gend',
    aliases: ["giveawayend"],
    description: 'Permet de terminer un giveaway existant.',
    use: "<code>",
    usage: "gend <code>",
    example: "➜ gend ABC123",
    run: async (client, message, args, commandName) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
        client.db.get(`owner_global_${message.author.id}`) === true || 
client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        if (!args[0]) {
            return message.reply({ content: "❌ Veuillez fournir le code du giveaway à terminer (ex: `gend ABC123`)." });
        }

        const giveawayCode = args[0]; // Ne pas convertir en majuscules
        const giveawayKey = `giveaway_${message.guild.id}_${giveawayCode}`;
        let giveaway = client.db.get(giveawayKey);
        
        if (!giveaway) {
            const allKeys = client.db.all().filter(k => k.ID.startsWith(`giveaway_${message.guild.id}_`));
            const foundKey = allKeys.find(k => k.ID.toLowerCase() === giveawayKey.toLowerCase());
            
            if (foundKey) {
                giveaway = client.db.get(foundKey.ID);
            } else {
                return message.reply({ content: `❌ Aucun giveaway trouvé avec le code \`${giveawayCode}\`.` });
            }
        }

        if (giveaway.ended) {
            return message.reply({ content: "❌ Ce giveaway est déjà terminé." });
        }

        const giveawayChannel = message.guild.channels.cache.get(giveaway.channel);
        if (!giveawayChannel) {
            client.db.delete(giveawayKey);
            return message.reply({ content: "❌ Le salon du giveaway n'existe plus. Le giveaway a été supprimé." });
        }

        let giveawayMessage;
        try {
            giveawayMessage = await giveawayChannel.messages.fetch(giveaway.messageid);
        } catch (e) {
            client.db.delete(giveawayKey);
            return message.reply({ content: "❌ Le message du giveaway n'existe plus. Le giveaway a été supprimé." });
        }

        let participants = giveaway.participant || [];
        if (giveaway.vocal) {
            participants = participants.filter(userId => {
                const member = message.guild.members.cache.get(userId);
                return member?.voice?.channel;
            });
        }

        let winners = [];
        if (giveaway.predef?.length > 0) {
            winners = giveaway.predef.slice(0, giveaway.gagnant);
        } else if (participants.length > 0) {
            for (let i = 0; i < Math.min(giveaway.gagnant, participants.length); i++) {
                const randomIndex = Math.floor(Math.random() * participants.length);
                winners.push(participants[randomIndex]);
                participants.splice(randomIndex, 1);
            }
        }

        const participantsCount = giveaway.participant?.length || 0;
        const endEmbed = new EmbedBuilder()
            .setTitle("🎉 Giveaway Terminé")
            .setDescription(
                `**Prix:** \`${giveaway.prix}\`\n` +
                `**Gagnants:** ${winners.length > 0 ? winners.map(w => `<@${w}>`).join(', ') : "Aucun participant valide"}\n` +
                `**Lancée par:** <@${giveaway.host}>\n` +
                `**Code:** \`${giveawayCode}\`\n`
            )
            .setColor(client.color)
            .setFooter(client.footer)
            .setTimestamp();

        const disabledRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId(`giveaway_entry_${giveawayCode}`)
                .setEmoji(giveaway.emoji || "🎉")
                .setStyle(ButtonStyle.Primary)
                .setDisabled(true),
            new ButtonBuilder()
                .setCustomId(`giveaway_list_${giveawayCode}`)
                .setLabel("Participants")
                .setStyle(ButtonStyle.Secondary)
                .setDisabled(true)
        );

        await giveawayMessage.edit({ 
            embeds: [endEmbed], 
            components: [disabledRow] 
        }).catch(e => console.error("Erreur lors de l'édition du message:", e));

        if (winners.length > 0) {
            await giveawayChannel.send({
                content: `🎉 Félicitations ${winners.map(w => `<@${w}>`).join(', ')} ! Vous avez gagné **${giveaway.prix}** !`
            }).catch(e => console.error("Erreur lors de l'envoi du message de victoire:", e));
        } else {
            await giveawayChannel.send({
                content: `❌ Aucun gagnant n'a pu être sélectionné pour le giveaway **${giveaway.prix}**.\nCode: \`${giveawayCode}\``
            }).catch(e => console.error("Erreur lors de l'envoi du message d'absence de gagnant:", e));
        }

        client.db.set(giveawayKey, { 
            ...giveaway, 
            ended: true,
            winners: winners,
            endedAt: Date.now()
        });

        await message.reply({ 
            content: `✅ Giveaway \`${giveawayCode}\` terminé avec succès!` 
        });
    }
};