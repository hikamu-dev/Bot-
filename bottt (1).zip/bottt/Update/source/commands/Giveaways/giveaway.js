const ms = require('ms');
const Discord = require('discord.js');
const { StringSelectMenuBuilder, ActionRowBuilder, EmbedBuilder, ChannelSelectMenuBuilder, UserSelectMenuBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    name: 'giveaway',
    aliases: ["gw"],
    description: 'Permet de configurer un giveaway interactif.',
    usage: "giveaway",
    run: async (client, message, args, commandName) => {
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
        client.db.get(`owner_global_${message.author.id}`) === true || 
client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        const originalMsg = await message.channel.send({ embeds: [new EmbedBuilder().setDescription("🎉 Chargement du panneau de configuration...").setColor(client.color)] });

        async function updateEmbed() {
            const db = client.db.get(`setgiveaway_${message.guild.id}`) || client.db.set(`setgiveaway_${message.guild.id}`, {
                prix: 'un prix',
                gagnant: 1,
                temps: null,
                channel: message.channel.id,
                vocal: false,
                predef: null,
                participant: [],
                emoji: '🎉',
                buttonColor: 'Primary', // Ajout de la couleur par défaut
                requiredInvites: 0 // Nouvelle propriété pour les invitations requises
            });

            const embed = new EmbedBuilder()
                .setTitle("🎁 Configuration du Giveaway")
                .setColor(client.color)
                .setFooter(client.footer)
                .setDescription("**Personnalisez votre giveaway avec les options ci-dessous !**")
                .addFields(
                    { name: "🎁 Prix", value: `\`${db.prix}\``, inline: true },
                    { name: "👥 Gagnants", value: `\`${db.gagnant}\``, inline: true },
                    { name: "⏳ Durée", value: `\`${db.temps ? formatTimeLeft(db.temps) : "Non défini"}\``, inline: true },
                    { name: "📢 Salon", value: `${message.guild.channels.cache.get(db.channel) || "\`Non défini\`"}`, inline: true },
                    { name: "🎨 Couleur du bouton", value: `\`${db.buttonColor}\``, inline: true }, // Ajout du champ pour la couleur
                    { name: "🎙️ Vocal requis", value: `${db.vocal ? "\`✅ Activé\`" : "\`❌ Désactivé\`"}`, inline: true },
                    { name: "✨ Emoji", value: `${db.emoji}`, inline: true },
                    { name: "📧 Invitations requises", value: `\`${db.requiredInvites}\``, inline: true }, // Nouveau champ
                    { 
                        name: "🏆 Gagnants prédéfinis", 
                        value: db.predef?.length > 0 
                            ? `\`\`\`yml\n${(await Promise.all(db.predef.map(async id => (await client.users.fetch(id)).username))).join(', ')}\`\`\`` 
                            : "\`Aucun\`" 
                    }
                );

            const selectMenu = new StringSelectMenuBuilder()
                .setCustomId(`gw_setup_${message.id}`)
                .setPlaceholder("Choisir une option à configurer...")
                .setMinValues(1)
                .setMaxValues(1)
                .addOptions([
                    { label: "Prix", value: `prix_${message.id}`, emoji: "🎁" },
                    { label: "Nombre de gagnants", value: `gagnant_${message.id}`, emoji: "👥" },
                    { label: "Durée", value: `temps_${message.id}`, emoji: "⏳" },
                    { label: "Salon", value: `salon_${message.id}`, emoji: "📢" },
                    { label: "Couleur du bouton", value: `buttonColor_${message.id}`, emoji: "🎨" }, // Ajout de l'option dans le menu
                    { label: "Vocal requis", value: `vocal_${message.id}`, emoji: "🎙️" },
                    { label: "Emoji", value: `emoji_${message.id}`, emoji: "✨" },
                    { label: "Gagnants prédéfinis", value: `gagnantpredef_${message.id}`, emoji: "🏆" },
                    { label: "Invitations requises", value: `invites_${message.id}`, emoji: "📧" } // Nouvelle option
                ]);

            const buttonReset = new Discord.ButtonBuilder()
                .setCustomId(`gw_setup_reset_${message.id}`)
                .setLabel("Réinitialiser")
                .setEmoji("⚠️")
                .setStyle(Discord.ButtonStyle.Danger);

            const buttonStart = new Discord.ButtonBuilder()
                .setCustomId(`gw_setup_start_${message.id}`)
                .setLabel("Lancer")
                .setEmoji("✅")
                .setStyle(Discord.ButtonStyle.Success);

            const rowMenu = new ActionRowBuilder().addComponents(selectMenu);
            const rowButtons = new ActionRowBuilder().addComponents(buttonStart, buttonReset);

            await originalMsg.edit({ embeds: [embed], components: [rowMenu, rowButtons], content: null });
        }

        await updateEmbed();

        const collector = message.channel.createMessageComponentCollector({ filter: m => m.user.id === message.author.id, time: ms("2m") });

        collector.on("collect", async (i) => {
            const db = client.db.get(`setgiveaway_${message.guild.id}`);
            if (!i.deferred) await i.deferUpdate().catch(() => false);
        
            if (i.isStringSelectMenu()) {
                const value = i.values[0];
        
                if (value === `salon_${message.id}`) {
                    const channelRow = new ActionRowBuilder().addComponents(
                        new ChannelSelectMenuBuilder()
                            .setCustomId(`gw_setup_salon_${message.id}`)
                            .setPlaceholder("Sélectionner un salon...")
                            .setMinValues(1)
                            .setMaxValues(1)
                            .setChannelTypes([Discord.ChannelType.GuildText])
                    );
                    await i.editReply({ content: "📢 Choisissez le salon du giveaway :", components: [channelRow] });
                } else if (value === `prix_${message.id}`) {
                    try {
                        const prompt = await i.followUp({ content: "🎁 Quel sera le prix du giveaway ? (ex: Nitro Boost)", ephemeral: true });
                        const collected = await message.channel.awaitMessages({ filter: m => m.author.id === message.author.id, max: 1, time: ms("1m") });
                        if (collected.size > 0) {
                            db.prix = collected.first().content.trim();
                            client.db.set(`setgiveaway_${message.guild.id}`, db);
                            await updateEmbed();
                            await prompt.delete().catch(() => false);
                            await collected.first().delete().catch(() => false);
                        }
                    } catch (error) {
                        console.error(`Error handling prix interaction: ${error}`);
                    }
                    await i.editReply({ embeds: originalMsg.embeds, components: originalMsg.components, content: null }).catch(console.error);
                } else if (value === `gagnant_${message.id}`) {
                    const prompt = await i.followUp({ content: "👥 Combien de gagnants ? (1-25)", ephemeral: true });
                    const collected = await message.channel.awaitMessages({ filter: m => m.author.id === message.author.id, max: 1, time: ms("1m") });
                    if (collected.size > 0) {
                        const winners = parseInteger(collected.first().content.trim());
                        if (winners && winners >= 1 && winners <= 25) {
                            db.gagnant = winners;
                            client.db.set(`setgiveaway_${message.guild.id}`, db);
                            await updateEmbed();
                        } else {
                            await message.channel.send("❌ Nombre invalide (doit être entre 1 et 25).").then(m => setTimeout(() => m.delete(), 3000));
                        }
                        prompt.delete().catch(() => false);
                        collected.first().delete().catch(() => false);
                    }
                    await i.editReply({ embeds: originalMsg.embeds, components: originalMsg.components, content: null });
                } else if (value === `temps_${message.id}`) {
                    const prompt = await i.followUp({ content: "⏳ Quelle sera la durée ? (ex: 5d)", ephemeral: true });
                    const collected = await message.channel.awaitMessages({ filter: m => m.author.id === message.author.id, max: 1, time: ms("1m") });
                    if (collected.size > 0) {
                        const time = parseTime(collected.first().content.trim());
                        if (time) {
                            db.temps = time;
                            client.db.set(`setgiveaway_${message.guild.id}`, db);
                            await updateEmbed();
                        } else {
                            await message.channel.send("❌ Format de temps invalide (ex: 5d, 1h).").then(m => setTimeout(() => m.delete(), 3000));
                        }
                        prompt.delete().catch(() => false);
                        collected.first().delete().catch(() => false);
                    }
                    await i.editReply({ embeds: originalMsg.embeds, components: originalMsg.components, content: null });
                } else if (value === `emoji_${message.id}`) {
                    const prompt = await i.followUp({ content: "✨ Quel emoji pour le giveaway ?", ephemeral: true });
                    const collected = await message.channel.awaitMessages({ filter: m => m.author.id === message.author.id, max: 1, time: ms("1m") });
                    if (collected.size > 0) {
                        const emoji = collected.first().content.trim();
                        db.emoji = emoji;
                        client.db.set(`setgiveaway_${message.guild.id}`, db);
                        await updateEmbed();
                        prompt.delete().catch(() => false);
                        collected.first().delete().catch(() => false);
                    }
                    await i.editReply({ embeds: originalMsg.embeds, components: originalMsg.components, content: null });
                } else if (value === `gagnantpredef_${message.id}`) {
                    const userRow = new ActionRowBuilder().addComponents(
                        new UserSelectMenuBuilder()
                            .setCustomId(`gw_setup_gagnant_${message.id}`)
                            .setPlaceholder("Sélectionner les gagnants...")
                            .setMinValues(1)
                            .setMaxValues(25)
                    );
                    await i.editReply({ content: "🏆 Choisissez les gagnants prédéfinis :", components: [userRow] });
                } else if (value === `vocal_${message.id}`) {
                    const vocalRow = new ActionRowBuilder().addComponents(
                        new Discord.ButtonBuilder().setCustomId(`gw_setup_voc_activer_${message.id}`).setLabel("Activer").setStyle(Discord.ButtonStyle.Success).setEmoji("✅"),
                        new Discord.ButtonBuilder().setCustomId(`gw_setup_voc_off_${message.id}`).setLabel("Désactiver").setStyle(Discord.ButtonStyle.Danger).setEmoji("❌")
                    );
                    await i.editReply({ content: "🎙️ Activer ou désactiver le vocal requis ?", components: [vocalRow] });
                } else if (value === `buttonColor_${message.id}`) {
                    const colorRow = new ActionRowBuilder().addComponents(
                        new Discord.ButtonBuilder().setCustomId(`gw_setup_color_primary_${message.id}`).setLabel("Primary").setStyle(Discord.ButtonStyle.Primary),
                        new Discord.ButtonBuilder().setCustomId(`gw_setup_color_secondary_${message.id}`).setLabel("Secondary").setStyle(Discord.ButtonStyle.Secondary),
                        new Discord.ButtonBuilder().setCustomId(`gw_setup_color_success_${message.id}`).setLabel("Success").setStyle(Discord.ButtonStyle.Success),
                        new Discord.ButtonBuilder().setCustomId(`gw_setup_color_danger_${message.id}`).setLabel("Danger").setStyle(Discord.ButtonStyle.Danger)
                    );
                    await i.editReply({ content: "🎨 Choisissez la couleur du bouton :", components: [colorRow] });
                } else if (value === `invites_${message.id}`) {
                    const prompt = await i.followUp({ content: "📧 Combien d'invitations sont requises pour participer ? (0 pour aucune)", ephemeral: true });
                    const collected = await message.channel.awaitMessages({ filter: m => m.author.id === message.author.id, max: 1, time: ms("1m") });
                    if (collected.size > 0) {
                        const invites = parseInteger(collected.first().content.trim());
                        if (invites !== null && invites >= 0) {
                            db.requiredInvites = invites;
                            client.db.set(`setgiveaway_${message.guild.id}`, db);
                            await updateEmbed();
                        } else {
                            await message.channel.send("❌ Nombre invalide (doit être un entier positif ou 0).").then(m => setTimeout(() => m.delete(), 3000));
                        }
                        prompt.delete().catch(() => false);
                        collected.first().delete().catch(() => false);
                    }
                    await i.editReply({ embeds: originalMsg.embeds, components: originalMsg.components, content: null });
                }
            } else if (i.isButton()) {
                if (i.customId === `gw_setup_voc_activer_${message.id}`) {
                    db.vocal = true;
                    client.db.set(`setgiveaway_${message.guild.id}`, db);
                    await updateEmbed();
                    await i.followUp({ content: "✅ Vocal requis activé !", ephemeral: true });
                    await i.editReply({ embeds: originalMsg.embeds, components: originalMsg.components, content: null });
                } else if (i.customId === `gw_setup_voc_off_${message.id}`) {
                    db.vocal = false;
                    client.db.set(`setgiveaway_${message.guild.id}`, db);
                    await updateEmbed();
                    await i.followUp({ content: "✅ Vocal requis désactivé !", ephemeral: true });
                    await i.editReply({ embeds: originalMsg.embeds, components: originalMsg.components, content: null });
                } else if (i.customId === `gw_setup_color_primary_${message.id}`) {
                    db.buttonColor = "Primary";
                    client.db.set(`setgiveaway_${message.guild.id}`, db);
                    await updateEmbed();
                    await i.followUp({ content: "✅ Couleur du bouton mise à jour !", ephemeral: true });
                    await i.editReply({ embeds: originalMsg.embeds, components: originalMsg.components, content: null });
                } else if (i.customId === `gw_setup_color_secondary_${message.id}`) {
                    db.buttonColor = "Secondary";
                    client.db.set(`setgiveaway_${message.guild.id}`, db);
                    await updateEmbed();
                    await i.followUp({ content: "✅ Couleur du bouton mise à jour !", ephemeral: true });
                    await i.editReply({ embeds: originalMsg.embeds, components: originalMsg.components, content: null });
                } else if (i.customId === `gw_setup_color_success_${message.id}`) {
                    db.buttonColor = "Success";
                    client.db.set(`setgiveaway_${message.guild.id}`, db);
                    await updateEmbed();
                    await i.followUp({ content: "✅ Couleur du bouton mise à jour !", ephemeral: true });
                    await i.editReply({ embeds: originalMsg.embeds, components: originalMsg.components, content: null });
                } else if (i.customId === `gw_setup_color_danger_${message.id}`) {
                    db.buttonColor = "Danger";
                    client.db.set(`setgiveaway_${message.guild.id}`, db);
                    await updateEmbed();
                    await i.followUp({ content: "✅ Couleur du bouton mise à jour !", ephemeral: true });
                    await i.editReply({ embeds: originalMsg.embeds, components: originalMsg.components, content: null });
                } else if (i.customId === `gw_setup_reset_${message.id}`) {
                    client.db.delete(`setgiveaway_${message.guild.id}`);
                    await updateEmbed();
                    await i.followUp({ content: "⚠️ Paramètres réinitialisés avec succès !", ephemeral: true });
                    await i.editReply({ embeds: originalMsg.embeds, components: originalMsg.components, content: null });
                } else if (i.customId === `gw_setup_start_${message.id}`) {
                    const missing = [];
                    if (!db.temps) missing.push("durée");
                    if (!db.channel) missing.push("salon");
                    if (db.gagnant === null) missing.push("nombre de gagnants");
                    if (db.prix === "un prix") missing.push("prix");
        
                    if (missing.length > 0) {
                        await i.followUp({ content: `❌ Configuration incomplète :\n${missing.map(m => `- ${m}`).join('\n')}`, ephemeral: true });
                        await i.editReply({ embeds: originalMsg.embeds, components: originalMsg.components, content: null });
                    } else {
                        const code = generateRandomCode(6);
                        const giveawayChannel = message.guild.channels.cache.get(db.channel);
                        const embed = new EmbedBuilder()
                            .setTitle("🎉 Nouveau Giveaway")
                            .setDescription(`**Prix** : \`${db.prix}\`\n**Fin** : <t:${Math.floor((Date.now() + db.temps) / 1000)}:R>\n**Lancée par** : <@${i.user.id}>\n**Participants** : 0`)
                            .setColor(client.color)
                            .setFooter(client.footer);
        
                        const row = new ActionRowBuilder().addComponents(
                            new Discord.ButtonBuilder().setCustomId(`giveaway_entry_${code}`).setEmoji(db.emoji).setStyle(Discord.ButtonStyle[db.buttonColor || "Primary"]),
                            new Discord.ButtonBuilder().setCustomId(`giveaway_list_${code}`).setLabel("Participants").setStyle(Discord.ButtonStyle.Secondary)
                        );
        
                        const giveawayMessage = await giveawayChannel.send({ embeds: [embed], components: [row] });
                        const endTime = Date.now() + db.temps;
        
                        const giveawayData = {
                            prix: db.prix,
                            gagnant: db.gagnant,
                            temps: endTime,
                            channel: db.channel,
                            vocal: db.vocal,
                            predef: db.predef,
                            participant: [],
                            emoji: db.emoji,
                            host: i.user.id,
                            createdTimestamp: Date.now(),
                            messageid: giveawayMessage.id,
                            ended: false,
                            buttonColor: db.buttonColor,
                            requiredInvites: db.requiredInvites
                        };
        
                        client.db.set(`giveaway_${message.guild.id}_${code}`, giveawayData);
        
setTimeout(async () => {
    const currentData = client.db.get(`giveaway_${message.guild.id}_${code}`);
    if (currentData && !currentData.ended) {
        const channel = client.channels.cache.get(currentData.channel);
        const gwMessage = await channel.messages.fetch(currentData.messageid).catch(() => null);
        if (!gwMessage) return;

        let participants = currentData.participant;
        if (currentData.vocal) {
            participants = participants.filter(userId => {
                const member = message.guild.members.cache.get(userId);
                return member && member.voice.channel;
            });
        }

        let winners = [];
        if (currentData.predef && currentData.predef.length > 0) {
            winners = currentData.predef.slice(0, currentData.gagnant);
        } else if (participants.length > 0) {
            const shuffled = participants.sort(() => 0.5 - Math.random());
            winners = shuffled.slice(0, Math.min(currentData.gagnant, participants.length));
        }

        const endEmbed = new EmbedBuilder()
            .setTitle("🎉 Giveaway Terminé")
            .setDescription(`**Prix** : \`${currentData.prix}\`\n**Gagnants** : ${winners.length > 0 ? winners.map(w => `<@${w}>`).join(', ') : "Aucun participant"}\n**Lancée par** : <@${currentData.host}>\n**Code** : \`${code}\``)
            .setColor(client.color)
            .setFooter(client.footer)
            .setTimestamp();

        const buttonStyle = Discord.ButtonStyle[currentData.buttonColor];

        const disabledRow = new ActionRowBuilder().addComponents(
            new Discord.ButtonBuilder().setCustomId(`giveaway_entry_${code}`).setEmoji(currentData.emoji).setStyle(buttonStyle).setDisabled(true),
            new Discord.ButtonBuilder().setCustomId(`giveaway_list_${code}`).setLabel("Participants").setStyle(Discord.ButtonStyle.Secondary).setDisabled(true)
        );

        await gwMessage.edit({ embeds: [endEmbed], components: [disabledRow] });

        if (winners.length > 0) {
            await channel.send(`🎉 Félicitations ${winners.map(w => `<@${w}>`).join(', ')} ! Vous avez gagné **${currentData.prix}** !`);

            // Vérifier si les MPs pour giveaway sont activés
            const mpGiveawayEnabled = client.db.get(`mp_giveaway_${message.guild.id}`) || false;
            
            if (mpGiveawayEnabled) {
                // Envoyer un DM à chaque gagnant
                for (const winnerId of winners) {
                    try {
                        const winner = await client.users.fetch(winnerId);
                        const giveawayLink = `https://discord.com/channels/${message.guild.id}/${currentData.channel}/${currentData.messageid}`;

                        const dmEmbed = new EmbedBuilder()
                            .setTitle("🎉 Félicitations, vous avez gagné un giveaway !")
                            .setDescription(
                                `Vous avez gagné **${currentData.prix}** dans le giveaway organisé dans le salon <#${currentData.channel}> !\n` +
                                `Cliquez sur le bouton ci-dessous pour voir le giveaway.`
                            )
                            .setColor(client.color)
                            .setFooter(client.footer)
                            .setTimestamp();

                        // Créer le bouton pour aller au giveaway
                        const giveawayButton = new ActionRowBuilder()
                            .addComponents(
                                new ButtonBuilder()
                                    .setLabel("Voir le giveaway")
                                    .setStyle(ButtonStyle.Link)
                                    .setURL(giveawayLink)
                                    .setEmoji("🎉")
                            );

                        // Envoyer le MP au gagnant
                        await winner.send({ 
                            embeds: [dmEmbed], 
                            components: [giveawayButton] 
                        });
                        
                        console.log(`MP de giveaway envoyé à ${winner.tag} pour le prix: ${currentData.prix}`);
                        
                    } catch (error) {
                        console.error(`Impossible d'envoyer le MP de giveaway à ${winner.tag}:`, error);
                        // Optionnel: envoyer un message dans le canal si le MP échoue
                        await channel.send(`🎉 <@${winnerId}>, vous avez gagné **${currentData.prix}** ! (Impossible d'envoyer un MP)`);
                    }
                }
            } else {
                console.log(`MPs pour giveaway désactivés dans le serveur ${message.guild.id}`);
            }
        } else {
            await channel.send("❌ Aucun gagnant n'a pu être sélectionné pour ce giveaway.");
        }

        client.db.set(`giveaway_${message.guild.id}_${code}`, { ...currentData, ended: true });
    }
}, db.temps);
        
                        await i.editReply({ embeds: [], components: [], content: "✅ Giveaway lancé avec succès !" });
                    }
                }
            } else if (i.isChannelSelectMenu()) {
                if (i.customId === `gw_setup_salon_${message.id}`) {
                    db.channel = i.values[0];
                    client.db.set(`setgiveaway_${message.guild.id}`, db);
                    await updateEmbed();
                    await i.followUp({ content: "✅ Salon mis à jour !", ephemeral: true });
                    await i.editReply({ embeds: originalMsg.embeds, components: originalMsg.components, content: null });
                }
            } else if (i.isUserSelectMenu()) {
                if (i.customId === `gw_setup_gagnant_${message.id}`) {
                    db.predef = i.values;
                    client.db.set(`setgiveaway_${message.guild.id}`, db);
                    await updateEmbed();
                    await i.followUp({ content: "✅ Gagnants prédéfinis mis à jour !", ephemeral: true });
                    await i.editReply({ embeds: originalMsg.embeds, components: originalMsg.components, content: null });
                }
            }
        });

        collector.on('end', () => {
            originalMsg.edit({ components: [] });
        });
    }
};

function parseTime(timeString) {
    const regex = /(\d+)([smhdwy])/;
    const match = timeString.match(regex);
    if (!match) return null;
    const value = parseInt(match[1]);
    const unit = match[2];
    const units = { s: 1000, m: 60000, h: 3600000, d: 86400000, w: 604800000, y: 31536000000 };
    return units[unit] ? value * units[unit] : null;
}

function formatTimeLeft(milliseconds) {
    if (milliseconds < 1000) return `${milliseconds}ms`;
    const seconds = Math.floor(milliseconds / 1000);
    if (seconds < 60) return `${seconds}s`;
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h`;
    const days = Math.floor(hours / 24);
    if (days < 365) return `${days}j`;
    return `${Math.floor(days / 365)}a`;
}

function parseInteger(input) {
    const parsed = parseInt(input);
    return isNaN(parsed) ? null : parsed;
}

function generateRandomCode(length) {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let code = '';
    for (let i = 0; i < length; i++) code += characters.charAt(Math.floor(Math.random() * characters.length));
    return code;
}