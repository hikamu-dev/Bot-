const Discord = require("discord.js")
getNow = () => { return { time: new Date().toLocaleString("fr-FR", { timeZone: "Europe/Paris", hour12: false, hour: "2-digit", minute: "2-digit", second: "2-digit" }) }; };
const ms = require("ms");

module.exports = {
    name: "unmute",
    aliases: ["untimeout", "untempmute"],
    description: 'Permet de retirer le mute temporaire d’un membre du serveur',
    usages: `unmute <@utilisateur/id>`,
    use: `<@utilisateur/id>`,
    example: `➜ unmute @tokyru\n➜ unmute 123456789012345678`,
    run: async (client, message, args, commandName) => {
                                        const whitelistDB = client.db.get(`wl.${message.guild.id}`) || [];

const isBypass = (
    client.staff.includes(message.author.id) ||
    client.config.buyers.includes(message.author.id) ||
    client.db.get(`owner_${message.author.id}`) === true ||
        client.db.get(`owner_global_${message.author.id}`) === true || 

    whitelistDB.includes(message.author.id)
);

if (!isBypass) {
    const limitData = client.db.get(`command_limit_${message.guild.id}_unmute`);
    if (limitData) {
        const key = `limit_used_unmute_${message.guild.id}_${message.author.id}`;
        const userData = client.db.get(key) || { count: 0, timestamp: 0 };
        const now = Date.now();

        if (userData.timestamp + limitData.timeLimit > now) {
            if (userData.count >= limitData.maxUse) {
                const remaining = Math.ceil((userData.timestamp + limitData.timeLimit - now) / 1000);
                return message.reply(`Tu as atteint la limite d'utilisation de la commande \`unmute\`. Réessaie dans ${remaining}s.`);
            } else {
                userData.count += 1;
            }
        } else {
            userData.count = 1;
            userData.timestamp = now;
        }

        client.db.set(key, userData);
    }
}
        let pass = false;

        // Autoriser automatiquement les staffs, buyers et owners
        if (
            client.staff.includes(message.author.id) ||
            client.config.buyers.includes(message.author.id) ||
                client.db.get(`owner_global_${message.author.id}`) === true || 

            client.db.get(`owner_${message.author.id}`) === true
        ) {
            pass = true;
        } else {
            // Vérifier les permissions personnalisées pour la commande
            const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
            if (commandPerms.length > 0) {
                const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                const userRoles = message.member.roles.cache.map(role => role.id);
                pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
            } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                pass = true;
            }
        }

if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        try {
            const target = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
            if (!target) return message.channel.send("Membre introuvable. Veuillez mentionner un utilisateur ou fournir un ID valide.");

            // Vérifier si l'utilisateur est bien mute avant de retirer le mute
            if (!target.communicationDisabledUntilTimestamp || target.communicationDisabledUntilTimestamp < Date.now()) {
                return message.channel.send("Ce membre n'est pas mute.");
            }

            // Retirer le timeout (unmute)
            await target.timeout(null);

            // Envoi du MP si activé
            const mpEnabled = client.db.get(`mp_unmute_${message.guild.id}`) || false;
            if (mpEnabled) {
                try {
                    await target.user.send(`Vous avez été **unmute** sur **\`${message.guild.name}\`**.`);
                } catch (error) {
                    console.log("Impossible d'envoyer un message privé à l'utilisateur :", error);
                }
            }

            // Message de confirmation dans le salon
            await message.channel.send(`${target.user.username} a été unmute par ${message.author.username}.`);

            // Log dans modlogs
            const embed = new Discord.EmbedBuilder()
                .setColor(client.color)
                .setDescription(`${message.author} a retiré le mute de [\`${target.user.username}\`](https://discord.com/users/${target.user.id})`);

            message.guild.channels.cache.get(client.db.get(`modlogs_${message.guild.id}`))?.send({ embeds: [embed] });

        } catch (erreur) {
            console.log(erreur);
            message.channel.send("❌ Une erreur est survenue lors du traitement de la commande.");
        }
    }
}
