// commands/moderation/warns.js
const {
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder
} = require("discord.js");

const MS_COLLECT = 10 * 60 * 1000; // 10 min

module.exports = {
  name: "warns",
  aliases: ["warnlist", "listwarns", "warnings"],
  description: "Affiche le compteur de warns d’un membre avec les raisons, et permet de supprimer via menu.",
  usages: "warns <@user|ID>",
  example: "warns @membre",

  /**
   * @param {import('discord.js').Client} client
   * @param {import('discord.js').Message} message
   * @param {string[]} args
   */
  run: async (client, message, args, commandName = "warns") => {
    try {
      // ----- Permissions (même logique que tes autres commandes) -----
      const whitelistDB = client.db.get(`wl.${message.guild.id}`) || [];
      const isBypassHard =
        client.staff?.includes?.(message.author.id) ||
        client.config?.buyers?.includes?.(message.author.id) ||
        client.db.get(`owner_${message.author.id}`) === true ||
        client.db.get(`owner_global_${message.author.id}`) === true ||
        whitelistDB.includes(message.author.id) ||
        message.guild.ownerId === message.author.id;

      let pass = isBypassHard;
      if (!pass) {
        const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
        if (commandPerms.length > 0) {
          const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
          const userRoles = message.member.roles.cache.map(r => r.id);
          pass = commandPerms.some(perm => userPerms[perm]?.some?.(roleId => userRoles.includes(roleId)));
        } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
          pass = true;
        }
      }
      if (!pass) {
        if (client.noperm && client.noperm.trim() !== "") {
          const sent = await message.channel.send(client.noperm);
          const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
          if (delayTime > 0) setTimeout(() => sent.delete().catch(() => {}), delayTime * 1000);
        }
        return;
      }

      // ----- Args -----
      if (!args[0]) return message.channel.send("Utilisation : `warns <@user|ID>`");

      let user = message.mentions.users.first() || null;
      if (!user) user = await client.users.fetch(args[0]).catch(() => null);
      if (!user) return message.channel.send("Utilisateur introuvable.");

      const guildId = message.guild.id;
      const countKey   = `warn_count_${guildId}_${user.id}`;
      const reasonsKey = `warn_reasons_${guildId}_${user.id}`;

      // ----- Lecture compteur + raisons -----
      let count   = Number(client.db.get(countKey) || 0);
      let reasons = Array.isArray(client.db.get(reasonsKey)) ? client.db.get(reasonsKey) : [];

      // Ajuste si jamais le compteur et la liste ne matchent pas
      if (reasons.length > count) reasons = reasons.slice(0, count);
      if (reasons.length < count) {
        // complète avec des raisons inconnues si des warns anciens n'avaient pas de raison
        reasons = reasons.concat(Array.from({ length: count - reasons.length }, () => "Raison inconnue"));
      }

      if (count <= 0) {
        return message.channel.send(`Aucun warn trouvé pour \`${user.tag}\` (compteur = 0).`);
      }

      // ----- Embed (liste #i + raison) -----
      const embed = new EmbedBuilder()
        .setTitle(`⚠️ Warns de ${user.tag}`)
        .setColor(client.color || 0xffc107)
        .setDescription(`**Compteur actuel :** ${count}`)
        .setFooter(client.footer || null);

      embed.addFields(
        ...reasons.map((r, i) => ({
          name: `#${i + 1}`,
          value: `• **Raison :** ${safeInline(r)}`,
          inline: false
        }))
      );

      // ----- Menu déroulant -----
      const select = new StringSelectMenuBuilder()
        .setCustomId(`warns_select_${user.id}_${message.id}`)
        .setPlaceholder("Choisis une action…")
        .addOptions(
          new StringSelectMenuOptionBuilder().setLabel("Supprimer 1 warn").setValue("delete_one").setEmoji("🗑️"),
          new StringSelectMenuOptionBuilder().setLabel("Supprimer TOUS les warns").setValue("delete_all").setEmoji("🔥"),
          new StringSelectMenuOptionBuilder().setLabel("Annuler").setValue("cancel").setEmoji("❎")
        );
      const row = new ActionRowBuilder().addComponents(select);

      const sent = await message.channel.send({ embeds: [embed], components: [row] });

      // ----- Collector -----
      const collector = sent.createMessageComponentCollector({ time: MS_COLLECT });

      collector.on("collect", async (interaction) => {
        if (interaction.user.id !== message.author.id) {
          return interaction.reply({ content: "Seul l'auteur de la commande peut utiliser ce menu.", ephemeral: true });
        }

        const [choice] = interaction.values;

        if (choice === "cancel") {
          await interaction.update({ components: [disableSelect(select)] });
          collector.stop("canceled");
          return;
        }

        // Relecture live
        count   = Number(client.db.get(countKey) || 0);
        reasons = Array.isArray(client.db.get(reasonsKey)) ? client.db.get(reasonsKey) : [];
        if (reasons.length > count) reasons = reasons.slice(0, count);
        if (reasons.length < count) {
          reasons = reasons.concat(Array.from({ length: count - reasons.length }, () => "Raison inconnue"));
        }

        if (count <= 0) {
          await interaction.update({ components: [disableSelect(select)] });
          await sent.edit({
            embeds: [
              new EmbedBuilder()
                .setTitle(`⚠️ Warns de ${user.tag}`)
                .setDescription("Aucun warn restant (compteur = 0).")
                .setColor(client.color || 0x43b581)
                .setFooter(client.footer || null)
            ]
          }).catch(() => {});
          collector.stop("empty");
          return;
        }

        if (choice === "delete_one") {
          await interaction.deferUpdate().catch(() => {});
          const ask = await message.channel.send(`👉 **${message.author}** réponds par le **numéro** du warn à supprimer (1–${count}). Tu as 60s.`);

          const picked = await waitForNumber(message, message.author.id, 60_000, count);
          try { await ask.delete().catch(() => {}); } catch {}
          if (picked?.messageRef) { try { await picked.messageRef.delete().catch(() => {}); } catch {} }

          if (!picked) {
            return message.channel.send("❌ Numéro invalide ou délai dépassé.")
              .then(m => setTimeout(() => m.delete().catch(() => {}), 5000));
          }

          // Supprime la raison correspondante (si existe) et décrémente le compteur
          const idx = picked.value - 1;
          let reasonsNow = Array.isArray(client.db.get(reasonsKey)) ? client.db.get(reasonsKey) : [];
          if (idx >= 0 && idx < reasonsNow.length) {
            reasonsNow.splice(idx, 1);
            client.db.set(reasonsKey, reasonsNow);
          }
          client.db.set(countKey, Math.max(0, count - 1));

          await message.channel.send(`🗑️ Warn **#${picked.value}** supprimé pour \`${user.tag}\`.`)
            .then(m => setTimeout(() => m.delete().catch(() => {}), 5000));

          await refreshEmbed(sent, client, user, guildId);
          return;
        }

        if (choice === "delete_all") {
          await interaction.deferUpdate().catch(() => {});
          const ask = await message.channel.send(`⚠️ **${message.author}** écris \`CONFIRMER\` pour **réinitialiser** tous les warns de \`${user.tag}\`. Tu as 45s.`);

          const confirm = await waitForText(message, message.author.id, 45_000);
          try { await ask.delete().catch(() => {}); } catch {}
          if (confirm?.messageRef) { try { await confirm.messageRef.delete().catch(() => {}); } catch {} }

          if (!confirm || confirm.value !== "CONFIRMER") {
            return message.channel.send("❌ Confirmation annulée ou expirée.")
              .then(m => setTimeout(() => m.delete().catch(() => {}), 5000));
          }

          client.db.set(countKey, 0);
          client.db.set(reasonsKey, []);
          await message.channel.send(`🔥 Tous les warns de \`${user.tag}\` ont été supprimés.`)
            .then(m => setTimeout(() => m.delete().catch(() => {}), 5000));

          await refreshEmbed(sent, client, user, guildId);
          return;
        }
      });

      collector.on("end", async () => {
        try { await sent.edit({ components: [disableSelect(select)] }); } catch {}
      });

    } catch (e) {
      console.error(e);
      message.reply("Une erreur est survenue dans `warns`.");
    }
  }
};

// ===== Helpers =====
function disableSelect(select) {
  return new ActionRowBuilder().addComponents(select.setDisabled(true));
}

function safeInline(text = "") {
  if (typeof text !== "string") return "—";
  return text.replace(/`/g, "ˋ");
}

async function waitForNumber(message, authorId, timeoutMs, max) {
  try {
    const collected = await message.channel.awaitMessages({
      max: 1,
      time: timeoutMs,
      errors: ["time"],
      filter: (m) => m.author.id === authorId && /^\d+$/.test(m.content.trim())
    });
    const first = collected.first();
    const n = parseInt(first.content.trim(), 10);
    if (isNaN(n) || n < 1 || n > max) return null;
    return { value: n, messageRef: first };
  } catch {
    return null;
  }
}

async function waitForText(message, authorId, timeoutMs) {
  try {
    const collected = await message.channel.awaitMessages({
      max: 1,
      time: timeoutMs,
      errors: ["time"],
      filter: (m) => m.author.id === authorId && m.content && m.content.trim().length > 0
    });
    const first = collected.first();
    return { value: first.content.trim(), messageRef: first };
  } catch {
    return null;
  }
}

async function refreshEmbed(sentMessage, client, user, guildId) {
  const countKey   = `warn_count_${guildId}_${user.id}`;
  const reasonsKey = `warn_reasons_${guildId}_${user.id}`;

  const count   = Number(client.db.get(countKey) || 0);
  const reasons = Array.isArray(client.db.get(reasonsKey)) ? client.db.get(reasonsKey) : [];

  if (count <= 0) {
    const empty = new EmbedBuilder()
      .setTitle(`⚠️ Warns de ${user.tag}`)
      .setDescription("Aucun warn restant (compteur = 0).")
      .setColor(client.color || 0x43b581)
      .setFooter(client.footer || null);
    return sentMessage.edit({ embeds: [empty] }).catch(() => {});
  }

  const normalized = (reasons.length >= count)
    ? reasons.slice(0, count)
    : reasons.concat(Array.from({ length: count - reasons.length }, () => "Raison inconnue"));

  const embed = new EmbedBuilder()
    .setTitle(`⚠️ Warns de ${user.tag}`)
    .setColor(client.color || 0xffc107)
    .setDescription(`**Compteur actuel :** ${count}`)
    .setFooter(client.footer || null);

  embed.addFields(
    ...normalized.map((r, i) => ({
      name: `#${i + 1}`,
      value: `• **Raison :** ${safeInline(r)}`,
      inline: false
    }))
  );

  return sentMessage.edit({ embeds: [embed] }).catch(() => {});
}
