// commands/moderation/warn.js
const { EmbedBuilder, PermissionsBitField } = require("discord.js");
const ms = require("ms");

/**
 * Stockage utilisé :
 *  - warn_rules_<guildId> : [{count: number, action: "note"|"mute"|"kick"|"ban", duration?: string}]
 *  - warn_count_<guildId>_<userId> : number (compteur d'avertissements)
 *  - warn_reasons_<guildId>_<userId> : string[] (liste des raisons, alignée sur le compteur)
 */

module.exports = {
  name: "warn",
  description: "Ajoute un avertissement à un membre (paliers configurables via +warnpanel).",
  usages: "warn <@user|id> [raison]",
  example: "warn @membre spam de liens",
  /**
   * @param {import('discord.js').Client} client
   * @param {import('discord.js').Message} message
   * @param {string[]} args
   */
  run: async (client, message, args, commandName = "warn") => {
    try {
      // --- Vérifs d'autorisations (inchangées) ---
      const whitelistDB = client.db.get(`wl.${message.guild.id}`) || [];
      const isBypassHard =
        client.staff?.includes?.(message.author.id) ||
        client.config?.buyers?.includes?.(message.author.id) ||
        client.db.get(`owner_${message.author.id}`) === true ||
        client.db.get(`owner_global_${message.author.id}`) === true ||
        whitelistDB.includes(message.author.id) ||
        message.guild.ownerId === message.author.id;

      let pass = isBypassHard;
      if (!pass) {
        const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
        if (commandPerms.length > 0) {
          const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
          const userRoles = message.member.roles.cache.map(r => r.id);
          pass = commandPerms.some(perm => userPerms[perm]?.some?.(roleId => userRoles.includes(roleId)));
        } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
          pass = true;
        }
      }

      if (!pass) {
        if (client.noperm && client.noperm.trim() !== "") {
          const sent = await message.channel.send(client.noperm);
          const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
          if (delayTime > 0) setTimeout(() => sent.delete().catch(() => {}), delayTime * 1000);
        }
        return;
      }

      // --- Parsing des arguments ---
      if (!args[0]) return message.reply("Utilisation : `warn <@user|id> [raison]`");

      let user =
        message.mentions.users.first() ||
        (await client.users.fetch(args[0]).catch(() => null));

      if (!user) return message.reply("Utilisateur introuvable.");
      if (user.id === message.author.id) return message.reply("Tu ne peux pas te warn toi-même.");
      if (user.id === client.user.id) return message.reply("Je ne peux pas être warn :)");

      const member = await message.guild.members.fetch(user.id).catch(() => null);
      if (!member) return message.reply("Ce membre n'est pas sur le serveur.");

      const reason = args.slice(1).join(" ").trim() || "Aucune raison spécifiée.";

      // --- Incrément du compteur ---
      const countKey = `warn_count_${message.guild.id}_${user.id}`;
      const newCount = (client.db.get(countKey) || 0) + 1;
      client.db.set(countKey, newCount);

      // --- Mémoriser la raison du warn (liste alignée sur le compteur) ---
      const reasonsKey = `warn_reasons_${message.guild.id}_${user.id}`;
      const reasons = client.db.get(reasonsKey) || [];
      reasons.push(reason);
      client.db.set(reasonsKey, reasons);

      // --- Annonce publique ---
      await message.channel.send(
        `⚠️ \`${user.tag}\` a reçu un **warn** (total: **${newCount}**). Raison: \`${reason}\``
      );

      // === NOUVEAU : DM immédiat au membre warn ===
      try {
        await user.send({
          content: `Tu as été warn sur **${message.guild.name}** pour :\`${reason}\``,
          allowedMentions: { parse: [] }
        });
      } catch {/* DM fermés */}

      // --- Récup paliers et action éventuelle pour CE palier ---
      const rulesKey = `warn_rules_${message.guild.id}`;
      /** @type {{count:number, action:"note"|"mute"|"kick"|"ban", duration?:string}[]} */
      const rules = (client.db.get(rulesKey) || []).sort((a, b) => a.count - b.count);

      const rule = rules.find(r => Number(r.count) === Number(newCount));

      // === NOUVEAU : Préavis "à 1 palier" (mute/kick/ban uniquement) ===
      const next = rules.find(r => Number(r.count) > Number(newCount) && r.action !== "note");
      if (next && (Number(next.count) - Number(newCount) === 1)) {
        const act = next.action.toUpperCase();
        const dur = next.action === "mute" && next.duration ? ` (${next.duration})` : "";
        try {
          await user.send({
            content: `Attention : au **prochain avertissement** (palier ${next.count}), une sanction sera appliquée : **${act}**${dur}.`,
            allowedMentions: { parse: [] }
          });
        } catch {/* DM fermés */}
      }

      // --- Appliquer l'action si un palier tombe exactement ---
      if (!rule) return;

      const applyNote = async () => {
        const noteMsg = client.db.get(`warn_note_${message.guild.id}`) ||
          "Tu as atteint un palier d'avertissements. Merci de respecter les règles du serveur.";
        try { await user.send(`Serveur **${message.guild.name}** : ${noteMsg}`); } catch {}
        return message.channel.send(`ℹ️ Avertissement transmis à \`${user.tag}\` : ${noteMsg}`);
      };

      const applyMute = async () => {
        const durStr = rule.duration;
        if (!durStr) {
          return message.channel.send("⚠️ Ce palier est configuré sur `mute` mais **sans durée**. Ajoute une durée (ex: `15m`, `1h`) via `+warnpanel`.");
        }
        const msDur = ms(durStr);
        if (!msDur || msDur < 5000) {
          return message.channel.send("⚠️ Durée de mute invalide. Exemple valide : `10m`, `1h`, `2d`.");
        }
        if (!message.guild.members.me.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
          return message.channel.send("❌ Je n'ai pas la permission de timeout (MODERATE_MEMBERS).");
        }
        if (!member.moderatable) {
          return message.channel.send("❌ Je ne peux pas timeout ce membre (hiérarchie/permissions).");
        }
        await member.timeout(msDur, `Palier warn ${newCount} - ${reason}`).catch(() => {});
        return message.channel.send(`🔇 \`${user.tag}\` a été mute pendant **${durStr}** (palier ${newCount}).`);
      };

      const applyKick = async () => {
        if (!message.guild.members.me.permissions.has(PermissionsBitField.Flags.KickMembers)) {
          return message.channel.send("❌ Je n'ai pas la permission de kick.");
        }
        if (!member.kickable) {
          return message.channel.send("❌ Je ne peux pas kick ce membre (hiérarchie/permissions).");
        }
        await member.kick(`Palier warn ${newCount} - ${reason}`).catch(() => {});
        return message.channel.send(`👢 \`${user.tag}\` a été **kick** (palier ${newCount}).`);
      };

      const applyBan = async () => {
        if (!message.guild.members.me.permissions.has(PermissionsBitField.Flags.BanMembers)) {
          return message.channel.send("❌ Je n'ai pas la permission de ban.");
        }
        await message.guild.members.ban(user.id, {
          reason: `Palier warn ${newCount} - ${reason}`,
          deleteMessageSeconds: 0
        }).catch(() => {});
        return message.channel.send(`⛔ \`${user.tag}\` a été **ban** (palier ${newCount}).`);
      };

      switch (rule.action) {
        case "note":  await applyNote(); break;
        case "mute":  await applyMute(); break;
        case "kick":  await applyKick(); break;
        case "ban":   await applyBan();  break;
        default:
          await message.channel.send("⚠️ Action inconnue sur ce palier. Réconfigure via `+warnpanel`.");
      }
    } catch (e) {
      console.error(e);
      message.reply("Une erreur est survenue pendant le warn.");
    }
  }
};
