const Discord = require('discord.js');
const ms = require('ms');
const { example } = require('./ban');

module.exports = {
    name: "unban",
    description: "Permet de débannir l'utilisateur indiqué",
    use: "<@utilisateur/id>",
    usages: "unban <@utilisateur/id>",
    example: "➜ unban @tokyru\n➜ unban 123456789012345678",
    run: async (client, message, args, commandName) => {
                                const whitelistDB = client.db.get(`wl.${message.guild.id}`) || [];

const isBypass = (
    client.staff.includes(message.author.id) ||
    client.config.buyers.includes(message.author.id) ||
    client.db.get(`owner_${message.author.id}`) === true ||
    client.db.get(`owner_global_${message.author.id}`) === true || 

    whitelistDB.includes(message.author.id)
);

if (!isBypass) {
    const limitData = client.db.get(`command_limit_${message.guild.id}_unban`);
    if (limitData) {
        const key = `limit_used_unban_${message.guild.id}_${message.author.id}`;
        const userData = client.db.get(key) || { count: 0, timestamp: 0 };
        const now = Date.now();

        if (userData.timestamp + limitData.timeLimit > now) {
            if (userData.count >= limitData.maxUse) {
                const remaining = Math.ceil((userData.timestamp + limitData.timeLimit - now) / 1000);
                return message.reply(`Tu as atteint la limite d'utilisation de la commande \`unban\`. Réessaie dans ${remaining}s.`);
            } else {
                userData.count += 1;
            }
        } else {
            userData.count = 1;
            userData.timestamp = now;
        }

        client.db.set(key, userData);
    }
}
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
            client.db.get(`owner_global_${message.author.id}`) === true || 

client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        let user = args[0];
        if (!user) return message.channel.send("Veuillez spécifier un ID d'utilisateur valide.");

        let bannedUser;
        try {
            bannedUser = await client.users.fetch(user);
        } catch (error) {
            console.error('Error fetching user:', error);
            return message.channel.send(`<@${user}> n'existe pas ou est déjà débanni`);
        }

        message.guild.members.unban(bannedUser).then(async () => {
            await message.channel.send(`**\`${bannedUser.tag}\`** a été **débanni**`);

            let Embed = new Discord.EmbedBuilder()
                .setColor(client.color)
                .setDescription(`${message.author} a **débanni** [\`${bannedUser.username}\`](https://discord.com/users/${bannedUser.id})`);

            message.guild.channels.cache.get(client.db.get(`modlogs_${message.guild.id}`))?.send({ embeds: [Embed] });
        }).catch(async (error) => {
            console.error('Error unbanning user:', error);
            await message.channel.send(`<@${user}> n'existe pas ou est déjà débanni`);
        });
    }
};