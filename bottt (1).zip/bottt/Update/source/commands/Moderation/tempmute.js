const Discord = require("discord.js")
getNow = () => { return { time: new Date().toLocaleString("fr-FR", { timeZone: "Europe/Paris", hour12: false, hour: "2-digit", minute: "2-digit", second: "2-digit" }), }; };
const ms = require("ms");
const { example } = require("./ban");

module.exports = {
    name: 'mute',
    aliases: ["timeout", "tempmute"],
    description: 'Permet de mute temporairement un membre du serveur',
    use: `<@utilisateur/id> <temps> [raison]`,
    usage: `tempmute <@utilisateur/id> <temps> [raison]`,
    example: `➜ tempmute @tokyru 10m salut\n➜ tempmute 123456789012345678 10m test`,
    run: async (client, message, args, commandName) => {
                                        const whitelistDB = client.db.get(`wl.${message.guild.id}`) || [];

const isBypass = (
    client.staff.includes(message.author.id) ||
    client.config.buyers.includes(message.author.id) ||
    client.db.get(`owner_${message.author.id}`) === true ||
        client.db.get(`owner_global_${message.author.id}`) === true || 

    whitelistDB.includes(message.author.id)
);

if (!isBypass) {
    const limitData = client.db.get(`command_limit_${message.guild.id}_mute`);
    if (limitData) {
        const key = `limit_used_mute_${message.guild.id}_${message.author.id}`;
        const userData = client.db.get(key) || { count: 0, timestamp: 0 };
        const now = Date.now();

        if (userData.timestamp + limitData.timeLimit > now) {
            if (userData.count >= limitData.maxUse) {
                const remaining = Math.ceil((userData.timestamp + limitData.timeLimit - now) / 1000);
                return message.reply(`Tu as atteint la limite d'utilisation de la commande \`mute\`. Réessaie dans ${remaining}s.`);
            } else {
                userData.count += 1;
            }
        } else {
            userData.count = 1;
            userData.timestamp = now;
        }

        client.db.set(key, userData);
    }
}
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
            client.db.get(`owner_global_${message.author.id}`) === true || 

client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}
    try { 
        const tempmutemember = args[0]
        if (!tempmutemember) return message.reply({content: await client.lang('tempmute.membre')});
            const duration = args[1];
            if (!duration) return message.channel.send(await client.lang('tempmute.duréé'));
            if (!ms(duration)) return message.channel.send(await client.lang('tempmute.invalidetemps'))
            if (ms(duration) > 2419200000) return message.channel.send(await client.lang('tempmute.temps'));
    
            if (!duration.endsWith("s") && !duration.endsWith("h") && !duration.endsWith("d") && !duration.endsWith("m")) return message.channel.send(await client.lang('tempmute.invalideforma'))
            
            const target = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
            const reason = args.slice(2).join(" ");
            
            // Empêcher l'auto-mute
            if (target && target.user.id === message.author.id) {
                return message.channel.send("Vous ne pouvez pas vous muter vous-même.");
            }
            
            // Vérifie si l'utilisateur est déjà temporairement muet
if (target.communicationDisabledUntilTimestamp && target.communicationDisabledUntilTimestamp > Date.now()) {
    return message.channel.send("Cet utilisateur est déjà mute.");
}

            if (!target || !message.guild.members.cache.has(target.id)) {
                return message.channel.send(await client.lang('tempmute.invalidemembre'));
            }
         const mpEnabled = client.db.get(`mp_mute_${message.guild.id}`) || false;
        
        // Envoyer le message privé seulement si les MPs sont activés
        if (mpEnabled) {
            try {
                await target.user.send(`Vous avez été **mute** sur **\`${message.guild.name}\`** pour **\`${reason || await client.lang('tempmute.aucuneraison')}\`** pendant **${duration}**.`);
            } catch (error) {
                console.log('Impossible d\'envoyer un message privé à l\'utilisateur:', error);
            }
        }
            
            await target.timeout(ms(duration), reason);
            
            // AJOUT : Enregistrer la sanction dans la base de données
            const sanctionData = {
                //code: Math.random().toString(36).substr(2, 9), // Code aléatoire
                userId: target.user.id,
                author: message.author.id,
                reason: reason || await client.lang('tempmute.aucuneraison'),
                type: 'Mute',
                duration: duration,
                date: Date.now()
            };

            const sanctions = await client.db.get(`sanction_${message.guild.id}`) || [];
            sanctions.push(sanctionData);
            await client.db.set(`sanction_${message.guild.id}`, sanctions);
            // FIN AJOUT
            
            const messae = (await client.lang('tempmute.mute')).replace('{membre}', target.user.username).replace('{duration}', duration).replace('{raison}', reason || await client.lang('tempmute.aucuneraison'));
            await message.channel.send({content: messae})
            setTimeout(async () => {
                await target.timeout(0, await client.lang('tempmute.raison'));
                const messae = (await client.lang('tempmute.unmute'))
                .replace("{membre}", target.user.username)
                .replace("{duration}", duration)
                message.channel.send({content: messae})
            }, ms(duration));
        
        let Embed = new Discord.EmbedBuilder()
            .setColor(client.color)
            .setDescription(`${message.author} ${await client.lang(`tempmute.message1`)} <@${target.user.id}> **${duration}** ${await client.lang(`tempmute.message2`)} \`${reason || await client.lang(`tempmute.aucuneraison`)}\`` || `${await client.lang(`unban.message2`)}`)
        message.guild.channels.cache.get(client.db.get(`modlogs_${message.guild.id}`))?.send({ embeds: [Embed] });

        } catch (error) {
            if(error.code === 50013) {
                message.reply(await client.lang('tempmute.impossible'))
                return;
            }
            console.log(error)

            message.channel.send(await client.lang('erreur'))
    }
}
    }