const Discord = require('discord.js');
const { example } = require('./ban');

module.exports = {
    name: "kick",
    description: "Permet d'expulser l'utilisateur mentionné",
    usages: "kick <@utilisateur/id>",
    use: "<@utilisateur/id>",
    example: "➜ kick @tokyru\n➜ kick 123456789012345678",
    run: async (client, message, args, commandName) => {
                const whitelistDB = client.db.get(`wl.${message.guild.id}`) || [];

const isBypass = (
    client.staff.includes(message.author.id) ||
    client.config.buyers.includes(message.author.id) ||
    client.db.get(`owner_${message.author.id}`) === true ||
        client.db.get(`owner_global_${message.author.id}`) === true || 

    whitelistDB.includes(message.author.id)
);

if (!isBypass) {
    const limitData = client.db.get(`command_limit_${message.guild.id}_kick`);
    if (limitData) {
        const key = `limit_used_kick_${message.guild.id}_${message.author.id}`;
        const userData = client.db.get(key) || { count: 0, timestamp: 0 };
        const now = Date.now();

        if (userData.timestamp + limitData.timeLimit > now) {
            if (userData.count >= limitData.maxUse) {
                const remaining = Math.ceil((userData.timestamp + limitData.timeLimit - now) / 1000);
                return message.reply(`Tu as atteint la limite d'utilisation de la commande \`kick\`. Réessaie dans ${remaining}s.`);
            } else {
                userData.count += 1;
            }
        } else {
            userData.count = 1;
            userData.timestamp = now;
        }

        client.db.set(key, userData);
    }
}
        let pass = false;

        // Autoriser automatiquement les staff, buyers, et owners
        if (client.staff.includes(message.author.id) || 
            client.config.buyers.includes(message.author.id) ||
                client.db.get(`owner_global_${message.author.id}`) === true || 

    client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {               pass = true;
        } else {
            // Vérifier les permissions personnalisées pour la commande
            const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
            if (commandPerms.length > 0) {
                const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                const userRoles = message.member.roles.cache.map(role => role.id);
                // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
                pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
            } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                // Conserver la compatibilité avec le mode "public"
                pass = true;
            }
        }

        // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        let user = message.mentions.users.first();
        let memberId = args[0];

        if (!user && memberId) {
            try {
                user = await client.users.fetch(memberId);
            } catch (error) {
                console.error('Error fetching user:', error);
            }
        }

        if (!user) {
            return message.channel.send(await client.lang(`kick.user`));
        }
        if (user.id === message.author.id) {
            return message.channel.send("Vous ne pouvez pas vous kick vous-même.");
        }

        let reason = args.slice(1).join(' ') || await client.lang(`kick.aucuneraison`);

        if (client.db.get(`owner_${user.id}`) === true || client.config.buyers.includes(user.id)) {
            return message.channel.send(await client.lang(`kick.pasexpulser`));
        }

        // Créer l'objet sanctionData pour la base de données
        const sanctionData = {
            userId: user.id,
            author: message.author.id,
            reason: reason,
            type: 'Kick',
            date: Date.now()
        };

        let kickedUser;
        try {
            kickedUser = await client.users.fetch(user);

            // Vérifier si les MPs sont activés pour l'action "kick"
            const mpEnabled = client.db.get(`mp_kick_${message.guild.id}`) || false;

            // Envoyer le message privé seulement si les MPs sont activés
            if (mpEnabled) {
                try {
                    await kickedUser.send(`Vous avez été **kick** sur **\`${message.guild.name}\`** pour **\`${reason}\`**.`);
                } catch (error) {
                    console.log('Impossible d\'envoyer un message privé à l\'utilisateur:', error);
                }
            }

            // Expulser l'utilisateur
            await message.guild.members.kick(user, reason);

            // Enregistrer la sanction dans la base de données
            const sanctions = await client.db.get(`sanction_${message.guild.id}`) || [];
            sanctions.push(sanctionData);
            await client.db.set(`sanction_${message.guild.id}`, sanctions);

            // Envoyer le message de confirmation
            message.channel.send(`**${kickedUser.username}** ${await client.lang(`kick.kick`)} \`${reason}\``);

            // Envoyer le log dans le canal de modération
            let embed = new Discord.EmbedBuilder()
                .setColor(client.color)
                .setDescription(`${message.author} ${await client.lang(`kick.akick`)} \`${kickedUser.username}\` ${await client.lang(`kick.rkick`)} \`${reason}\``);

            message.guild.channels.cache.get(client.db.get(`modlogs_${message.guild.id}`))?.send({ embeds: [embed] });
        } catch (error) {
            console.error('Error kicking user:', error);
            message.channel.send(await client.lang(`erreur`));
        }
    }
};