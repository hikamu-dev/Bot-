// commands/moderation/warnpanel.js
// Panel de configuration des paliers de sanctions pour les warns (auto-refresh).
//
// DB :
//  warn_rules_<guildId> : [{ count:number, action:"note"|"mute"|"kick"|"ban", duration?:string }]
//  warn_note_<guildId>  : string (message pour l'action "note")
//
// Actions possibles : note | mute | kick | ban
// Pour mute, la durée est optionnelle mais recommandée (ex: "15m", "1h").
// L'embed + les boutons se rafraîchissent après CHAQUE interaction.

const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  EmbedBuilder,
} = require("discord.js");

module.exports = {
  name: "warnpanel",
  description: "Ouvre le panel de configuration des paliers de sanctions pour les warns.",
  usages: "warnpanel",
  example: "warnpanel",
  /**
   * @param {import('discord.js').Client} client
   * @param {import('discord.js').Message} message
   */
  run: async (client, message, args, commandName = "warnpanel") => {
    try {
      if (!message.guild) return;

      // ---- Permissions (même logique que tes autres cmd) ----
      const whitelistDB = client.db.get(`wl.${message.guild.id}`) || [];
      const isBypassHard =
        client.staff?.includes?.(message.author.id) ||
        client.config?.buyers?.includes?.(message.author.id) ||
        client.db.get(`owner_${message.author.id}`) === true ||
        client.db.get(`owner_global_${message.author.id}`) === true ||
        whitelistDB.includes(message.author.id) ||
        message.guild.ownerId === message.author.id;

      let pass = isBypassHard;
      if (!pass) {
        const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
        if (commandPerms.length > 0) {
          const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
          const userRoles = message.member.roles.cache.map(r => r.id);
          pass = commandPerms.some(perm => userPerms[perm]?.some?.(roleId => userRoles.includes(roleId)));
        } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") pass = true;
      }
      if (!pass) {
        if (client.noperm && client.noperm.trim() !== "") {
          const sent = await message.channel.send({ content: client.noperm, allowedMentions: { parse: [] } });
          const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
          if (delayTime > 0) setTimeout(() => sent.delete().catch(() => {}), delayTime * 1000);
        }
        return;
      }

      const gId = message.guild.id;
      const rulesKey = `warn_rules_${gId}`;
      const noteKey  = `warn_note_${gId}`;

      // ---- Helpers DB (toujours frais) ----
      const getRules = () => {
        const arr = client.db.get(rulesKey) || [];
        return arr
          .map(r => ({ count: Number(r.count), action: String(r.action || "").toLowerCase(), duration: r.duration }))
          .filter(r => Number.isInteger(r.count) && r.count >= 1 && ["note","mute","kick","ban"].includes(r.action))
          .sort((a, b) => a.count - b.count);
      };
      const getNote = () =>
        client.db.get(noteKey) ||
        "Tu as atteint un palier d'avertissements. Merci de respecter les règles du serveur.";

      // ---- UI builders (lisent l'état ACTUEL) ----
      const baseEmbed = () => {
        const rules = getRules();
        const noteMsg = getNote();

        const lines = rules.length
          ? rules.map(r => {
              const dur = r.action === "mute" && r.duration ? ` (${r.duration})` : "";
              return `• **${r.count}** → **${r.action.toUpperCase()}**${dur}`;
            }).join("\n")
          : "_Aucun palier défini._";

        return new EmbedBuilder()
          .setColor(client.color || 0xffc107)
          .setTitle("⚙️ Configuration des paliers de warn")
          .setDescription([
            "Ajoute autant de paliers que tu veux. Rien n’est prédéfini.",
            "",
            "**Paliers actuels :**",
            lines,
            "",
            `**Message d'avertissement (action NOTE)** :\n> ${noteMsg}`,
          ].join("\n"))
          .setFooter({ text: "Actions : Ajouter, Lister, Supprimer, Vider, Config NOTE, Fermer" });
      };

      const panelId = `warnpanel_${message.id}_${Date.now()}`;
      const makeRows = () => {
        const row1 = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId(`${panelId}:add`).setLabel("➕ Ajouter").setStyle(ButtonStyle.Success),
          new ButtonBuilder().setCustomId(`${panelId}:list`).setLabel("📋 Lister").setStyle(ButtonStyle.Secondary),
          new ButtonBuilder().setCustomId(`${panelId}:del`).setLabel("🗑️ Supprimer").setStyle(ButtonStyle.Danger),
        );
        const row2 = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId(`${panelId}:clear`).setLabel("♻️ Vider tout").setStyle(ButtonStyle.Danger),
          new ButtonBuilder().setCustomId(`${panelId}:note`).setLabel("✉️ Config NOTE").setStyle(ButtonStyle.Primary),
          new ButtonBuilder().setCustomId(`${panelId}:close`).setLabel("❌ Fermer").setStyle(ButtonStyle.Secondary),
        );
        return [row1, row2];
      };

      // ---- Envoi initial + utilitaire refresh ----
      const panelMsg = await message.channel.send({
        embeds: [baseEmbed()],
        components: makeRows(),
        allowedMentions: { parse: [] }
      });

      async function refresh() {
        try {
          await panelMsg.edit({ embeds: [baseEmbed()], components: makeRows() });
        } catch {}
      }

      // ---- Collector boutons ----
      const collector = panelMsg.createMessageComponentCollector({ time: 10 * 60 * 1000 });

      collector.on("collect", async (itx) => {
        if (itx.user.id !== message.author.id) {
          return itx.reply({ content: "Seul l'initiateur peut utiliser ce panel.", ephemeral: true });
        }
        const [pid, action] = (itx.customId || "").split(":");
        if (pid !== panelId) return;

        // ADD → modale
        if (action === "add") {
          const modal = new ModalBuilder()
            .setCustomId(`${panelId}:addmodal`)
            .setTitle("Ajouter un palier");

          const tiCount = new TextInputBuilder()
            .setCustomId("count")
            .setLabel("Nombre de warns (ex: 2, 4, 6…)")
            .setStyle(TextInputStyle.Short)
            .setPlaceholder("ex: 2")
            .setRequired(true);

          const tiAction = new TextInputBuilder()
            .setCustomId("action")
            .setLabel("Action (note | mute | kick | ban)")
            .setStyle(TextInputStyle.Short)
            .setPlaceholder("note / mute / kick / ban")
            .setRequired(true);

          const tiDuration = new TextInputBuilder()
            .setCustomId("duration")
            .setLabel("Durée (si action = mute, ex: 15m, 1h)")
            .setStyle(TextInputStyle.Short)
            .setPlaceholder("laisser vide si non applicable")
            .setRequired(false);

          modal.addComponents(
            new ActionRowBuilder().addComponents(tiCount),
            new ActionRowBuilder().addComponents(tiAction),
            new ActionRowBuilder().addComponents(tiDuration),
          );

          await itx.showModal(modal);
          return;
        }

        // LIST → ping ephemeral
        if (action === "list") {
          const rules = getRules();
          await itx.reply({
            content: rules.length ? "Les paliers sont affichés dans l’embed du panel." : "Aucun palier pour l’instant.",
            ephemeral: true
          });
          await refresh();
          return;
        }

        // DEL → menu pour choisir le palier (par count)
        if (action === "del") {
          const rules = getRules();
          if (!rules.length) return itx.reply({ content: "Aucun palier à supprimer.", ephemeral: true });

          const select = new StringSelectMenuBuilder()
            .setCustomId(`${panelId}:delmenu`)
            .setPlaceholder("Choisis un palier à supprimer")
            .addOptions(
              rules.map(r => ({
                label: `${r.count} → ${r.action.toUpperCase()}${r.action === "mute" && r.duration ? ` (${r.duration})` : ""}`,
                value: String(r.count),
              }))
            );

          const row = new ActionRowBuilder().addComponents(select);
          return itx.reply({ content: "Sélectionne un palier :", components: [row], ephemeral: true });
        }

        // CLEAR → vide la liste
        if (action === "clear") {
          client.db.set(rulesKey, []);
          await itx.deferUpdate();
          await refresh();
          return;
        }

        // NOTE → modale pour le message
        if (action === "note") {
          const modal = new ModalBuilder()
            .setCustomId(`${panelId}:notemodal`)
            .setTitle("Message d'avertissement (action NOTE)");

          const ti = new TextInputBuilder()
            .setCustomId("note")
            .setLabel("Message envoyé au membre")
            .setStyle(TextInputStyle.Paragraph)
            .setValue(getNote())
            .setRequired(true);

          modal.addComponents(new ActionRowBuilder().addComponents(ti));
          await itx.showModal(modal);
          return;
        }

        // CLOSE → ferme le panel
        if (action === "close") {
          collector.stop("closed");
          return itx.update({ components: [] });
        }
      });

      // ---- Listener local pour menus & modales ----
      const onInteraction = async (i) => {
        const [pid, what] = (i.customId || "").split(":");
        if (pid !== panelId) return;
        if (i.user.id !== message.author.id) return i.reply({ content: "Seul l'initiateur peut utiliser ce panel.", ephemeral: true });

        // Supprimer un palier (select)
        if (i.isStringSelectMenu() && what === "delmenu") {
          const value = Number(i.values?.[0]);
          const rules = getRules();
          const next = rules.filter(r => Number(r.count) !== value);
          client.db.set(rulesKey, next);

          await i.update({ content: `🗑️ Palier **${value}** supprimé.`, components: [] });
          await refresh();
          return;
        }

        // Ajouter un palier (modale)
        if (i.isModalSubmit() && what === "addmodal") {
          const count = Number(i.fields.getTextInputValue("count"));
          const action = String(i.fields.getTextInputValue("action") || "").toLowerCase().trim();
          const duration = String(i.fields.getTextInputValue("duration") || "").trim();

          if (!Number.isInteger(count) || count < 1) {
            return i.reply({ content: "Le **count** doit être un entier ≥ 1.", ephemeral: true });
          }
          if (!["note", "mute", "kick", "ban"].includes(action)) {
            return i.reply({ content: "Action invalide. Valeurs acceptées : `note`, `mute`, `kick`, `ban`.", ephemeral: true });
          }
          if (action === "mute" && !duration) {
            return i.reply({ content: "Pour `mute`, indique une **durée** (ex: `15m`, `1h`).", ephemeral: true });
          }

          // Upsert par count
          const rules = getRules();
          const has = rules.some(r => r.count === count);
          const entry = { count, action, ...(duration ? { duration } : {}) };

          let next;
          if (has) next = rules.map(r => (r.count === count ? entry : r));
          else {
            next = rules.concat(entry).sort((a,b)=>a.count-b.count);
          }
          client.db.set(rulesKey, next);

          await i.reply({ content: `✅ Palier **${count}** → **${action.toUpperCase()}** ${duration ? `(${duration})` : ""} enregistré.`, ephemeral: true });
          await refresh();
          return;
        }

        // Config NOTE (modale)
        if (i.isModalSubmit() && what === "notemodal") {
          const note = i.fields.getTextInputValue("note")?.trim();
          if (!note) return i.reply({ content: "Message vide.", ephemeral: true });

          client.db.set(noteKey, note);
          await i.reply({ content: "✅ Message d'avertissement mis à jour.", ephemeral: true });
          await refresh();
          return;
        }
      };

      client.on("interactionCreate", onInteraction);

      // ---- Fin du panel ----
      collector.on("end", async () => {
        try { await panelMsg.edit({ components: [] }); } catch {}
        client.removeListener("interactionCreate", onInteraction);
      });

    } catch (e) {
      console.error(e);
      message.channel.send({ content: "❌ Impossible d'ouvrir le panel de warn.", allowedMentions: { parse: [] } });
    }
  }
};
