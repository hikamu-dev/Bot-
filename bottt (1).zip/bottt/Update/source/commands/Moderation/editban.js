const Discord = require('discord.js');
const ms = require('ms');
const { example } = require('./ban');

module.exports = {
    name: "editban",
    description: "Permet de modifier la raison et/ou le temps d'un bannissement existant",
    use: "<@utilisateur/id> [nouveau_temps] <nouvelle_raison>",
    usages: "editban <@utilisateur/id> [nouveau_temps] <nouvelle_raison>",
    example: "➜ editban @tokyru 10m salut\n➜ editban 123456789012345678 10m raison inchangée",
    run: async (client, message, args, commandName) => {
        const whitelistDB = client.db.get(`wl.${message.guild.id}`) || [];

const isBypass = (
    client.staff.includes(message.author.id) ||
    client.config.buyers.includes(message.author.id) ||
    client.db.get(`owner_${message.author.id}`) === true ||
        client.db.get(`owner_global_${message.author.id}`) === true || 

    whitelistDB.includes(message.author.id)
);

if (!isBypass) {
    const limitData = client.db.get(`command_limit_${message.guild.id}_editban`);
    if (limitData) {
        const key = `limit_used_editban_${message.guild.id}_${message.author.id}`;
        const userData = client.db.get(key) || { count: 0, timestamp: 0 };
        const now = Date.now();

        if (userData.timestamp + limitData.timeLimit > now) {
            if (userData.count >= limitData.maxUse) {
                const remaining = Math.ceil((userData.timestamp + limitData.timeLimit - now) / 1000);
                return message.reply(`Tu as atteint la limite d'utilisation de la commande \`editban\`. Réessaie dans ${remaining}s.`);
            } else {
                userData.count += 1;
            }
        } else {
            userData.count = 1;
            userData.timestamp = now;
        }

        client.db.set(key, userData);
    }
}
        let pass = false;

        if (client.staff.includes(message.author.id) ||
            client.config.buyers.includes(message.author.id) ||
                client.db.get(`owner_global_${message.author.id}`) === true || 

    client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {               pass = true;
        } else {
            const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
            if (commandPerms.length > 0) {
                const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                const userRoles = message.member.roles.cache.map(role => role.id);
                pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
            } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                pass = true;
            }
        }

if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        let user = message.mentions.users.first();
        let memberId = args[0];

        if (!user && memberId) {
            try {
                user = await client.users.fetch(memberId);
            } catch (error) {
                console.error('Erreur lors de la récupération de l\'utilisateur:', error);
            }
        }

        if (!user) {
            return message.channel.send("Vous devez mentionner un utilisateur ou donner l'identifiant.");
        }

        // Analyser les arguments pour déterminer s'il y a un temps et une raison
        let newDuration = null;
        let newReason = null;
        
        // Vérifier si le deuxième argument est un temps valide
        if (args[1] && /^\d+[smhd]$/.test(args[1])) {
            newDuration = args[1];
            newReason = args.slice(2).join(' ');
        } else {
            // Sinon, tout est considéré comme la raison
            newReason = args.slice(1).join(' ');
        }

        if (!newReason && !newDuration) {
            return message.channel.send("Vous devez spécifier une nouvelle raison et/ou un nouveau temps.");
        }

        try {
            // Vérifier si l'utilisateur est banni
            const banList = await message.guild.bans.fetch();
            const bannedUser = banList.get(user.id);
            
            if (!bannedUser) {
                return message.channel.send(`**\`${user.username}\`** n'est pas banni de ce serveur.`);
            }

            // Récupérer les sanctions existantes
            const sanctions = await client.db.get(`sanction_${message.guild.id}`) || [];
            
            // Trouver la sanction de ban correspondante (la plus récente)
            let sanctionIndex = -1;
            let latestBanDate = 0;
            
            for (let i = 0; i < sanctions.length; i++) {
                const sanction = sanctions[i];
                if (sanction.userId === user.id && 
                    (sanction.type === 'Ban' || sanction.type === 'Tempban' || 
                     sanction.reason.toLowerCase().includes('ban')) &&
                    sanction.date > latestBanDate) {
                    sanctionIndex = i;
                    latestBanDate = sanction.date;
                }
            }

            if (sanctionIndex === -1) {
                return message.channel.send(`Aucune sanction de ban trouvée dans la base de données pour **\`${user.username}\`**.`);
            }

            // Sauvegarder les anciennes valeurs
            const oldReason = sanctions[sanctionIndex].reason;
            const oldDuration = sanctions[sanctionIndex].duration;
            const oldEndTime = sanctions[sanctionIndex].endTime;
            
            // Mettre à jour la raison si fournie
            if (newReason) {
                sanctions[sanctionIndex].reason = newReason;
            }
            
            // Mettre à jour la durée si fournie
            if (newDuration) {
                const durationInMs = ms(newDuration);
                const newEndTime = Date.now() + durationInMs;
                
                sanctions[sanctionIndex].duration = newDuration;
                sanctions[sanctionIndex].endTime = newEndTime;
                sanctions[sanctionIndex].type = 'Tempban'; // Changer le type en tempban
                
                // Programmer le déban automatique
                setTimeout(async () => {
                    try {
                        await message.guild.members.unban(user.id, "Fin du bannissement temporaire");
                        
                        // Supprimer la sanction de la base de données
                        const currentSanctions = await client.db.get(`sanction_${message.guild.id}`) || [];
                        const updatedSanctions = currentSanctions.filter(s => 
                            !(s.userId === user.id && s.endTime === newEndTime)
                        );
                        await client.db.set(`sanction_${message.guild.id}`, updatedSanctions);
                        
                        // Log du déban automatique
                        const unbanEmbed = new Discord.EmbedBuilder()
                            .setColor("#00FF00")
                            .setDescription(`<@${user.id}> a été automatiquement débanni (fin du tempban)`);
                        
                        message.guild.channels.cache.get(client.db.get(`modlogs_${message.guild.id}`))?.send({ embeds: [unbanEmbed] });
                        
                    } catch (error) {
                        console.error('Erreur lors du déban automatique:', error);
                    }
                }, durationInMs);
            }
            
            // Mettre à jour les métadonnées
            sanctions[sanctionIndex].editedBy = message.author.id;
            sanctions[sanctionIndex].editedAt = Date.now();
            
            // S'assurer que le type est bien défini
            if (!sanctions[sanctionIndex].type) {
                sanctions[sanctionIndex].type = newDuration ? 'Tempban' : 'Ban';
            }
            
            await client.db.set(`sanction_${message.guild.id}`, sanctions);

            // Mettre à jour la raison du ban Discord si la raison a changé
            if (newReason && newReason !== oldReason) {
                await message.guild.members.unban(user.id, "Mise à jour de la raison");
                await message.guild.members.ban(user, { reason: newReason });
            }
const shortResponse = `Le bannissement de <@${user.id}> a été modifié raison: \`${newReason || 'inchangée'}\`  temps: \`${newDuration || 'permanent'}\``;
message.channel.send(shortResponse);

            // Log dans le canal de modération
            let embedDescription = `${message.author} a modifié le bannissement de <@${user.id}>\n`;
            
            if (newReason) {
                embedDescription += `**Ancienne raison :** \`${oldReason || 'Non spécifiée'}\`\n`;
                embedDescription += `**Nouvelle raison :** \`${newReason}\`\n`;
            }
            
            if (newDuration) {
                embedDescription += `**Ancienne durée :** \`${oldDuration || 'Permanente'}\`\n`;
                embedDescription += `**Nouvelle durée :** \`${newDuration}\`\n`;
                embedDescription += `**Nouvelle fin :** <t:${Math.floor(sanctions[sanctionIndex].endTime / 1000)}:F>`;
            }

            const embed = new Discord.EmbedBuilder()
                .setColor(client.color)
                .setDescription(embedDescription);

            message.guild.channels.cache.get(client.db.get(`modlogs_${message.guild.id}`))?.send({ embeds: [embed] });

            // Envoyer un message privé à l'utilisateur si les MPs sont activés
            const mpEnabled = client.db.get(`mp_ban_${message.guild.id}`) || false;
            
            if (mpEnabled) {
                try {
                    let dmMessage = `Votre bannissement sur **\`${message.guild.name}\`** a été modifié.\n`;
                    if (newReason) {
                        dmMessage += `**Nouvelle raison :** \`${newReason}\`\n`;
                    }
                    if (newDuration) {
                        dmMessage += `**Nouvelle durée :** \`${newDuration}\`\n`;
                        dmMessage += `**Nouvelle fin :** <t:${Math.floor(sanctions[sanctionIndex].endTime / 1000)}:F>`;
                    }
                    
                    await user.send(dmMessage);
                } catch (error) {
                    console.log('Impossible d\'envoyer un message privé à l\'utilisateur:', error);
                }
            }

        } catch (error) {
            console.error('Erreur lors de la modification du bannissement:', error);
            message.channel.send("Une erreur s'est produite lors de la modification du bannissement.");
        }
    }
};