module.exports = {
    name: 'cancelunbanall',
    description: 'Annule l\'unbanall de tous les bans.',
    usage: 'cancelunbanall',
    run: async (client, message) => {
const whitelistDB = client.db.get(`wl.${message.guild.id}`) || [];

const isBypass = (
    client.staff.includes(message.author.id) ||
    client.config.buyers.includes(message.author.id) ||
    client.db.get(`owner_${message.author.id}`) === true ||
        client.db.get(`owner_global_${message.author.id}`) === true || 
    whitelistDB.includes(message.author.id)
);

if (!isBypass) {
    const limitData = client.db.get(`command_limit_${message.guild.id}_cancelunbanall`);
    if (limitData) {
        const key = `limit_used_cancelunbanall_${message.guild.id}_${message.author.id}`;
        const userData = client.db.get(key) || { count: 0, timestamp: 0 };
        const now = Date.now();

        if (userData.timestamp + limitData.timeLimit > now) {
            if (userData.count >= limitData.maxUse) {
                const remaining = Math.ceil((userData.timestamp + limitData.timeLimit - now) / 1000);
                return message.reply(`Tu as atteint la limite d'utilisation de la commande \`cancelunbanall\`. Réessaie dans ${remaining}s.`);
            } else {
                userData.count += 1;
            }
        } else {
            userData.count = 1;
            userData.timestamp = now;
        }

        client.db.set(key, userData);
    }
}
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
            client.db.get(`owner_global_${message.author.id}`) === true || 

client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}
        const unbanall = client.db.get(`unbanall_${message.guild.id}`);

        if (!unbanall || unbanall.length === 0) {
            return message.reply({ content: "Aucun ban n'a été annulé récemment.", allowedMentions: { repliedUser: false } });
        }

        try {
            unbanall.forEach(async (user) => {
                await message.guild.members.ban(user.id);
            });

            client.db.delete(`unbanall_${message.guild.id}`);

            return message.reply({ content: "L'annulation des bans a été annulée avec succès.", allowedMentions: { repliedUser: false } });
        } catch (error) {
            console.error(error);
            message.reply(await client.lang('erreur'));
        }
    }
};
