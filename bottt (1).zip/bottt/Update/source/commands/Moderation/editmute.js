const Discord = require("discord.js");
const ms = require("ms");
const { example } = require("./ban");

module.exports = {
    name: 'editmute',
    description: 'Permet de modifier la raison et/ou le temps d\'un mute existant',
    use: `<@utilisateur/id> [nouveau_temps] <nouvelle_raison>`,
    usage: `editmute <@utilisateur/id> [nouveau_temps] <nouvelle_raison>`,
    example: `➜ editmute @tokyru 10m salut\n➜ editmute 123456789012345678 10m raison inchangée`,
    run: async (client, message, args, commandName) => {
                const whitelistDB = client.db.get(`wl.${message.guild.id}`) || [];

const isBypass = (
    client.staff.includes(message.author.id) ||
    client.config.buyers.includes(message.author.id) ||
    client.db.get(`owner_${message.author.id}`) === true ||
        client.db.get(`owner_global_${message.author.id}`) === true || 

    whitelistDB.includes(message.author.id)
);

if (!isBypass) {
    const limitData = client.db.get(`command_limit_${message.guild.id}_editmute`);
    if (limitData) {
        const key = `limit_used_editmute_${message.guild.id}_${message.author.id}`;
        const userData = client.db.get(key) || { count: 0, timestamp: 0 };
        const now = Date.now();

        if (userData.timestamp + limitData.timeLimit > now) {
            if (userData.count >= limitData.maxUse) {
                const remaining = Math.ceil((userData.timestamp + limitData.timeLimit - now) / 1000);
                return message.reply(`Tu as atteint la limite d'utilisation de la commande \`editmute\`. Réessaie dans ${remaining}s.`);
            } else {
                userData.count += 1;
            }
        } else {
            userData.count = 1;
            userData.timestamp = now;
        }

        client.db.set(key, userData);
    }
}
        let pass = false;

        // Autoriser automatiquement les staff, buyers, et owners
        if (client.staff.includes(message.author.id) || 
            client.config.buyers.includes(message.author.id) ||
                client.db.get(`owner_global_${message.author.id}`) === true || 
 
    client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {               pass = true;
        } else {
            // Vérifier les permissions personnalisées pour la commande
            const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
            if (commandPerms.length > 0) {
                const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                const userRoles = message.member.roles.cache.map(role => role.id);
                // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
                pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
            } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                // Conserver la compatibilité avec le mode "public"
                pass = true;
            }
        }

        // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        try {
            const target = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
            
            if (!target) {
                return message.channel.send("Vous devez mentionner un utilisateur ou donner l'identifiant.");
            }

            // Vérifier si l'utilisateur est actuellement mute
            if (!target.communicationDisabledUntilTimestamp || target.communicationDisabledUntilTimestamp <= Date.now()) {
                return message.channel.send(`**\`${target.user.username}\`** n'est pas actuellement mute.`);
            }

            // Analyser les arguments pour déterminer s'il y a un temps et une raison
            let newDuration = null;
            let newReason = null;
            
            // Vérifier si le deuxième argument est un temps valide
            if (args[1] && ms(args[1])) {
                newDuration = args[1];
                newReason = args.slice(2).join(' ');
            } else {
                // Sinon, tout est considéré comme la raison
                newReason = args.slice(1).join(' ');
            }

            if (!newReason && !newDuration) {
                return message.channel.send("Vous devez spécifier une nouvelle raison et/ou un nouveau temps.");
            }

            // Vérifications pour la durée si elle est fournie
            if (newDuration) {
                if (ms(newDuration) > 2419200000) {
                    return message.channel.send("La durée ne peut pas dépasser 28 jours.");
                }
                if (!newDuration.endsWith("s") && !newDuration.endsWith("h") && !newDuration.endsWith("d") && !newDuration.endsWith("m")) {
                    return message.channel.send("Format de temps invalide. Utilisez s, m, h, ou d.");
                }
            }

            // Récupérer les sanctions existantes
            const sanctions = await client.db.get(`sanction_${message.guild.id}`) || [];
            
            // Trouver la sanction de mute correspondante (la plus récente qui est encore active)
            let sanctionIndex = -1;
            let latestMuteDate = 0;
            
            for (let i = 0; i < sanctions.length; i++) {
                const sanction = sanctions[i];
                if (sanction.userId === target.user.id && 
                    (sanction.type === 'Mute' || sanction.reason.toLowerCase().includes('mute')) &&
                    sanction.date > latestMuteDate) {
                    sanctionIndex = i;
                    latestMuteDate = sanction.date;
                }
            }

            if (sanctionIndex === -1) {
                return message.channel.send(`Aucune sanction de mute trouvée dans la base de données pour **\`${target.user.username}\`**.`);
            }

            // Sauvegarder les anciennes valeurs
            const oldReason = sanctions[sanctionIndex].reason;
            const oldDuration = sanctions[sanctionIndex].duration;
            
            // Mettre à jour les données dans la base de données
            if (newReason) {
                sanctions[sanctionIndex].reason = newReason;
            }
            if (newDuration) {
                sanctions[sanctionIndex].duration = newDuration;
                // Mettre à jour la date de la sanction pour recalculer correctement la fin
                sanctions[sanctionIndex].date = Date.now();
            }
            
            // Ajouter les informations de modification
            sanctions[sanctionIndex].editedBy = message.author.id;
            sanctions[sanctionIndex].editedAt = Date.now();
            
            // S'assurer que le type est bien défini
            if (!sanctions[sanctionIndex].type) {
                sanctions[sanctionIndex].type = 'Mute';
            }
            
            await client.db.set(`sanction_${message.guild.id}`, sanctions);

            // Appliquer le nouveau mute avec les nouvelles valeurs
            const finalDuration = newDuration ? ms(newDuration) : (target.communicationDisabledUntilTimestamp - Date.now());
            const finalReason = newReason || oldReason;
            
            // Retirer le mute actuel puis appliquer le nouveau
            await target.timeout(null);
            await target.timeout(finalDuration, finalReason);

            // Construire le message de réponse
const shortResponse = `Le mute de <@${target.user.id}> a été modifié raison: \`${newReason || 'inchangée'}\` temps: \`${newDuration || 'inchangé'}\``;
message.channel.send(shortResponse);

            // Log dans le canal de modération
            let embedDescription = `${message.author} a modifié le mute de <@${target.user.id}>\n`;
            
            if (newReason) {
                embedDescription += `**Ancienne raison :** \`${oldReason}\`\n**Nouvelle raison :** \`${newReason}\`\n`;
            }
            
            if (newDuration) {
                embedDescription += `**Ancienne durée :** \`${oldDuration}\`\n**Nouvelle durée :** \`${newDuration}\`\n`;
                embedDescription += `**Nouvelle fin :** <t:${Math.floor((Date.now() + ms(newDuration)) / 1000)}:F>`;
            }

            const embed = new Discord.EmbedBuilder()
                .setColor(client.color)
                .setDescription(embedDescription);

            message.guild.channels.cache.get(client.db.get(`modlogs_${message.guild.id}`))?.send({ embeds: [embed] });

            // Envoyer un message privé à l'utilisateur si les MPs sont activés
            const mpEnabled = client.db.get(`mp_mute_${message.guild.id}`) || false;
            
            if (mpEnabled) {
                try {
                    let dmMessage = `Votre mute sur **\`${message.guild.name}\`** a été modifié.\n`;
                    if (newReason) {
                        dmMessage += `**Nouvelle raison :** \`${newReason}\`\n`;
                    }
                    if (newDuration) {
                        dmMessage += `**Nouvelle durée :** \`${newDuration}\`\n`;
                        dmMessage += `**Nouvelle fin :** <t:${Math.floor((Date.now() + ms(newDuration)) / 1000)}:F>`;
                    }
                    
                    await target.user.send(dmMessage);
                } catch (error) {
                    console.log('Impossible d\'envoyer un message privé à l\'utilisateur:', error);
                }
            }

        } catch (error) {
            if (error.code === 50013) {
                message.reply("Je n'ai pas les permissions nécessaires pour modifier ce mute.");
                return;
            }
            console.log(error);
            message.channel.send("Une erreur s'est produite lors de la modification du mute.");
        }
    }
};