const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'derank',
    description: "Enlève tous les rôles d'un utilisateur, sauf ceux protégés par noderank",
    usage: 'derank <@membre/id>',
    use: "<@membre/id>",
    example: "➜ derank @tokyru",
    run: async (client, message, args, commandName) => {
        const whitelistDB = client.db.get(`wl.${message.guild.id}`) || [];

const isBypass = (
    client.staff.includes(message.author.id) ||
    client.config.buyers.includes(message.author.id) ||
    client.db.get(`owner_${message.author.id}`) === true ||
        client.db.get(`owner_global_${message.author.id}`) === true || 

    whitelistDB.includes(message.author.id)
);

if (!isBypass) {
    const limitData = client.db.get(`command_limit_${message.guild.id}_derank`);
    if (limitData) {
        const key = `limit_used_derank_${message.guild.id}_${message.author.id}`;
        const userData = client.db.get(key) || { count: 0, timestamp: 0 };
        const now = Date.now();

        if (userData.timestamp + limitData.timeLimit > now) {
            if (userData.count >= limitData.maxUse) {
                const remaining = Math.ceil((userData.timestamp + limitData.timeLimit - now) / 1000);
                return message.reply(`Tu as atteint la limite d'utilisation de la commande \`derank\`. Réessaie dans ${remaining}s.`);
            } else {
                userData.count += 1;
            }
        } else {
            userData.count = 1;
            userData.timestamp = now;
        }

        client.db.set(key, userData);
    }
}
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
            client.db.get(`owner_global_${message.author.id}`) === true || 

client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        // Get member
        const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        if (!member) {
                return message.channel.send("Utilisation incorrecte : derank <@membre/id>");
        }

        // Check hierarchy
        if (member.roles.highest.comparePositionTo(message.guild.members.me.roles.highest) >= 0) {
            return message.channel.send("Impossible de derank ce membre car son rôle le plus élevé est au-dessus ou égal à celui du bot.");
        }

        // Get protected roles from noderank
        const protectedRoles = client.db.get(`noderank_roles_${message.guild.id}`) || [];
        const rolesToKeep = member.roles.cache.filter(role => protectedRoles.includes(role.id));

        // Vérifie si l'utilisateur booste le serveur et ajoute le rôle booster aux rôles à conserver
        const boosterRoleId = message.guild.roles.premiumSubscriberRole?.id;
        const hasBoosterRole = boosterRoleId && member.roles.cache.has(boosterRoleId);

        // Créer la liste des rôles à conserver
        const rolesToKeepIds = rolesToKeep.map(r => r.id);
        if (hasBoosterRole && !rolesToKeepIds.includes(boosterRoleId)) {
            rolesToKeepIds.push(boosterRoleId); // On garde le rôle booster
        }

        // Définir les rôles (conserver seulement les rôles protégés et le booster si applicable)
        member.roles.set(rolesToKeepIds)
            .then(async () => {
                let keptRolesText = '';
                
                // Message pour les rôles protégés par noderank
                if (rolesToKeep.size > 0) {
                    keptRolesText += ` (sauf ${rolesToKeep.map(r => `<${r.name}`).join(', ')} protégés par noderank`;
                }
                
                // Ajouter info sur le rôle booster si conservé
                if (hasBoosterRole) {
                    if (keptRolesText) {
                        keptRolesText += ' et le rôle booster)';
                    } else {
                        keptRolesText = ' (sauf le rôle booster)';
                    }
                } else if (keptRolesText) {
                    keptRolesText += ')';
                }

                // Vérifier si les MPs sont activés pour l'action "derank"
                const mpEnabled = client.db.get(`mp_derank_${message.guild.id}`) || false;
                
                // Envoyer le message privé seulement si les MPs sont activés
                if (mpEnabled) {
                    try {
                        await member.user.send(`Tous vos rôles ont été retirés sur **\`${message.guild.name}\`** \`${keptRolesText}\`.`);
                    } catch (dmError) {
                        console.log(`Impossible d'envoyer un MP à ${member.user.tag}: ${dmError.message}`);
                    }
                }

                await message.channel.send(`Tous les rôles ont été retirés à \`${member.user.username}\`${keptRolesText}.`);
                
                // Send modlog
                const embed = new EmbedBuilder()
                    .setColor(client.color)
                    .setDescription(`${message.author} a retiré tous les rôles de ${member} (https://discord.com/users/${member.id})${keptRolesText}.`)
                    .setTimestamp();

                const modlogChannel = message.guild.channels.cache.get(client.db.get(`modlogs_${message.guild.id}`));
                if (modlogChannel) {
                    modlogChannel.send({ embeds: [embed] }).catch(error => console.error('Error sending modlog:', error));
                }
            })
            .catch(error => {
                console.error('Error deranking member:', error);
                message.channel.send("Une erreur s'est produite lors du retrait des rôles.");
            });
    },
};