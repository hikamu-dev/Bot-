const ms = require('ms');
const Discord = require('discord.js');

module.exports = {
    name: "ban",
    description: "Permet de bannir l'utilisateur mentionné (temporairement ou définitivement)",
    use: "<@utilisateur/id> [durée] [raison]",
    usages: "ban <@utilisateur/id> [durée] [raison]",
    example: "➜ ban @tokyru 10m salut",
    run: async (client, message, args, commandName) => {
const whitelistDB = client.db.get(`wl.${message.guild.id}`) || [];

const isBypass = (
    client.staff.includes(message.author.id) ||
    client.config.buyers.includes(message.author.id) ||
    client.db.get(`owner_${message.author.id}`) === true ||
    client.db.get(`owner_global_${message.author.id}`) === true || 
    whitelistDB.includes(message.author.id)
);

if (!isBypass) {
    const limitData = client.db.get(`command_limit_${message.guild.id}_ban`);
    if (limitData) {
        const key = `limit_used_ban_${message.guild.id}_${message.author.id}`;
        const userData = client.db.get(key) || { count: 0, timestamp: 0 };
        const now = Date.now();

        if (userData.timestamp + limitData.timeLimit > now) {
            if (userData.count >= limitData.maxUse) {
                const remaining = Math.ceil((userData.timestamp + limitData.timeLimit - now) / 1000);
                return message.reply(`Tu as atteint la limite d'utilisation de la commande \`ban\`. Réessaie dans ${remaining}s.`);
            } else {
                userData.count += 1;
            }
        } else {
            userData.count = 1;
            userData.timestamp = now;
        }

        client.db.set(key, userData);
    }

        }        let pass = false;

        if (client.staff.includes(message.author.id) ||
        client.config.buyers.includes(message.author.id) ||
        client.db.get(`owner_global_${message.author.id}`) === true || 
client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {               
            pass = true;
        } else {
            const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
            if (commandPerms.length > 0) {
                const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                const userRoles = message.member.roles.cache.map(role => role.id);
                pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
            } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                pass = true;
            }
        }

if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        let user = message.mentions.users.first();
        let memberId = args[0];

        if (!user && memberId) {
            try {
                user = await client.users.fetch(memberId);
            } catch (error) {
                console.error('Erreur lors de la récupération de l\'utilisateur:', error);
            }
        }

        if (!user) {
            return message.channel.send("Vous devez mentionner un utilisateur ou donner l'identifiant.");
        }
        if (user.id === message.author.id) {
            return message.channel.send("Vous ne pouvez pas vous bannir vous-même.");
        }

        if (client.db.get(`owner_${user.id}`) === true || client.config.buyers.includes(user.id)) {
            return message.channel.send("Vous ne pouvez pas bannir cette personne.");
        }

        const rawTime = args[1];
        // Vérifier si rawTime existe et n'est pas vide avant d'utiliser ms()
        let isValidTime = false;
        let duration = null;
        
        if (rawTime && rawTime.trim() !== '') {
            try {
                isValidTime = ms(rawTime);
                duration = isValidTime ? rawTime : null;
            } catch (error) {
                console.error('Erreur lors de la conversion du temps:', error);
                isValidTime = false;
            }
        }

        const reason = args.slice(duration ? 2 : 1).join(' ') || await client.lang('tempmute.aucuneraison');

        const sanctionData = {
            userId: user.id,
            author: message.author.id,
            reason: reason,
            type: duration ? 'Tempban' : 'Ban',
            duration: duration || null,
            date: Date.now()
        };

        try {
            const mpEnabled = client.db.get(`mp_ban_${message.guild.id}`) || false;

            if (mpEnabled) {
                try {
                    await user.send(`Vous avez été **banni** du serveur **\`${message.guild.name}\`** pour **\`${reason}\`**${duration ? ` pendant **${duration}**` : ""}.`);
                } catch (err) {
                    console.log("Impossible d'envoyer le message privé:", err);
                }
            }

            await message.guild.members.ban(user, { reason });

            const sanctions = await client.db.get(`sanction_${message.guild.id}`) || [];
            sanctions.push(sanctionData);
            await client.db.set(`sanction_${message.guild.id}`, sanctions);

            message.channel.send(`**\`${user.username}\`** a été **banni** ${duration ? `temporairement (${duration})` : `définitivement`} pour \`${reason}\``);

            const embed = new Discord.EmbedBuilder()
                .setColor(client.color)
                .setDescription(`${message.author} a banni ${user.username} ${duration ? `temporairement (${duration})` : ''} pour \`${reason}\``);

            message.guild.channels.cache.get(client.db.get(`modlogs_${message.guild.id}`))?.send({ embeds: [embed] });

            if (duration) {
                setTimeout(() => {
                    message.guild.members.unban(user.id, `Fin du tempban`).catch(() => false);
                }, ms(duration));
            }
        } catch (error) {
            console.error('Erreur lors du bannissement:', error);
            message.channel.send("Une erreur s'est produite lors du bannissement.");
        }
    }
};