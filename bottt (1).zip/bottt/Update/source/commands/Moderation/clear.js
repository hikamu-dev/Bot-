// commands/moderation/clear.js
const Discord = require('discord.js');

module.exports = {
  name: "clear",
  description: "Supprime des messages (général ou ciblé).",
  use: "[@membre|id] <1-99>",
  usage: "clear 9 | clear @user 9",
  example: "➜ clear 9\n➜ clear @phebo 10",

  run: async (client, message, args) => {
    const commandName = module.exports.name;

    // ===== Vérif d'accès (comme ton schéma habituel) =====
    let pass = false;

    // Accès forts
    if (
      client?.staff?.includes?.(message.author.id) ||
      client.config.buyers.includes(message.author.id) ||
      client.db.get(`owner_global_${message.author.id}`) === true ||
      client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true ||
      message.guild.ownerId === message.author.id
    ) {
      pass = true;
    }

    // Accès custom (setperm) / public
    if (!pass) {
      const guildId = message.guild.id;
      const commandPerms = client.db.get(`command_permissions.${guildId}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${guildId}`) || {};
        const userRoles = message.member.roles.cache.map(r => r.id);
        pass = commandPerms.some(perm => (userPerms[perm] || []).some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${guildId}`) === "public") {
        pass = true;
      }
    }

    if (!pass) {
      if (client.noperm && client.noperm.trim() !== '') {
        const sent = await message.channel.send(client.noperm);
        const delay = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delay > 0) setTimeout(() => sent.delete().catch(() => {}), delay * 1000);
      }
      return;
    }
    // ======================================================

    // ===== Vérifs bot =====
    const me = message.guild.members.me || message.guild.members.cache.get(client.user.id);
    if (!me?.permissions?.has?.(Discord.PermissionsBitField.Flags.ManageMessages)) {
      return message.channel.send({ content: "Je n'ai pas la permission **Gérer les messages**.", allowedMentions: { parse: [] } });
    }

    // ===== Parsing : mode général OU ciblé membre =====
    const targetMember =
      message.mentions.members.first() ||
      message.guild.members.cache.get(args[0]);

    let amount;
    if (targetMember) {
      amount = parseInt(args[1], 10);
    } else {
      amount = parseInt(args[0], 10);
    }

    if (!Number.isInteger(amount) || amount < 1 || amount > 100) {
      return message.channel.send({
        content: "```\nUtilisation : clear [@membre|id] <1-100>\n```",
        allowedMentions: { parse: [] }
      });
    }

    // 1) Supprimer le message de commande
    await message.delete().catch(() => {});

    // 2) Suppression
    let deletedCount = 0;
    let note14 = "";

    try {
      if (!targetMember) {
        // --- Mode général ---
        // bulkDelete ignore (>14 jours) quand filterOld=true
        const deleted = await message.channel.bulkDelete(amount, true);
        deletedCount = deleted?.size ?? 0;
        if (deletedCount < amount) note14 = " (certains messages avaient > 14 jours)";
      } else {
        // --- Mode ciblé membre ---
        // On collecte jusqu'à "amount" messages du membre, récents (<14j)
        const TWO_WEEKS = 14 * 24 * 60 * 60 * 1000;
        const toDelete = [];
        let lastId = undefined;
        let guard = 0;

        while (toDelete.length < amount && guard < 10) { // jusqu'à ~1000 messages scannés
          guard++;
          const fetchOpts = { limit: 100 };
          if (lastId) fetchOpts.before = lastId;

          const fetched = await message.channel.messages.fetch(fetchOpts);
          if (!fetched.size) break;

          for (const m of fetched.values()) {
            if (Date.now() - m.createdTimestamp >= TWO_WEEKS) continue; // >14j
            if (m.author.id !== targetMember.id) continue;
            toDelete.push(m);
            if (toDelete.length === amount) break;
          }

          lastId = fetched.last()?.id;
          if (!lastId) break;
        }

        if (toDelete.length === 0) {
          const msg = await message.channel.send({
            content: `Aucun message récent (≤ 14 jours) trouvé pour ${targetMember}.`,
            allowedMentions: { parse: [] }
          });
          setTimeout(() => msg.delete().catch(() => {}), 30_000);
          return;
        }

        if (toDelete.length === 1) {
          await toDelete[0].delete().catch(() => {});
          deletedCount = 1;
        } else {
          const deleted = await message.channel.bulkDelete(toDelete, true);
          deletedCount = deleted?.size ?? toDelete.length;
        }

        if (deletedCount < amount) note14 = " (moins de messages récents disponibles ou > 14 jours)";
      }
    } catch (e) {
      return message.channel.send({
        content: "❌ Impossible de supprimer les messages (permissions, messages trop anciens, ou channel invalide).",
        allowedMentions: { parse: [] }
      });
    }

    // 3) Confirmation auto-supprimée après 30s
    const who = targetMember ? ` de ${targetMember}` : "";
    const confirm = await message.channel.send({
      content: `\`${deletedCount}\` message(s) supprimé(s)${who}${note14}.`,
      allowedMentions: { parse: [] }
    });
    setTimeout(() => confirm.delete().catch(() => {}), 30_000);
  }
};
