// commands/moderation/softban.js
const Discord = require('discord.js');

module.exports = {
  name: "softban",
  description: "Softban un membre et supprime ses messages des 7 derniers jours.",
  usage: "softban <@membre|id> [raison]",
  run: async (client, message, args, commandName) => {
    // ===== Vérif d'accès (comme tes autres cmds) =====
    let pass = false;
    if (
      client?.staff?.includes?.(message.author.id) ||
      client.config.buyers.includes(message.author.id) ||
      client.db.get(`owner_global_${message.author.id}`) === true ||
      client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true ||
      message.guild.ownerId === message.author.id
    ) {
      pass = true;
    } else {
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(r => r.id);
        pass = commandPerms.some(perm => (userPerms[perm] || []).some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        pass = true;
      }
    }
    if (!pass) {
      if (client.noperm && client.noperm.trim() !== '') {
        const sent = await message.channel.send(client.noperm);
        const delay = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delay > 0) setTimeout(() => sent.delete().catch(() => {}), delay * 1000);
      }
      return;
    }
    // =================================================

    // ===== Parsing minimal =====
    const target =
      message.mentions.members.first() ||
      message.guild.members.cache.get(args[0]);
    if (!target) return message.channel.send("Utilisation incorrecte : `softban <membre>`");

    const reason = (args.slice(1).join(" ").trim() || "Aucune raison fournie");

    if (target.id === message.author.id) return message.channel.send("Tu ne peux pas te softban toi-même.");
    if (target.id === client.user.id)   return message.channel.send("Tu ne peux pas softban le bot.");
    if (!target.bannable)               return message.channel.send("Je ne peux pas softban ce membre (rôle trop élevé ?).");

    // ===== Permissions bot =====
    const me = message.guild.members.me || message.guild.members.cache.get(client.user.id);
    if (!me?.permissions?.has?.(Discord.PermissionsBitField.Flags.BanMembers)) {
      return message.channel.send("Il me manque la permission **Bannir des membres**.");
    }

    // ===== Créer une invitation (si possible) =====
    let inviteUrl = null;
    try {
      if (message.channel?.createInvite) {
        const invite = await message.channel.createInvite({ maxAge: 0, maxUses: 0 });
        inviteUrl = `https://discord.gg/${invite.code}`;
      } else if (message.guild?.invites?.create) {
        const invite = await message.guild.invites.create(message.channel.id, { maxAge: 0, maxUses: 0 });
        inviteUrl = `https://discord.gg/${invite.code}`;
      }
    } catch {
      // pas de permission "Créer des invitations" → on continue sans lien
    }

    // ===== DM AVANT ban/unban (embed + bouton, pas d'emoji) =====
    try {
      const dmEmbed = new Discord.EmbedBuilder()
        .setColor(client.color || 0xffc107)
        .setTitle(`Softban de ${message.guild.name}`)
        .setDescription(
          `Vous avez été **soft** du serveur **\`${message.guild.name}\`** pour **\`${reason}\`**.\n` +
          `Vos messages récents (7 jours) ont été supprimés.`
        )
        .setTimestamp();

      const dmRow = inviteUrl
        ? new Discord.ActionRowBuilder().addComponents(
            new Discord.ButtonBuilder()
              .setStyle(Discord.ButtonStyle.Link)
              .setLabel(`Rejoindre ${message.guild.name}`)
              .setURL(inviteUrl)
          )
        : null;

      await target.user.send({
        embeds: [dmEmbed],
        components: dmRow ? [dmRow] : [],
        allowedMentions: { parse: [] },
      });
    } catch {
      // DM fermé → on continue quand même
    }

    // ===== Ban (delete 7 jours) + Unban =====
    try {
      await target.ban({
        reason: `Softban par ${message.author.tag} | ${reason}`,
        deleteMessageSeconds: 604800, // 7 jours (basique Discord)
      });
      await message.guild.members.unban(target.id, "Softban automatique (unban immédiat)");
    } catch (err) {
      console.error("[SOFTBAN] Erreur ban/unban :", err);
      return message.channel.send("Une erreur est survenue lors du softban (ban/unban).");
    }

    // ===== Message SALON (texte simple) =====
    await message.channel.send({
      content: `${target.user.tag} a été **soft** du serveur **\`${message.guild.name}\`** pour **\`${reason}\`**.`,
      allowedMentions: { parse: [] },
    });
  },
};
