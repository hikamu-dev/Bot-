const Discord = require("discord.js");
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const Astroia = require("../../structures/client");
const { example } = require("./ban");

module.exports = {
    name: "sanction",
    aliases: ["sanctions", "sanc"],
    description: "Affiche les sanctions d'un membre du serveur avec un bouton pour ouvrir un modal afin de supprimer une sanction spécifique ou toutes les sanctions.",
    use: "<@user/ID>",
    usages: "sanction <@user/ID>",
    example: "➜ sanction @tokyru\n➜ sanction 123456789012345678",
    /**
     * @param {Astroia} client
     * @param {Astroia} message
     * @param {Astroia} args
     * @returns
     */
    run: async (client, message, args, commandName) => {
                        const whitelistDB = client.db.get(`wl.${message.guild.id}`) || [];

const isBypass = (
    client.staff.includes(message.author.id) ||
    client.config.buyers.includes(message.author.id) ||
    client.db.get(`owner_${message.author.id}`) === true ||
        client.db.get(`owner_global_${message.author.id}`) === true || 

    whitelistDB.includes(message.author.id)
);

if (!isBypass) {
    const limitData = client.db.get(`command_limit_${message.guild.id}_sanction`);
    if (limitData) {
        const key = `limit_used_sanction_${message.guild.id}_${message.author.id}`;
        const userData = client.db.get(key) || { count: 0, timestamp: 0 };
        const now = Date.now();

        if (userData.timestamp + limitData.timeLimit > now) {
            if (userData.count >= limitData.maxUse) {
                const remaining = Math.ceil((userData.timestamp + limitData.timeLimit - now) / 1000);
                return message.reply(`Tu as atteint la limite d'utilisation de la commande \`sanction\`. Réessaie dans ${remaining}s.`);
            } else {
                userData.count += 1;
            }
        } else {
            userData.count = 1;
            userData.timestamp = now;
        }

        client.db.set(key, userData);
    }
}
        try {
            // Vérification des permissions
            let pass = false;
            if (client.staff.includes(message.author.id) || 
                client.config.buyers.includes(message.author.id) ||
                    client.db.get(`owner_global_${message.author.id}`) === true || 

        client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {                   pass = true;
            } else {
                const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
                if (commandPerms.length > 0) {
                    const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
                    const userRoles = message.member.roles.cache.map(role => role.id);
                    pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
                } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
                    pass = true;
                }
            }

if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

            // Vérification des arguments
            if (args.length < 1) {
                return message.channel.send("Utilisation incorrecte : `sanction <@user/ID> [delete <numéro/all>]`");
            }

            // Récupération de l'utilisateur
            let user = message.mentions.users.first();
            let memberId = args[0];

            if (!user && memberId) {
                user = await client.users.fetch(memberId).catch(() => null);
            }

            if (!user) {
                return message.channel.send("Utilisateur non trouvé. Utilisation correcte : `sanction <@user/ID> [delete <numéro/all>]`");
            }

            // Récupération des sanctions
            const db = await client.db.get(`sanction_${message.guild.id}`) || [];
            const userSanctions = db.filter(s => s.userId === user.id);

            // Gestion de la commande delete
            if (args[1] && args[1].toLowerCase() === 'delete') {
                if (!args[2]) {
                    return message.channel.send("Veuillez fournir le numéro de la sanction ou 'all' : `sanction <@user/ID> delete <numéro/all>`");
                }

                if (args[2].toLowerCase() === 'all') {
                    if (userSanctions.length === 0) {
                        return message.channel.send(`Aucune sanction à supprimer pour <@${user.id}>.`);
                    }

                    const newDb = db.filter(s => s.userId !== user.id);
                    await client.db.set(`sanction_${message.guild.id}`, newDb);

                    return message.channel.send(`🗑️ Toutes les sanctions de <@${user.id}> ont été supprimées. (${userSanctions.length} sanction${userSanctions.length > 1 ? 's' : ''} supprimée${userSanctions.length > 1 ? 's' : ''})`);
                }

                const sanctionNumber = parseInt(args[2]) - 1; // Soustraire 1 car l'index commence à 0
                if (isNaN(sanctionNumber) || sanctionNumber < 0 || sanctionNumber >= userSanctions.length) {
                    return message.channel.send(`Numéro de sanction invalide. Les numéros disponibles sont de 1 à ${userSanctions.length}.`);
                }

                const sanctionToRemove = userSanctions[sanctionNumber];
                const newDb = db.filter(s => s !== sanctionToRemove);
                await client.db.set(`sanction_${message.guild.id}`, newDb);

                return message.channel.send(`🗑️ La sanction numéro ${sanctionNumber + 1} pour <@${user.id}> a été supprimée.`);
            }

            if (userSanctions.length === 0) {
                return message.channel.send(`Aucune sanction trouvée pour <@${user.id}>.`);
            }

            // Création de l'embed des sanctions
            const sanctionEmbed = new EmbedBuilder()
                .setTitle(`📄 Sanctions pour \`${user.tag}\``)
                .setColor(client.color)
                .setFooter(client.footer);

            // Création du bouton pour ouvrir le modal
            const deleteButton = new ButtonBuilder()
                .setCustomId(`delete_sanction_${user.id}_${message.id}`)
                .setLabel('Supprimer Sanction')
                .setStyle(ButtonStyle.Danger);

            const row = new ActionRowBuilder().addComponents(deleteButton);

            for (let i = 0; i < userSanctions.length; i++) {
                const sanction = userSanctions[i];
                let modTag = "Inconnu";

                if (sanction.author) {
                    try {
                        const modUser = await client.users.fetch(sanction.author);
                        modTag = modUser.tag;
                    } catch (e) {
                        modTag = `ID: ${sanction.author}`;
                    }
                }

                const sanctionType = sanction.type || getSanctionType(sanction.reason);
                const typeEmoji = getSanctionEmoji(sanctionType);

                let durationText = '';
                if (sanction.duration && ['mute', 'tempban'].includes(sanctionType.toLowerCase())) {
                    const endTime = Math.floor((sanction.date + require('ms')(sanction.duration)) / 1000);
                    durationText = `\n- **Durée :** ${sanction.duration}\n- **Fin :** <t:${endTime}:F>`;
                }

                const codeText = sanction.code ? `**- Code :** \`${sanction.code}\`\n` : '';

                // Ajout des informations de modification
                let editText = '';
                if (sanction.editedBy && sanction.editedAt) {
                    try {
                        const editUser = await client.users.fetch(sanction.editedBy);
                        const editDate = Math.floor(sanction.editedAt / 1000);
                        editText = `\n- **Modifié par :** \`${editUser.tag}\`\n- **Date de modification :** <t:${editDate}:F>`;
                    } catch (e) {
                        const editDate = Math.floor(sanction.editedAt / 1000);
                        editText = `\n- **Modifié par :** \`ID: ${sanction.editedBy}\`\n- **Date de modification :** <t:${editDate}:F>`;
                    }
                }

                // Indicateur visuel si la sanction a été modifiée
                const editedIndicator = sanction.editedBy ? ' ✏️' : '';

                sanctionEmbed.addFields({
                    name: `> ${typeEmoji} Sanction ${i + 1} - **\`${sanctionType}\`**${editedIndicator}`,
                    value: `${codeText}- **Raison :** ${sanction.reason}\n- **Date :** <t:${Math.floor(sanction.date / 1000)}:F>\n- **Sanctionné par :** \`${modTag}\`${durationText}${editText}`
                });
            }

            const sentMessage = await message.channel.send({ embeds: [sanctionEmbed], components: [row] });

            // Gestion des interactions avec le bouton
            const buttonCollector = sentMessage.createMessageComponentCollector({ time: 600000 }); // 10 minutes

            buttonCollector.on('collect', async (interaction) => {
                if (interaction.user.id !== message.author.id) {
                    await interaction.reply({ content: "Seul l'auteur de la commande peut utiliser ce bouton.", ephemeral: true });
                    return;
                }

                // Création et affichage du modal
                const modal = new ModalBuilder()
                    .setCustomId(`sanction_modal_${user.id}_${message.id}`)
                    .setTitle('Supprimer');

                const sanctionInput = new TextInputBuilder()
                    .setCustomId('sanction_number')
                    .setLabel('Numéro de sanction ou "all"')
                    .setPlaceholder('Entrez un numéro (ex: 1) ou "all" pour tout supprimer')
                    .setStyle(TextInputStyle.Short)
                    .setRequired(true);

                const actionRow = new ActionRowBuilder().addComponents(sanctionInput);
                modal.addComponents(actionRow);

                await interaction.showModal(modal);
            });

            // Gestion des soumissions de modal
            const modalHandler = async (interaction) => {
                if (!interaction.isModalSubmit() || interaction.customId !== `sanction_modal_${user.id}_${message.id}` || interaction.user.id !== message.author.id) return;

                await interaction.deferUpdate();

                const input = interaction.fields.getTextInputValue('sanction_number').trim().toLowerCase();
                const db = await client.db.get(`sanction_${message.guild.id}`) || [];
                let newDb = db;
                const updatedSanctions = db.filter(s => s.userId === user.id);

                if (input === 'all') {
                    if (updatedSanctions.length === 0) {
                        await interaction.followUp({ content: `Aucune sanction à supprimer pour <@${user.id}>.`, ephemeral: true });
                        await sentMessage.edit({ components: [] });
                        return;
                    }

                    newDb = db.filter(s => s.userId !== user.id);
                    await client.db.set(`sanction_${message.guild.id}`, newDb);
                    await interaction.followUp({ content: `🗑️ Toutes les sanctions de <@${user.id}> ont été supprimées.`, ephemeral: true });

                    await sentMessage.edit({ 
                        embeds: [new EmbedBuilder()
                            .setTitle(`📄 Sanctions pour \`${user.tag}\``)
                            .setDescription("Aucune sanction restante.")
                            .setColor(client.color)
                            .setFooter(client.footer)
                        ], 
                        components: [] 
                    });
                    buttonCollector.stop();
                    client.off('interactionCreate', modalHandler);
                    return;
                }

                const sanctionNumber = parseInt(input) - 1; // Soustraire 1 car l'index commence à 0
                if (isNaN(sanctionNumber) || sanctionNumber < 0 || sanctionNumber >= updatedSanctions.length) {
                    await interaction.followUp({ content: `Numéro de sanction invalide. Les numéros disponibles sont de 1 à ${updatedSanctions.length}.`, ephemeral: true });
                    return;
                }

                const sanctionToRemove = updatedSanctions[sanctionNumber];
                newDb = db.filter(s => s !== sanctionToRemove);
                await client.db.set(`sanction_${message.guild.id}`, newDb);
                await interaction.followUp({ content: `🗑️ La sanction numéro ${sanctionNumber + 1} pour <@${user.id}> a été supprimée.`, ephemeral: true });

                // Mise à jour de l'embed
                const remainingSanctions = newDb.filter(s => s.userId === user.id);
                if (remainingSanctions.length === 0) {
                    await sentMessage.edit({ 
                        embeds: [new EmbedBuilder()
                            .setTitle(`📄 Sanctions pour \`${user.tag}\``)
                            .setDescription("Aucune sanction restante.")
                            .setColor(client.color)
                            .setFooter(client.footer)
                        ], 
                        components: [] 
                    });
                    buttonCollector.stop();
                    client.off('interactionCreate', modalHandler);
                    return;
                }

                const updatedEmbed = new EmbedBuilder()
                    .setTitle(`📄 Sanctions pour \`${user.tag}\``)
                    .setColor(client.color)
                    .setFooter(client.footer);

                for (let i = 0; i < remainingSanctions.length; i++) {
                    const sanction = remainingSanctions[i];
                    let modTag = "Inconnu";

                    if (sanction.author) {
                        try {
                            const modUser = await client.users.fetch(sanction.author);
                            modTag = modUser.tag;
                        } catch (e) {
                            modTag = `ID: ${sanction.author}`;
                        }
                    }

                    const sanctionType = sanction.type || getSanctionType(sanction.reason);
                    const typeEmoji = getSanctionEmoji(sanctionType);

                    let durationText = '';
                    if (sanction.duration && ['mute', 'tempban'].includes(sanctionType.toLowerCase())) {
                        const endTime = Math.floor((sanction.date + require('ms')(sanction.duration)) / 1000);
                        durationText = `\n- **Durée :** ${sanction.duration}\n- **Fin :** <t:${endTime}:F>`;
                    }

                    const codeText = sanction.code ? `**Code :** \`${sanction.code}\`\n` : '';

                    // Ajout des informations de modification pour l'embed mis à jour
                    let editText = '';
                    if (sanction.editedBy && sanction.editedAt) {
                        try {
                            const editUser = await client.users.fetch(sanction.editedBy);
                            const editDate = Math.floor(sanction.editedAt / 1000);
                            editText = `\n- **Modifié par :** \`${editUser.tag}\`\n- **Date de modification :** <t:${editDate}:F>`;
                        } catch (e) {
                            const editDate = Math.floor(sanction.editedAt / 1000);
                            editText = `\n- **Modifié par :** \`ID: ${sanction.editedBy}\`\n- **Date de modification :** <t:${editDate}:F>`;
                        }
                    }

                    // Indicateur visuel si la sanction a été modifiée
                    const editedIndicator = sanction.editedBy ? ' ✏️' : '';

                    updatedEmbed.addFields({
                        name: `> ${typeEmoji} Sanction ${i + 1} - **\`${sanctionType}\`**${editedIndicator}`,
                        value: `${codeText}- **Raison :** ${sanction.reason}\n- **Date :** <t:${Math.floor(sanction.date / 1000)}:F>\n- **Sanctionné par :** \`${modTag}\`${durationText}${editText}`
                    });
                }

                await sentMessage.edit({ embeds: [updatedEmbed], components: [row] });
            };

            client.on('interactionCreate', modalHandler);

            buttonCollector.on('end', async () => {
                try {
                    const disabledRow = new ActionRowBuilder().addComponents(
                        deleteButton.setDisabled(true) // Désactiver le bouton au lieu de le supprimer
                    );
                    await sentMessage.edit({ components: [disabledRow] });
                    client.off('interactionCreate', modalHandler);
                } catch (err) {
                    console.error('Erreur lors de la désactivation des boutons:', err);
                }
            });

        } catch (err) {
            console.error('Erreur:', err);
            message.reply("Une erreur est survenue...");
        }
    }
};

// Fonction pour déterminer le type de sanction basé sur la raison
function getSanctionType(reason) {
    const reasonLower = reason.toLowerCase();
    
    if (reasonLower.includes('ban') || reasonLower.includes('banni')) {
        return 'Ban';
    } else if (reasonLower.includes('mute') || reasonLower.includes('muet') || reasonLower.includes('temp')) {
        return 'Mute';
    } else if (reasonLower.includes('kick') || reasonLower.includes('expuls')) {
        return 'Kick';
    } else if (reasonLower.includes('warn') || reasonLower.includes('avert')) {
        return 'Warn';
    } else {
        return 'Warn'; // Par défaut, considérer comme un warn
    }
}

// Fonction pour obtenir l'emoji correspondant au type de sanction
function getSanctionEmoji(type) {
    switch (type.toLowerCase()) {
        case 'ban':
            return '🔨';
        case 'mute':
            return '🔇';
        case 'kick':
            return '👢';
        case 'warn':
            return '⚠️';
        default:
            return '📛';
    }
}