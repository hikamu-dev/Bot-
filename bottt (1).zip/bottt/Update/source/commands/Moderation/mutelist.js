const { ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType, EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'listmute',
  aliases: ["mutelist"],
  description: 'Liste tous les membres mute sur le serveur.',
  run: async (client, message, args, commandName) => {
                    const whitelistDB = client.db.get(`wl.${message.guild.id}`) || [];

const isBypass = (
    client.staff.includes(message.author.id) ||
    client.config.buyers.includes(message.author.id) ||
    client.db.get(`owner_${message.author.id}`) === true ||
        client.db.get(`owner_global_${message.author.id}`) === true || 

    whitelistDB.includes(message.author.id)
);

if (!isBypass) {
    const limitData = client.db.get(`command_listmute_${message.guild.id}_listmute`);
    if (limitData) {
        const key = `listmute_used_kick_${message.guild.id}_${message.author.id}`;
        const userData = client.db.get(key) || { count: 0, timestamp: 0 };
        const now = Date.now();

        if (userData.timestamp + limitData.timeLimit > now) {
            if (userData.count >= limitData.maxUse) {
                const remaining = Math.ceil((userData.timestamp + limitData.timeLimit - now) / 1000);
                return message.reply(`Tu as atteint la limite d'utilisation de la commande \`listmute\`. Réessaie dans ${remaining}s.`);
            } else {
                userData.count += 1;
            }
        } else {
            userData.count = 1;
            userData.timestamp = now;
        }

        client.db.set(key, userData);
    }
}
    let pass = false;

    // Autoriser automatiquement les staff, buyers, et owners
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) ||
            client.db.get(`owner_global_${message.author.id}`) === true || 

client.db.get(`owner_${message.guild.id}_${message.author.id}`) === true || 
    message.guild.ownerId === message.author.id) {         pass = true;
    } else {
      // Vérifier les permissions personnalisées pour la commande
      const commandPerms = client.db.get(`command_permissions.${message.guild.id}.${commandName}`) || [];
      if (commandPerms.length > 0) {
        const userPerms = client.db.get(`permissions.${message.guild.id}`) || {};
        const userRoles = message.member.roles.cache.map(role => role.id);
        // Vérifier si l'utilisateur a un rôle correspondant à une permission requise
        pass = commandPerms.some(perm => userPerms[perm] && userPerms[perm].some(roleId => userRoles.includes(roleId)));
      } else if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") {
        // Conserver la compatibilité avec le mode "public"
        pass = true;
      }
    }

    // Refuser l'accès si pas de permission
if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

    // Filtrer les membres mute en vérifiant si le timeout est encore actif
    const now = Date.now();
    const mutedMembers = message.guild.members.cache.filter((member) => {
      return member.communicationDisabledUntilTimestamp !== null && 
             member.communicationDisabledUntilTimestamp > now;
    });
    
    if (!mutedMembers.size) return message.reply('Aucun membre mute trouvé sur ce serveur.');

    const PAGE_SIZE = 10;
    const pageCount = Math.ceil(mutedMembers.size / PAGE_SIZE);
    let currentPage = 1;
    const msg = await message.reply(`Recherche en cours...`);

    const sendMuteList = async () => {
      // Refiltrer les membres mute à chaque actualisation pour enlever ceux qui sont expirés
      const currentNow = Date.now();
      const currentMutedMembers = message.guild.members.cache.filter((member) => {
        return member.communicationDisabledUntilTimestamp !== null && 
               member.communicationDisabledUntilTimestamp > currentNow;
      });

      // Si plus de membres mute, afficher un message
      if (!currentMutedMembers.size) {
        const embed = new EmbedBuilder()
          .setTitle(`List des mute de ${message.guild.name}`)
          .setDescription('Aucun membre mute trouvé sur ce serveur.')
          .setColor(client.color);

        return await msg.edit({
          embeds: [embed],
          content: null,
          components: [],
        });
      }

      // Recalculer la pagination avec la liste mise à jour
      const newPageCount = Math.ceil(currentMutedMembers.size / PAGE_SIZE);
      if (currentPage > newPageCount) {
        currentPage = newPageCount;
      }

      const start = (currentPage - 1) * PAGE_SIZE;
      const end = start + PAGE_SIZE;
      
      // Récupérer les audit logs pour obtenir les raisons des mutes
      let auditLogs = null;
      try {
        auditLogs = await message.guild.fetchAuditLogs({
          type: 24, // MEMBER_UPDATE pour les timeouts
          limit: 100
        });
      } catch (error) {
        console.log('Impossible de récupérer les audit logs:', error);
      }

      const muteList = currentMutedMembers
        .map((member) => {
          let reason = 'Aucune raison spécifiée';
          
          // Chercher la raison dans les audit logs
          if (auditLogs) {
            const auditEntry = auditLogs.entries.find(entry => 
              entry.target.id === member.user.id && 
              entry.changes.some(change => change.key === 'communication_disabled_until')
            );
            
            if (auditEntry && auditEntry.reason) {
              reason = auditEntry.reason;
            }
          }
          
          return `+<@${member.user.id}> \`${member.user.id}\`\n📝 **Raison:** ${reason}\n⏰ **Fin:** <t:${Math.round(parseInt(member.communicationDisabledUntilTimestamp) / 1000)}:R>`;
        })
        .slice(start, end)
        .join('\n\n');

      const embed = new EmbedBuilder()
        .setTitle(`List des mute de ${message.guild.name}`)
        .setDescription(muteList)
        .setColor(client.color)
        .setFooter({ text: `Page ${currentPage}/${newPageCount}` });

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`avant_${message.id}`)
          .setLabel('<<<')
          .setStyle(ButtonStyle.Primary)
          .setDisabled(currentPage === 1),
        new ButtonBuilder()
          .setCustomId(`suivant_${message.id}`)
          .setLabel('>>>')
          .setStyle(ButtonStyle.Primary)
          .setDisabled(currentPage === newPageCount)
      );

      await msg.edit({
        embeds: [embed],
        content: null,
        components: [row],
      });
    };

    await sendMuteList();

    const collector = msg.createMessageComponentCollector({
      componentType: ComponentType.Button,
      time: 60000,
    });

    collector.on('collect', async (button) => {
        if (button.user.id !== message.author.id) {
          return button.reply({ content: await client.lang('noperminterac'), ephemeral: true });
        }
        if (button.customId === `avant_${message.id}` && currentPage > 1) {
          currentPage--;
          button.deferUpdate()          
        } else if (button.customId === `suivant_${message.id}` && currentPage < pageCount) {
          currentPage++;
          button.deferUpdate()          
        }
  
        await sendMuteList();
      });

    collector.on('end', () => {
      msg.edit({ components: [] });
    });
  },
};