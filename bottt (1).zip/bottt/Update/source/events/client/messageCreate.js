const { Client, Message, EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'messageCreate',
  run: async (client, message) => {
    if (!message.guild || message.author.bot) return;

    const prefix = client.db.get(`prefix_${message.guild.id}`) || client.config.prefix;
    client.color = client.db.get(`color_${message.guild.id}`) || client.config.default_color;
    client.prefix = prefix;
    client.noperm = client.db.get(`noperm_${message.guild.id}`) === 'vent' ? null : (client.db.get(`noperm_${message.guild.id}`) || await client.lang('perm'));

    if (message.content === `<@${client.user.id}>` || message.content === `<@!${client.user.id}>`) {
      const embed = new EmbedBuilder()
        .setColor(client.color)
        .setDescription(`Mon préfixe sur ce serveur est \`${prefix}\``)

      const sentMessage = await message.channel.send({ embeds: [embed] }).catch(() => {});
      
      // Supprimer le message après 3 secondes
      if (sentMessage) {
        setTimeout(() => {
          sentMessage.delete().catch(() => {});
        }, 3000);
      }
      
      return;
    }

    if (!message.content.startsWith(prefix) || message.content === prefix || message.content.startsWith(prefix + ' ')) {
      if (!message.content.startsWith(`<@${client.user.id}>`) && !message.content.startsWith(`<@!${client.user.id}>`)) {
        return;
      }
    }

    const escapeRegex = (str) => str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const prefixRegex = new RegExp(`^(<@!?${client.user.id}>|${escapeRegex(prefix)})\\s*`);
    if (!prefixRegex.test(message.content)) return;

    const [, matchedPrefix] = message.content.match(prefixRegex);
    const args = message.content.slice(matchedPrefix.length).trim().split(/ +/);
    let commandName = args.shift()?.toLowerCase().normalize();
    if (!commandName) return;

    // Gestion des alias stockés en base
    const guildAliases = client.db.get(`aliases.${message.guild.id}`) || {};
    for (const [cmd, aliases] of Object.entries(guildAliases)) {
      if (aliases.includes(commandName)) {
        commandName = cmd; // Remplace alias par la commande principale
        break;
      }
    }

    const cmd = client.commands.get(commandName) || client.aliases.get(commandName);
    if (!cmd) return;

    try {
      await cmd.run(client, message, args, commandName);
    } catch (error) {
      console.error(`Erreur lors de l'exécution de la commande ${commandName}:`, error);
      message.reply("Une erreur est survenue lors de l'exécution de cette commande.");
    }
  }
}