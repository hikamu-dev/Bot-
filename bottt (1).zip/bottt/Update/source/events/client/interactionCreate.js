
module.exports = {
    name: 'interactionCreate',
    async run(client, interaction) {
        // ... autres interactions ...

        if (interaction.isButton() && interaction.customId.startsWith('resend_embed_')) {
            const data = client.deletedEmbeds?.get(interaction.customId);
            if (!data) {
                return interaction.reply({ content: 'Embed introuvable ou expiré.', ephemeral: true });
            }

            // Récupère le salon d'origine
            const targetChannel = interaction.guild.channels.cache.get(data.channelId);
            if (!targetChannel) {
                return interaction.reply({ content: 'Salon d\'origine introuvable.', ephemeral: true });
            }

            // Renvoyer l'embed dans le salon d'origine
            await targetChannel.send({ embeds: [data.embed] });
            return interaction.reply({ content: 'Embed renvoyé dans le salon d\'origine !', ephemeral: true });
        }

        // Gestion du bouton Copier l'ID
        if (interaction.isButton() && interaction.customId.startsWith('copy_id_')) {
            const id = interaction.customId.replace('copy_id_', '');
            return interaction.reply({ content: id, ephemeral: true });
        }

        // Gestion du modal de configuration des motifs de tickets
// Gestion du modal de configuration des motifs de tickets
if (interaction.isModalSubmit() && interaction.customId.startsWith('config_motifs_modal_')) {
    const id = interaction.customId.split('_').pop();
    let db = await client?.db.get(`ticket_${interaction.guild.id}`) || { option: [] };
    const validOption = db.option && db.option.find(option => option.value === id);
    if (!validOption) return await interaction.reply({ content: 'Option non trouvée.', ephemeral: true });

    // Récupérer les motifs saisis dans le modal
    const motifs = [];
    for (let idx = 0; idx < 4; idx++) {
        const value = interaction.fields.getTextInputValue(`motif_input_${idx}`);
        if (value && value.trim().length > 0) motifs.push(value.trim());
    }
    validOption.motifs = motifs;

    // Log pour déboguer les motifs
    //console.log(`[DEBUG] Motifs avant sauvegarde pour option ${id}:`, validOption.motifs);

    // Sauvegarder les modifications dans la base de données
    await client.db.set(`ticket_${interaction.guild.id}`, db);

    // Recharger la base de données pour garantir la synchronisation
    db = await client.db.get(`ticket_${interaction.guild.id}`) || { option: [] };
    const updatedOption = db.option.find(option => option.value === id);
    if (!updatedOption) return await interaction.reply({ content: 'Erreur : Option non trouvée après mise à jour.', ephemeral: true });

    // Log pour déboguer les motifs après rechargement
    //console.log(`[DEBUG] Motifs après rechargement pour option ${id}:`, updatedOption.motifs);

    // Répondre à l'interaction
   // await interaction.reply({ content: `✅ Motifs mis à jour !`, ephemeral: true });

    // Chercher le message de configuration de l'option (titre "Configuration d'une Option")
    const configMsg = await interaction.channel.messages.fetch({ limit: 50 })
        .then(msgs => msgs.find(m => m.author.id === client.user.id && m.embeds.length && m.embeds[0].title && m.embeds[0].title.includes('Configuration d\'une Option')))
        .catch(() => null);

    if (configMsg) {
        const category = client.channels.cache.get(updatedOption.categorie);
        const logChannel = client.channels.cache.get(updatedOption.logs);
        const role = interaction.guild.roles.cache.get(updatedOption.mention);
        const rolesAccess = Array.isArray(updatedOption.acess)
            ? updatedOption.acess.map(roleId => `<@&${roleId}>`).join(', ')
            : 'Aucun';

        const Discord = require('discord.js');
        const optionEmbed = new Discord.EmbedBuilder()
            .setTitle('⚙️ Configuration d\'une Option')
            .setDescription(`Modifiez les paramètres de l'option : **${updatedOption.text}**`)
            .setColor(client.color || '#5865F2')
            .setFooter({ text: client.footer?.text || 'Système de Tickets', iconURL: client.footer?.iconURL })
            .setTimestamp()
            .addFields([
                { name: '📂 Catégorie', value: category ? `#${category.name}` : 'Non définie', inline: true },
                { name: '🪄 Emoji', value: updatedOption.emoji || 'Aucun', inline: true },
                { name: '✍️ Texte', value: updatedOption.text || 'Non défini', inline: true },
                { name: '📝 Description', value: updatedOption.description || 'Aucune', inline: true },
                { name: '📜 Salon de logs', value: logChannel ? `<#${logChannel.id}>` : 'Non défini', inline: true },
                { name: '🔔 Rôle mentionné', value: role ? `<@&${role.id}>` : 'Aucun', inline: true },
                { name: '📬 Message d\'ouverture', value: updatedOption.message || 'Non défini', inline: true },
                { name: '🔐 Rôles ayant accès', value: rolesAccess || 'Aucun', inline: true },
                { name: '📋 Motifs d\'ouverture', value: updatedOption.motifs && updatedOption.motifs.length > 0 ? updatedOption.motifs.map((motif, index) => `${index + 1}. ${motif}`).join('\n') : 'Aucun motif configuré', inline: false }
            ]);

        const buttons = new Discord.ActionRowBuilder().addComponents(
            new Discord.ButtonBuilder()
                .setCustomId('retourmenu')
                .setLabel('Retour au menu')
                .setEmoji('⬅️')
                .setStyle(Discord.ButtonStyle.Secondary),
            new Discord.ButtonBuilder()
                .setCustomId(`suppoption_${updatedOption.value}`)
                .setLabel('Supprimer l\'option')
                .setEmoji('🗑️')
                .setStyle(Discord.ButtonStyle.Danger)
        );

        const selectMenu = new Discord.ActionRowBuilder().addComponents(
            new Discord.StringSelectMenuBuilder()
                .setCustomId('configmenu')
                .setPlaceholder('🛠️ Modifier un paramètre')
                .addOptions([
                    { label: 'Catégorie', emoji: '📂', value: `categorieoption_${updatedOption.value}` },
                    { label: 'Emoji', emoji: '🪄', value: `emojioption_${updatedOption.value}` },
                    { label: 'Texte', emoji: '✍️', value: `textoption_${updatedOption.value}` },
                    { label: 'Description', emoji: '📝', value: `descriptionoption_${updatedOption.value}` },
                    { label: 'Salon de logs', emoji: '📜', value: `salonoption_${updatedOption.value}` },
                    { label: 'Rôle mentionné', emoji: '🔔', value: `roleoption_${updatedOption.value}` },
                    { label: 'Message d\'ouverture', emoji: '📬', value: `ouvertoption_${updatedOption.value}` },
                    { label: 'Rôles ayant accès', emoji: '🔐', value: `roleacess_${updatedOption.value}` },
                    { label: 'Motifs d\'ouverture', emoji: '📋', value: `motifsoption_${updatedOption.value}` }
                ])
        );

        // Log pour déboguer le contenu des motifs dans l'embed
        //console.log(`[DEBUG] Contenu du champ 'Motifs d\'ouverture' dans l'embed:`, 
            //updatedOption.motifs && updatedOption.motifs.length > 0 
                //? updatedOption.motifs.map((motif, index) => `${index + 1}. ${motif}`).join('\n') 
                //: 'Aucun motif configuré'
        //);

        try {
            await configMsg.edit({ embeds: [optionEmbed], components: [selectMenu, buttons] });
        } catch (error) {
            console.error('[DEBUG] Erreur lors de l\'édition du message:', error);
            await interaction.followUp({ content: '❌ Erreur lors de la mise à jour de l\'embed. Vérifiez les permissions du bot.', ephemeral: true });
        }
    } else {
        //console.log('[DEBUG] Aucun message de configuration trouvé.');
        await interaction.followUp({ content: '⚠️ Impossible de trouver le message de configuration à mettre à jour.', ephemeral: true });
    }
    return;
}

        // ... autres interactions ...
    }
};