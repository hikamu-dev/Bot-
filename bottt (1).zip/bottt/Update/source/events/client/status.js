const Discord = require("discord.js");
const { ActivityType } = require("discord.js");
const Astroia = require("../../structures/client/index");

module.exports = {
    name: "ready",
    /**
     *
     * @param {Astroia} client
     */
    run: async (client) => {
        setInterval(() => { 
            const status = client.db.get('nomstatut') || ".gg/lyna " + client.version;
            const custom = client.db.get('type') || "STREAMING";
            const presence = client.db.get('presence') || 'dnd';

            let activityType;
            let url = null;

            if (custom === "STREAMING") {
                activityType = ActivityType.Streaming;
                url = "https://twitch.tv/discord";
            } else if (custom === "WATCHING") {
                activityType = ActivityType.Watching;
            } else if (custom === "PLAYING") {
                activityType = ActivityType.Playing;
            } else if (custom === "LISTENING") {
                activityType = ActivityType.Listening;
            }

            const presenceOptions = {
                status: presence,  
                activities: [{
                    name: status,
                    type: activityType,
                    url: url 
                }]
            };

            client.user.setPresence(presenceOptions);
        
        }, 5000);
    }
};
