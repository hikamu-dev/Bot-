const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');
const ms = require('ms');
const Discord = require('discord.js');

module.exports = {
    name: 'messageCreate',
    run: async (client, message) => {
        if (message.channel.type === 1) { // Message en DM
            if (message.content.toLowerCase() === `${client.prefix}close`) return;
            if (message.author.id === client.user.id) return;

            const dbUser = client.db.get(`modmail_user_${message.author.id}`);
            if (!dbUser || !dbUser.channel) {
                // Aucun modmail ouvert, on explique à l'utilisateur comment en ouvrir un
                return await message.channel.send(`Pour ouvrir un modmail, utilisez la commande : \`${client.prefix}open\``);
            }

            await message.react('✅'); // Réaction ajoutée sur le message de l'utilisateur

            // Si le modmail existe déjà
            try {
                const ticketChannel = await client.channels.fetch(dbUser.channel);
                if (ticketChannel) {
                    // Préparer le contenu du message
                    const messageContent = message.content || "Aucun texte";
                    const embeds = [];
                    const files = [];

                    // Ajouter les pièces jointes (photos, fichiers, etc.)
                    if (message.attachments.size > 0) {
                        message.attachments.forEach(attachment => {
                            files.push({
                                attachment: attachment.url,
                                name: attachment.name
                            });
                        });
                    }

                    // Créer un embed pour le message
                    const embed = new EmbedBuilder()
                        .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL() })
                        .setDescription(messageContent)
                        .setTimestamp()
                        .setColor(client.color);

                    embeds.push(embed);

                    // Envoyer le message avec texte et pièces jointes
                    await ticketChannel.send({
                        //content: `<@${message.author.id}>`,
                        embeds: embeds,
                        files: files
                    });

                    client.db.set(`modmail_channel_${ticketChannel.id}`, message.author.id);
                }
            } catch (error) {
                console.error('Erreur lors de l\'envoi du message du DM vers le ticket :', error);
            }
        }

        if (message.channel.type === 0) { // Message dans un serveur (canal textuel)
            if (message.author.id === client.user.id) return;

            const authorID = client.db.get(`modmail_channel_${message.channel.id}`);
            if (!authorID) return;

            try {
                const dmChannel = await client.users.fetch(authorID);
                if (dmChannel) {
                    // Préparer le contenu du message
                    const messageContent = message.content || "Aucun texte";
                    const embeds = [];
                    const files = [];

                    // Ajouter les pièces jointes (photos, fichiers, etc.)
                    if (message.attachments.size > 0) {
                        message.attachments.forEach(attachment => {
                            files.push({
                                attachment: attachment.url,
                                name: attachment.name
                            });
                        });
                    }

                    // Créer un embed pour le message
                    const embed = new EmbedBuilder()
                        .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL() })
                        .setDescription(messageContent)
                        .setTimestamp()
                        .setColor(client.color);

                    embeds.push(embed);

                    // Envoyer le message avec texte et pièces jointes
                    await dmChannel.send({
                        //content: `<@${message.author.id}>`,
                        embeds: embeds,
                        files: files
                    });

                    await message.react('✅'); // Réaction ajoutée sur le message de l'utilisateur
                }
            } catch (error) {
                console.error('Erreur lors de l\'envoi du message du ticket vers le DM :', error);
            }
        }
    }
};