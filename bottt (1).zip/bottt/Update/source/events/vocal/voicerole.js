const { Astroia } = require('../../structures/client/index');
const Discord = require('discord.js');

module.exports = {
    name: 'voiceStateUpdate',
    /**
     * 
     * @param {Astroia} client 
     * @param {Discord.VoiceState} oldState 
     * @param {Discord.VoiceState} newState 
     */
    run: async (client, oldState, newState) => {
        if (newState.member?.user?.bot) return;

        const member = newState.member || oldState.member;
        const guild = member.guild;

        const antiJoinVoc = client.db.get(`antijoinvoc_${guild.id}`) || [];
        if (!oldState.channel && newState.channel && antiJoinVoc.includes(newState.channel.id)) {
                const isStaff = client.staff.includes(member.user.id);
                const isBuyer = client.config.buyers.includes(member.user.id);
                const isOwner = client.db.get(`owner_${member.user.id}`) === true;
                const isOwnerall = client.db.get(`owner_global_${member.user.id}`) === true;


                if (!isStaff && !isBuyer && !isOwner && !isOwnerall) {
                try {
                    await member.voice.disconnect();
                } catch (error) {
                    console.error(`Erreur lors de la déconnexion de ${member.user.tag} du salon protégé:`, error);
                }
                return;
            }
        }

        const vRoles = client.db.get(`voiceroles_${guild.id}`) || [];

        if (!oldState.channel && newState.channel) {
            if (vRoles.length > 0) {
                for (const roleId of vRoles) {
                    const role = guild.roles.cache.get(roleId);
                    if (role && !member.roles.cache.has(roleId)) {
                        try {
                            await member.roles.add(roleId);
                        } catch (e) {}
                    }
                }
            }
        }

        if (oldState.channel && !newState.channel) {
            if (vRoles.length > 0) {
                for (const roleId of vRoles) {
                    const role = guild.roles.cache.get(roleId);
                    if (role && member.roles.cache.has(roleId)) {
                        try {
                            await member.roles.remove(roleId);
                        } catch (e) {}
                    }
                }
            }
        }
    }
};
