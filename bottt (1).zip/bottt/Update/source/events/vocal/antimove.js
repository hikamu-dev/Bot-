const { Astroia } = require('../../structures/client/index');
const Discord = require('discord.js');

module.exports = {
    name: 'voiceStateUpdate',
    /**
     * 
     * @param {Astroia} client 
     * @param {Discord.VoiceState} oldState 
     * @param {Discord.VoiceState} newState 
     */
    run: async (client, oldState, newState) => {
        // Ignorer si l'utilisateur est un bot
        if (newState.member.user.bot) return;

        // Vérifier si le membre a rejoint un salon vocal
        if (!oldState.channel && newState.channel) {
            const member = newState.member;
            const guild = newState.guild;

            // Vérifier si le salon est protégé par antijoinvoc
            const antiJoinVocChannels = client.db.get(`antijoinvoc_${guild.id}`) || [];
            if (antiJoinVocChannels.includes(newState.channel.id)) {
                // Vérifier si l'utilisateur a les permissions pour contourner la protection
                const isStaff = client.staff.includes(member.user.id);
                const isBuyer = client.config.buyers.includes(member.user.id);
                const isOwner = client.db.get(`owner_${member.user.id}`) === true;
                const isOwnerall = client.db.get(`owner_global_${member.user.id}`) === true;


                if (!isStaff && !isBuyer && !isOwner && !isOwnerall) {
                    try {
                        // Déconnecter l'utilisateur du salon protégé
                        await member.voice.disconnect();
                        
                        // Optionnel : envoyer un message privé à l'utilisateur
                        try {
                        } catch (dmError) {
                            // Ignorer si on ne peut pas envoyer de MP
                        }
                    } catch (error) {
                        console.error(`Erreur lors de la déconnexion de ${member.user.tag} du salon protégé:`, error);
                    }
                    return;
                }
            }

            // Récupérer les rôles configurés pour vrole
            const roles = client.db.get(`vrole_${guild.id}`) || [];
            if (roles.length > 0) {
                // Ajouter les rôles au membre
                try {
                    for (const roleId of roles) {
                        const role = guild.roles.cache.get(roleId);
                        if (role && !member.roles.cache.has(roleId)) {
                            await member.roles.add(roleId);
                        }
                    }
                } catch (error) {
                    console.error(`Erreur lors de l'attribution des rôles à ${member.user.tag}:`, error);
                }
            }
        }

        // Vérifier si le membre a été déplacé d'un salon vers un autre
        if (oldState.channel && newState.channel && oldState.channel.id !== newState.channel.id) {
            const member = newState.member;
            const guild = newState.guild;

            // Vérifier si le salon d'origine est protégé par antimoove
            const antiMooveChannels = client.db.get(`antimoove_${guild.id}`) || [];
            if (antiMooveChannels.includes(oldState.channel.id)) {
                // Vérifier si l'utilisateur a les permissions pour contourner la protection
                const isStaff = client.staff.includes(member.user.id);
                const isBuyer = client.config.buyers.includes(member.user.id);
                const isOwner = client.db.get(`owner_${member.user.id}`) === true;

                if (!isStaff && !isBuyer && !isOwner) {
                    try {
                        // Remettre l'utilisateur dans son salon d'origine
                        await member.voice.setChannel(oldState.channel);
                        
                        // Optionnel : envoyer un message privé à l'utilisateur
                        try {
                        } catch (dmError) {
                            // Ignorer si on ne peut pas envoyer de MP
                        }
                    } catch (error) {
                        console.error(`Erreur lors du replacement de ${member.user.tag} dans le salon protégé:`, error);
                    }
                    return;
                }
            }
        }

        // Vérifier si le membre a quitté un salon vocal
        if (oldState.channel && !newState.channel) {
            const member = oldState.member;
            const guild = oldState.guild;

            const roles = client.db.get(`vrole_${guild.id}`) || [];
            if (roles.length > 0) {
                try {
                    for (const roleId of roles) {
                        if (member.roles.cache.has(roleId)) {
                            await member.roles.remove(roleId);
                        }
                    }
                } catch (error) {
                    console.error(`Erreur lors de la suppression des rôles de ${member.user.tag}:`, error);
                }
            }
        }
    }
};