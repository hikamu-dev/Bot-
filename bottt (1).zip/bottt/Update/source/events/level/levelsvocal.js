// events/levels_ready.js
const { EmbedBuilder } = require("discord.js");

const kEnabled = g => `levels_enabled_${g}`;
const kChan    = g => `levels_channel_${g}`;
const kMode    = g => `levels_mode_${g}`;
const kFmt     = g => `levels_format_${g}`;   // "embed" | "message"
const kCfg     = g => `levels_config_${g}`;
const kUser    = (g,u) => `levels_user_${g}_${u}`;
const kMsgTpl  = g => `levels_msgtpl_${g}`;
const kRewards = g => `levels_rewards_${g}`;

function getCfg(client, guildId) {
  return client.db.get?.(kCfg(guildId)) || {
    diff: "moyen",
    xpMin: 8, xpMax: 12,
    cooldown: 35,
    voiceXpPerMin: 1,
    maxLevel: 0
  };
}

function triangular(n){ return (n*(n+1))/2; }
function needFor(cfg, level) {
  const L = Math.max(0, level);
  switch ((cfg.diff||"moyen").toLowerCase()) {
    case "facile":     return 100 + 20*L;
    case "moyen":      return 120 + 30*L + 5*L*L;
    case "difficile":  return 150 + 50*triangular(L);   // 150,200,300,450,650,900...
    case "ultrahard":  return 200 + 100*triangular(L);  // 200,300,500,800,1200...
    default:           return 120 + 30*L + 5*L*L;
  }
}

async function giveRewards(client, member, level) {
  const list = client.db.get?.(kRewards(member.guild.id)) || [];
  const got = list.filter(r => r.level === level);
  for (const r of got) {
    const role = member.guild.roles.cache.get(r.roleId);
    if (role && !member.roles.cache.has(role.id)) {
      await member.roles.add(role).catch(() => {});
    }
  }
}

function renderMsgTemplate(client, guild, member, level) {
  const tpl = client.db.get?.(kMsgTpl(guild.id)) || "🎉 {mention} est maintenant **niveau {level}** !";
  return tpl
    .replace(/\{mention\}/g, `${member}`)
    .replace(/\{user\}/g, `${member.user.username}`)
    .replace(/\{level\}/g, `${level}`);
}

async function announceLevelup(client, guild, member, newLevel) {
  const mode  = client.db.get?.(kMode(guild.id)) || "channel";
  const fmt   = (client.db.get?.(kFmt(guild.id)) || "embed").toLowerCase();
  const chId  = client.db.get?.(kChan(guild.id));
  const ch    = chId ? guild.channels.cache.get(chId) : null;
  const color = client.color || 0x5865F2;

  const content = renderMsgTemplate(client, guild, member, newLevel);
  const embed = new EmbedBuilder().setColor(color).setDescription(content);
  const canSendCh = ch && ch.permissionsFor(guild.members.me)?.has(["ViewChannel","SendMessages"]);

  const sendDM = async () => {
    try {
      if (fmt === "embed") await member.user.send({ embeds: [embed] });
      else await member.user.send({ content });
      return true;
    } catch { return false; }
  };
  const sendCH = async () => {
    if (!canSendCh) return false;
    try {
      if (fmt === "embed") await ch.send({ embeds: [embed] });
      else await ch.send({ content });
      return true;
    } catch { return false; }
  };

  if (mode === "dm") {
    const ok = await sendDM();
    if (!ok) await sendCH();
    return;
  }
  if (mode === "both") {
    await sendDM();
    await sendCH();
    return;
  }
  await sendCH();
}

async function addXpAndMaybeLevelUp(client, guild, member, gain) {
  const cfg = getCfg(client, guild.id);
  const maxLevel = (!cfg.maxLevel || cfg.maxLevel <= 0) ? Infinity : cfg.maxLevel;

  const state = client.db.get?.(kUser(guild.id, member.id)) || { xp: 0, level: 0 };
  let xp = state.xp + gain;
  let lvl = state.level;

  let up = false;
  while (xp >= needFor(cfg, lvl) && lvl < maxLevel) {
    xp -= needFor(cfg, lvl);
    lvl++;
    up = true;
    if (lvl > 100000) break; // garde-fou
  }

  client.db.set?.(kUser(guild.id, member.id), { xp, level: lvl });

  if (up) {
    await giveRewards(client, member, lvl).catch(() => {});
    await announceLevelup(client, guild, member, lvl).catch(() => {});
  }
}

let voiceTickerStarted = false;

module.exports = {
  name: "ready",
  run: async (client) => {
    if (voiceTickerStarted) return;
    voiceTickerStarted = true;

    setInterval(async () => {
      try {
        for (const [, guild] of client.guilds.cache) {
          const enabled = !!client.db.get?.(kEnabled(guild.id));
          if (!enabled) continue;

          const cfg = getCfg(client, guild.id);
          const perMin = Math.max(0, cfg.voiceXpPerMin || 0);
          if (!perMin) continue;

          for (const [, ch] of guild.channels.cache) {
            if (!ch?.isVoiceBased?.()) continue;

            // Au moins 2 humains non sourds (anti-AFK solo)
            const humans = [...ch.members.values()].filter(m =>
              m && !m.user.bot && !m.voice.selfDeaf
            );
            if (humans.length < 2) continue;

            for (const m of humans) {
              await addXpAndMaybeLevelUp(client, guild, m, perMin);
            }
          }
        }
      } catch {}
    }, 60 * 1000); // chaque minute
  }
};
