const Discord = require('discord.js');

module.exports = {
  name: 'ready',
  once: true,
  run: async (client) => {
    setInterval(async () => {
      for (const guild of client.guilds.cache.values()) {
        const reminderKey = `reminders_${guild.id}`;
        let reminders = client.db.get(reminderKey) || [];

        const now = Math.floor(Date.now() / 1000);
        const remindersToSend = reminders.filter(r => r.remindAt <= now);

        if (remindersToSend.length === 0) continue;

        for (const reminder of remindersToSend) {
          const user = await client.users.fetch(reminder.userId).catch(() => null);
          if (!user) continue;

          const embed = new Discord.EmbedBuilder()
            .setColor(client.color)
            .setFooter(client.footer)
            .setTitle('⏰ Rappel')
            .setDescription(`Tu m'as demandé de te rappeler : **${reminder.message}**\nDéclenché à <t:${reminder.remindAt}:F>`)
            .setTimestamp();

          try {
            await user.send({ embeds: [embed] });
          } catch (error) {
            console.error(`Impossible d'envoyer un DM à ${reminder.userId} pour le rappel ID ${reminder.id}:`, error);
          }
        }

        reminders = reminders.filter(r => r.remindAt > now);
        client.db.set(reminderKey, reminders);
      }
    }, 10000);
  }
};
