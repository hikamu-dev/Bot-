const { EmbedBuilder, Events } = require('discord.js');

module.exports = {
    name: Events.GuildMemberUpdate,
    /**
     * @param {import('discord.js').Client} client
     * @param {import('discord.js').GuildMember} oldMember
     * @param {import('discord.js').GuildMember} newMember
     */
    run: async (client, oldMember, newMember) => {
        try {
            // Détection du boost (ajout)
            const wasBoosting = !!oldMember.premiumSince;
            const isNowBoosting = !!newMember.premiumSince;

            if (!wasBoosting && isNowBoosting) {
                const db = client.db.get(`boostembed_${newMember.guild.id}`);
                if (!db || !db.status || !db.channel || !db.message) return;

                const channel = newMember.guild.channels.cache.get(db.channel);
                if (!channel || !channel.send) return;

                const user = newMember.user || await newMember.fetch(); // Fallback au cas où `user` serait partiellement chargé

                const description = db.message
                    .replace(/{user}/g, `<@${newMember.id}>`)
                    .replace(/{server}/g, `${newMember.guild.name}`)
                    .replace(/{boostcount}/g, `${newMember.guild.premiumSubscriptionCount}`)
                    .replace(/{boost}/g, `🔮`);

                const embed = new EmbedBuilder()
                    .setColor("#ff73fa")
                    .setDescription(description)
                    .setAuthor({ name: `${user.username} vient de booster le serveur !`, iconURL: user.displayAvatarURL() })
                    .setTimestamp();

                await channel.send({ embeds: [embed] });
            }
        } catch (error) {
            console.error(`[Boost Event Error]`, error);
        }
    }
};
