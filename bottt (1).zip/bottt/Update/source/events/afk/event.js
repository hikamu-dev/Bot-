const Discord = require('discord.js');
const processedMessages = new Set();

module.exports = {
  name: 'messageCreate',
  run: async (client, message) => {
    if (!message.guild || message.author.bot) return;

    // Vérifiez si le message a déjà été traité
    if (processedMessages.has(message.id)) return;
    processedMessages.add(message.id);

    // Supprimez l'ID après un court délai pour éviter les fuites mémoire
    setTimeout(() => processedMessages.delete(message.id), 5000);

    const prefix = client.config.prefix || "!";

    if (!message.content.startsWith(prefix)) {
      // Gestion des mentions d'AFK même hors commande
      if (message.mentions.users.size > 0) {
        for (const [, user] of message.mentions.users) {
          const afkData = client.db.get(`afk_${user.id}`);
          if (afkData) {
            const timestamp = Math.floor(afkData.timestamp / 1000); // Convertir en secondes pour Discord timestamp
            message.channel.send(
            `**${user.tag}** est actuellement AFK \`${afkData.reason ? `${afkData.reason}` : ""}\` (<t:${timestamp}:R>.)`            );
          }
        }
      }
      // Si l'auteur était AFK, on retire le mode
      const authorAfk = client.db.get(`afk_${message.author.id}`);
      if (authorAfk) {
        client.db.delete(`afk_${message.author.id}`);
        message.channel.send(`Le mode afk de <@${message.author.id}> a été retiré.`);
      }
      return;
    }

    const args = message.content.slice(prefix.length).trim().split(/ +/);
    let commandName = args.shift().toLowerCase();

    const guildAliases = client.db.get(`aliases.${message.guild.id}`) || {};

    for (const [cmd, aliases] of Object.entries(guildAliases)) {
      if (aliases.includes(commandName)) {
        commandName = cmd;
        break;
      }
    }

    const command = client.commands.get(commandName) || client.aliases.get(commandName);
    if (!command) return;
  }
};