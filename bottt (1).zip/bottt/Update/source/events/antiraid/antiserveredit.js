// events/antiserverEdit.js
const Discord = require("discord.js");

function calcBypass(client, guild, executorMember, cfg){
  const id = executorMember?.id;
  const wl = client.db.get(`wl.${guild.id}`) || [];
  const isBuyer    = client.config?.buyers?.includes?.(id);
  const isStaff    = client.staff?.includes?.(id);
  const isOwnerLoc = client.db.get(`owner_${guild.id}_${id}`) === true || client.db.get(`owner_${id}`) === true;
  const isOwnerGbl = client.db.get(`owner_global_${id}`) === true;
  const isGOwner   = guild.ownerId === id;

  const bypassStored = client.db.get(`bypass_antiserveredit_${guild.id}`) || { users: [], roles: [] };
  const byUser = bypassStored.users?.includes?.(id);
  const byRole = executorMember ? bypassStored.roles?.some?.(r => executorMember.roles.cache.has(r)) : false;

  return (cfg.mode === "max")
    ? (isBuyer || isStaff || isOwnerLoc || isOwnerGbl || isGOwner || byUser || byRole)
    : (isBuyer || isStaff || isOwnerLoc || isOwnerGbl || isGOwner || wl.includes(id) || byUser || byRole);
}

async function findGuildUpdateExecutor(guild) {
  try {
    const logs = await guild.fetchAuditLogs({ type: Discord.AuditLogEvent.GuildUpdate, limit: 5 });
    const now = Date.now();
    const e = logs.entries.find(x => now - (x.createdTimestamp || 0) <= 15000);
    return e || null;
  } catch { return null; }
}

async function revertChanges(oldGuild, newGuild, diffs) {
  const patch = {};
  if (diffs.includes("name")) patch.name = oldGuild.name;
  if (diffs.includes("icon")) patch.icon = oldGuild.iconURL({ extension: "png", size: 256 }) || null;
  if (diffs.includes("banner")) patch.banner = oldGuild.bannerURL({ extension: "png", size: 1024 }) || null;
  if (diffs.includes("systemChannelId")) patch.systemChannel = oldGuild.systemChannelId || null;
  if (diffs.includes("afkChannelId")) patch.afkChannel = oldGuild.afkChannelId || null;
  if (diffs.includes("afkTimeout")) patch.afkTimeout = oldGuild.afkTimeout;
  if (diffs.includes("defaultMessageNotifications")) patch.defaultMessageNotifications = oldGuild.defaultMessageNotifications;
  if (diffs.includes("explicitContentFilter")) patch.explicitContentFilter = oldGuild.explicitContentFilter;
  if (diffs.includes("verificationLevel")) patch.verificationLevel = oldGuild.verificationLevel;
  if (diffs.includes("preferredLocale")) patch.preferredLocale = oldGuild.preferredLocale;

  const keys = Object.keys(patch);
  if (!keys.length) return false;

  try {
    await newGuild.edit(patch, "AntiServerEdit: revert");
    return true;
  } catch { return false; }
}

async function sendLog(client, guild, embed) {
  const id = client.db.get(`raidlogs_${guild.id}`);
  const ch = id ? (guild.channels.cache.get(id) || await guild.channels.fetch(id).catch(()=>null)) : null;
  if (ch?.send) await ch.send({ embeds: [embed], allowedMentions: { parse: [] } }).catch(()=>{});
}

module.exports = {
  name: "guildUpdate",
  run: async (client, oldGuild, newGuild) => {
    try {
      const guild = newGuild;
      if (!guild?.available) return;

      // cfg object
      let cfg = client.db.get(`antiserveredit.${guild.id}`);
      if (!cfg) return;
      if (typeof cfg === "string") cfg = (cfg === "on") ? { status:"on", mode:"normal" } : { status:"off", mode:"normal" };
      if (cfg.status !== "on") return;

      const color = client.db.get(`color_${guild.id}`) || client.config.default_color;

      // diffs
      const diffs = [];
      if (oldGuild.name !== newGuild.name) diffs.push("name");
      if (oldGuild.icon !== newGuild.icon) diffs.push("icon");
      if (oldGuild.banner !== newGuild.banner) diffs.push("banner");
      if (oldGuild.systemChannelId !== newGuild.systemChannelId) diffs.push("systemChannelId");
      if (oldGuild.afkChannelId !== newGuild.afkChannelId) diffs.push("afkChannelId");
      if (oldGuild.afkTimeout !== newGuild.afkTimeout) diffs.push("afkTimeout");
      if (oldGuild.defaultMessageNotifications !== newGuild.defaultMessageNotifications) diffs.push("defaultMessageNotifications");
      if (oldGuild.explicitContentFilter !== newGuild.explicitContentFilter) diffs.push("explicitContentFilter");
      if (oldGuild.verificationLevel !== newGuild.verificationLevel) diffs.push("verificationLevel");
      if (oldGuild.preferredLocale !== newGuild.preferredLocale) diffs.push("preferredLocale");
      if (!diffs.length) return;

      // executor
      const entry = await findGuildUpdateExecutor(guild);
      const execUser = entry?.executor || null;
      const execMember = execUser ? await guild.members.fetch(execUser.id).catch(()=>null) : null;

      // inconnu: revert si possible et log
      if (!execMember) {
        if (guild.members.me?.permissions.has(Discord.PermissionFlagsBits.ManageGuild)) {
          await revertChanges(oldGuild, newGuild, diffs);
        }
        const embed = new Discord.EmbedBuilder()
          .setColor(color)
          .setTitle("🚨 Lyna - AntiServerEdit")
          .setDescription(`Changements: \`${diffs.join(", ")}\`\nSanction appliquée: \`ban\` (exécuteur inconnu)`)
          .setTimestamp();
        return void sendLog(client, guild, embed);
      }

      // bypass ?
      const ok = calcBypass(client, guild, execMember, cfg);
      if (ok) {
        const embed = new Discord.EmbedBuilder()
          .setColor(color)
          .setTitle("✅ Lyna - AntiServerEdit (autorisé)")
          .setDescription(`${execMember} a modifié des paramètres (bypass).\nChangements: \`${diffs.join(", ")}\`\nSanction appliquée: \`aucune\``)
          .setTimestamp();
        return void sendLog(client, guild, embed);
      }

      // revert si possible
      let reverted = false;
      if (guild.members.me?.permissions.has(Discord.PermissionFlagsBits.ManageGuild)) {
        reverted = await revertChanges(oldGuild, newGuild, diffs);
      }

      // sanction (toujours, sans seuil)
      let sanction = (client.db.get(`punish_${guild.id}.antiserveredit`) || "ban").toLowerCase();
      try {
        if (execMember.manageable) {
          if (sanction === "ban" && guild.members.me?.permissions.has(Discord.PermissionFlagsBits.BanMembers)) {
            await guild.members.ban(execMember.id, { reason: "AntiServerEdit: modification non autorisée" });
          } else if (sanction === "kick" && guild.members.me?.permissions.has(Discord.PermissionFlagsBits.KickMembers)) {
            await execMember.kick("AntiServerEdit: modification non autorisée");
          } else if (sanction === "derank" && guild.members.me?.permissions.has(Discord.PermissionFlagsBits.ManageRoles)) {
            const roles = execMember.roles.cache.filter(r => r.editable && r.id !== guild.id).map(r => r.id);
            if (roles.length) await execMember.roles.remove(roles, "AntiServerEdit: modification non autorisée");
          } else if ((sanction === "mute" || sanction === "timeout") && guild.members.me?.permissions.has(Discord.PermissionFlagsBits.ModerateMembers)) {
            await execMember.timeout(10*60*1000, "AntiServerEdit: modification non autorisée");
          }
        }
      } catch {}

      // log
      const embed = new Discord.EmbedBuilder()
        .setColor(color)
        .setTitle(reverted ? "🚨 Lyna - AntiServerEdit (rétabli)" : "🚨 Lyna - AntiServerEdit")
        .setDescription(`${execMember} a modifié des paramètres du serveur.\nChangements: \`${diffs.join(", ")}\`\nSanction appliquée: \`${sanction}\``)
        .addFields(
          { name: "Auteur", value: `${execMember.user.tag} (${execMember.id})`, inline: true },
          { name: "Rétablissement", value: reverted ? "Oui" : "Non", inline: true }
        )
        .setTimestamp();

      await sendLog(client, guild, embed);

    } catch {}
  }
};
