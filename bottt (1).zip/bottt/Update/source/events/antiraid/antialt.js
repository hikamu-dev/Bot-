const { Astroia } = require('../../structures/client/index');
const Discord = require('discord.js');
const ms = require('ms');

module.exports = {
  name: 'guildMemberAdd',
  /**
   * @param {Astroia} client
   */
  run: async (client, member) => {
    const guild = member.guild;

    if (member.user.bot) return;
    if (member.id === guild.ownerId) return;
    if (client.config.buyers.includes(member.id)) return;
    if (client.db.get(`owner_global_${member.id}`) === true) return;
    if (client.db.get(`owner_${member.id}`) === true) return;

    const antialt = client.db.get(`antialt_${guild.id}`);
    if (!antialt || antialt.status !== 'on') return;

    const wl = client.db.get(`wl.${guild.id}`) || [guild.ownerId];
    if (wl.includes(member.id)) return;

    const accountAge = Date.now() - member.user.createdTimestamp;
    const minAge = parseInterval(antialt.minAge || '7d');

    if (accountAge < minAge) {
      const sanction = client.db.get(`punish_${guild.id}.antialt`) || 'kick';
      const reason = `Anti-Alt | Compte trop récent (moins de ${antialt.minAge})`;

      try {
        switch (sanction) {
          case 'derank':
            await member.roles.set([]);
            break;
          case 'kick':
            await member.kick(reason);
            break;
          case 'ban':
            await member.ban({ reason, days: 1 });
            break;
          case 'mute':
            if (member.moderatable) {
              await member.timeout(ms('1h'), reason); // Timeout 1h ici aussi
            }
            break;
        }

        // Logs
        const logsEmbed = new Discord.EmbedBuilder()
          .setTimestamp()
          .setColor(client.db.get(`color_${guild.id}`) || client.config.default_color)
          .setDescription(`${member} a été sanctionné pour compte trop récent (< ${antialt.minAge})\nSanction appliquée: \`${sanction}\``)
          .setAuthor({
            name: `${member.user.tag} (${member.id})`,
            iconURL: member.user.displayAvatarURL()
          })
          .addFields(
            { name: 'Âge du compte', value: formatTime(accountAge), inline: true },
            { name: 'Âge minimum requis', value: antialt.minAge, inline: true }
          );

        // PING
        let content = null;
        const pingraid = client.db.get(`pingraid_${guild.id}`);
        const pingraidRole = client.db.get(`pingraid_role_${guild.id}`);

        if (pingraid) {
          switch (pingraid) {
            case "everyone": content = "@everyone"; break;
            case "here": content = "@here"; break;
            case "role": content = pingraidRole ? `<@&${pingraidRole}>` : null; break;
            case "buyers": content = client.config.buyers.length > 0 ? `<@${client.config.buyers.join(", ")}>` : null; break;
            case "owners":
              const globalOwners = Object.entries(client.db.all())
                .filter(([key, value]) => key.startsWith(`owner_global_`) && value === true)
                .map(([key]) => key.split('_')[2]);

              const serverOwners = Object.entries(client.db.all())
                .filter(([key, value]) => key.startsWith(`owner_${guild.id}_`) && value === true)
                .map(([key]) => key.split('_')[2]);

              const allOwners = [...new Set([...globalOwners, ...serverOwners])];
              content = allOwners.length > 0 ? allOwners.map(o => `<@${o}>`).join(", ") : "Aucun owner";
              break;
          }
        }

        const logChannel = guild.channels.cache.get(client.db.get(`raidlogs_${guild.id}`));
        if (logChannel) {
          logChannel.send({ embeds: [logsEmbed], content });
        }

      } catch (error) {
        console.error(`Erreur lors de la sanction anti-alt: ${error}`);
      }
    }
  }
};

function parseInterval(input) {
  if (!input || typeof input !== 'string') return NaN;

  const intervalRegex = /^(\d+)([smhdwja])$/;
  const match = input.match(intervalRegex);
  if (!match) return NaN;

  const value = parseInt(match[1]);
  const unit = match[2];

  switch (unit) {
    case 's': return value * 1000;
    case 'm': return value * 60000;
    case 'h': return value * 3600000;
    case 'd': return value * 86400000;
    case 'w': return value * 604800000;
    case 'a': return value * 31536000000;
    default: return NaN;
  }
}

function formatTime(ms) {
  const days = Math.floor(ms / (24 * 60 * 60 * 1000));
  const hours = Math.floor((ms % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000));
  return `${days}j ${hours}h`;
}