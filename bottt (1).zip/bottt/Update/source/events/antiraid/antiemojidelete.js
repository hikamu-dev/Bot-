// events/antiemojiDelete.js
const Discord = require("discord.js");
const https = require("https");

function download(url){
  return new Promise((resolve,reject)=>{
    https.get(url, res=>{
      if (res.statusCode !== 200) { res.resume(); return reject(new Error("HTTP "+res.statusCode)); }
      const chunks=[]; res.on("data",d=>chunks.push(d));
      res.on("end", ()=> resolve(Buffer.concat(chunks)));
    }).on("error", reject);
  });
}

async function findEmojiDeleteExecutor(guild) {
  try {
    const logs = await guild.fetchAuditLogs({ type: Discord.AuditLogEvent.EmojiDelete, limit: 5 });
    const now = Date.now();
    const e = logs.entries.find(x => now - (x.createdTimestamp || 0) <= 15000);
    return e?.executor || null;
  } catch { return null; }
}

function calcBypass(client, guild, executorMember, cfg){
  const id = executorMember?.id;
  const wl = client.db.get(`wl.${guild.id}`) || [];
  const isBuyer    = client.config?.buyers?.includes?.(id);
  const isStaff    = client.staff?.includes?.(id);
  const isOwnerLoc = client.db.get(`owner_${guild.id}_${id}`) === true || client.db.get(`owner_${id}`) === true;
  const isOwnerGbl = client.db.get(`owner_global_${id}`) === true;
  const isGOwner   = guild.ownerId === id;

  const bypassStored = client.db.get(`bypass_antiemojidelete_${guild.id}`) || { users: [], roles: [] };
  const byUser = bypassStored.users?.includes?.(id);
  const byRole = executorMember ? bypassStored.roles?.some?.(r => executorMember.roles.cache.has(r)) : false;

  return (cfg.mode === "max")
    ? (isBuyer || isStaff || isOwnerLoc || isOwnerGbl || isGOwner || byUser || byRole)
    : (isBuyer || isStaff || isOwnerLoc || isOwnerGbl || isGOwner || wl.includes(id) || byUser || byRole);
}

async function sendLog(client, guild, embed) {
  const id = client.db.get(`raidlogs_${guild.id}`);
  const ch = id ? (guild.channels.cache.get(id) || await guild.channels.fetch(id).catch(()=>null)) : null;
  if (ch?.send) await ch.send({ embeds: [embed], allowedMentions: { parse: [] } }).catch(()=>{});
}

module.exports = {
  name: "emojiDelete",
  run: async (client, emoji) => {
    try {
      const guild = emoji.guild;
      if (!guild?.available) return;

      // cfg object
      let cfg = client.db.get(`antiemojidelete_${guild.id}`);
      if (!cfg) return;
      if (typeof cfg === "string") cfg = (cfg === "on") ? { status:"on", mode:"normal" } : { status:"off", mode:"normal" };
      if (cfg.status !== "on") return;

      const color = client.db.get(`color_${guild.id}`) || client.config.default_color;

      // exécuteur
      const execUser = await findEmojiDeleteExecutor(guild);
      const execMember = execUser ? await guild.members.fetch(execUser.id).catch(()=>null) : null;

      // tentative de restauration
      let restored = false, used = "cache";
      const me = guild.members.me;

      if (me?.permissions.has(Discord.PermissionFlagsBits.ManageGuildExpressions)) {
        const vault = client.db.get(`emoji_vault.${guild.id}.${emoji.id}`);
        let name = emoji.name, buf = null;

        if (vault?.b64) {
          try { buf = Buffer.from(vault.b64, "base64"); name = vault.name || name; } catch {}
        }
        if (!buf) {
          try {
            used = "cdn";
            const url = `https://cdn.discordapp.com/emojis/${emoji.id}.${emoji.animated ? "gif" : "webp"}?size=128&quality=lossless`;
            buf = await download(url);
          } catch {}
        }
        if (buf) {
          try {
            await guild.emojis.create({ attachment: buf, name }, { reason: "AntiEmojiDelete: restauration auto" });
            restored = true;
          } catch { restored = false; }
        }
      }

      if (!execMember) {
        const embed = new Discord.EmbedBuilder()
          .setColor(color).setTitle("🛡️ AntiEmojiDelete")
          .setDescription(`Emoji \`${emoji.name}\` supprimé — exécuteur **inconnu**.\nAction: ${restored ? `**emoji restauré** (via ${used})` : "**restauration impossible**"}`)
          .setTimestamp();
        return void sendLog(client, guild, embed);
      }

      // bypass ?
      const ok = calcBypass(client, guild, execMember, cfg);
      if (ok) {
        const embed = new Discord.EmbedBuilder()
          .setColor(color).setTitle("🛡️ AntiEmojiDelete (autorisé)")
          .setDescription(`${execMember} a supprimé \`${emoji.name}\` (bypass).`)
          .setTimestamp();
        return void sendLog(client, guild, embed);
      }

      // log (non-bypass)
      const embed = new Discord.EmbedBuilder()
        .setColor(color)
        .setTitle("🛡️ AntiEmojiDelete")
        .setDescription(`${execMember} a supprimé un emoji sans autorisation.\nAction: ${restored ? `**emoji restauré** (via ${used})` : "**restauration impossible**"} (aucune sanction)`)
        .addFields(
          { name: "Auteur", value: `${execMember.user.tag} (${execMember.id})`, inline: true },
          { name: "Emoji", value: `\`${emoji.name}\` (${emoji.id})`, inline: true }
        )
        .setTimestamp();

      await sendLog(client, guild, embed);

    } catch {}
  }
};
