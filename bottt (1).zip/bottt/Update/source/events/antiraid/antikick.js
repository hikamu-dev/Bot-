// events/antikick.js
const Discord = require('discord.js');
const ms = require('ms');

/**
 * LOGS RAID (garde ta même base)
 */
async function sendAntiKickLog(client, guild, executor, kickedMember, sanction) {
  const embed = new Discord.EmbedBuilder()
    .setColor(client.db.get(`color_${guild.id}`) || client.config.default_color)
    .setTitle("🚨 AntiKick détecté")
    .setDescription(`${executor} a exclu ${kickedMember}\nSanction: \`${sanction}\``)
    .setAuthor({
      name: `${executor.username} (${executor.id})`,
      iconURL: executor.displayAvatarURL()
    })
    .setTimestamp();

  await sendLogToChannel(client, guild, embed);
}
async function sendErrorLog(client, guild, executor, kickedMember, error) {
  const embed = new Discord.EmbedBuilder()
    .setColor("#FF0000")
    .setTitle("⚠️ Erreur AntiKick")
    .setDescription(`Erreur lors de la sanction`)
    .addFields(
      { name: "Membre exclu", value: `${kickedMember.user?.tag || kickedMember.id}`, inline: true },
      { name: "Erreur", value: `\`\`\`${error?.message || error}\`\`\`` }
    )
    .setAuthor({
      name: `${executor?.username || "inconnu"} (${executor?.id || "?"})`,
      iconURL: executor?.displayAvatarURL?.() || null
    })
    .setTimestamp();

  await sendLogToChannel(client, guild, embed);
}
async function sendLogToChannel(client, guild, embed) {
  let pingraid = client.db.get(`pingraid_${guild.id}`);
  const pingraidRole = client.db.get(`pingraid_role_${guild.id}`);
  let content = null;

  if (pingraid) {
    switch (pingraid) {
      case "everyone": content = "@everyone"; break;
      case "here": content = "@here"; break;
      case "role": content = pingraidRole ? `<@&${pingraidRole}>` : null; break;
      case "buyers": content = (client.config?.buyers?.length ? client.config.buyers.map(id=>`<@${id}>`).join(", ") : null); break;
      case "owners": {
        const all = client.db.all?.() || [];
        const globalOwners = all.filter(([k,v]) => k.startsWith(`owner_global_`) && v === true).map(([k]) => k.split('_')[2]);
        const serverOwners = all.filter(([k,v]) => k.startsWith(`owner_${guild.id}_`) && v === true).map(([k]) => k.split('_')[2]);
        const allOwners = [...new Set([...globalOwners, ...serverOwners])];
        content = allOwners.length > 0 ? allOwners.map(o => `<@${o}>`).join(", ") : null;
        break;
      }
    }
  }

  const logChannel = guild.channels.cache.get(client.db.get(`raidlogs_${guild.id}`));
  if (logChannel) {
    await logChannel.send({ embeds: [embed], content }).catch(() => {});
  }
}

/**
 * EVENT: guildMemberRemove (+ AuditLog MemberKick)
 * - Seuil de sanction
 * - Bypass module (users/roles) : bypass_antikick_<guild>
 * - Mode "max" = pas de WL
 * - Bot self-bypass
 */
module.exports = {
  name: 'guildMemberRemove',
  /**
   * @param {import('../../structures/client').Astroia} client
   * @param {Discord.GuildMember} member
   */
  run: async (client, member) => {
    try {
      const guild = member.guild;
      if (!guild) return;

      // Config
      let cfg = client.db.get(`antikick_${guild.id}`);
      if (!cfg) return;
      if (typeof cfg === "string") {
        // compat legacy "on/off/max"
        cfg = (cfg === "off") ? { status: "off", mode: "normal", seuil_sanction: 1, epoch: 0 }
            : (cfg === "on")  ? { status: "on",  mode: "normal", seuil_sanction: 1, epoch: 0 }
            :                    { status: "on",  mode: "max",    seuil_sanction: 1, epoch: 0 };
      } else if (cfg && typeof cfg === "object" && (cfg.status === "max" && !cfg.mode)) {
        cfg = { ...cfg, status: "on", mode: "max", seuil_sanction: (cfg.seuil_sanction ?? 1), epoch: (cfg.epoch ?? 0) };
      }
      if (cfg.status !== 'on') return;
      const epoch = cfg.epoch || 0;

      // AuditLog: vérifier que c'est bien un KICK
      const logs = await guild.fetchAuditLogs({ type: Discord.AuditLogEvent.MemberKick, limit: 5 }).catch(()=>null);
      const entry = logs?.entries?.find(e => (e.target?.id || e.targetId) === member.id);
      if (!entry) return; // départ volontaire ou autre cause
      const executor = entry.executor;
      if (!executor) return;

      // Bot (toi) se bypass
      const botId = guild.members.me?.id || client.user.id;
      if (executor.id === botId) return;

      const exMember = await guild.members.fetch(executor.id).catch(() => null);

      // BYPASS
      const isBuyer  = Array.isArray(client.config?.buyers) && client.config.buyers.includes(executor.id);
      const isStaff  = Array.isArray(client.staff) && client.staff.includes(executor.id);
      const isOwnerLocalLegacy = client.db.get(`owner_${executor.id}`) === true;
      const isOwnerLocalScoped  = client.db.get(`owner_${guild.id}_${executor.id}`) === true;
      const isGlobalOwner       = client.db.get(`owner_global_${executor.id}`) === true;
      const isGuildOwner        = executor.id === guild.ownerId;

      const wlList       = client.db.get(`wl.${guild.id}`) || [];
      const isWlArray    = Array.isArray(wlList) && wlList.includes(executor.id);
      const isWlFlag     = client.db.get(`wlmd_${guild.id}_${executor.id}`) === true;
      const isWhitelisted = isWlArray || isWlFlag;

      const bypassStored = client.db.get(`bypass_antikick_${guild.id}`) || { users: [], roles: [] };
      const isBypassUser = Array.isArray(bypassStored.users) && bypassStored.users.includes(executor.id);
      const isBypassRole = exMember ? (Array.isArray(bypassStored.roles) && bypassStored.roles.some(r => exMember.roles.cache.has(r))) : false;

      // Règles:
      //  - mode normal: buyers/staff/owners/guildOwner/WL/bypassModule
      //  - mode max:    buyers/staff/owners/guildOwner/bypassModule (pas WL)
      const okBypass = (cfg.mode === "max")
        ? (isBuyer || isStaff || isOwnerLocalLegacy || isOwnerLocalScoped || isGlobalOwner || isGuildOwner || isBypassUser || isBypassRole)
        : (isBuyer || isStaff || isOwnerLocalLegacy || isOwnerLocalScoped || isGlobalOwner || isGuildOwner || isWhitelisted || isBypassUser || isBypassRole);

      if (okBypass) return;

      // == REPAIR avant sanction ==
      // Discord n'autorise pas de "re-add" direct après un kick ; on tente une invite + DM (best effort)
      try {
        const defaultChannel = guild.systemChannel || guild.channels.cache.find(c => c.isTextBased?.() && c.permissionsFor(guild.members.me).has(Discord.PermissionsBitField.Flags.CreateInstantInvite));
        if (defaultChannel) {
          const inv = await defaultChannel.createInvite({ maxUses: 1, maxAge: 3600, reason: "AntiKick - Invite de réparation" }).catch(()=>null);
          if (inv) {
            await member.user?.send?.(`Tu as été kick de **${guild.name}**. Voici une invitation de réparation: ${inv.url}`).catch(()=>{});
          }
        }
      } catch {}

      // == Compteur par epoch ==
      const counterKey = `antikick_counter_${guild.id}.v${epoch}.kick.${executor.id}`;
      const count = (client.db.get(counterKey) || 0) + 1;
      client.db.set(counterKey, count);

      // == Seuil & Sanction ==
      const threshold = Number.isInteger(cfg.seuil_sanction) ? cfg.seuil_sanction : 1;
      let sanctionApplied = "aucune";

      if (threshold !== 0 && count >= threshold && exMember) {
        const punishDb = client.db.get(`punish_${guild.id}`) || {};
        const punishment = (punishDb.antikick || "").toLowerCase();
        const reason = "Kick non autorisé";

        try {
          switch (punishment) {
            case "mute":
              if (exMember.moderatable) {
                await exMember.timeout(ms("28d"), reason);
                sanctionApplied = "mute (28d)";
              } else {
                const roles = exMember.roles.cache.filter(r => r.editable && r.id !== guild.id);
                if (roles.size) await exMember.roles.remove(roles).catch(()=>{});
                sanctionApplied = "derank (fallback)";
              }
              break;
            case "kick":
              await exMember.kick(reason); sanctionApplied = "kick"; break;
            case "ban":
              await exMember.ban({ reason }); sanctionApplied = "ban"; break;
            case "derank":
              const roles = exMember.roles.cache.filter(r => r.editable && r.id !== guild.id);
              if (roles.size) await exMember.roles.remove(roles).catch(()=>{});
              sanctionApplied = "derank";
              break;
            default:
              sanctionApplied = "aucune (punish non défini)";
          }
        } catch (error) {
          console.error(`[ANTIKICK] sanction error:`, error);
          await sendErrorLog(client, guild, executor, member, error);
        }
      }

      await sendAntiKickLog(client, guild, executor, member, sanctionApplied);

    } catch (e) {
      console.error("[ANTIKICK] event error:", e);
    }
  }
};
