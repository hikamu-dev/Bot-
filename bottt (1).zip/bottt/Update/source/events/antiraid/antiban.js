// events/antiban.js
const Discord = require('discord.js');
const ms = require('ms');

/**
 * Log helpers (mêmes réponses que tes autres modules)
 */
async function sendAntiBanLog(client, guild, executor, bannedUser, sanction) {
  const embed = new Discord.EmbedBuilder()
    .setColor(client.db.get(`color_${guild.id}`) || client.config.default_color || 0x2b2d31)
    .setTitle("🚨 AntiBan détecté")
    .setDescription(`${executor} a banni ${bannedUser}\nSanction: \`${sanction}\``)
    .setAuthor({ name: `${executor.username} (${executor.id})`, iconURL: executor.displayAvatarURL() })
    .setTimestamp();
  await sendLogToChannel(client, guild, embed);
}

async function sendErrorLog(client, guild, executor, bannedUser, error) {
  const embed = new Discord.EmbedBuilder()
    .setColor("#FF0000")
    .setTitle("⚠️ Erreur AntiBan")
    .setDescription(`Erreur lors de la sanction`)
    .addFields(
      { name: "Utilisateur banni", value: `${bannedUser?.tag || bannedUser?.id || "inconnu"}`, inline: true },
      { name: "Erreur", value: `\`\`\`${error?.message || error}\`\`\`` }
    )
    .setAuthor({ name: `${executor?.username || "inconnu"} (${executor?.id || "?"})`, iconURL: executor?.displayAvatarURL?.() || null })
    .setTimestamp();
  await sendLogToChannel(client, guild, embed);
}

async function sendLogToChannel(client, guild, embed) {
  let content = null;
  const pingraid = client.db.get(`pingraid_${guild.id}`);
  const pingraidRole = client.db.get(`pingraid_role_${guild.id}`);
  if (pingraid) {
    switch (pingraid) {
      case "everyone": content = "@everyone"; break;
      case "here": content = "@here"; break;
      case "role": content = pingraidRole ? `<@&${pingraidRole}>` : null; break;
      case "buyers": content = (client.config?.buyers || []).map(id => `<@${id}>`).join(", "); break;
      case "owners": {
        const all = client.db.all?.() || [];
        const globals = all.filter(([k,v]) => k.startsWith("owner_global_") && v === true).map(([k]) => k.split("_")[2]);
        const locals  = all.filter(([k,v]) => k.startsWith(`owner_${guild.id}_`) && v === true).map(([k]) => k.split("_")[2]);
        const uniq = [...new Set([...globals, ...locals])];
        content = uniq.length ? uniq.map(o => `<@${o}>`).join(", ") : null;
        break;
      }
    }
  }
  const logChannel = guild.channels.cache.get(client.db.get(`raidlogs_${guild.id}`));
  if (logChannel) await logChannel.send({ embeds: [embed], content }).catch(()=>{});
}

/**
 * Event
 */
module.exports = {
  name: 'guildBanAdd',
  /**
   * @param {import('../../structures/client').Astroia} client
   * @param {Discord.GuildBan} ban
   */
  run: async (client, ban) => {
    try {
      const guild = ban.guild;
      const user = ban.user;
      if (!guild) return;

      // === Lire config + compat anciens formats ===
      let cfg = client.db.get(`antiban_${guild.id}`);
      if (!cfg) return; // pas configuré
      if (typeof cfg === "string") {
        // legacy: "off" | "on" | "max"
        cfg = (cfg === "off") ? { status: "off", mode: "normal", seuil_sanction: 1, epoch: 0 }
            : (cfg === "on")  ? { status: "on",  mode: "normal", seuil_sanction: 1, epoch: 0 }
            :                    { status: "on",  mode: "max",    seuil_sanction: 1, epoch: 0 };
      } else if (cfg && typeof cfg === "object" && (cfg.status === "max" && !cfg.mode)) {
        // legacy: { status: "max" } → on/mode=max
        cfg = { ...cfg, status: "on", mode: "max", seuil_sanction: (cfg.seuil_sanction ?? 1), epoch: (cfg.epoch ?? 0) };
      }
      if (cfg.status !== "on") return;
      const epoch = cfg.epoch || 0;

      // === Récupération de l’exécuteur via audit log ===
      const action = await guild.fetchAuditLogs({ limit: 5, type: Discord.AuditLogEvent.MemberBanAdd }).catch(()=>null);
      const entry = action?.entries?.find(e => (e.target?.id || e.targetId) === user.id) || action?.entries?.first();
      const executor = entry?.executor;
      if (!executor) return;

      // === Bypass: bot lui-même ===
      const botId = guild.members.me?.id || client.user.id;
      if (executor.id === botId) return;

      // === Bypass: roles/personnes/config ===
      const member = await guild.members.fetch(executor.id).catch(() => null);

      const isBuyer = Array.isArray(client.config?.buyers) && client.config.buyers.includes(executor.id);
      const isStaff = Array.isArray(client.staff) && client.staff.includes(executor.id);
      const isOwnerLocalLegacy = client.db.get(`owner_${executor.id}`) === true;
      const isOwnerLocalScoped  = client.db.get(`owner_${guild.id}_${executor.id}`) === true;
      const isGlobalOwner       = client.db.get(`owner_global_${executor.id}`) === true;
      const isGuildOwner        = (executor.id === guild.ownerId);

      // WL : soit liste array wl.<guild>, soit flags wlmd_<guild>_<user>
      const wlList = client.db.get(`wl.${guild.id}`) || [];
      const isWlArray = Array.isArray(wlList) && wlList.includes(executor.id);
      const isWlFlag  = client.db.get(`wlmd_${guild.id}_${executor.id}`) === true;
      const isWhitelisted = isWlArray || isWlFlag;

      // Bypass module dédié (users/roles) — via ta cmd +bypass antiban ...
      const bypassStored = client.db.get(`bypass_antiban_${guild.id}`) || { users: [], roles: [] };
      const isBypassUser = Array.isArray(bypassStored.users) && bypassStored.users.includes(executor.id);
      const isBypassRole = member ? (Array.isArray(bypassStored.roles) && bypassStored.roles.some(r => member.roles.cache.has(r))) : false;

      // Règles:
      //  - mode normal: buyers/staff/owners/guildOwner/WL/bypassModule
      //  - mode max:    buyers/staff/owners/guildOwner/bypassModule (pas WL)
      const okBypass = (cfg.mode === "max")
        ? (isBuyer || isStaff || isOwnerLocalLegacy || isOwnerLocalScoped || isGlobalOwner || isGuildOwner || isBypassUser || isBypassRole)
        : (isBuyer || isStaff || isOwnerLocalLegacy || isOwnerLocalScoped || isGlobalOwner || isGuildOwner || isWhitelisted || isBypassUser || isBypassRole);

      if (okBypass) return;

      // === Réparer: débannir la cible (toujours) ===
      await guild.members.unban(user.id, "AntiBan: débannissement automatique").catch(()=>{});

      // === Compteur par epoch ===
      const counterKey = `antiban_counter_${guild.id}.v${epoch}.ban.${executor.id}`;
      const count = (client.db.get(counterKey) || 0) + 1;
      client.db.set(counterKey, count);

      // === Seuil & sanction ===
      const threshold = Number.isInteger(cfg.seuil_sanction) ? cfg.seuil_sanction : 1;
      let sanctionApplied = "aucune";

      if (threshold !== 0 && count >= threshold && member) {
        const punishDb = client.db.get(`punish_${guild.id}`) || {};
        const punishment = (punishDb.antiban || "").toLowerCase();
        const reason = "Ban non autorisé";

        try {
          switch (punishment) {
            case "mute":
              if (member.moderatable) { await member.timeout(ms("1h"), reason); sanctionApplied = "mute (1h)"; }
              else { // fallback
                const roles = member.roles.cache.filter(r => r.editable && r.id !== guild.id);
                if (roles.size) await member.roles.remove(roles).catch(()=>{});
                sanctionApplied = "derank (fallback)";
              }
              break;
            case "kick":
              await member.kick(reason); sanctionApplied = "kick"; break;
            case "ban":
              await member.ban({ reason, deleteMessageSeconds: 0 }); sanctionApplied = "ban"; break;
            case "derank":
              const roles = member.roles.cache.filter(r => r.editable && r.id !== guild.id);
              if (roles.size) await member.roles.remove(roles).catch(()=>{});
              sanctionApplied = "derank"; break;
            default:
              sanctionApplied = "aucune (punish non défini)";
          }
        } catch (e) {
          await sendErrorLog(client, guild, executor, user, e);
        }
      }

      // === Log raid ===
      await sendAntiBanLog(client, guild, executor, user, sanctionApplied);

    } catch (err) {
      console.error("antiban event error:", err);
    }
  }
};
