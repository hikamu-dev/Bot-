const { Astroia } = require('../../structures/client/index');
const Discord = require('discord.js');

const cache = new Map();

module.exports = {
  name: 'messageCreate',
  /**
   * @param {Astroia} client
   * @param {Discord.Message} message
   */
  run: async (client, message) => {
    const guild = message.guild;
    if (!guild || message.author.bot) return;

    // === Config & compat ===
    let cfg = client.db.get(`antispam_${guild.id}`);
    if (!cfg) return;
    if (typeof cfg === 'string') {
      cfg = (cfg === 'off') ? { status:'off', mode:'normal', message:5, temps:5000 }
          : (cfg === 'on')  ? { status:'on',  mode:'normal', message:5, temps:5000 }
          :                    { status:'on',  mode:'max',    message:5, temps:5000 };
    } else if (cfg.status === 'max' && !cfg.mode) {
      cfg = { ...cfg, status:'on', mode:'max' };
    }
    if (cfg.status === 'off') return;

    // === BYPASS (on/max) + bypass_antispam_<guild> ===
    const isBuyer    = client.config?.buyers?.includes?.(message.author.id);
    const isStaff    = client.staff?.includes?.(message.author.id);
    const isOwnerLoc = client.db.get(`owner_${guild.id}_${message.author.id}`) === true || client.db.get(`owner_${message.author.id}`) === true;
    const isOwnerGbl = client.db.get(`owner_global_${message.author.id}`) === true;
    const isGOwner   = message.author.id === guild.ownerId;

    const wlList  = client.db.get(`wl.${guild.id}`) || [];
    const isWLArr = Array.isArray(wlList) && wlList.includes(message.author.id);
    const isWLKey = client.db.get(`wlmd_${guild.id}_${message.author.id}`) === true;
    const isWL    = isWLArr || isWLKey;

    const bypassStore = client.db.get(`bypass_antispam_${guild.id}`) || { users: [], roles: [] };
    const byUser = bypassStore.users?.includes?.(message.author.id);
    const byRole = (() => {
      const m = message.member;
      return m ? bypassStore.roles?.some?.(r => m.roles.cache.has(r)) : false;
    })();

    const okBypass = (cfg.mode === 'max')
      ? (isBuyer || isStaff || isOwnerLoc || isOwnerGbl || isGOwner || byUser || byRole)
      : (isBuyer || isStaff || isOwnerLoc || isOwnerGbl || isGOwner || isWL || byUser || byRole);
    if (okBypass) return;

    // === AntiSpam logique (inchangée) ===
    const limit = cfg.message || 5;
    const interval = cfg.temps || 5000;

    const now = Date.now();
    const userId = message.author.id;
    const timestamps = cache.get(userId) || [];

    timestamps.push(now);
    const filtered = timestamps.filter(t => now - t < interval);
    cache.set(userId, filtered);

    if (filtered.length >= limit) {
      const sanction = client.db.get(`punish_${guild.id}.antispam`) || 'mute';
      const member = await guild.members.fetch(userId).catch(() => null);
      if (!member) return;

      let deleted = 0;
      try {
        const messages = await message.channel.messages.fetch({ limit: 100 });
        const userMessages = messages.filter(m => m.author.id === userId);
        await message.channel.bulkDelete(userMessages, true);
        deleted = userMessages.size;
      } catch {
        await message.delete().catch(() => {});
        deleted = 1;
      }

      const logChannelId = client.db.get(`raidlogs_${guild.id}`);
      const logChannel = guild.channels.cache.get(logChannelId);

      const embed = new Discord.EmbedBuilder()
        .setColor(client.db.get(`color_${guild.id}`) || client.config.default_color)
        .setTitle("🚨 Lyna - AntiSpam")
        .setDescription(`${message.author} a spam avec ${filtered.length} messages en ${interval / 1000}s\nSanction appliquée : \`${sanction}\``)
        .addFields(
          { name: "👤 Membre", value: `${message.author.tag} (${userId})`, inline: true },
          { name: "🗑️ Messages supprimés", value: `${deleted}`, inline: true }
        )
        .setTimestamp()
        .setFooter({ text: "Lyna - Protection", iconURL: client.user.displayAvatarURL() });

      let content = null;
      const pingType = client.db.get(`pingraid_${guild.id}`);
      const pingRole = client.db.get(`pingraid_role_${guild.id}`);

      switch (pingType) {
        case "everyone": content = "@everyone"; break;
        case "here": content = "@here"; break;
        case "role": content = pingRole ? `<@&${pingRole}>` : null; break;
        case "buyers":
          content = client.config.buyers.length > 0 ? client.config.buyers.map(id => `<@${id}>`).join(", ") : null;
          break;
        case "owners":
          const all = client.db.all?.() || [];
          const owners = all.filter(([k,v]) => k.startsWith(`owner_global_`) && v === true).map(([k]) => `<@${k.split("_")[2]}>`);
          content = owners.length > 0 ? owners.join(", ") : null;
          break;
      }

      if (logChannel) logChannel.send({ embeds: [embed], content }).catch(() => {});

      try {
        switch (sanction) {
          case "derank": await member.roles.set([]).catch(()=>{}); break;
          case "kick": await member.kick("Lyna Anti-Spam").catch(()=>{}); break;
          case "ban": await member.ban({ reason: "Lyna Anti-Spam", days: 1 }).catch(()=>{}); break;
          case "mute":
            if (member.moderatable) {
              await member.timeout(60 * 60 * 1000, "Lyna Anti-Spam").catch(()=>{});
            }
            break;
        }
      } catch (e) {
        console.error("Erreur sanction antispam:", e);
      }

      cache.delete(userId);
    } else if (filtered.length === limit - 1) {
      if (!message.channel.lastAntispamWarn || (Date.now() - message.channel.lastAntispamWarn > 30000)) {
        message.channel.send(`${message.author}, veuillez arrêter de spammer.`)
          .then(m => setTimeout(() => m.delete().catch(() => {}), 4000));
        message.channel.lastAntispamWarn = Date.now();
      }
    }

    // Nettoyage de cache (anti débordement mémoire)
    if (Math.random() < 0.0005) {
      for (const [id, timestamps] of cache.entries()) {
        if (timestamps.length === 0 || Date.now() - timestamps[timestamps.length - 1] > 60000) {
          cache.delete(id);
        }
      }
    }
  }
};
