// events/antinick.js
const Discord = require("discord.js");

/* ========== Logs helper (même style que tes autres modules) ========== */
async function sendLogToChannel(client, guild, embed) {
  const pingraid = client.db.get(`pingraid_${guild.id}`);
  const pingraidRole = client.db.get(`pingraid_role_${guild.id}`);
  let content = null;

  if (pingraid) {
    switch (pingraid) {
      case "everyone": content = "@everyone"; break;
      case "here": content = "@here"; break;
      case "role": content = pingraidRole ? `<@&${pingraidRole}>` : null; break;
      case "buyers":
        content = (client.config?.buyers || []).map(id => `<@${id}>`).join(", ") || null;
        break;
      case "owners": {
        const all = client.db.all?.() || [];
        const globals = all.filter(([k,v]) => k.startsWith("owner_global_") && v === true).map(([k]) => k.split("_")[2]);
        const locals  = all.filter(([k,v]) => k.startsWith(`owner_${guild.id}_`) && v === true).map(([k]) => k.split("_")[2]);
        const uniq = [...new Set([...globals, ...locals])];
        content = uniq.length ? uniq.map(o => `<@${o}>`).join(", ") : null;
        break;
      }
    }
  }

  const logChannel = guild.channels.cache.get(client.db.get(`raidlogs_${guild.id}`));
  if (logChannel) await logChannel.send({ embeds: [embed], content }).catch(()=>{});
}

async function sendAntiNickLog(client, guild, executor, targetMember, oldNick, newNick, reverted) {
  const embed = new Discord.EmbedBuilder()
    .setColor(client.db.get(`color_${guild.id}`) || client.config.default_color || 0x2b2d31)
    .setTitle("🚨 AntiNick détecté")
    .setDescription(
      `${executor ? `${executor}` : "Inconnu"} a modifié le pseudo de ${targetMember}\n` +
      `Avant: \`${oldNick ?? "—"}\`\nAprès: \`${newNick ?? "—"}\`\n` +
      `Action: \`${reverted ? "revert du pseudo" : "aucune (revert impossible)"}\` — **pas de sanction**`
    )
    .setAuthor({ name: executor ? `${executor.username} (${executor.id})` : "Exécuteur inconnu", iconURL: executor?.displayAvatarURL?.() || null })
    .setTimestamp();

  await sendLogToChannel(client, guild, embed);
}

async function sendErrorLog(client, guild, executor, targetMember, error) {
  const embed = new Discord.EmbedBuilder()
    .setColor("#FF0000")
    .setTitle("⚠️ Erreur AntiNick")
    .setDescription(`Erreur lors du revert de pseudo (aucune sanction appliquée)`)
    .addFields(
      { name: "Membre ciblé", value: `${targetMember?.user?.tag || targetMember?.id || "?"}`, inline: true },
      { name: "Erreur", value: `\`\`\`${error?.message || String(error)}\`\`\`` }
    )
    .setAuthor({ name: executor ? `${executor.username} (${executor.id})` : "Exécuteur inconnu", iconURL: executor?.displayAvatarURL?.() || null })
    .setTimestamp();

  await sendLogToChannel(client, guild, embed);
}

/* ========== Event ========== */
module.exports = {
  name: "guildMemberUpdate",
  /**
   * @param {import('../../structures/client').Astroia} client
   * @param {Discord.GuildMember} oldMember
   * @param {Discord.GuildMember} newMember
   */
  run: async (client, oldMember, newMember) => {
    try {
      const guild = newMember.guild;
      if (!guild?.available) return;

      // Config lecture & compat legacy
      let cfg = client.db.get(`antinick.${guild.id}`);
      if (!cfg) return; // non configuré
      if (typeof cfg === "string") cfg = (cfg === "on") ? { status:"on", mode:"normal" } : { status:"off", mode:"normal" };
      if (cfg.status !== "on") return;

      // Détection: changement de pseudo
      const oldNick = oldMember.nickname;
      const newNick = newMember.nickname;
      if (oldNick === newNick) return;

      // Audit logs → trouver l’exécuteur
      const logs = await guild.fetchAuditLogs({ type: Discord.AuditLogEvent.MemberUpdate, limit: 5 }).catch(()=>null);
      const now = Date.now();
      const entry = logs?.entries?.find(e =>
        (e.target?.id || e.targetId) === newMember.id && now - (e.createdTimestamp || 0) < 15000
      );
      const executor = entry?.executor || null;

      // Bot (toi) s’ignore lui-même
      const botId = guild.members.me?.id || client.user.id;
      if (executor && executor.id === botId) return;

      // BYPASS (on/max) + bypass_antinick_<guild>
      let okBypass = false;
      if (executor) {
        const execMember = await guild.members.fetch(executor.id).catch(()=>null);

        const isBuyer    = client.config?.buyers?.includes?.(executor.id);
        const isStaff    = client.staff?.includes?.(executor.id);
        const isOwnerLoc = client.db.get(`owner_${guild.id}_${executor.id}`) === true || client.db.get(`owner_${executor.id}`) === true;
        const isOwnerGbl = client.db.get(`owner_global_${executor.id}`) === true;
        const isGOwner   = guild.ownerId === executor.id;

        const wlList  = client.db.get(`wl.${guild.id}`) || [];
        const isWLArr = Array.isArray(wlList) && wlList.includes(executor.id);
        const isWLKey = client.db.get(`wlmd_${guild.id}_${executor.id}`) === true;
        const isWL    = isWLArr || isWLKey;

        const bypassStore = client.db.get(`bypass_antinick_${guild.id}`) || { users: [], roles: [] };
        const byUser = bypassStore.users?.includes?.(executor.id);
        const byRole = execMember ? bypassStore.roles?.some?.(r => execMember.roles.cache.has(r)) : false;

        okBypass = (cfg.mode === "max")
          ? (isBuyer || isStaff || isOwnerLoc || isOwnerGbl || isGOwner || byUser || byRole)
          : (isBuyer || isStaff || isOwnerLoc || isOwnerGbl || isGOwner || isWL || byUser || byRole);
        if (okBypass) return; // bypass → on laisse le changement
      }

      // Revert du pseudo (pas de sanction)
      let reverted = false;
      try {
        if (guild.members.me?.permissions.has(Discord.PermissionFlagsBits.ManageNicknames)) {
          await newMember.setNickname(oldNick || null, "AntiNick: changement non autorisé");
          reverted = true;
        } else {
          reverted = false;
        }
      } catch (e) {
        reverted = false;
        await sendErrorLog(client, guild, executor, newMember, e);
      }

      // Log raid
      await sendAntiNickLog(client, guild, executor, newMember, oldNick, newNick, reverted);

    } catch (e) {
      console.error("[ANTINICK] event error:", e);
    }
  }
};
