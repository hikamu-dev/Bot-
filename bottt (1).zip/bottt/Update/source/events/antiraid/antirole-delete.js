// events/antirole-delete.js
const Discord = require("discord.js");
const ms = require("ms");

/* Utils */
const sleep = (t) => new Promise(r => setTimeout(r, t));
function ensureLocks(client) { if (!client._rlLocks) client._rlLocks = { create: new Set(), delete: new Set(), update: new Set() }; }
function setTempLock(set, key, ttl = 6000) { set.add(key); setTimeout(() => set.delete(key), ttl); }

async function getExecutorForRole(guild, type, targetId) {
  for (const delay of [0, 300, 600]) {
    if (delay) await sleep(delay);
    const logs = await guild.fetchAuditLogs({ type, limit: 5 }).catch(() => null);
    const entry = logs?.entries?.find(e => (e.target?.id || e.targetId) === targetId);
    if (entry) return entry.executor || null;
  }
  return null;
}

/* Raid logs */
async function sendLogToChannel(client, guild, embed) {
  let content = null;
  const pingraid = client.db.get(`pingraid_${guild.id}`);
  const pingraidRole = client.db.get(`pingraid_role_${guild.id}`);
  if (pingraid) {
    switch (pingraid) {
      case "everyone": content = "@everyone"; break;
      case "here": content = "@here"; break;
      case "role": content = pingraidRole ? `<@&${pingraidRole}>` : null; break;
      case "buyers": content = (client.config?.buyers || []).map(id => `<@${id}>`).join(" ") || null; break;
      case "owners": {
        const all = client.db.all?.() || [];
        const g = all.filter(([k,v]) => k.startsWith("owner_global_") && v === true).map(([k]) => k.split("_")[2]);
        const s = all.filter(([k,v]) => k.startsWith(`owner_${guild.id}_`) && v === true).map(([k]) => k.split("_")[2]);
        const u = [...new Set([...g, ...s])];
        content = u.length ? u.map(x => `<@${x}>`).join(" ") : null; break;
      }
    }
  }
  const logChannel = guild.channels.cache.get(client.db.get(`raidlogs_${guild.id}`));
  if (logChannel) await logChannel.send({ embeds: [embed], content }).catch(()=>{});
}

/* Event */
module.exports = {
  name: "roleDelete",
  run: async (client, role) => {
    try {
      ensureLocks(client);
      const guild = role?.guild;
      if (!guild) return;

      if (client._rlLocks.delete.has(role.id)) return;

      const cfg = client.db.get(`antirole_delete_${guild.id}`);
      if (!cfg || cfg.status !== "on") return;
      const epoch = cfg.epoch || 0;

      const executor = await getExecutorForRole(guild, Discord.AuditLogEvent.RoleDelete, role.id);
      if (!executor) return;

      // BYPASS bot
      const botId = guild.members.me?.id || client.user.id;
      if (executor.id === botId) return;

      const member = guild.members.cache.get(executor.id) || await guild.members.fetch(executor.id).catch(()=>null);

      // BYPASS logic
      const isBuyer = Array.isArray(client.config?.buyers) && client.config.buyers.includes(executor.id);
      const isStaff = Array.isArray(client.staff) && client.staff.includes(executor.id);
      const isOwnerLocalLegacy = client.db.get(`owner_${executor.id}`) === true;
      const isOwnerLocalScoped  = client.db.get(`owner_${guild.id}_${executor.id}`) === true;
      const isGlobalOwner       = client.db.get(`owner_global_${executor.id}`) === true;
      const isGuildOwner        = executor.id === guild.ownerId;
      const wl = client.db.get(`wl.${guild.id}`) || [guild.ownerId];
      const isWhitelisted      = Array.isArray(wl) && wl.includes(executor.id);
      const bypassStored = client.db.get(`bypass_antirole_${guild.id}`) || { users: [], roles: [] };
      const isBypassUser = Array.isArray(bypassStored.users) && bypassStored.users.includes(executor.id);
      const isBypassRole = member ? (Array.isArray(bypassStored.roles) && bypassStored.roles.some(r => member.roles.cache.has(r))) : false;

      const okBypass = (cfg.mode === "max")
        ? (isBuyer || isStaff || isOwnerLocalLegacy || isOwnerLocalScoped || isGlobalOwner || isGuildOwner || isBypassUser || isBypassRole)
        : (isBuyer || isStaff || isOwnerLocalLegacy || isOwnerLocalScoped || isGlobalOwner || isGuildOwner || isWhitelisted || isBypassUser || isBypassRole);
      if (okBypass) return;

      // Réparer: recréer le rôle supprimé (best-effort) + position
      let restored = null;
      try {
        restored = await guild.roles.create({
          name: role.name,
          color: role.color,
          hoist: role.hoist,
          permissions: role.permissions,
          mentionable: role.mentionable,
          reason: "AntiRoleDelete: restauration rôle"
        }).catch(()=>null);
        if (restored) await restored.setPosition(role.rawPosition).catch(()=>{});
      } catch {}

      if (restored) setTempLock(client._rlLocks.create, restored.id, 6000);

      // Compteur
      const counterKey = `antirole_counter_${guild.id}.v${epoch}.delete.${executor.id}`;
      const count = (client.db.get(counterKey) || 0) + 1;
      client.db.set(counterKey, count);

      const threshold = Number.isInteger(cfg.seuil_sanction) ? cfg.seuil_sanction : 1;
      let sanctionApplied = "aucune";

      if (threshold !== 0 && count >= threshold && member) {
        const punishDb = client.db.get(`punish_${guild.id}`) || {};
        const punishment = (punishDb.antiroledelete || "").toLowerCase();
        const reason = "Role Delete non autorisé";
        try {
          switch (punishment) {
            case "mute": await member.timeout?.(ms("1h"), reason); sanctionApplied = "mute (1h)"; break;
            case "kick": await member.kick(reason); sanctionApplied = "kick"; break;
            case "ban":  await member.ban({ reason }); sanctionApplied = "ban"; break;
            case "derank":
              const roles = member.roles.cache.filter(r => r.editable && r.id !== guild.id);
              if (roles.size) await member.roles.remove(roles).catch(()=>{});
              sanctionApplied = "derank"; break;
            default: sanctionApplied = "aucune (punish non défini)";
          }
        } catch (e) {
          const embedErr = new Discord.EmbedBuilder()
            .setColor(0xFF0000).setTitle("⚠️ Erreur AntiRole")
            .setDescription("Erreur lors de la sanction")
            .addFields({ name: "Action", value: `DELETE: ${role?.name || role?.id}` },
                       { name: "Erreur", value: `\`\`\`${e?.message || e}\`\`\`` })
            .setAuthor({ name: `${executor.username} (${executor.id})`, iconURL: executor.displayAvatarURL?.() || null })
            .setTimestamp();
          await sendLogToChannel(client, guild, embedErr);
        }
      }

      const embed = new Discord.EmbedBuilder()
        .setColor(client.db.get(`color_${guild.id}`) || client.config.default_color || 0x2b2d31)
        .setTitle("🚨 AntiRole DELETE détecté")
        .setDescription(`<@${executor.id}> a supprimé un rôle: **${role?.name || "inconnu"}**\nSanction: \`${sanctionApplied}\``)
        .setAuthor({ name: `${executor.username} (${executor.id})`, iconURL: executor.displayAvatarURL?.() || null })
        .setTimestamp();
      await sendLogToChannel(client, guild, embed);

    } catch (err) { console.error("antirole-delete error:", err); }
  }
};
