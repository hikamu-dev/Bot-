// events/antilink.js
const ms = require('ms');

module.exports = {
  name: 'messageCreate',
  run: async (client, message) => {
    try {
      if (!message.guild || message.author.bot) return;

      const guild = message.guild;
      const meId = guild.members.me?.id || client.user.id;
      if (message.author.id === meId) return; // self-ignore

      // === Config ===
      const raw = client.db.get(`antilink_${guild.id}`) || {};
      const status = (raw.status || (raw.on ? 'on' : 'off')).toLowerCase();
      const mode = status === 'max' ? 'max' : (status === 'on' ? 'on' : 'off');
      if (mode === 'off') return;

      const lienType = (raw.lien === 'invites' || raw.lien === 'discord') ? 'invites' : 'all';
      const ignoreChannels = Array.isArray(raw.ignore) ? raw.ignore : [];

      // Ignorer salons whitelistés
      if (ignoreChannels.includes(message.channel.id)) return;

      // Ticket: autoriser si activé
      const tickets = client.db.get(`ticket_user_${guild.id}`) || [];
      const isTicket = Array.isArray(tickets) && tickets.some(t => t.salon === message.channel.id);
      const ticketCfg = client.db.get(`ticket_${guild.id}`);
      if (isTicket && ticketCfg?.autoriserliens) return;

      // === BYPASS ===
      const m = message.member;
      if (!m) return;

      const isBuyer    = client.config?.buyers?.includes?.(message.author.id);
      const isStaff    = client.staff?.includes?.(message.author.id);
      const isOwnerLoc = client.db.get(`owner_${guild.id}_${message.author.id}`) === true || client.db.get(`owner_${message.author.id}`) === true;
      const isOwnerGbl = client.db.get(`owner_global_${message.author.id}`) === true;
      const isGOwner   = guild.ownerId === message.author.id;

      const wlArr  = client.db.get(`wl.${guild.id}`) || [];
      const isWLArr = Array.isArray(wlArr) && wlArr.includes(message.author.id);
      const isWLKey = client.db.get(`wlmd_${guild.id}_${message.author.id}`) === true;
      const isWL    = isWLArr || isWLKey;

      const bypass = client.db.get(`bypass_antilink_${guild.id}`) || { users: [], roles: [] };
      const byUser = Array.isArray(bypass.users) && bypass.users.includes(message.author.id);
      const byRole = Array.isArray(bypass.roles) && m.roles.cache.some(r => bypass.roles.includes(r.id));

      const okBypass = (mode === 'max')
        ? (isBuyer || isStaff || isOwnerLoc || isOwnerGbl || isGOwner || byUser || byRole)
        : (isBuyer || isStaff || isOwnerLoc || isOwnerGbl || isGOwner || isWL || byUser || byRole);
      if (okBypass) return;

      // === Détection liens ===
      const regexInvite  = /(https:\/\/)?(www\.)?(discord\.gg|discord\.me|discordapp\.com[\/\\]invite|discord\.com\/invite)\/?[a-z0-9\-._]+/i;
      const regexAllUrls = /(https?:\/\/[^\s]+|www\.[^\s]+)/i;

      const hasLink =
        (lienType === 'invites' && regexInvite.test(message.content)) ||
        (lienType === 'all' && (regexInvite.test(message.content) || regexAllUrls.test(message.content)));

      if (!hasLink) return;

      // Supprime + petit warn (anti-spam)
      await message.delete().catch(() => {});
      let warnTxt = "les liens ne sont pas autorisés ici.";
      try { warnTxt = await client.lang?.("antilink.not") || warnTxt; } catch {}
      try {
        const recent = await message.channel.messages.fetch({ limit: 10 });
        const already = recent.find(mg => mg.author.id === meId && mg.content.includes(warnTxt));
        if (!already) {
          message.channel.send(`${message.author}, ${warnTxt}`)
            .then(mg => setTimeout(() => mg.delete().catch(()=>{}), 1200))
            .catch(()=>{});
        }
      } catch {}

      // Sanction (si configurée)
      const punish = (client.db.get(`punish_${guild.id}`) || {}).antilink;
      if (!punish) return;

      try {
        if (punish === "derank") {
          const me = guild.members.me;
          if (me?.permissions?.has('ManageRoles')) {
            const removable = m.roles.cache
              .filter(r => r.id !== guild.id && !r.managed && me.roles.highest.position > r.position);
            if (removable.size) await m.roles.remove(removable, "AntiLink").catch(()=>{});
          }
        } else if (punish === "mute") {
          if (m.moderatable) await m.timeout(ms('1h'), "AntiLink").catch(()=>{});
        } else if (punish === "kick") {
          await m.kick("AntiLink").catch(()=>{});
        } else if (punish === "ban") {
          await m.ban({ reason: "AntiLink" }).catch(()=>{});
        }
      } catch {}
    } catch (e) {
      console.error("antilink create error:", e);
    }
  }
};
