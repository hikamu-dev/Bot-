const { Astroia } = require('../../structures/client/index');
const Discord = require('discord.js');

const cache = new Map();

module.exports = {
  name: 'messageCreate',
  /**
   * @param {Astroia} client
   * @param {Discord.Message} message
   */
  run: async (client, message) => {
    const guild = message.guild;
    if (!guild || message.author.bot) return;

    const antispam = client.db.get(`antispam_${guild.id}`);
    if (!antispam || antispam.status === 'off') return;

    if (
      client.staff.includes(message.author.id) ||
      client.config.buyers.includes(message.author.id) ||
      client.db.get(`owner_${message.author.id}`) === true ||
      client.db.get(`owner_global_${message.author.id}`) === true ||
      client.db.get(`wlmd_${guild.id}_${message.author.id}`) === true
    ) return;

    const limit = antispam.message || 5;
    const interval = antispam.temps || 5000;

    const now = Date.now();
    const userId = message.author.id;
    const timestamps = cache.get(userId) || [];

    timestamps.push(now);
    const filtered = timestamps.filter(t => now - t < interval);
    cache.set(userId, filtered);

    if (filtered.length >= limit) {
      const sanction = client.db.get(`punish_${guild.id}.antispam`) || 'mute';
      const member = await guild.members.fetch(userId).catch(() => null);
      if (!member) return;

      let deleted = 0;
      try {
        const messages = await message.channel.messages.fetch({ limit: 100 });
        const userMessages = messages.filter(m => m.author.id === userId);
        await message.channel.bulkDelete(userMessages, true);
        deleted = userMessages.size;
      } catch {
        await message.delete().catch(() => {});
        deleted = 1;
      }

      const logChannelId = client.db.get(`raidlogs_${guild.id}`);
      const logChannel = guild.channels.cache.get(logChannelId);

      const embed = new Discord.EmbedBuilder()
        .setColor(client.db.get(`color_${guild.id}`) || client.config.default_color)
        .setTitle("🚨 Lyna - AntiSpam")
        .setDescription(`${message.author} a spam avec ${filtered.length} messages en ${interval / 1000}s\nSanction appliquée : \`${sanction}\``)
        .addFields(
          { name: "👤 Membre", value: `${message.author.tag} (${userId})`, inline: true },
          { name: "🗑️ Messages supprimés", value: `${deleted}`, inline: true }
        )
        .setTimestamp()
        .setFooter({ text: "Lyna - Protection", iconURL: client.user.displayAvatarURL() });

      let content = null;
      const pingType = client.db.get(`pingraid_${guild.id}`);
      const pingRole = client.db.get(`pingraid_role_${guild.id}`);

      switch (pingType) {
        case "everyone": content = "@everyone"; break;
        case "here": content = "@here"; break;
        case "role": content = pingRole ? `<@&${pingRole}>` : null; break;
        case "buyers":
          content = client.config.buyers.length > 0 ? client.config.buyers.map(id => `<@${id}>`).join(", ") : null;
          break;
        case "owners":
          const owners = Object.entries(client.db.all())
            .filter(([key, value]) => key.startsWith(`owner_global_`) && value === true)
            .map(([key]) => `<@${key.split("_")[2]}>`);
          content = owners.length > 0 ? owners.join(", ") : null;
          break;
      }

      if (logChannel) logChannel.send({ embeds: [embed], content }).catch(() => {});

      try {
        switch (sanction) {
          case "derank": await member.roles.set([]); break;
          case "kick": await member.kick("Lyna Anti-Spam"); break;
          case "ban": await member.ban({ reason: "Lyna Anti-Spam", days: 1 }); break;
          case "mute":
            if (member.moderatable) {
              await member.timeout(60 * 60 * 1000, "Lyna Anti-Spam");
            }
            break;
        }
      } catch (e) {
        console.error("Erreur sanction antispam:", e);
      }

      cache.delete(userId);
    } else if (filtered.length === limit - 1) {
      if (!message.channel.lastAntispamWarn || (Date.now() - message.channel.lastAntispamWarn > 30000)) {
        message.channel.send(`${message.author}, veuillez arrêter de spammer.`).then(m => setTimeout(() => m.delete().catch(() => {}), 4000));
        message.channel.lastAntispamWarn = Date.now();
      }
    }

    // Nettoyage de cache (anti débordement mémoire)
    if (Math.random() < 0.0005) {
      for (const [id, timestamps] of cache.entries()) {
        if (timestamps.length === 0 || Date.now() - timestamps[timestamps.length - 1] > 60000) {
          cache.delete(id);
        }
      }
    }
  }
};
