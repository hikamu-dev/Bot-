const { Astroia } = require('../../structures/client/index');
const Discord = require('discord.js');
const ms = require('ms');

module.exports = {
  name: 'guildMemberAdd',
  /**
   * @param {Astroia} client
   * @param {Discord.GuildMember} member
   */
  run: async (client, member) => {
    const guild = member.guild;
    if (!member.user.bot) return;

    // === Config & compat ===
    let cfg = client.db.get(`antibot_${guild.id}`);
    if (!cfg) return;
    if (typeof cfg === 'string') {
      cfg = (cfg === 'off') ? { status:'off', mode:'normal' }
          : (cfg === 'on')  ? { status:'on',  mode:'normal' }
          :                    { status:'on',  mode:'max'    };
    } else if (cfg.status === 'max' && !cfg.mode) {
      cfg = { ...cfg, status:'on', mode:'max' };
    }
    if (cfg.status === 'off') return;

    const action = await guild.fetchAuditLogs({ limit: 1, type: 28 }) // 28 = BOT_ADD
      .then(audit => audit.entries.first())
      .catch(() => null);
    const executor = action?.executor;
    if (!executor || executor.id === client.user.id) return;

    // === BYPASS (on/max) + bypass_antibot_<guild> ===
    const execMember = await guild.members.fetch(executor.id).catch(()=>null);

    const isBuyer    = client.config?.buyers?.includes?.(executor.id);
    const isStaff    = client.staff?.includes?.(executor.id);
    const isOwnerLoc = client.db.get(`owner_${guild.id}_${executor.id}`) === true || client.db.get(`owner_${executor.id}`) === true;
    const isOwnerGbl = client.db.get(`owner_global_${executor.id}`) === true;
    const isGOwner   = guild.ownerId === executor.id;

    const wlList  = client.db.get(`wl.${guild.id}`) || [];
    const isWLArr = Array.isArray(wlList) && wlList.includes(executor.id);
    const isWLKey = client.db.get(`wlmd_${guild.id}_${executor.id}`) === true;
    const isWL    = isWLArr || isWLKey;

    const bypassStore = client.db.get(`bypass_antibot_${guild.id}`) || { users: [], roles: [] };
    const byUser = bypassStore.users?.includes?.(executor.id);
    const byRole = execMember ? bypassStore.roles?.some?.(r => execMember.roles.cache.has(r)) : false;

    const okBypass = (cfg.mode === 'max')
      ? (isBuyer || isStaff || isOwnerLoc || isOwnerGbl || isGOwner || byUser || byRole)
      : (isBuyer || isStaff || isOwnerLoc || isOwnerGbl || isGOwner || isWL || byUser || byRole);

    if (okBypass) return;

    const sanction = client.db.get(`punish_${guild.id}.antibot`) || "derank";

    try {
      await member.kick("Lyna AntiBot - Bot non autorisé");

      const executorMember = execMember || await guild.members.fetch(executor.id).catch(() => null);
      if (!executorMember) return;

      switch (sanction) {
        case "derank":
          await executorMember.roles.set([]).catch(()=>{});
          break;
        case "kick":
          await executorMember.kick("Lyna AntiBot").catch(()=>{});
          break;
        case "ban":
          await executorMember.ban({ reason: "Lyna AntiBot" }).catch(()=>{});
          break;
        case "mute":
          if (executorMember.moderatable) await executorMember.timeout(ms("1h"), "Lyna AntiBot").catch(()=>{});
          else await executorMember.roles.set([]).catch(()=>{});
          break;
      }

      await sendAntiBotLog(client, guild, executor, member, sanction);

    } catch (error) {
      console.error(`Erreur lors de la sanction antibot:`, error);
      await sendErrorLog(client, guild, executor, member, error);
    }
  }
};

async function sendAntiBotLog(client, guild, executor, botMember, sanction) {
  const embed = new Discord.EmbedBuilder()
    .setColor(client.db.get(`color_${guild.id}`) || client.config.default_color)
    .setTitle("🚨 Détection AntiBot")
    .setDescription(`${executor} a ajouté le bot \`${botMember.user.tag}\`\nSanction appliquée: \`${sanction}\``)
    .setAuthor({ name: `${executor.username} (${executor.id})`, iconURL: executor.displayAvatarURL() })
    .addFields(
      { name: "Bot ajouté", value: `${botMember.user.tag} (${botMember.id})`, inline: true },
      { name: "Statut AntiBot", value: (client.db.get(`antibot_${guild.id}`)?.status || 'on'), inline: true }
    )
    .setTimestamp();

  await sendLogToChannel(client, guild, embed);
}

async function sendErrorLog(client, guild, executor, botMember, error) {
  const embed = new Discord.EmbedBuilder()
    .setColor("#FF0000")
    .setTitle("⚠️ Erreur AntiBot")
    .setDescription(`Erreur lors de la sanction d'un ajout de bot`)
    .setAuthor({ name: `${executor.username} (${executor.id})`, iconURL: executor.displayAvatarURL() })
    .addFields(
      { name: "Bot concerné", value: `${botMember.user.tag} (${botMember.id})`, inline: true },
      { name: "Erreur", value: `\`\`\`${error?.message || error}\`\`\`` }
    )
    .setTimestamp();

  await sendLogToChannel(client, guild, embed);
}

async function sendLogToChannel(client, guild, embed) {
  let pingraid = client.db.get(`pingraid_${guild.id}`);
  const pingraidRole = client.db.get(`pingraid_role_${guild.id}`);
  let content = null;

  if (pingraid) {
    switch (pingraid) {
      case "everyone": content = "@everyone"; break;
      case "here": content = "@here"; break;
      case "role": content = pingraidRole ? `<@&${pingraidRole}>` : null; break;
      case "buyers":
        content = client.config.buyers.length > 0 ? `<@${client.config.buyers.join(", ")}>` : null;
        break;
      case "owners":
        const all = client.db.all?.() || [];
        const globalOwners = all.filter(([k,v]) => k.startsWith(`owner_global_`) && v === true).map(([k]) => k.split('_')[2]);
        const serverOwners = all.filter(([k,v]) => k.startsWith(`owner_${guild.id}_`) && v === true).map(([k]) => k.split('_')[2]);
        const allOwners = [...new Set([...globalOwners, ...serverOwners])];
        content = allOwners.length ? allOwners.map(o => `<@${o}>`).join(", ") : null;
        break;
    }
  }

  const logChannel = guild.channels.cache.get(client.db.get(`raidlogs_${guild.id}`));
  if (logChannel) await logChannel.send({ embeds: [embed], content });
}
