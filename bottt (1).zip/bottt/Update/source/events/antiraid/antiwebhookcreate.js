const { Astroia } = require('../../structures/client/index');
const Discord = require('discord.js');
const ms = require('ms');

// Cache temporaire pour éviter les doubles logs
const recentActions = new Set();

module.exports = {
  name: 'webhooksUpdate',
  /**
   * @param {Astroia} client
   * @param {Discord.GuildChannel} channel
   */
  run: async (client, channel) => {
    const guild = channel.guild;

    // === Config & compat ===
    let cfg = client.db.get(`antiwebhook_${guild.id}`);
    if (!cfg) return;
    if (typeof cfg === 'string') {
      cfg = (cfg === 'off') ? { status:'off', mode:'normal' }
          : (cfg === 'on')  ? { status:'on',  mode:'normal' }
          :                    { status:'on',  mode:'max'    };
    } else if (cfg.status === 'max' && !cfg.mode) {
      cfg = { ...cfg, status:'on', mode:'max' };
    }
    if (cfg.status === 'off') return;

    const auditLogs = await guild.fetchAuditLogs({
      type: Discord.AuditLogEvent.WebhookCreate,
      limit: 1
    }).catch(() => null);

    const webhookLog = auditLogs?.entries.first();
    if (!webhookLog) return;

    const executor = webhookLog.executor;
    if (!executor || executor.id === client.user.id) return;

    const actionId = `${webhookLog.id}-${executor.id}-${channel.id}`;
    if (recentActions.has(actionId)) return;
    recentActions.add(actionId);
    setTimeout(() => recentActions.delete(actionId), 5000);

    // === BYPASS (on/max) avec bypass_antiwebhook_<guild> ===
    const execMember = await guild.members.fetch(executor.id).catch(()=>null);

    const isBuyer    = client.config?.buyers?.includes?.(executor.id);
    const isStaff    = client.staff?.includes?.(executor.id);
    const isOwnerLoc = client.db.get(`owner_${guild.id}_${executor.id}`) === true || client.db.get(`owner_${executor.id}`) === true;
    const isOwnerGbl = client.db.get(`owner_global_${executor.id}`) === true;
    const isGOwner   = guild.ownerId === executor.id;

    const wlList  = client.db.get(`wl.${guild.id}`) || [];
    const isWLArr = Array.isArray(wlList) && wlList.includes(executor.id);
    const isWLKey = client.db.get(`wlmd_${guild.id}_${executor.id}`) === true;
    const isWL    = isWLArr || isWLKey;

    const bypassStore = client.db.get(`bypass_antiwebhook_${guild.id}`) || { users: [], roles: [] };
    const byUser = bypassStore.users?.includes?.(executor.id);
    const byRole = execMember ? bypassStore.roles?.some?.(r => execMember.roles.cache.has(r)) : false;

    const okBypass = (cfg.mode === 'max')
      ? (isBuyer || isStaff || isOwnerLoc || isOwnerGbl || isGOwner || byUser || byRole)
      : (isBuyer || isStaff || isOwnerLoc || isOwnerGbl || isGOwner || isWL || byUser || byRole);

    if (okBypass) return;

    const sanction = client.db.get(`punish_${guild.id}.antiwebhook`) || "mute";

    try {
      // supprimer le webhook tout de suite si possible
      const webhooks = await channel.fetchWebhooks();
      const newWebhook = webhooks.find(w => w.owner?.id === executor.id && w.createdTimestamp >= Date.now() - 8000);
      if (newWebhook) {
        await newWebhook.delete("Lyna AntiWebhook - Création non autorisée");
      }

      const executorMember = execMember || await guild.members.fetch(executor.id).catch(() => null);
      if (!executorMember) return;

      switch (sanction) {
        case "derank":
          await executorMember.roles.set([]).catch(()=>{});
          break;
        case "kick":
          await executorMember.kick("Lyna AntiWebhook - Création non autorisée").catch(()=>{});
          break;
        case "ban":
          await executorMember.ban({ reason: "Lyna AntiWebhook - Création non autorisée", days: 1 }).catch(()=>{});
          break;
        case "mute":
          if (executorMember.moderatable) {
            await executorMember.timeout(ms('1h'), "Lyna AntiWebhook").catch(()=>{});
          } else {
            await executorMember.roles.set([]).catch(()=>{});
          }
          break;
      }

      await sendAntiWebhookLog(client, guild, executor, channel, sanction);

    } catch (error) {
      console.error(`Erreur antiwebhook:`, error);
      await sendErrorLog(client, guild, executor, channel, error);
    }
  }
};

async function sendAntiWebhookLog(client, guild, executor, channel, sanction) {
  const embed = new Discord.EmbedBuilder()
    .setColor(client.db.get(`color_${guild.id}`) || client.config.default_color)
    .setTitle("🚨 Détection AntiWebhook")
    .setDescription(`${executor} a créé un webhook dans ${channel}\nSanction appliquée: \`${sanction}\``)
    .setAuthor({ name: `${executor.username} (${executor.id})`, iconURL: executor.displayAvatarURL() })
    .setTimestamp();

  await sendLogToChannel(client, guild, embed);
}

async function sendErrorLog(client, guild, executor, channel, error) {
  const embed = new Discord.EmbedBuilder()
    .setColor("#FF0000")
    .setTitle("⚠️ Erreur AntiWebhook")
    .setDescription("Une erreur s'est produite lors de l'application de la sanction")
    .setAuthor({ name: `${executor.username} (${executor.id})`, iconURL: executor.displayAvatarURL() })
    .addFields(
      { name: "Canal concerné", value: `${channel.name} (${channel.id})`, inline: true },
      { name: "Erreur", value: `\`\`\`${error?.message || error}\`\`\`` }
    )
    .setTimestamp();

  await sendLogToChannel(client, guild, embed);
}

async function sendLogToChannel(client, guild, embed) {
  const pingraid = client.db.get(`pingraid_${guild.id}`);
  const pingraidRole = client.db.get(`pingraid_role_${guild.id}`);
  let content = null;

  switch (pingraid) {
    case "everyone": content = "@everyone"; break;
    case "here": content = "@here"; break;
    case "role": content = pingraidRole ? `<@&${pingraidRole}>` : null; break;
    case "buyers":
      content = client.config.buyers.length > 0 ? client.config.buyers.map(id => `<@${id}>`).join(", ") : null;
      break;
    case "owners":
      const all = client.db.all?.() || [];
      const globalOwners = all.filter(([k,v]) => k.startsWith(`owner_global_`) && v === true).map(([k]) => k.split('_')[2]);
      const serverOwners = all.filter(([k,v]) => k.startsWith(`owner_${guild.id}_`) && v === true).map(([k]) => k.split('_')[2]);
      const allOwners = [...new Set([...globalOwners, ...serverOwners])];
      content = allOwners.length ? allOwners.map(o => `<@${o}>`).join(", ") : null;
      break;
  }

  const logChannel = guild.channels.cache.get(client.db.get(`raidlogs_${guild.id}`));
  if (logChannel) await logChannel.send({ embeds: [embed], content }).catch(() => {});
}
