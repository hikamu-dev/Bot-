const { Astroia } = require('../../structures/client/index');

module.exports = {
    name: 'guildMemberUpdate',
    /**
     * @param {Astroia} client
     */
    run: async (client, oldMember, newMember) => {
        const guild = newMember.guild;

        if (newMember.user.bot) return;
        if (newMember.id === guild.ownerId) return;
        if (client.config.buyers.includes(newMember.id)) return;
        if (client.db.get(`owner_${newMember.id}`) === true) return;
        if (client.db.get(`owner_global_${newMember.id}`) === true) return;

        const wl = client.db.get(`wl.${guild.id}`) || [guild.ownerId];
        if (wl.includes(newMember.id)) return;

        const addedRoles = newMember.roles.cache.filter(role => !oldMember.roles.cache.has(role.id));
        if (addedRoles.size === 0) return;

        const roleLimits = client.db.get(`rolelimits_${guild.id}`);
        if (!roleLimits || Object.keys(roleLimits).length === 0) return;

        await checkRoleLimitsOnUpdate(client, newMember, addedRoles, roleLimits);
    }
};

async function checkRoleLimitsOnUpdate(client, member, addedRoles, roleLimits) {
    const guild = member.guild;

    for (const addedRole of addedRoles.values()) {
        const limit = roleLimits[addedRole.id];
        if (!limit) continue;

        const currentCount = addedRole.members.size;

        if (currentCount > limit) {
            try {
                await member.roles.remove(addedRole, `Limite de rôle dépassée (${currentCount}/${limit})`);
                //console.log(`Rôle "${addedRole.name}" retiré à ${member.user.tag} (limite dépassée)`);
            } catch (err) {
                console.error(`Erreur lors du retrait du rôle à ${member.user.tag}:`, err);
            }
        }
    }
}
