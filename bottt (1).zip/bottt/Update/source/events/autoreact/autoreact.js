const Discord = require('discord.js')
module.exports = {
    name: 'messageCreate',
    run: async (client, message) => {

        if (!message.guild) return
        if (message.author.id === client.user.id) return

        let autoreact = client.db.get(`autoreact_${message.guild.id}`)
        if (!autoreact || autoreact.length === 0) return

        let autoreact_ = autoreact.filter(r => r.channel === message.channel.id)
        if (autoreact_.length === 0) return

        let autoreact_emoji = autoreact_.map(r => r.emoji)

        console.log("autoreact_emoji array:", autoreact_emoji);
        for (let emoji of autoreact_emoji) {
            console.log("Trying to react with emoji:", emoji);
            try {
                if (typeof emoji === "string" && emoji.length > 0) {
                    await message.react(emoji);
                } else {
                    console.error("Invalid emoji for react:", emoji);
                }
            } catch (e) {
                console.error("Error reacting with emoji:", emoji, e);
            }
        }
    }
}
