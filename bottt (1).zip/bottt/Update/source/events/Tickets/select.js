const {
    ActionRowBuilder,
    StringSelectMenuBuilder,
    PermissionFlagsBits,
    ButtonBuilder,
    EmbedBuilder,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle
} = require('discord.js');
const Valory = require('../../structures/client');

module.exports = {
    name: "interactionCreate",
    run: async (client, interaction) => {
        try {
            if (!interaction.isStringSelectMenu() && !interaction.isButton() && !interaction.isModalSubmit()) return;

            if (interaction.isStringSelectMenu() && interaction.customId === 'ticket') {
                const color = await client.db.get(`color_${interaction.guild.id}`) || client.config.default_color;
                const id = interaction.values[0].split('_')[1];
                const db = await client.db.get(`ticket_${interaction.guild.id}`);
                if (!db) return await handleReply(interaction, 'Configuration de ticket non trouvée.');

                const option = db.option.find(opt => opt.value === id);
                if (!option) return await handleReply(interaction, 'Option de ticket non trouvée.');

                const tickeruser = await client.db.get(`ticket_user_${interaction.guild.id}`) || [];
                const resul = tickeruser.find(ticket => ticket.author === interaction.user.id);

                if (resul && tickeruser.length >= db?.maxticket) {
                    return await handleReply(interaction, `Vous avez déjà atteint le nombre maximal de tickets ouverts !`);
                }

                // Vérification des rôles interdits
                if (db.roleinterdit && Array.isArray(db.roleinterdit) && db.roleinterdit.length > 0) {
                    const userRoles = interaction.member.roles.cache.map(role => role.id);
                    const hasForbiddenRole = db.roleinterdit.some(roleId => userRoles.includes(roleId));
                    
                    if (hasForbiddenRole) {
                        return await handleReply(interaction, `❌ Vous avez un rôle interdit et ne pouvez pas créer de ticket.`);
                    }
                }

                // Vérification des rôles requis
                if (db.rolerequis && Array.isArray(db.rolerequis) && db.rolerequis.length > 0) {
                    const userRoles = interaction.member.roles.cache.map(role => role.id);
                    const hasRequiredRole = db.rolerequis.some(roleId => userRoles.includes(roleId));
                    
                    if (!hasRequiredRole) {
                        return await handleReply(interaction, `❌ Vous n'avez pas les rôles requis pour créer un ticket.`);
                    }
                }

                // ----- MODAL MOTIFS -----
                if (option.motifs && Array.isArray(option.motifs) && option.motifs.length > 0) {
                    const modal = new ModalBuilder()
                        .setCustomId(`ticket_motif_modal_${id}`)
                        .setTitle('Motifs');
                    option.motifs.forEach((motif, idx) => {
                        const input = new TextInputBuilder()
                            .setCustomId(`motif_input_${idx}`)
                            .setLabel(motif.length > 45 ? motif.substring(0, 45) : motif)
                            .setStyle(TextInputStyle.Short)
                            .setRequired(true);
                        modal.addComponents(new ActionRowBuilder().addComponents(input));
                    });
                    await interaction.showModal(modal);
                    return;
                }

                const deferred = await safeDefer(interaction);
                if (!deferred) return;

                let permissionOverwrites = [
                    {
                        id: interaction.guild.roles.everyone,
                        deny: [PermissionFlagsBits.ViewChannel],
                    },
                    {
                        id: interaction.user.id,
                        allow: [
                            PermissionFlagsBits.SendMessages,
                            PermissionFlagsBits.ViewChannel,
                            PermissionFlagsBits.AttachFiles,
                            PermissionFlagsBits.AddReactions
                        ]
                    }
                ];

                if (Array.isArray(option.acess)) {
                    for (const roleId of option.acess) {
                        const role = interaction.guild.roles.cache.get(roleId);
                        if (role) {
                            permissionOverwrites.push({
                                id: role.id,
                                allow: [
                                    PermissionFlagsBits.SendMessages,
                                    PermissionFlagsBits.ViewChannel,
                                    PermissionFlagsBits.AttachFiles,
                                    PermissionFlagsBits.AddReactions
                                ]
                            });
                        }
                    }
                }

                const category = client.channels.cache.get(option.categorie);
                const channel = await interaction.guild.channels.create({
                    parent: category ? option.categorie : null,
                    name: `⏰・${interaction.user.username}`,
                    type: 0,
                    permissionOverwrites: permissionOverwrites,
                }).catch(console.error);

                if (channel) {
                    await handleReply(interaction, `Ticket ouvert <#${channel.id}>`);

                    const embed = new EmbedBuilder()
                        .setColor(color)
                        .setFooter(client.footer)
                        .setDescription(option.message)
                        .setTitle('Ticket ouvert par ' + interaction.user.username);

                    const idunique = code(15);
                    const buttonRow = new ActionRowBuilder().addComponents(
                        new ButtonBuilder()
                            .setLabel('Fermer le ticket')
                            .setStyle(4)
                            .setEmoji('🔒')
                            .setCustomId("close_" + idunique)
                    );

                    if (db.claimbutton) {
                        buttonRow.addComponents(
                            new ButtonBuilder()
                                .setLabel('Claim le ticket')
                                .setStyle(2)
                                .setEmoji('🔐')
                                .setCustomId("claim_" + idunique)
                        );
                    }

                    if (db.boutonrappel) {
                        buttonRow.addComponents(
                            new ButtonBuilder()
                                .setLabel('Rappeler le créateur')
                                .setStyle(1)
                                .setEmoji('🔔')
                                .setCustomId("rappel_" + idunique)
                        );
                    }

                    await channel.send({
                        embeds: [embed],
                        content: option.mention ? `<@&${option.mention}>` : null,
                        components: [buttonRow]
                    });

                    tickeruser.push({
                        salon: channel.id,
                        author: interaction.user.id,
                        date: Date.now(),
                        id: idunique,
                        option: option.value,
                        claim: null,
                        motif: null,
                    });

                    await client.db.set(`ticket_user_${interaction.guild.id}`, tickeruser);
                } else {
                    await handleReply(interaction, 'Erreur lors de la création du ticket.');
                }
            }

            // ----- Gestion du Modal Motifs -----
            if (interaction.isModalSubmit() && interaction.customId.startsWith('ticket_motif_modal_')) {
                const id = interaction.customId.split('_').pop();
                const db = await client?.db.get(`ticket_${interaction.guild.id}`);
                if (!db) return await handleReply(interaction, 'Configuration de ticket non trouvée.');
                const option = db.option.find(option => option.value === id);
                if (!option) return await handleReply(interaction, 'Option de ticket non trouvée.');
                const color = await client.db.get(`color_${interaction.guild.id}`) || client.config.default_color;
                const tickeruser = await client.db.get(`ticket_user_${interaction.guild.id}`) || [];
                
                // Vérifier le quota de tickets max
                if (tickeruser.filter(t => t.author === interaction.user.id).length >= db?.maxticket) {
                    return await handleReply(interaction, `Vous avez déjà atteint le nombre maximal de tickets ouverts !`);
                }

                // Collecter tous les motifs remplis
                const motifsFilled = [];
                for (let idx = 0; idx < option.motifs.length; idx++) {
                    const value = interaction.fields.getTextInputValue(`motif_input_${idx}`);
                    if (value && value.trim().length > 0) {
                        motifsFilled.push({
                            motif: option.motifs[idx],
                            message: value.trim()
                        });
                    }
                }

                if (motifsFilled.length === 0) {
                    return await handleReply(interaction, '❌ Aucun champ rempli, aucun ticket créé.');
                }

                // Créer un seul ticket avec tous les motifs
                let permissionOverwrites = [
                    {
                        id: interaction.guild.roles.everyone,
                        deny: [PermissionFlagsBits.ViewChannel],
                    },
                    {
                        id: interaction.user.id,
                        allow: [
                            PermissionFlagsBits.SendMessages,
                            PermissionFlagsBits.ViewChannel,
                            PermissionFlagsBits.AttachFiles,
                            PermissionFlagsBits.AddReactions
                        ]
                    }
                ];

                if (option.acess && Array.isArray(option.acess)) {
                    option.acess.forEach(roleId => {
                        const role = interaction.guild.roles.cache.get(roleId);
                        if (role) {
                            permissionOverwrites.push({
                                id: role.id,
                                allow: [
                                    PermissionFlagsBits.SendMessages,
                                    PermissionFlagsBits.ViewChannel,
                                    PermissionFlagsBits.AttachFiles,
                                    PermissionFlagsBits.AddReactions
                                ]
                            });
                        }
                    });
                }

                const category = client.channels.cache.get(option.categorie);
                const channel = await interaction.guild.channels.create({
                    parent: category ? option.categorie : null,
                    name: `⏰・${interaction.user.username}`,
                    type: 0,
                    permissionOverwrites: permissionOverwrites,
                }).catch(console.error);

                if (channel) {
                    // Créer la description avec tous les motifs
                    let description = option.message + '\n\n**📋 Motifs et messages :**';
                    motifsFilled.forEach((item, index) => {
                        description += `\n**${index + 1}. ${item.motif}**\`\`\`\n${item.message}\n\`\`\`\n`;
                    });

                    const embed = new EmbedBuilder()
                        .setColor(color)
                        .setFooter(client.footer)
                        .setDescription(description)
                        .setTitle('Ticket ouvert par ' + interaction.user.username);

                    const idunique = code(15);
                    const buttonRow = new ActionRowBuilder().addComponents(
                        new ButtonBuilder()
                            .setLabel('Fermer le ticket')
                            .setStyle(4)
                            .setEmoji('🔒')
                            .setCustomId("close_" + idunique)
                    );

                    if (db.claimbutton) {
                        buttonRow.addComponents(
                            new ButtonBuilder()
                                .setLabel('Claim le ticket')
                                .setStyle(2)
                                .setEmoji('🔐')
                                .setCustomId("claim_" + idunique)
                        );
                    }

                    if (db.boutonrappel) {
                        buttonRow.addComponents(
                            new ButtonBuilder()
                                .setLabel('Rappeler le créateur')
                                .setStyle(1)
                                .setEmoji('🔔')
                                .setCustomId("rappel_" + idunique)
                        );
                    }

                    await channel.send({
                        embeds: [embed],
                        content: option.mention ? `<@&${option.mention}>` : null,
                        components: [buttonRow]
                    });

                    tickeruser.push({
                        salon: channel.id,
                        author: interaction.user.id,
                        date: Date.now(),
                        id: idunique,
                        option: option.value,
                        claim: null,
                        motif: motifsFilled.map(item => item.motif).join(', '),
                        message: motifsFilled.map(item => `${item.motif}: ${item.message}`).join('\n')
                    });

                    await client.db.set(`ticket_user_${interaction.guild.id}`, tickeruser);
                    await handleReply(interaction, `✅ Ticket ouvert avec succès ! <#${channel.id}>`);
                } else {
                    await handleReply(interaction, '❌ Erreur lors de la création du ticket.');
                }
                return;
            }

            // ----- Gestion du Modal de fermeture de ticket -----
            if (interaction.isModalSubmit() && interaction.customId.startsWith('close_reason_')) {
                const ticketId = interaction.customId.split('_').pop();
                const tickets = await client.db.get(`ticket_user_${interaction.guild.id}`);
                const resul = tickets.find(ticket => ticket.id === ticketId);
                if (!resul) return await handleReply(interaction, 'Ticket introuvable.');
                const user = await client.users.fetch(resul.author).catch(() => null);
                const usercache = client.users.cache.get(resul.author);
                const dbserveur = await client?.db.get(`ticket_${interaction.guild.id}`);
                if (!dbserveur) return await handleReply(interaction, 'Configuration de ticket non trouvée.');
                const dboption = dbserveur.option.find(option => option.value === resul.option);
                const channel = interaction.guild.channels.cache.get(dboption?.logs);
                const channelticket = interaction.guild.channels.cache.get(resul.salon);
                const color = await client.db.get(`color_${interaction.guild.id}`) || client.config.default_color;
                const reason = interaction.fields.getTextInputValue('close_reason_input') || 'Aucune raison fournie';
                const discordTranscripts = require('discord-html-transcripts');
                const { EmbedBuilder } = require('discord.js');
                const attachment = await discordTranscripts.createTranscript(channelticket);

                // Envoi dans le salon de logs
                if (channel) {
                    const embed = new EmbedBuilder()
                        .setColor(color)
                        .setFooter(client.footer)
                        .setAuthor({ name: `${user?.username || 'Utilisateur inconnu'} (${resul.author})`, iconURL: user?.avatarURL() })
                        .setTimestamp()
                        .setTitle(`Ticket Fermé par ${interaction.user.username}`)
                        .setDescription(`Raison : ${reason}`);
                    channel.send({
                        files: [attachment],
                        embeds: [embed]
                    }).catch(() => {});
                }

                // Envoi en MP si transcript activé
                if (dbserveur.transcript === true && usercache) {
                    const embed = new EmbedBuilder()
                        .setColor(color)
                        .setAuthor({ name: `${interaction.user.username} (${interaction.user.id})`, iconURL: interaction.user.displayAvatarURL() })
                        .setTitle(`Ticket Fermé par ${interaction.user.username}`)
                        .setDescription(`Raison : ${reason}`)
                        .setFooter(client.footer)
                        .setTimestamp();

                    usercache.send({
                        embeds: [embed],
                        files: [attachment],
                    }).catch(() => {});
                }
// === Demande d'avis en DM (après le transcript MP s’il est activé) ===
try {
  const targetType = resul.claim ? 'member' : 'server'; // si claim -> avis pour le staff, sinon pour le serveur
  const targetId   = resul.claim ? resul.claim : interaction.guild.id;

  // On DM le demandeur même si transcript MP pas activé, pour qu’il puisse laisser son avis
  const targetUser = usercache || (await client.users.fetch(resul.author).catch(() => null));
  if (targetUser) {
    const endEmbed = new EmbedBuilder()
      .setColor(color)
      .setTitle('Ton ticket a été fermé')
      .setDescription([
        'Merci d’avoir contacté le support.',
        '',
        '⭐ **Note ce ticket** en choisissant une étoile ci-dessous.',
        'Après avoir cliqué, tu auras **1 minute** pour écrire un avis (texte).',
        'Si tu n’écris rien, on enregistrera **uniquement ta note**.'
      ].join('\n'))
      .setTimestamp();

    const starsRow = new ActionRowBuilder().addComponents(
      ...[1,2,3,4,5].map(n =>
        new ButtonBuilder()
          .setCustomId(`dmrate_${interaction.guild.id}_${resul.id}_${n}_${targetType}_${targetId}`)
          .setLabel('★'.repeat(n))
          .setStyle(n <= 2 ? 4 : (n === 3 ? 2 : 3)) // Danger / Secondary / Success
      )
    );

    await targetUser.send({ embeds: [endEmbed], components: [starsRow] }).catch(() => {});
  }
} catch (e) {
  console.error('DM review error (select.js):', e);
}

                // Suppression du ticket de la base et fermeture du salon
                const ticketupdate = tickets.filter(ticket => ticket.id !== ticketId);
                await client.db.set(`ticket_user_${interaction.guild.id}`, ticketupdate);
                // Répondre à l'utilisateur qui ferme le ticket AVANT de supprimer le salon
                await handleReply(interaction, 'Ticket fermé avec succès.');
                await channelticket.delete().catch(() => {});
                return;
            }

            if (interaction.isButton() && interaction.customId.startsWith('claim_')) {
                const deferred = await safeDefer(interaction);
                if (!deferred) return;

                const tickeruser = await client.db.get(`ticket_user_${interaction.guild.id}`) || [];
                const ticketData = tickeruser.find(ticket => ticket.id === interaction.customId.split('_')[1]);

                if (!ticketData) return await handleReply(interaction, 'Ce ticket n\'existe plus ou n\'a pas été trouvé.');

                const channel = interaction.guild.channels.cache.get(ticketData.salon);
                if (!channel) return await handleReply(interaction, 'Salon introuvable.');

                if (ticketData.author === interaction.user.id) {
                    return await handleReply(interaction, `Vous ne pouvez pas claim votre propre ticket !`);
                }

                const db = await client.db.get(`ticket_${interaction.guild.id}`);
                if (!db) return await handleReply(interaction, 'Configuration de ticket non trouvée.');

                const option = db.option.find(opt => opt.value === ticketData.option);
                if (!option) return await handleReply(interaction, 'Option de ticket non trouvée.');

                if (Array.isArray(option.acess)) {
                    for (const roleId of option.acess) {
                        const role = interaction.guild.roles.cache.get(roleId);
                        if (role) {
                            await channel.permissionOverwrites.edit(role, {
                                SendMessages: false,
                                ViewChannel: true,
                                CreatePrivateThreads: false
                            }).catch(console.error);
                        }
                    }
                }

                await channel.permissionOverwrites.edit(interaction.guild.roles.everyone.id, {
                    SendMessages: false,
                    ViewChannel: false
                }).catch(console.error);

                await channel.permissionOverwrites.edit(interaction.user.id, {
                    SendMessages: true,
                    ViewChannel: true,
                    AttachFiles: true,
                    AddReactions: true,
                    ManageMessages: true
                }).catch(console.error);
                const ticketOwner = await client.users.fetch(ticketData.author).catch(() => null);
                if (ticketOwner) {
                    await channel.setName(`🔐・${ticketOwner.username}`).catch(console.error);
                }
                
                const message = (await channel.messages.fetch({ limit: 10 }))
                    .find(msg => msg.components.length > 0);
                if (message) {
                    const row = message.components[0];
                    const newRow = new ActionRowBuilder();

                    for (const component of row.components) {
                        if (component.customId.startsWith('claim_')) {
                            newRow.addComponents(
                                ButtonBuilder.from(component).setDisabled(true)
                            );
                        } else {
                            newRow.addComponents(component);
                        }
                    }

                    await message.edit({ components: [newRow] }).catch(console.error);
                }

                ticketData.claim = interaction.user.id;
                await client.db.set(`ticket_user_${interaction.guild.id}`, tickeruser);
                await channel.send({ content: `🔐 Ce ticket a été claim par ${interaction.user}.` });

                await handleReply(interaction, 'Vous avez claim ce ticket avec succès.');
            }

            if (interaction.isButton() && interaction.customId.startsWith('rappel_')) {
                const deferred = await safeDefer(interaction);
                if (!deferred) return;

                const ticketId = interaction.customId.split('_')[1];
                const color = await client.db.get(`color_${interaction.guild.id}`) || client.config.default_color;
                const tickeruser = await client.db.get(`ticket_user_${interaction.guild.id}`) || [];
                const ticketData = tickeruser.find(ticket => ticket.id === ticketId);

                if (!ticketData) return await handleReply(interaction, 'Ce ticket n\'existe plus ou n\'a pas été trouvé.');

                if (ticketData.author === interaction.user.id) {
                    return await handleReply(interaction, `Vous ne pouvez pas vous rappeler vous-même !`);
                }

                try {
                    const user = await client.users.fetch(ticketData.author);
                    if (user) {
                        const db = await client.db.get(`ticket_${interaction.guild.id}`);
                        const option = db?.option?.find(opt => opt.value === ticketData.option);
                        const ticketName = option?.text || 'Ticket';
                        
                        const embed = new EmbedBuilder()
                            .setColor(color)
                            .setTitle('🔔 Rappel de ticket')
                            .setDescription(`Vous avez été rappelé pour votre ticket **${ticketName}** sur le serveur **${interaction.guild.name}**.\n\nCliquez ici pour y accéder : <#${ticketData.salon}>`)
                            .setTimestamp()
                            .setFooter({ text: `Rappelé par ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() });

                        await user.send({ embeds: [embed] }).catch(() => {
                            return handleReply(interaction, '❌ Impossible d\'envoyer un message privé à l\'utilisateur. Il a peut-être désactivé les messages privés.');
                        });

                        await handleReply(interaction, `Rappel envoyé avec succès à <@${user.id}> !`);
                    } else {
                        await handleReply(interaction, '❌ Utilisateur introuvable.');
                    }
                } catch (error) {
                    console.error('Erreur lors de l\'envoi du rappel:', error);
                    await handleReply(interaction, '❌ Erreur lors de l\'envoi du rappel.');
                }
            }

        } catch (error) {
            console.error('Uncaught Exception:', error);
            await handleReply(interaction, 'Une erreur est survenue.');
        }
    }
};

async function handleReply(interaction, content) {
    try {
        if (interaction.deferred) {
            await interaction.editReply({ content, ephemeral: true });
        } else if (!interaction.replied) {
            await interaction.reply({ content, ephemeral: true });
        }
    } catch (err) {
        console.error("Erreur lors de l'envoi de réponse :", err);
    }
}

async function safeDefer(interaction) {
    try {
        if (!interaction.deferred && !interaction.replied) {
            await interaction.deferReply({ ephemeral: true });
        }
        return true;
    } catch (err) {
        if (err.code === 10062) return false;
        console.error('Erreur lors du deferReply :', err);
        return false;
    }
}


function code(length) {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let code = '';
    for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * characters.length);
        code += characters.charAt(randomIndex);
    }
    return code;
}
