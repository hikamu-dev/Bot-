const { ActionRowBuilder, ButtonBuilder, EmbedBuilder } = require('discord.js');
const Valory = require('../../structures/client');
const Discord = require('discord.js');
const discordTranscripts = require('discord-html-transcripts');

module.exports = {
    name: "interactionCreate",
    /**
     * @param {Valory} client
     * @param {Valory} interaction
     */
    run: async (client, interaction) => {

        // === Avis en DM : clic sur une étoile ===
        // customId: dmrate_<guildId>_<ticketId>_<stars>_<toType>_<toId>
        if (interaction.isButton() && interaction.customId && interaction.customId.startsWith('dmrate_')) {
            try {
                const parts = interaction.customId.split('_'); // ['dmrate', guildId, ticketId, stars, toType, toId]
                const guildId = parts[1];
                const ticketId = parts[2];
                const stars = Math.max(1, Math.min(5, parseInt(parts[3], 10) || 5));
                const toType = parts[4]; // 'member' | 'server'
                const toId   = parts[5]; // id du staff si member, sinon guildId
                const userId = interaction.user.id;

                // ✅ Ack discret pour éviter "Une erreur est survenue"
                await interaction.deferUpdate().catch(() => {});

                const channel = interaction.channel;
                if (!channel || channel.type !== Discord.ChannelType.DM) return;

                // Prompt clair en DM
                await channel.send(
                  `Tu as mis **${'★'.repeat(stars)}**.\n` +
                  `Écris ton avis dans ce DM (message libre). Tu as **1 minute**.\n` +
                  `Si tu n’écris rien, j’enregistrerai uniquement la note.`
                ).catch(() => {});

                const filter = (m) => m.author.id === userId;
                const collector = channel.createMessageCollector({ filter, time: 60_000, max: 1 });

                let saved = false;

                const saveReview = async (commentText) => {
                    try {
                        const key = `ticket_reviews_${guildId}`;
                        const reviews = (await client.db.get(key)) || [];
                        reviews.push({
                            id: `${Date.now()}_${Math.random().toString(36).slice(2)}`,
                            ticketId,
                            stars,
                            comment: commentText || null,
                            toType,
                            toId,
                            fromId: userId,
                            claimId: toType === 'member' ? toId : null,
                            createdAt: Date.now()
                        });
                        await client.db.set(key, reviews);
                        saved = true;
                    } catch (e) {
                        console.error('saveReview error:', e);
                    }
                };

                collector.on('collect', async (m) => {
                    await saveReview(m.content?.trim() || null);
                    await channel.send(`✅ Avis enregistré : **${'★'.repeat(stars)}** avec commentaire.`).catch(() => {});
                });

                collector.on('end', async (collected) => {
                    if (saved) return;
                    if (collected.size === 0) {
                        await saveReview(null);
                        await channel.send(`✅ Avis enregistré : **${'★'.repeat(stars)}** sans commentaire.`).catch(() => {});
                    }
                });
            } catch (e) {
                console.error('dmrate handler error:', e);
            }
            return; // IMPORTANT : on s'arrête ici (DM)
        }

        if (!interaction.isButton()) return;
        if (!interaction.guild) return; // tout le reste (claim/close...) doit être en serveur

        const color = await client.db.get(`color_${interaction.guild.id}`) || client.config.default_color;
        const dbserveur = await client?.db.get(`ticket_${interaction.guild.id}`);
        const buttonId = interaction.customId;
        const userId = interaction.user.id;

        if (buttonId.startsWith('claim_')) {
            const ticketId = buttonId.split('_')[1];
            const tickets = await client.db.get(`ticket_user_${interaction.guild.id}`);
            const resul = tickets.find(ticket => ticket.id === ticketId);

            if (resul.author === userId) {
                return interaction.reply({ content: 'Vous ne pouvez pas claim votre propre ticket !', ephemeral: true });
            }

            await interaction.deferUpdate();

            resul.claim = userId;
            const ticketupdate = tickets.map(ticket => (ticket.id === ticketId ? resul : ticket));
            await client.db.set(`ticket_user_${interaction.guild.id}`, ticketupdate);

            const button = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId('close_' + resul.id)
                    .setLabel('Fermer le ticket')
                    .setStyle(4)
                    .setEmoji('🔒'),
                new ButtonBuilder()
                    .setCustomId('unclaim_' + resul.id)
                    .setLabel('Unclaim le ticket')
                    .setStyle(2)
                    .setEmoji('📝'),
                new ButtonBuilder()
                    .setStyle(2)
                    .setDisabled(true)
                    .setEmoji('🔐')
                    .setCustomId("claim_" + resul.id)
            );

            const channel = interaction.guild.channels.cache.get(resul.salon);
            const dboption = dbserveur.option.find(option => option.value === resul.option);

            if (dboption && dboption.acess && Array.isArray(dboption.acess)) {
                for (const roleId of dboption.acess) {
                    const role = interaction.guild.roles.cache.get(roleId);
                    if (role) {
                        await channel.permissionOverwrites.edit(role, {
                            SendMessages: false,
                            ViewChannel: true,
                            ReadMessageHistory: true
                        }).catch(() => {});
                    }
                }
            }

            await channel.permissionOverwrites.edit(resul.author, {
                SendMessages: true,
                ViewChannel: true,
                ReadMessageHistory: true
            }).catch(() => {});

            await channel.permissionOverwrites.edit(interaction.user.id, {
                SendMessages: true,
                ViewChannel: true,
                ReadMessageHistory: true
            }).catch(() => {});

            await interaction.message.edit({ components: [button] }).catch(() => {});
            return;
        }

        if (buttonId.startsWith('unclaim_')) {
            const ticketId = buttonId.split('_')[1];
            const tickets = await client.db.get(`ticket_user_${interaction.guild.id}`);
            const resul = tickets.find(ticket => ticket.id === ticketId);

            if (!resul) return interaction.reply({ content: 'Ticket introuvable.', ephemeral: true });

            await interaction.deferUpdate();

            delete resul.claim;
            const ticketupdate = tickets.map(ticket => (ticket.id === ticketId ? resul : ticket));
            await client.db.set(`ticket_user_${interaction.guild.id}`, ticketupdate);

            const button = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId('close_' + resul.id)
                    .setLabel('Fermer le ticket')
                    .setStyle(4)
                    .setEmoji('🔒'),
                new ButtonBuilder()
                    .setCustomId('claim_' + resul.id)
                    .setLabel('Claim le ticket')
                    .setStyle(2)
                    .setEmoji('🔐')
            );

            const channel = interaction.guild.channels.cache.get(resul.salon);
            const dboption = dbserveur.option.find(option => option.value === resul.option);

            if (dboption && dboption.acess && Array.isArray(dboption.acess)) {
                for (const roleId of dboption.acess) {
                    const role = interaction.guild.roles.cache.get(roleId);
                    if (role) {
                        await channel.permissionOverwrites.edit(role, {
                            SendMessages: true,
                            ViewChannel: true,
                            ReadMessageHistory: true
                        }).catch(() => {});
                    }
                }
            }

            await interaction.message.edit({ components: [button] }).catch(() => {});
            return;
        }

        if (buttonId.startsWith('close_')) {
            const ticketId = buttonId.split('_')[1];

            const modal = new Discord.ModalBuilder()
                .setCustomId(`close_reason_${ticketId}`)
                .setTitle(`Fermeture du ticket`);

            const reasonInput = new Discord.TextInputBuilder()
                .setCustomId('close_reason_input')
                .setLabel('Raison de la fermeture')
                .setStyle(Discord.TextInputStyle.Paragraph)
                .setPlaceholder('Explique brièvement la raison de la fermeture.')
                .setRequired(false);

            const row = new Discord.ActionRowBuilder().addComponents(reasonInput);
            modal.addComponents(row);

            return interaction.showModal(modal);
        }

        // === Submit du modal de fermeture : transcript + logs + DM transcript + DM avis + fermeture
        if (interaction.isModalSubmit() && interaction.customId.startsWith('close_reason_')) {
            const ticketId = interaction.customId.split('_')[2];
            const tickets = await client.db.get(`ticket_user_${interaction.guild.id}`) || [];
            const resul = tickets?.find(ticket => ticket.id === ticketId);
            if (!resul) return;

            const user = await client.users.fetch(resul.author).catch(() => null);
            const usercache = client.users.cache.get(resul.author);
            const dbserveur = await client?.db.get(`ticket_${interaction.guild.id}`);
            if (!dbserveur) return;
            const dboption = dbserveur.option.find(option => option.value === resul.option);
            const channel = interaction.guild.channels.cache.get(dboption?.logs);
            const channelticket = interaction.guild.channels.cache.get(resul.salon);
            const color = await client.db.get(`color_${interaction.guild.id}`) || client.config.default_color;
            const reason = interaction.fields.getTextInputValue('close_reason_input') || 'Aucune raison fournie';
            const attachment = await discordTranscripts.createTranscript(channelticket);

            // Envoi dans le salon de logs
            if (channel) {
                const embed = new EmbedBuilder()
                    .setColor(color)
                    .setFooter(client.footer)
                    .setAuthor({ name: `${user?.username || 'Utilisateur inconnu'} (${resul.author})`, iconURL: user?.avatarURL() })
                    .setTimestamp()
                    .setTitle(`Ticket Fermé par ${interaction.user.username}`)
                    .setDescription(`Raison : ${reason}`);
                channel.send({
                    files: [attachment],
                    embeds: [embed]
                }).catch(() => {});
            }

            // Envoi en MP si transcript activé
            if (dbserveur.transcript === true && usercache) {
                const embed = new EmbedBuilder()
                    .setColor(color)
                    .setAuthor({ name: `${interaction.user.username} (${interaction.user.id})`, iconURL: interaction.user.displayAvatarURL() })
                    .setTitle(`Ticket Fermé par ${interaction.user.username}`)
                    .setDescription(`Raison : ${reason}`)
                    .setFooter(client.footer)
                    .setTimestamp();

                usercache.send({
                    embeds: [embed],
                    files: [attachment],
                }).catch(() => {});
            }

            // === Envoi DM pour avis (après le transcript)
            try {
                const targetType = resul.claim ? 'member' : 'server';
                const targetId   = resul.claim ? resul.claim : interaction.guild.id;
                if (usercache) {
                    const endEmbed = new EmbedBuilder()
                        .setColor(color)
                        .setTitle('Ton ticket a été fermé')
                        .setDescription([
                            'Merci d’avoir contacté le support.',
                            '',
                            '⭐ **Note ce ticket** en choisissant une étoile ci-dessous.',
                            'Après avoir cliqué, tu auras **1 minute** pour écrire un avis (texte).',
                            'Si tu n’écris rien, on enregistrera **uniquement ta note**.'
                        ].join('\n'))
                        .setTimestamp();

                    const starsRow = new ActionRowBuilder().addComponents(
                        ...[1,2,3,4,5].map(n =>
                            new ButtonBuilder()
                                .setCustomId(`dmrate_${interaction.guild.id}_${resul.id}_${n}_${targetType}_${targetId}`)
                                .setLabel('★'.repeat(n))
                                .setStyle(n <= 2 ? Discord.ButtonStyle.Danger : (n === 3 ? Discord.ButtonStyle.Secondary : Discord.ButtonStyle.Success))
                        )
                    );

                    await usercache.send({ embeds: [endEmbed], components: [starsRow] }).catch(() => {});
                }
            } catch (e) {
                console.error('DM review error (buttonsevents close modal):', e);
            }

            // Suppression du ticket de la base et fermeture du salon
            const ticketupdate = tickets.filter(ticket => ticket.id !== ticketId);
            await client.db.set(`ticket_user_${interaction.guild.id}`, ticketupdate);
            await channelticket.delete().catch(() => {});
            // Répondre à l'utilisateur qui ferme le ticket
            await interaction.reply({ content: 'Ticket fermé avec succès.', ephemeral: true });
            return;
        }
    }
};
