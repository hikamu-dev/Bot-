const { ActionRowBuilder, PermissionFlagsBits, ButtonBuilder, EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const Valory = require('../../structures/client');

module.exports = {
    name: "interactionCreate",
    /**
     * @param {Valory} client
     * @param {Valory} interaction
     */
    run: async (client, interaction) => {
        try {
            if (!interaction.isButton()) return;

            // 🔒 AJOUT 1: ignorer les étoiles en DM (déjà gérées dans buttons.js)
            if (interaction.customId?.startsWith('dmrate_')) return;
            // 🔒 AJOUT 2: tout le reste doit se faire en serveur
            if (!interaction.guild) return;

            const color = await client.db.get(`color_${interaction.guild.id}`) || client.config.default_color;

            // ----- Création Ticket -----
            if (interaction.customId.startsWith('ticket_')) {
                const id = interaction.customId.split('_')[1];
                const db = await client?.db.get(`ticket_${interaction.guild.id}`);
                if (!db) return await safeReply(interaction, 'Configuration de ticket non trouvée.');

                const option = db.option.find(option => option.value === id);
                if (!option) return await safeReply(interaction, 'Option de ticket non trouvée.');

                const tickeruser = await client.db.get(`ticket_user_${interaction.guild.id}`) || [];
                const resul = tickeruser.find(ticket => ticket.author === interaction.user.id);

                if (resul && tickeruser.length >= db?.maxticket) {
                    return await safeReply(interaction, `Vous avez déjà atteint le nombre maximal de tickets ouverts !`);
                }

                // Vérification des rôles interdits
                if (db.roleinterdit && Array.isArray(db.roleinterdit) && db.roleinterdit.length > 0) {
                    const userRoles = interaction.member.roles.cache.map(role => role.id);
                    const hasForbiddenRole = db.roleinterdit.some(roleId => userRoles.includes(roleId));
                    
                    if (hasForbiddenRole) {
                        return await safeReply(interaction, `❌ Vous avez un rôle interdit et ne pouvez pas créer de ticket.`);
                    }
                }

                // Vérification des rôles requis
                if (db.rolerequis && Array.isArray(db.rolerequis) && db.rolerequis.length > 0) {
                    const userRoles = interaction.member.roles.cache.map(role => role.id);
                    const hasRequiredRole = db.rolerequis.some(roleId => userRoles.includes(roleId));
                    
                    if (!hasRequiredRole) {
                        return await safeReply(interaction, `❌ Vous n'avez pas les rôles requis pour créer un ticket.`);
                    }
                }

                // ----- MODAL MOTIFS -----
                if (option.motifs && Array.isArray(option.motifs) && option.motifs.length > 0) {
                    const modal = new ModalBuilder()
                        .setCustomId(`ticket_motif_modal_${id}`)
                        .setTitle('Motifs');
                    option.motifs.forEach((motif, idx) => {
                        const input = new TextInputBuilder()
                            .setCustomId(`motif_input_${idx}`)
                            .setLabel(motif.length > 45 ? motif.substring(0, 45) : motif)
                            .setStyle(TextInputStyle.Short)
                            .setRequired(true);
                        modal.addComponents(new ActionRowBuilder().addComponents(input));
                    });
                    await interaction.showModal(modal);
                    return;
                }

                const deferred = await interaction.deferReply({ ephemeral: true }).catch(() => null);
                if (!deferred) return;

                let permissionOverwrites = [
                    {
                        id: interaction.guild.roles.everyone,
                        deny: [PermissionFlagsBits.ViewChannel],
                    },
                    {
                        id: interaction.user.id,
                        allow: [
                            PermissionFlagsBits.SendMessages,
                            PermissionFlagsBits.ViewChannel,
                            PermissionFlagsBits.AttachFiles,
                            PermissionFlagsBits.AddReactions
                        ]
                    }
                ];

                if (option.acess && Array.isArray(option.acess)) {
                    option.acess.forEach(roleId => {
                        const role = interaction.guild.roles.cache.get(roleId);
                        if (role) {
                            permissionOverwrites.push({
                                id: role.id,
                                allow: [
                                    PermissionFlagsBits.SendMessages,
                                    PermissionFlagsBits.ViewChannel,
                                    PermissionFlagsBits.AttachFiles,
                                    PermissionFlagsBits.AddReactions
                                ]
                            });
                        }
                    });
                }

                const channel = await interaction.guild.channels.create({
                    parent: client.channels.cache.get(option.categorie) ? option.categorie : null,
                    name: `⏰・${interaction.user.username}`,
                    type: 0,
                    permissionOverwrites: permissionOverwrites,
                }).catch(console.error);

                if (channel) {
                    await safeReply(interaction, `Ticket ouvert <#${channel.id}>`);

                    const embed = new EmbedBuilder()
                        .setColor(color)
                        .setFooter(client.footer)
                        .setDescription(option.message)
                        .setTitle('Ticket ouvert par ' + interaction.user.username);

                    const idunique = code(15);
                    const buttonRow = new ActionRowBuilder().addComponents(
                        new ButtonBuilder()
                            .setLabel('Fermer le ticket')
                            .setStyle(4)
                            .setEmoji('🔒')
                            .setCustomId("close_" + idunique)
                    );

                    if (db.claimbutton) {
                        buttonRow.addComponents(
                            new ButtonBuilder()
                                .setLabel('Claim le ticket')
                                .setStyle(2)
                                .setEmoji('🔐')
                                .setCustomId("claim_" + idunique)
                        );
                    }

                    if (db.boutonrappel) {
                        buttonRow.addComponents(
                            new ButtonBuilder()
                                .setLabel('Rappeler le créateur')
                                .setStyle(2)
                                .setEmoji('🔔')
                                .setCustomId("rappel_" + idunique)
                        );
                    }

                    await channel.send({
                        embeds: [embed],
                        content: option.mention ? `<@&${option.mention}>` : null,
                        components: [buttonRow]
                    });

                    tickeruser.push({
                        salon: channel.id,
                        author: interaction.user.id,
                        date: Date.now(),
                        id: idunique,
                        option: option.value,
                        claim: null,
                        motif: null,
                    });

                    await client.db.set(`ticket_user_${interaction.guild.id}`, tickeruser);
                } else {
                    await safeReply(interaction, 'Erreur lors de la création du ticket.');
                }
            }

            // ----- Gestion du Modal Motifs -----
            if (interaction.isModalSubmit() && interaction.customId.startsWith('ticket_motif_modal_')) {
                const id = interaction.customId.split('_').pop();
                const db = await client?.db.get(`ticket_${interaction.guild.id}`);
                if (!db) return await safeReply(interaction, 'Configuration de ticket non trouvée.');
                const option = db.option.find(option => option.value === id);
                if (!option) return await safeReply(interaction, 'Option de ticket non trouvée.');
                const color = await client.db.get(`color_${interaction.guild.id}`) || client.config.default_color;
                const tickeruser = await client.db.get(`ticket_user_${interaction.guild.id}`) || [];
                
                // Vérifier le quota de tickets max
                if (tickeruser.filter(t => t.author === interaction.user.id).length >= db?.maxticket) {
                    return await safeReply(interaction, `Vous avez déjà atteint le nombre maximal de tickets ouverts !`);
                }

                // Collecter tous les motifs remplis
                const motifsFilled = [];
                for (let idx = 0; idx < option.motifs.length; idx++) {
                    const value = interaction.fields.getTextInputValue(`motif_input_${idx}`);
                    if (value && value.trim().length > 0) {
                        motifsFilled.push({
                            motif: option.motifs[idx],
                            message: value.trim()
                        });
                    }
                }

                if (motifsFilled.length === 0) {
                    return await safeReply(interaction, '❌ Aucun champ rempli, aucun ticket créé.');
                }

                // Créer un seul ticket avec tous les motifs
                let permissionOverwrites = [
                    {
                        id: interaction.guild.roles.everyone,
                        deny: [PermissionFlagsBits.ViewChannel],
                    },
                    {
                        id: interaction.user.id,
                        allow: [
                            PermissionFlagsBits.SendMessages,
                            PermissionFlagsBits.ViewChannel,
                            PermissionFlagsBits.AttachFiles,
                            PermissionFlagsBits.AddReactions
                        ]
                    }
                ];

                if (option.acess && Array.isArray(option.acess)) {
                    option.acess.forEach(roleId => {
                        const role = interaction.guild.roles.cache.get(roleId);
                        if (role) {
                            permissionOverwrites.push({
                                id: role.id,
                                allow: [
                                    PermissionFlagsBits.SendMessages,
                                    PermissionFlagsBits.ViewChannel,
                                    PermissionFlagsBits.AttachFiles,
                                    PermissionFlagsBits.AddReactions
                                ]
                            });
                        }
                    });
                }

                const channel = await interaction.guild.channels.create({
                    parent: client.channels.cache.get(option.categorie) ? option.categorie : null,
                    name: `⏰・${interaction.user.username}`,
                    type: 0,
                    permissionOverwrites: permissionOverwrites,
                }).catch(console.error);

                if (channel) {
                    // Créer la description avec tous les motifs
                    let description = option.message + '\n\n**📋 Motifs et messages :**';
                    motifsFilled.forEach((item, index) => {
                        description += `\n**${index + 1}. ${item.motif}**\`\`\`\n${item.message}\n\`\`\`\n`;
                    });

                    const embed = new EmbedBuilder()
                        .setColor(color)
                        .setFooter(client.footer)
                        .setDescription(description)
                        .setTitle('Ticket ouvert par ' + interaction.user.username);

                    const idunique = code(15);
                    const buttonRow = new ActionRowBuilder().addComponents(
                        new ButtonBuilder()
                            .setLabel('Fermer le ticket')
                            .setStyle(4)
                            .setEmoji('🔒')
                            .setCustomId("close_" + idunique)
                    );

                    if (db.claimbutton) {
                        buttonRow.addComponents(
                            new ButtonBuilder()
                                .setLabel('Claim le ticket')
                                .setStyle(2)
                                .setEmoji('🔐')
                                .setCustomId("claim_" + idunique)
                        );
                    }

                    if (db.boutonrappel) {
                        buttonRow.addComponents(
                            new ButtonBuilder()
                                .setLabel('Rappeler le créateur')
                                .setStyle(2)
                                .setEmoji('🔔')
                                .setCustomId("rappel_" + idunique)
                        );
                    }

                    await channel.send({
                        embeds: [embed],
                        content: option.mention ? `<@&${option.mention}>` : null,
                        components: [buttonRow]
                    });

                    tickeruser.push({
                        salon: channel.id,
                        author: interaction.user.id,
                        date: Date.now(),
                        id: idunique,
                        option: option.value,
                        claim: null,
                        motif: motifsFilled.map(item => item.motif).join(', '),
                        message: motifsFilled.map(item => `${item.motif}: ${item.message}`).join('\n')
                    });

                    await client.db.set(`ticket_user_${interaction.guild.id}`, tickeruser);
                    await safeReply(interaction, `✅ Ticket ouvert avec succès ! <#${channel.id}>`);
                } else {
                    await safeReply(interaction, '❌ Erreur lors de la création du ticket.');
                }
                return;
            }

            // ----- Claim Ticket -----
            else if (interaction.customId.startsWith('claim_')) {
                const ticketId = interaction.customId.split('_')[1];
                const tickeruser = await client.db.get(`ticket_user_${interaction.guild.id}`) || [];
                const ticketData = tickeruser.find(ticket => ticket.id === ticketId);

                if (!ticketData) return await safeReply(interaction, 'Ce ticket n\'existe plus ou n\'a pas été trouvé.');

                const channel = interaction.guild.channels.cache.get(ticketData.salon);
                if (!channel) return await safeReply(interaction, 'Salon introuvable.');

                if (ticketData.author === interaction.user.id) {
                    return await safeReply(interaction, `Vous ne pouvez pas claim votre propre ticket !`);
                }

                const deferred = await interaction.deferReply({ ephemeral: true }).catch(() => null);
                if (!deferred) return;

                const db = await client.db.get(`ticket_${interaction.guild.id}`);
                if (!db) return await safeReply(interaction, 'Configuration de ticket non trouvée.');

                const option = db.option.find(opt => opt.value === ticketData.option);
                if (!option) return await safeReply(interaction, 'Option de ticket non trouvée.');

                if (option.acess && Array.isArray(option.acess)) {
                    for (const roleId of option.acess) {
                        const role = interaction.guild.roles.cache.get(roleId);
                        if (role) {
                            await channel.permissionOverwrites.edit(role, {
                                SendMessages: false,
                                ViewChannel: true
                            }).catch(console.error);
                        }
                    }
                }

                await channel.permissionOverwrites.edit(interaction.guild.roles.everyone.id, {
                    SendMessages: false,
                    ViewChannel: false
                }).catch(console.error);

                await channel.permissionOverwrites.edit(interaction.user.id, {
                    SendMessages: true,
                    ViewChannel: true,
                    AttachFiles: true,
                    AddReactions: true,
                    ManageMessages: true
                }).catch(console.error);

                await channel.setName(`🔐・${interaction.user.username}`).catch(console.error);

                const message = (await channel.messages.fetch({ limit: 10 })).find(msg => msg.components.length > 0);
                if (message) {
                    const row = message.components[0];
                    const newRow = new ActionRowBuilder();

                    for (const component of row.components) {
                        if (component.customId?.startsWith('claim_')) {
                            newRow.addComponents(
                                ButtonBuilder.from(component).setDisabled(true)
                            );
                        } else {
                            newRow.addComponents(component);
                        }
                    }

                    await message.edit({ components: [newRow] }).catch(console.error);
                }

                await channel.send({ content: `🔐 Ce ticket a été claim par ${interaction.user}.` });

                ticketData.claim = interaction.user.id;
                await client.db.set(`ticket_user_${interaction.guild.id}`, tickeruser);

                await safeReply(interaction, 'Vous avez claim ce ticket avec succès.');
            }

            // ----- Rappel Ticket -----
            else if (interaction.customId.startsWith('rappel_')) {
                const ticketId = interaction.customId.split('_')[1];
                const tickeruser = await client.db.get(`ticket_user_${interaction.guild.id}`) || [];
                const ticketData = tickeruser.find(ticket => ticket.id === ticketId);

                if (!ticketData) return await safeReply(interaction, 'Ce ticket n\'existe plus ou n\'a pas été trouvé.');

                if (ticketData.author === interaction.user.id) {
                    return await safeReply(interaction, `Vous ne pouvez pas vous rappeler vous-même !`);
                }

                const deferred = await interaction.deferReply({ ephemeral: true }).catch(() => null);
                if (!deferred) return;

                try {
                    const user = await client.users.fetch(ticketData.author);
                    if (user) {
                        const db = await client.db.get(`ticket_${interaction.guild.id}`);
                        const option = db?.option?.find(opt => opt.value === ticketData.option);
                        const ticketName = option?.text || 'Ticket';
                        
                        const embed = new EmbedBuilder()
                            .setColor(color)
                            .setTitle('🔔 Rappel de ticket')
                            .setDescription(`Vous avez été rappelé pour votre ticket **${ticketName}** sur le serveur **${interaction.guild.name}**.\n\nCliquez ici pour y accéder : <#${ticketData.salon}>`)
                            .setTimestamp()
                            .setFooter({ text: `Rappelé par ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() });

                        // Ajout du bouton lien vers le ticket
                        const ticketUrl = `https://discord.com/channels/${interaction.guild.id}/${ticketData.salon}`;
                        const row = new ActionRowBuilder().addComponents(
                            new ButtonBuilder()
                                .setLabel('Accéder au ticket')
                                .setStyle(5) // Style Lien
                                .setURL(ticketUrl)
                        );

                        await user.send({ embeds: [embed], components: [row] }).catch(() => {
                            return safeReply(interaction, '❌ Impossible d\'envoyer un message privé à l\'utilisateur. Il a peut-être désactivé les messages privés.');
                        });

                        await safeReply(interaction, `Rappel envoyé avec succès à <@${user.id}> !`);
                    } else {
                        await safeReply(interaction, '❌ Utilisateur introuvable.');
                    }
                } catch (error) {
                    console.error('Erreur lors de l\'envoi du rappel:', error);
                    await safeReply(interaction, '❌ Erreur lors de l\'envoi du rappel.');
                }
            }

        } catch (error) {
            console.error('Uncaught Exception:', error);
            if (interaction.deferred || interaction.replied) {
                await interaction.editReply({ content: 'Une erreur est survenue.', ephemeral: true }).catch(console.error);
            } else {
                await interaction.reply({ content: 'Une erreur est survenue.', ephemeral: true }).catch(console.error);
            }
        }
    }
};

// Fonction utilitaire pour gérer les réponses
async function safeReply(interaction, content) {
    try {
        if (interaction.deferred || interaction.replied) {
            await interaction.editReply({ content, ephemeral: true });
        } else {
            await interaction.reply({ content, ephemeral: true });
        }
    } catch (err) {
        if (err.code === 10062) {
            console.warn('Interaction expirée ou invalide.');
        } else {
            console.error('safeReply error:', err);
        }
    }
}

// Générateur d'ID unique
function code(length) {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let code = '';
    for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * characters.length);
        code += characters.charAt(randomIndex);
    }
    return code;
}
