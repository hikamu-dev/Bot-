const { ButtonStyle, ActionRowBuilder, ButtonBuilder, EmbedBuilder } = require("discord.js");

module.exports = {
    name: 'guildMemberAdd',
    run: async (client, member) => {
        try {
            // Vérifier si le membre et la guild existent
            if (!member || !member.guild) {
                console.log('Membre ou guild invalide');
                return;
            }

            // Vérifier si le bot a les permissions nécessaires
            if (!member.guild.members.me.permissions.has('ManageRoles')) {
                console.log(`Permissions insuffisantes dans ${member.guild.name}`);
                return;
            }

            // Récupérer la configuration de la base de données
            const db = client.db.get(`defautrole_${member.guild.id}`);
            
            if (!db) {
                //console.log(`Aucune configuration d'autorole pour ${member.guild.name}`);
                return;
            }
            
            if (db.status === false) {
                console.log(`Autorole désactivé pour ${member.guild.name}`);
                return;
            }

            const rolesToAdd = db.role;
            
            if (!rolesToAdd || !Array.isArray(rolesToAdd) || rolesToAdd.length === 0) {
                console.log(`Aucun rôle configuré pour ${member.guild.name}`);
                return;
            }

            // Attendre un peu pour s'assurer que le membre est complètement chargé
            await new Promise(resolve => setTimeout(resolve, 1000));

            // Traiter chaque rôle individuellement avec gestion d'erreur
            for (const roleID of rolesToAdd) {
                try {
                    const role = member.guild.roles.cache.get(roleID);
                    
                    if (!role) {
                        console.log(`Rôle ${roleID} introuvable dans ${member.guild.name}`);
                        continue;
                    }

                    // Vérifier si le bot peut gérer ce rôle (hiérarchie)
                    if (role.position >= member.guild.members.me.roles.highest.position) {
                        console.log(`Rôle ${role.name} trop élevé dans la hiérarchie`);
                        continue;
                    }

                    // Vérifier si le membre n'a pas déjà ce rôle
                    if (member.roles.cache.has(roleID)) {
                        console.log(`${member.user.tag} a déjà le rôle ${role.name}`);
                        continue;
                    }

                    // Ajouter le rôle
                    await member.roles.add(role, { reason: 'Shelia | Autorole' });
                    console.log(`Rôle ${role.name} ajouté à ${member.user.tag} dans ${member.guild.name}`);
                    
                    // Petit délai entre chaque ajout de rôle pour éviter le rate limiting
                    await new Promise(resolve => setTimeout(resolve, 500));
                    
                } catch (roleError) {
                    console.error(`Erreur lors de l'ajout du rôle ${roleID} à ${member.user.tag}:`, roleError);
                }
            }

        } catch (error) {
            console.error(`Erreur dans l'autorole pour ${member?.user?.tag || 'utilisateur inconnu'}:`, error);
        }
    }
}