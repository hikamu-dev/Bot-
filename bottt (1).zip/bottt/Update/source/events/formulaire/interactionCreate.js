const { ActionRowBuilder, ButtonBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'interactionCreate',
    /**
     * 
     * @param {Snoway} client 
     * @param {Discord.Message} message 
     * @param {string[]} args 
     * @returns 
     */
    run: async (client, interaction) => {
        if (interaction.isButton() && interaction.customId.startsWith('form_')) {
            try {
                const formId = interaction.customId.split('_')[1];
                const forms = client.db.get(`forms_${interaction.guild.id}`) || [];
                const form = forms.find(f => f.id === formId);

                if (!form) {
                    return interaction.reply({ 
                        content: "⚠️ Ce formulaire n'existe plus ou a été supprimé.", 
                        ephemeral: true 
                    });
                }

                const modal = new ModalBuilder()
                    .setCustomId(`form_response_${formId}`)
                    .setTitle(form.title || 'Formulaire');

                form.options.forEach((option, index) => {
                    const input = new TextInputBuilder()
                        .setCustomId(`response_${index}`)
                        .setLabel(option.length > 45 ? option.substring(0, 45) + '...' : option)
                        .setStyle(TextInputStyle.Paragraph)
                        .setRequired(true);

                    modal.addComponents(new ActionRowBuilder().addComponents(input));
                });

                await interaction.showModal(modal);

            } catch (error) {
                console.error('Erreur lors de l\'affichage du modal:', error);
                if (interaction.deferred || interaction.replied) {
                    await interaction.editReply({ 
                        content: "❌ Une erreur s'est produite lors de l'ouverture du formulaire.", 
                        ephemeral: true 
                    });
                } else {
                    await interaction.reply({ 
                        content: "❌ Une erreur s'est produite lors de l'ouverture du formulaire.", 
                        ephemeral: true 
                    });
                }
            }
        }

        if (interaction.isModalSubmit() && interaction.customId.startsWith('form_response_')) {
            await interaction.deferReply({ ephemeral: true });
            
            try {
                const formId = interaction.customId.split('_')[2];
                const forms = client.db.get(`forms_${interaction.guild.id}`) || [];
                const form = forms.find(f => f.id === formId);

                if (!form) {
                    return interaction.editReply({ 
                        content: "⚠️ Ce formulaire n'existe plus ou a été supprimé.", 
                        ephemeral: true 
                    });
                }

                const responses = form.options.map((option, index) => {
                    return {
                        question: option,
                        answer: interaction.fields.getTextInputValue(`response_${index}`)
                    };
                });
                const responseEmbed = new EmbedBuilder()
                .setTitle(`Réponse au formulaire: ${form.title}`)
                .setDescription(`Réponses de <@${interaction.user.id}>\n ID du formulaire \`${formId}\``)
                .addFields(
                    responses.map(response => ({
                        name: `Question: ${response.question}`,
                        value: `Réponse: ${response.answer.length > 1024 
                            ? response.answer.substring(0, 1021) + '...' 
                            : response.answer}`,
                        inline: false
                    }))
                )
                    .setFooter(client.footer)
                    .setColor(client.color)

                if (form.logChannelId) {
                    const logChannel = interaction.guild.channels.cache.get(form.logChannelId);
                    if (logChannel) {
                        await logChannel.send({ embeds: [responseEmbed] });
                    }
                }

                await interaction.editReply({ 
                    content: "✅ Votre réponse a été enregistrée avec succès!", 
                    ephemeral: true 
                });

            } catch (error) {
                console.error('Erreur lors du traitement des réponses:', error);
                await interaction.editReply({ 
                    content: "❌ Une erreur s'est produite lors de l'enregistrement de vos réponses.", 
                    ephemeral: true 
                });
            }
        }
    }
};