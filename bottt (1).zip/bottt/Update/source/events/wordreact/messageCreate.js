    const Discord = require('discord.js');

module.exports = {
    name: 'messageCreate',
    run: async (client, message) => {
        // Ignorer les messages hors serveur, les messages du bot lui-même, ou les messages dans les DM
        if (!message.guild || message.author.id === client.user.id || message.author.bot) return;

        // Vérifier les permissions du bot dans le canal
        const botMember = message.guild.members.cache.get(client.user.id);
        if (!botMember.permissionsIn(message.channel).has(Discord.PermissionsBitField.Flags.AddReactions)) {
            return;
        }

        // Récupérer les réactions automatiques configurées pour le serveur
        const dbKey = `wordreactions_${message.guild.id}`;
        const wordReactions = client.db.get(dbKey) || {};

        // Si aucune réaction automatique n'est configurée, quitter
        if (Object.keys(wordReactions).length === 0) return;

        // Vérifier chaque mot configuré
        for (const [word, emoji] of Object.entries(wordReactions)) {
            // Vérifier si le message contient le mot (insensible à la casse)
            if (message.content.toLowerCase().includes(word.toLowerCase())) {
                try {
                    await message.react(emoji);
                } catch (error) {
                    console.error(`Erreur lors de l'ajout de la réaction pour le mot "${word}" avec l'emoji "${emoji}" :`, error);
                }
            }
        }
    }
};