// events/autoupdate_ready.js
const { exec } = require('child_process');
const axios = require('axios');
const fs = require('fs');
const cron = require('node-cron');

const DB_ENABLED_KEY = 'autoupdate.enabled';

let started = false;  // évite double init si loader charge deux fois
let task = null;      // instance cron

function t() {
  const n = new Date();
  return `[${n.getHours().toString().padStart(2,'0')}:${n.getMinutes().toString().padStart(2,'0')}:${n.getSeconds().toString().padStart(2,'0')}]`;
}

function execp(cmd) {
  return new Promise((res, rej) => exec(cmd, (err, out) => err ? rej(err) : res(out)));
}

async function dmBuyers(client, content) {
  const buyers = Array.isArray(client?.config?.buyers) ? [...new Set(client.config.buyers)] : [];
  for (const id of buyers) {
    try {
      const u = await client.users.fetch(id).catch(() => null);
      if (!u) continue;
      await u.send({ content, allowedMentions: { parse: [] } }).catch(() => {});
    } catch { /* DM fermés */ }
  }
}

async function performUpdate(client) {
  try {
    // chemins/étapes calqués sur ton système
    const botPath = `/home/ubuntu/bot/${client.user.id}`;
    const updatePath = `/home/ubuntu/Update`;
    const versionFilePath = `${botPath}/version.js`;
    const apiConfig = require('/home/ubuntu/API/config.js');

    await execp(`cd ${botPath} && rm -r source lang && rm version.js index.js`);
    await execp(`cp -r ${updatePath}/* ${botPath}`);

    let botVersion = {};
    try { botVersion = require(versionFilePath); } catch {}
    botVersion.version = apiConfig.version;

    await fs.promises.writeFile(
      versionFilePath,
      `module.exports = ${JSON.stringify(botVersion, null, 2)};`
    );

    await execp(`pm2 restart ${client.user.id}`);

    await dmBuyers(client, `✅ Mise à jour terminée — nouvelle version : ${apiConfig.version}`);
  } catch (e) {
    await dmBuyers(client, `❌ Une erreur est survenue pendant la mise à jour.`);
  }
}

async function checkForUpdate(client) {
  try {
    const res = await axios.post(`http://${client.config.panel}/api/version`, { version: client.version });
    if (res?.data?.message !== 'Mise à jour disponible en attente.') return;

    await dmBuyers(client, `${t()} Mise à jour automatique : démarrage…`);

    const steps = [
                '📥 Téléchargement des fichiers',
                '⚙️ Application de la mise à jour',
                '♻️ Redémarrage du bot en cours'
    ];
    for (const s of steps) {
      await new Promise(r => setTimeout(r, 1500));
      await dmBuyers(client, s);
    }

    await performUpdate(client);
  } catch (e) {
    await dmBuyers(client, `❌ Erreur lors de la vérification de mise à jour.`);
  }
}

function startCron(client) {
  if (task) return task; // déjà actif
// toutes les 2 minutes
task = cron.schedule('0 * * * *', async () => {
    try { await checkForUpdate(client); } catch {}
  });
  return task;
}

function stopCron() {
  if (task) {
    try { task.stop(); } catch {}
    task = null;
  }
}

module.exports = {
  name: 'ready',
  run: async (client) => {
    if (started) return;
    started = true;

    const enabled = client.db.get(DB_ENABLED_KEY) === true;
    if (!enabled) return;

    startCron(client);
    await dmBuyers(client, `AutoUpdate: (reprise au redémarrage).`);

    // check immédiat au boot (optionnel)
    try { await checkForUpdate(client); } catch {}
  },

  // exposé pour la commande afin de piloter le cron sans reboot
  startCron,
  stopCron,
};
