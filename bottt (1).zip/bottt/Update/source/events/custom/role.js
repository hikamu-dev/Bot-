module.exports = {
    name: 'messageCreate',
    run: async (client, message) => {
        // Skip if the message is from a bot
        if (message.author.bot) return;

        // Skip if the message is not in a guild (e.g., DMs)
        if (!message.guild) return;

        const customCommands = client.db.get(`custom_commands_${message.guild.id}`) || [];
        if (!customCommands.length) return;

        // Check if the message matches a custom command
        const prefix = client.config.prefix;
        if (!message.content.startsWith(prefix)) return;
        
        const args = message.content.slice(prefix.length).trim().split(/ +/);
        const commandName = args.shift().toLowerCase();

        const customCommand = customCommands.find(cmd => cmd.name.toLowerCase() === commandName);
        if (!customCommand) return;

        // Permission check
        let pass = false;

        // Autoriser automatiquement les buyers et owners
        if (client.config.buyers.includes(message.author.id) ||
                      client.db.get(`owner_global_${executor.id}`) === true || 

            client.db.get(`owner_${message.author.id}`) === true) {
            pass = true;
        } else {
            // Vérifier la permission spécifique pour la commande
            const permissionName = customCommand.permission;
            // console.log(`Vérification des permissions - Permission requise: ${permissionName}`);
            
            if (permissionName === "public") {
                pass = true;
            } else {
                const permissions = client.db.get(`permissions.${message.guild.id}`) || {};
                const allowedRoles = permissions[permissionName] || [];
                const userRoles = message.member?.roles?.cache?.map(role => role.id) || [];
                // Vérifier si l'utilisateur a un rôle correspondant à la permission
                pass = allowedRoles.some(roleId => userRoles.includes(roleId));
            }
        }

if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        // Determine target (self or another user)
        let targetMember = message.member;
        if (customCommand.target === 'utilisateur') {
            const userMention = args[0];
            if (!userMention) {
                return message.channel.send('Veuillez mentionner un utilisateur pour cette commande.');
            }
            const userId = userMention.replace(/[<@!>|]/g, '');
            targetMember = message.guild.members.cache.get(userId);
            if (!targetMember) {
                return message.channel.send('Utilisateur invalide.');
            }
        }

        // Process command modules
        for (const module of customCommand.modules) {
            if (typeof module === 'object' && module !== null) {
                // Determine destination channel for confirmation messages
                let targetChannel = message.channel;
                if (module.destinationChannelId) {
                    const destinationChannel = message.guild.channels.cache.get(module.destinationChannelId);
                    if (destinationChannel) {
                        targetChannel = destinationChannel;
                    } else {
                        await message.channel.send(`Salon de destination invalide pour le module ${module.type}. Envoi dans le salon actuel.`);
                    }
                }

                if (module.type === 'message') {
                    // Send the message
                    if (module.content) {
                        await targetChannel.send(module.content);
                    }
                } else if (module.type === 'role') {
                    // Check if the role exists
                    const role = message.guild.roles.cache.get(module.roleId);
                    if (!role) {
                        await targetChannel.send('Le rôle spécifié n\'existe plus.');
                        continue;
                    }

                    try {
                        if (module.action === 'ajouter') {
                            // Add the role
                            if (!targetMember.roles.cache.has(module.roleId)) {
                                await targetMember.roles.add(module.roleId);
                                await targetChannel.send(`Le rôle <@&${role.id}> a été ajouté à <@${targetMember.id}>.`);
                            } else {
                                await targetChannel.send(`<@${targetMember.id}> a déjà le rôle ${role.name}.`);
                            }
                        } else if (module.action === 'retirer') {
                            // Remove the role
                            if (targetMember.roles.cache.has(module.roleId)) {
                                await targetMember.roles.remove(module.roleId);
                                await targetChannel.send(`Le rôle ${role.name} a été retiré à <@${targetMember.id}>.`);
                            } else {
                                await targetChannel.send(`<@${targetMember.id}> n'a pas le rôle ${role.name}.`);
                            }
                        }
                    } catch (error) {
                        await targetChannel.send('Une erreur est survenue lors de la gestion du rôle. Assurez-vous que le bot a les permissions nécessaires.');
                        console.error(error);
                    }
                }
            }
        }
    }
};