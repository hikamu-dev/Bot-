const Discord = require('discord.js');
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'messageCreate',
    /**
     * @param {Discord.Client} client 
     * @param {Discord.Message} message 
     * @returns 
     */
    run: async (client, message) => {
        const prefix = client.config.prefix; // Préfixe par défaut

        // Vérifier si le message provient d'un serveur (pas DM)
        if (!message.guild) return;

        if (!message.content.startsWith(prefix) || message.author.bot) return;

        const args = message.content.slice(prefix.length).trim().split(/ +/);
        const commandName = args.shift().toLowerCase();

        // Vérifier si la commande est une commande personnalisée
        const customCommands = client.db.get(`custom_commands_${message.guild.id}`) || [];
        const customCommand = customCommands.find(cmd => cmd.name.toLowerCase() === commandName);

        if (!customCommand) {
            // console.log(`Commande personnalisée "${commandName}" non trouvée.`);
            return;
        }

        // console.log(`Exécution de la commande personnalisée: ${customCommand.name}`);

        // Vérification des permissions pour exécuter la commande
        let pass = false;

        // Autoriser automatiquement les buyers et owners
        if (client.config.buyers.includes(message.author.id) || 
              client.db.get(`owner_global_${executor.id}`) === true || 
            client.db.get(`owner_${message.author.id}`) === true) {
            pass = true;
        } else {
            // Vérifier la permission spécifique pour la commande
            const permissionName = customCommand.permission;
            // console.log(`Vérification des permissions - Permission requise: ${permissionName}`);
            
            if (permissionName === "public") {
                pass = true;
            } else {
                const permissions = client.db.get(`permissions.${message.guild.id}`) || {};
                const allowedRoles = permissions[permissionName] || [];
                const userRoles = message.member.roles.cache.map(role => role.id);
                // Vérifier si l'utilisateur a un rôle correspondant à la permission
                pass = allowedRoles.some(roleId => userRoles.includes(roleId));
            }
        }

if (!pass) {
    if (client.noperm && client.noperm.trim() !== '') {
        const sentMessage = await message.channel.send(client.noperm);
        // Récupérer le délai configuré pour ce serveur
        const delayTime = client.db.get(`noperm_delay_${message.guild.id}`) || 0;
        if (delayTime > 0) {
            setTimeout(() => {
                sentMessage.delete().catch(() => {});
            }, delayTime * 1000);
        }
    }
    return;
}

        // console.log(`Utilisateur ${message.author.id} a les permissions nécessaires.`);

        // Exécuter les modules de la commande
        for (const module of customCommand.modules) {
            if (typeof module === 'object' && module.type === 'embed') {
                // console.log(`Traitement du module embed: ${JSON.stringify(module)}`);
                try {
                    // Récupérer le salon source
                    const sourceChannel = message.guild.channels.cache.get(module.sourceChannelId);
                    if (!sourceChannel) {
                        // console.log(`Salon source ${module.sourceChannelId} introuvable.`);
                        await message.channel.send("Salon source introuvable.").then(msg => setTimeout(() => msg.delete(), 5000));
                        continue;
                    }

                    // console.log(`Salon source trouvé: ${sourceChannel.id}`);

                    // Récupérer le message contenant l'embed
                    const sourceMessage = await sourceChannel.messages.fetch(module.messageId).catch(err => {
                        // console.log(`Erreur lors de la récupération du message ${module.messageId} : ${err.message}`);
                        return null;
                    });
                    if (!sourceMessage) {
                        // console.log(`Message ${module.messageId} introuvable dans le salon ${sourceChannel.id}.`);
                        await message.channel.send("Message introuvable.").then(msg => setTimeout(() => msg.delete(), 5000));
                        continue;
                    }
                    if (!sourceMessage.embeds || sourceMessage.embeds.length === 0) {
                        // console.log(`Aucun embed trouvé dans le message ${module.messageId}. Contenu du message : ${sourceMessage.content}`);
                        await message.channel.send("Aucun embed trouvé dans le message.").then(msg => setTimeout(() => msg.delete(), 5000));
                        continue;
                    }

                    // console.log(`Message trouvé: ${sourceMessage.id}, embeds: ${sourceMessage.embeds.length}`);

                    // Récupérer l'embed
                    const embedToSend = sourceMessage.embeds[0];
                    // console.log(`Contenu de l'embed à envoyer : ${JSON.stringify(embedToSend.toJSON())}`);

                    // Déterminer le salon de destination
                    const destinationChannel = module.destinationChannelId
                        ? message.guild.channels.cache.get(module.destinationChannelId) || message.channel
                        : message.channel;

                    // console.log(`Envoi de l'embed dans le salon: ${destinationChannel.id}`);

                    // Envoyer l'embed dans le salon de destination
                    await destinationChannel.send({ embeds: [embedToSend] });
                    // console.log(`Embed envoyé avec succès dans le salon ${destinationChannel.id} à ${new Date().toISOString()}`);
                } catch (error) {
                    console.error(`Erreur lors de l'envoi de l'embed: ${error.message}`);
                    await message.channel.send("Une erreur est survenue lors de l'envoi de l'embed.").then(msg => setTimeout(() => msg.delete(), 5000));
                }
            }
        }
    },
};