// interactionCreate.js (corrigé)
const {
  ModalBuilder,
  TextInputBuilder,
  ActionRowBuilder,
  EmbedBuilder,
  TextInputStyle,
} = require("discord.js");

module.exports = {
  name: "interactionCreate",
  run: async (client, interaction) => {
    try {
      // On ne gère ici que les boutons liés aux suggestions
      if (!interaction.isButton()) return;
      if (!interaction.customId || !interaction.customId.startsWith("suggest_")) return;

      const [_, action] = interaction.customId.split("_"); // suggest_accept | suggest_refuse | suggest_delete
      const suggestionMessage = interaction.message;

      // Sécurité: s'assurer qu'on a un embed source
      const embed = suggestionMessage?.embeds?.[0];
      const suggestionContent = embed?.description || "Contenu non trouvé.";
      const originalAuthor = embed?.author;

      // ---- Permissions ----
      // Clé de permission dédiée pour modérer les suggestions
      const commandName = "suggest_moderate";

      let pass = false;

      // 1) Rôles privilégiés
      if (
        client.staff?.includes(interaction.user.id) ||
        client.config?.buyers?.includes(interaction.user.id) ||
        client.db.get(`owner_global_${interaction.user.id}`) === true ||
        client.db.get(`owner_${interaction.guild.id}_${interaction.user.id}`) === true ||
        interaction.guild?.ownerId === interaction.user.id
      ) {
        pass = true;
      } else {
        // 2) Permissions personnalisées par rôle (schema similaire à tes commandes)
        const commandPerms =
          client.db.get(
            `command_permissions.${interaction.guild.id}.${commandName}`
          ) || [];
        if (commandPerms.length > 0) {
          const userPerms =
            client.db.get(`permissions.${interaction.guild.id}`) || {};
          const userRoles = interaction.member?.roles?.cache?.map((r) => r.id) || [];
          pass = commandPerms.some(
            (perm) =>
              userPerms[perm] &&
              userPerms[perm].some((roleId) => userRoles.includes(roleId))
          );
        } else if (
          client.db.get(`perm_${commandName}.${interaction.guild.id}`) ===
          "public"
        ) {
          pass = true;
        }
      }

      if (!pass) {
        return interaction.reply({
          content: "Vous n'avez pas la permission de faire cela.",
          ephemeral: true,
        });
      }

      // ---- Actions ----
      if (action === "delete") {
        // Suppression simple + log
        await suggestionMessage.delete().catch((e) => console.error("Delete error:", e));

        await interaction.reply({
          content: "Suggestion supprimée.",
          ephemeral: true,
        });

        const logsChannelId = client.db.get(
          `suggestions_logs_${interaction.guild.id}`
        );
        const logsChannel = interaction.guild.channels.cache.get(logsChannelId);
        if (logsChannel) {
          const logEmbed = new EmbedBuilder()
            .setTitle("Suggestion Supprimée")
            .setDescription(suggestionContent)
            .addFields({
              name: "Supprimée par",
              value: `<@${interaction.user.id}>`,
            })
            .setColor(client.color || 0x2f3136)
            .setTimestamp();

          await logsChannel
            .send({ embeds: [logEmbed] })
            .catch((e) => console.error("Log send error:", e));
        }
        return;
      }

      if (action !== "accept" && action !== "refuse") {
        // action inconnue => ignorer
        return;
      }

      // Ouvrir un modal pour la raison
      const modal = new ModalBuilder()
        .setCustomId(`suggest_${action}_modal`)
        .setTitle(action === "accept" ? "Accepter la suggestion" : "Refuser la suggestion");

      const reasonInput = new TextInputBuilder()
        .setCustomId("reasonInput")
        .setLabel("Raison")
        .setStyle(TextInputStyle.Short)
        .setRequired(true);

      const reasonRow = new ActionRowBuilder().addComponents(reasonInput);
      modal.addComponents(reasonRow);

      await interaction.showModal(modal);

      // Attendre la soumission du modal (30s timeout)
      const modalInteraction = await interaction
        .awaitModalSubmit({
          time: 30_000,
          filter: (i) =>
            i.customId === `suggest_${action}_modal` &&
            i.user.id === interaction.user.id,
        })
        .catch(() => null);

      if (!modalInteraction) {
        // Rien reçu (fermé/timeout)
        return; // pas de reply nécessaire: l’UI du modal se ferme côté client
      }

      const reason = modalInteraction.fields.getTextInputValue("reasonInput");

      // Nettoyage "Suggestion :" si présent
      let cleanedContent = suggestionContent;
      if (cleanedContent.toLowerCase().startsWith("suggestion :")) {
        cleanedContent = cleanedContent.slice("suggestion :".length).trim();
      }

      const updatedEmbed = new EmbedBuilder()
        .setTitle(action === "accept" ? "Suggestion Validée" : "Suggestion Rejetée")
        .setDescription(cleanedContent)
        .setColor(action === "accept" ? 0x57f287 /* Green */ : 0xed4245 /* Red */)
        .setAuthor({
          name: originalAuthor?.name || "Auteur inconnu",
          iconURL: originalAuthor?.iconURL || null,
        })
        .setFooter({
          text: `${action === "accept" ? "Validée" : "Rejetée"} par ${
            interaction.user.tag
          } • ${new Date().toLocaleString("fr-FR", {
            timeZone: "Europe/Paris",
            day: "2-digit",
            month: "2-digit",
            year: "numeric",
            hour: "2-digit",
            minute: "2-digit",
          })}`,
          iconURL: interaction.user.displayAvatarURL({ dynamic: true }),
        });

      // Canal de destination selon action (acceptées/refusées)
      const targetKey =
        action === "accept" ? "suggestions_acceptees" : "suggestions_refusees";
      const targetChannelId = client.db.get(`${targetKey}_${interaction.guild.id}`);
      const targetChannel = interaction.guild.channels.cache.get(targetChannelId);

      if (!targetChannel) {
        await modalInteraction.reply({
          content: `Le salon des suggestions ${
            action === "accept" ? "acceptées" : "refusées"
          } n'est pas configuré.`,
          ephemeral: true,
        });
        return;
      }

      // Supprimer l'origine + publier la version finale
      await suggestionMessage.delete().catch((e) => console.error("Delete error:", e));
      await targetChannel
        .send({ embeds: [updatedEmbed], components: [] })
        .catch((e) => console.error("Send target error:", e));

      await modalInteraction.reply({
        content: `Suggestion ${action === "accept" ? "acceptée" : "refusée"} avec succès !`,
        ephemeral: true,
      });

      // Logs
      const logsChannelId = client.db.get(`suggestions_logs_${interaction.guild.id}`);
      const logsChannel = interaction.guild.channels.cache.get(logsChannelId);

      if (logsChannel) {
        const logEmbed = new EmbedBuilder()
          .setTitle(`Suggestion ${action === "accept" ? "Validée" : "Refusée"}`)
          .setDescription(suggestionContent)
          .addFields(
            { name: "Raison", value: reason || "Aucune" },
            { name: "Traité par", value: `<@${interaction.user.id}>` }
          )
          .setColor(action === "accept" ? 0x57f287 : 0xed4245)
          .setTimestamp();

        await logsChannel
          .send({ embeds: [logEmbed] })
          .catch((e) => console.error("Log send error:", e));
      }
    } catch (err) {
      console.error("interactionCreate suggest_* error:", err);
      // Eviter les 'Unknown interaction' si déjà répondu
      if (interaction.isRepliable() && !interaction.replied && !interaction.deferred) {
        try {
          await interaction.reply({
            content: "Une erreur est survenue pendant le traitement.",
            ephemeral: true,
          });
        } catch (_) {}
      }
    }
  },
};
