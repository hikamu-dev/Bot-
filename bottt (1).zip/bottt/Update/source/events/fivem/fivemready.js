// ready.js
// Relance auto FiveM + met à jour le statut {Fivem...} toutes les 10s au démarrage.
// Ne modifie rien d'autre.

const Discord = require('discord.js');
const db = require('quick.db');

// fetch natif Node18+, fallback node-fetch si besoin
let _fetch = globalThis.fetch;
try { if (!_fetch) _fetch = require('node-fetch'); } catch {}

module.exports = {
  name: 'ready',
  /**
   * @param {Discord.Client} client
   */
  run: async (client) => {
    // --- 1) Démarrer/relancer les pollers FiveM pour toutes les guildes qui ont une IP ---
    if (!client.fivemPollers) client.fivemPollers = new Map();

    // Liste des guildes où une IP FiveM est enregistrée (dans client.db)
    const guildsWithIp = [];
    for (const [gid] of client.guilds.cache) {
      const ip = client.db.get(`fivem_ip_${gid}`);
      if (ip) {
        guildsWithIp.push({ gid, ip });
        if (!client.fivemPollers.has(gid)) startPoller(client, gid, ip); // 10s + anti-cache
      }
    }

    // --- 2) Reposer immédiatement le dernier statut enregistré ---
    const lastType  = db.get('type');       // "PLAYING" | "STREAMING" | "LISTENING" | "WATCHING"
    const lastText  = db.get('nomstatut');  // peut contenir {Fivem...}
    const presence  = db.get('presence') || 'online';
    const streamURL = db.get('streamURL') || undefined;

    const ActivityType = Discord.ActivityType;
    const typeMap = {
      PLAYING:   ActivityType.Playing,
      STREAMING: ActivityType.Streaming,
      LISTENING: ActivityType.Listening,
      WATCHING:  ActivityType.Watching
    };

    if (lastType && lastText) {
      try {
        await client.user.setPresence({
          activities: [{ name: String(lastText), type: typeMap[lastType] ?? ActivityType.Playing, url: lastType === 'STREAMING' ? streamURL : undefined }],
          status: presence
        });
      } catch {}
    }

    // --- 3) Si le texte contient des placeholders {Fivem...}, MAJ toutes les 10s ---
    // On prend comme référence la 1ère guilde qui a une IP (ou sinon la 1ère guilde du bot)
    let refGuildId = guildsWithIp[0]?.gid || client.guilds.cache.first()?.id || null;

    if (lastType && lastText && /\{Fivem/i.test(String(lastText))) {
      if (client._presenceTimer) clearInterval(client._presenceTimer);

      const template = String(lastText);
      const currentType = String(lastType);

      client._presenceTimer = setInterval(async () => {
        try {
          // Si aucune guilde de ref choisie, on réessaie d'en prendre une
          if (!refGuildId) {
            refGuildId = client.guilds.cache.first()?.id || null;
            if (!refGuildId) return;
          }

          // Données FiveM les + récentes stockées par le poller (configfivem)
          const ref = client.db.get(`fivem_last_${refGuildId}`) || {};

          // Remplacement des placeholders
          const again = String(template)
            .replace(/\{FivemMembersCount\}/g, String(ref.count ?? 'unknown'))
            .replace(/\{FivemMaxMembers\}/g,   String(ref.max ?? 'unknown'))
            .replace(/\{FivemHostName\}/g,     String(ref.host ?? 'unknown'))
            .replace(/\{FivemGameType\}/g,     String(ref.gametype ?? 'unknown'))
            .replace(/\{FivemMapName\}/g,      String(ref.map ?? 'unknown'))
            .replace(/\{FivemStatus\}/g,       String(ref.status ?? 'unknown'));

          // On met aussi à jour la DB du texte pour persistance
          db.set('nomstatut', again);

          // Appliquer la présence (STREAMING garde l'URL)
          await client.user.setPresence({
            activities: [{
              name: again,
              type: typeMap[currentType] ?? ActivityType.Playing,
              url: currentType === 'STREAMING' ? (db.get('streamURL') || undefined) : undefined
            }],
            status: db.get('presence') || 'online'
          });
        } catch {}
      }, 10_000); // 10 secondes
    }
  }
};

// ----------------- Helpers FiveM -----------------

function startPoller(client, gid, ip) {
  stopPoller(client, gid);
  if (!ip) return;
  const tick = async () => {
    const data = await pull(ip);
    client.db.set(`fivem_last_${gid}`, data);
  };
  const intv = setInterval(tick, 10_000); // 10s
  client.fivemPollers.set(gid, intv);
  tick(); // premier fetch immédiat
}

function stopPoller(client, gid) {
  const itv = client.fivemPollers?.get(gid);
  if (itv) { clearInterval(itv); client.fivemPollers.delete(gid); }
}

// Requêtes FiveM avec anti-cache
async function pull(ip) {
  const ts = Date.now();
  try {
    const [iRes, pRes] = await Promise.all([
      _fetch(`http://${ip}/info.json?ts=${ts}`,    { cache: 'no-store' }),
      _fetch(`http://${ip}/players.json?ts=${ts}`, { cache: 'no-store' })
    ]);
    if (!iRes || !pRes || !iRes.ok || !pRes.ok) throw 0;

    const info = await iRes.json();
    const players = await pRes.json();

    return {
      count: Array.isArray(players) ? players.length : 0,
      max: Number(info?.vars?.sv_maxClients) || (Array.isArray(players) ? players.length : 0),
      host: info?.vars?.sv_projectName || info?.hostname || 'unknown',
      gametype: info?.vars?.gamename || info?.vars?.gametype || 'unknown',
      map: info?.vars?.mapname || 'unknown',
      status: 'En ligne'
    };
  } catch {
    return { count: 0, max: 0, host: 'unknown', gametype: 'unknown', map: 'unknown', status: 'Hors ligne' };
  }
}
