const { EmbedBuilder, PermissionsBitField, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    name: 'messageReactionAdd',
    run: async (client, reaction, user) => {
        // Ignorer les réactions de bots
        if (user.bot) return;

        // S'assurer que le message et la réaction sont complets
        if (reaction.partial) {
            try {
                await reaction.fetch();
            } catch (error) {
                return console.error('Erreur lors du fetch de la réaction :', error);
            }
        }
        if (reaction.message.partial) {
            try {
                await reaction.message.fetch();
            } catch (error) {
                return console.error('Erreur lors du fetch du message :', error);
            }
        }

        const message = reaction.message;
        const guild = message.guild;
        if (!guild) return;

        // Récupération des données de configuration
        const emoji = client.db.get(`starboard_emoji_${guild.id}`) || '⭐';
        const count = client.db.get(`starboard_count_${guild.id}`) || 3;
        const channelId = client.db.get(`starboard_channel_${guild.id}`);
        const enabled = client.db.get(`starboard_enabled_${guild.id}`) ?? false;

        if (!enabled || !channelId) return;
        if (reaction.emoji.name !== emoji) return;
        if (reaction.count < count) return;

        const starboardChannel = guild.channels.cache.get(channelId);
        if (!starboardChannel) return;

        // Vérifie les permissions du bot
        const botMember = guild.members.me;
        if (!botMember.permissionsIn(starboardChannel).has(PermissionsBitField.Flags.SendMessages)) return;

        // Empêche les doublons
        const existingMessages = await starboardChannel.messages.fetch({ limit: 100 }).catch(() => null);
        if (existingMessages?.some(msg => msg.embeds[0]?.footer?.text?.includes(`ID: ${message.id}`))) return;

        // Construction de l'embed Starboard
        const embed = new EmbedBuilder()
            .setColor('#FFD700')
            .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL() })
            .setDescription(message.content || '*Aucun contenu textuel*')
            .setFooter({ text: `${emoji} ${reaction.count} | ID: ${message.id}` })
            .setTimestamp();

        if (message.attachments.size > 0) {
            embed.setImage(message.attachments.first().url);
        }

        // Création du bouton "Aller au message"
        const button = new ButtonBuilder()
            .setLabel('Aller au message')
            .setStyle(ButtonStyle.Link)
            .setURL(message.url);

        const row = new ActionRowBuilder().addComponents(button);

        try {
            await starboardChannel.send({ embeds: [embed], components: [row] });

            // Envoi d'un log dans le modlogs si configuré
            const modlogId = client.db.get(`modlogs_${guild.id}`);
            const modlogChannel = guild.channels.cache.get(modlogId);
            if (modlogChannel && botMember.permissionsIn(modlogChannel).has(PermissionsBitField.Flags.SendMessages)) {
                const logEmbed = new EmbedBuilder()
                    .setColor('#FFD700')
                    .setDescription(`🌟 Le message de ${message.author.tag} a été posté dans le **Starboard**.`)
                    .addFields(
                        { name: 'Salon', value: `<#${message.channel.id}>`, inline: true },
                        { name: 'Lien', value: `[Voir le message](${message.url})`, inline: true }
                    )
                    .setTimestamp();
                await modlogChannel.send({ embeds: [logEmbed] });
            }

        } catch (err) {
            console.error('Erreur lors de l\'envoi sur le Starboard :', err);
        }
    }
};
