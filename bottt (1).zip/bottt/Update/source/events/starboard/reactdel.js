const { PermissionsBitField } = require('discord.js');

module.exports = {
    name: 'messageReactionRemove',
    run: async (client, reaction, user) => {
        if (user.bot) return;

        // S'assurer que la réaction et le message sont complets
        if (reaction.partial) {
            try {
                await reaction.fetch();
            } catch (error) {
                return console.error('Erreur lors du fetch de la réaction :', error);
            }
        }
        if (reaction.message.partial) {
            try {
                await reaction.message.fetch();
            } catch (error) {
                return console.error('Erreur lors du fetch du message :', error);
            }
        }

        const message = reaction.message;
        const guild = message.guild;
        if (!guild) return;

        // Récupération des données de configuration
        const emoji = client.db.get(`starboard_emoji_${guild.id}`) || '⭐';
        const count = client.db.get(`starboard_count_${guild.id}`) || 3;
        const channelId = client.db.get(`starboard_channel_${guild.id}`);
        const enabled = client.db.get(`starboard_enabled_${guild.id}`) ?? false;

        if (!enabled || !channelId) return;
        if (reaction.emoji.name !== emoji) return;

        // Si le nombre de réactions est encore supérieur ou égal au seuil, ne fait rien
        if (reaction.count >= count) return;

        const starboardChannel = guild.channels.cache.get(channelId);
        if (!starboardChannel) return;

        // Vérifie les permissions du bot
        const botMember = guild.members.me;
        if (!botMember.permissionsIn(starboardChannel).has(PermissionsBitField.Flags.ManageMessages)) return;

        // Cherche le message dans le starboard qui correspond au message original
        const fetchedMessages = await starboardChannel.messages.fetch({ limit: 100 }).catch(() => null);
        if (!fetchedMessages) return;

        // Trouve le message starboard avec le footer contenant l'ID du message original
        const starboardMessage = fetchedMessages.find(m => m.embeds[0]?.footer?.text?.includes(`ID: ${message.id}`));
        if (!starboardMessage) return;

        // Supprime le message starboard
        try {
            await starboardMessage.delete();
        } catch (err) {
            console.error('Erreur lors de la suppression du message Starboard :', err);
        }
    }
};
