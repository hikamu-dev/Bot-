const { PermissionsBitField } = require('discord.js');

module.exports = {
    name: 'messageDelete',
    run: async (client, message) => {
        if (!message.guild) return;

        const guild = message.guild;

        // Récupération des données de configuration
        const channelId = client.db.get(`starboard_channel_${guild.id}`);
        const enabled = client.db.get(`starboard_enabled_${guild.id}`) ?? false;

        if (!enabled || !channelId) return;

        const starboardChannel = guild.channels.cache.get(channelId);
        if (!starboardChannel) return;

        // Vérifie les permissions du bot
        const botMember = guild.members.me;
        if (!botMember.permissionsIn(starboardChannel).has(PermissionsBitField.Flags.ManageMessages)) return;

        // Cherche le message dans le starboard qui correspond au message original
        const fetchedMessages = await starboardChannel.messages.fetch({ limit: 100 }).catch(() => null);
        if (!fetchedMessages) return;

        // Trouve le message starboard avec le footer contenant l'ID du message original
        const starboardMessage = fetchedMessages.find(m => m.embeds[0]?.footer?.text?.includes(`ID: ${message.id}`));
        if (!starboardMessage) return;

        // Supprime le message starboard
        try {
            await starboardMessage.delete();
        } catch (err) {
            console.error('Erreur lors de la suppression du message Starboard suite à la suppression du message original :', err);
        }
    }
};
