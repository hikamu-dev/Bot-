const { WebhookClient, EmbedBuilder } = require("discord.js");

module.exports = {
  name: "guildCreate",
  run: async (client, guild) => {
    // Vérification de la sécurité si activée
    const securbot = await client.db.get(`securbot.${guild.id}`);
    if (securbot) {
      const owner = await client.users.fetch(guild.ownerId);
      if (!owner) {
        guild.leave(); // Quitte le serveur si aucun propriétaire n'est trouvé
        return;
      }
    }

    // Vérification de la présence d'un buyer sur le serveur
    const buyerIds = client.config.buyers;
    const members = await guild.members.fetch().catch(() => null);
    const hasBuyer = members && buyerIds.some((buyerId) => members.has(buyerId));

    if (!hasBuyer) {
      // Création d'un embed pour informer les buyers
      const leaveEmbed = new EmbedBuilder()
        .setTitle("Départ d'un Serveur")
        .setColor(client.config.default_color)
        .setDescription(`
*J'ai quitté le serveur* \`${guild.name}\` car aucun acheteur n'est présent.\n
**Propriétaire :**
- **Mention** : <@${guild.ownerId || "Inconnu"}>
- **ID** : \`${guild.ownerId || "Inconnu"}\`\n
**Membres :**
- **Total** : \`${guild.memberCount}\`
- **Vanity** : \`${guild.vanityURLCode || "Aucune"}\``)
        .setFooter(client.footer)
        .setTimestamp();

      // Envoi de l'embed aux acheteurs
      const buyerUsers = client.users.cache.filter((u) =>
        client.config.buyers.includes(u.id)
      );
      buyerUsers.forEach((u) => {
        u.send({ embeds: [leaveEmbed] }).catch(() => {});
      });

      // Quitter le serveur
      await guild.leave();
      return;
    }  },
};