const { Events, EmbedBuilder } = require("discord.js");

module.exports = {
    name: Events.GuildMemberRemove,
    run: async (client, member) => {
        try {
            // Fetch the full member object if it's partial
            if (member.partial) member = await member.fetch();

            const guildId = member.guild.id;
            const userId = member.user.id;

            // Fetch leave settings from the database
            const db = client.db.get(`leavesettings_${guildId}`);
            if (!db || !db.status) return;

            // Get the guild's configured color
            const color = client.db.get(`color_${guildId}`) || client.config.default_color;

            // Fetch the inviter's ID from the database
            const inviterId = await client.db.get(`invitedby_${guildId}_${userId}`);
            let inviter = null;
            let invitesOfUser = { total: 0, valid: 0, left: 0, bonus: 0 };

            if (inviterId && inviterId !== "vanity") {
                inviter = member.guild.members.cache.get(inviterId);
                invitesOfUser = await client.db.get(`invites_${inviterId}_${guildId}`) || invitesOfUser;
                // Increment the 'left' count for the inviter
                invitesOfUser.left++;
                await client.db.set(`invites_${inviterId}_${guildId}`, invitesOfUser);
            }

            // IMPORTANT: Envoyer le DM AVANT de traiter les autres messages
            // Car une fois que le membre quitte, l'accès DM peut être limité
            if (db.dm?.status && db.dm.message) {
                try {
                    let dmMessageTemplate = db.dm.message;

                    let toSendDM = dmMessageTemplate
                        .replaceAll('{user.id}', member.user.id)
                        .replaceAll('{user.tag}', member.user.tag)
                        .replaceAll('{user.username}', member.user.username)
                        .replaceAll('{user}', member.user.toString())
                        .replaceAll('{inviter.id}', inviter?.user.id || 'Inconnu')
                        .replaceAll('{inviter.username}', inviter?.user.username || 'Inconnu')
                        .replaceAll('{inviter.tag}', inviter?.user.tag || 'Inconnu#0000')
                        .replaceAll('{inviter}', inviter?.toString() || 'Inconnu')
                        .replaceAll('{inviter.total}', invitesOfUser.total)
                        .replaceAll('{inviter.valid}', invitesOfUser.valid)
                        .replaceAll('{inviter.invalide}', invitesOfUser.left)
                        .replaceAll('{inviter.bonus}', invitesOfUser.bonus)
                        .replaceAll('{guild.name}', member.guild.name)
                        .replaceAll('{guild.id}', guildId)
                        .replaceAll('{guild.count}', member.guild.memberCount);

                    // Ensure toSendDM is not empty
                    toSendDM = toSendDM.trim() || `Vous avez quitté ${member.guild.name}.`;

                    // Essayer d'envoyer le DM avec plusieurs méthodes
                    let sentDM = null;
                    
                    try {
                        // Méthode 1: Essayer avec member.send
                        if (db.dm.embed) {
                            const dmEmbed = new EmbedBuilder()
                                .setColor(color)
                                .setDescription(toSendDM)
                                .setFooter(client.footer)
                                .setTimestamp();
                            sentDM = await member.send({ embeds: [dmEmbed] });
                        } else {
                            sentDM = await member.send(toSendDM);
                        }
                        console.log(`DM envoyé avec succès à ${member.user.tag}`);
                    } catch (memberSendError) {
                        // Vérifier si c'est un problème de paramètres de confidentialité
                        if (memberSendError.message.includes("Cannot send messages to this user")) {
                            console.log(`❌ DM non envoyé à ${member.user.tag}: Paramètres de confidentialité restrictifs`);
                            
                            // Option: Envoyer une notification dans un canal spécifique si configuré
                            const dmFailChannel = client.db.get(`dmfail_${guildId}`);
                            if (dmFailChannel) {
                                const failChannel = member.guild.channels.cache.get(dmFailChannel);
                                if (failChannel && failChannel.permissionsFor(member.guild.members.me).has(['SendMessages', 'ViewChannel'])) {
                                    const failEmbed = new EmbedBuilder()
                                        .setColor('#ff6b6b')
                                        .setDescription(`⚠️ Impossible d'envoyer le message de départ en DM à ${member.user.tag}\n**Raison**: Paramètres de confidentialité restrictifs`)
                                        .setFooter({ text: 'Message de départ non délivré' })
                                        .setTimestamp();
                                    
                                    try {
                                        await failChannel.send({ embeds: [failEmbed] });
                                    } catch (err) {
                                        console.error('Erreur envoi notification DM fail:', err);
                                    }
                                }
                            }
                            return; // Ne pas essayer les autres méthodes si c'est un problème de confidentialité
                        }
                        
                        console.log(`Échec envoi DM via member.send pour ${member.user.tag}:`, memberSendError.message);
                        
                        // Méthode 2: Essayer avec client.users.fetch puis send
                        try {
                            const user = await client.users.fetch(userId);
                            if (db.dm.embed) {
                                const dmEmbed = new EmbedBuilder()
                                    .setColor(color)
                                    .setDescription(toSendDM)
                                    .setFooter(client.footer)
                                    .setTimestamp();
                                sentDM = await user.send({ embeds: [dmEmbed] });
                            } else {
                                sentDM = await user.send(toSendDM);
                            }
                            console.log(`✅ DM envoyé avec succès via client.users.fetch à ${user.tag}`);
                        } catch (userSendError) {
                            if (userSendError.message.includes("Cannot send messages to this user")) {
                                console.log(`❌ DM non envoyé à ${member.user.tag}: Paramètres de confidentialité restrictifs`);
                                return;
                            }
                            
                            console.log(`Échec envoi DM via client.users.fetch pour ${userId}:`, userSendError.message);
                            
                            // Méthode 3: Essayer avec member.user.send
                            try {
                                if (db.dm.embed) {
                                    const dmEmbed = new EmbedBuilder()
                                        .setColor(color)
                                        .setDescription(toSendDM)
                                        .setFooter(client.footer)
                                        .setTimestamp();
                                    sentDM = await member.user.send({ embeds: [dmEmbed] });
                                } else {
                                    sentDM = await member.user.send(toSendDM);
                                }
                                console.log(`✅ DM envoyé avec succès via member.user.send à ${member.user.tag}`);
                            } catch (userDirectSendError) {
                                if (userDirectSendError.message.includes("Cannot send messages to this user")) {
                                    console.log(`❌ DM non envoyé à ${member.user.tag}: Paramètres de confidentialité restrictifs`);
                                } else {
                                    console.error(`Impossible d'envoyer le DM à ${member.user.tag}:`, userDirectSendError.message);
                                }
                            }
                        }
                    }

                    // Suppression automatique du message privé si configurée
                    if (db.dm.autoDelete?.status && db.dm.autoDelete.time && sentDM) {
                        setTimeout(() => {
                            sentDM.delete().catch(err => {
                                console.error(`Erreur lors de la suppression automatique du DM:`, err);
                            });
                        }, db.dm.autoDelete.time * 1000);
                    }
                } catch (error) {
                    console.error(`Erreur générale lors de l'envoi du DM à ${member.user.tag}:`, error);
                }
            }

            // Send leave message in channel if configured
            if (db.channel && db.message) {
                const goodbyeChannel = member.guild.channels.cache.get(db.channel);
                if (goodbyeChannel && goodbyeChannel.permissionsFor(member.guild.members.me).has(['SendMessages', 'ViewChannel'])) {
                    let goodbyeMessageTemplate = db.message;

                    let toSend = goodbyeMessageTemplate
                        .replaceAll('{user.id}', member.user.id)
                        .replaceAll('{user.tag}', member.user.tag)
                        .replaceAll('{user.username}', member.user.username)
                        .replaceAll('{user}', member.user.toString())
                        .replaceAll('{inviter.id}', inviter?.user.id || 'Inconnu')
                        .replaceAll('{inviter.username}', inviter?.user.username || 'Inconnu')
                        .replaceAll('{inviter.tag}', inviter?.user.tag || 'Inconnu#0000')
                        .replaceAll('{inviter}', inviter?.toString() || 'Inconnu')
                        .replaceAll('{inviter.total}', invitesOfUser.total)
                        .replaceAll('{inviter.valid}', invitesOfUser.valid)
                        .replaceAll('{inviter.invalide}', invitesOfUser.left)
                        .replaceAll('{inviter.bonus}', invitesOfUser.bonus)
                        .replaceAll('{guild.name}', member.guild.name)
                        .replaceAll('{guild.id}', guildId)
                        .replaceAll('{guild.count}', member.guild.memberCount);

                    // Ensure toSend is not empty
                    toSend = toSend.trim() || `${member.user.toString()} a quitté ${member.guild.name}.`;

                    try {
                        let sentMessage;
                        if (db.embed) {
                            const goodbyeEmbed = new EmbedBuilder()
                                .setColor(color)
                                .setDescription(toSend)
                                .setFooter(client.footer)
                                .setTimestamp();
                            sentMessage = await goodbyeChannel.send({ embeds: [goodbyeEmbed] });
                        } else {
                            sentMessage = await goodbyeChannel.send(toSend);
                        }

                        // Suppression automatique du message de départ si configurée
                        if (db.autoDelete?.status && db.autoDelete.time && sentMessage) {
                            setTimeout(() => {
                                sentMessage.delete().catch(err => {
                                    console.error(`Erreur lors de la suppression automatique du message de départ:`, err);
                                });
                            }, db.autoDelete.time * 1000);
                        }
                    } catch (error) {
                        console.error(`Erreur lors de l'envoi du message de départ pour ${member.user.tag} dans ${goodbyeChannel.name}:`, error);
                    }
                }
            }

            // Send log message to joinsleave channel if configured
            const channelID = client.db.get(`joinsleave_${guildId}`);
            if (channelID) {
                const logChannel = member.guild.channels.cache.get(channelID);
                if (logChannel && logChannel.permissionsFor(member.guild.members.me).has(['SendMessages', 'ViewChannel'])) {
                    let leaveMessage = "";
                    if (inviterId === "vanity") {
                        leaveMessage = `${member} (\`${member.user.id}\`) a quitté le serveur (rejoint via URL personnalisée).`;
                    } else if (inviter) {
                        leaveMessage = `${member} (\`${member.user.id}\`) a quitté le serveur, invité par ${inviter} (\`${inviterId}\`).`;
                    } else {
                        leaveMessage = `${member} (\`${member.user.id}\`) a quitté le serveur, mais je ne peux pas déterminer qui l'a invité.`;
                    }

                    const leaveEmbed = new EmbedBuilder()
                        .setColor(color)
                        .setDescription(leaveMessage || "Un membre a quitté le serveur, mais aucun message de journalisation n'a pu être généré.")
                        .setFooter({ text: `Nous sommes maintenant : ${member.guild.memberCount}` });

                    try {
                        await logChannel.send({ embeds: [leaveEmbed] });
                    } catch (error) {
                        console.error(`Erreur lors de l'envoi du log pour ${member.user.tag} dans ${logChannel.name}:`, error);
                    }
                }
            }
        } catch (error) {
            console.error('Erreur lors du traitement de l\'événement guildMemberRemove:', error);
        }
    }
};