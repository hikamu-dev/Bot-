const Discord = require('discord.js');
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'guildMemberAdd',
    run: async (client, member) => {
        // Fetch partial member data if needed
       if (member.partial) member = await member.fetch();
// ⛔ Ignorer totalement les bots
if (member.user?.bot) return;


        // Fetch current invites and vanity URL data
        const newInvites = await member.guild.invites.fetch();
        if (member.guild.vanityURLCode) {
            newInvites.set(member.guild.vanityURLCode, await member.guild.fetchVanityData());
        }

        // Find the invite used by the member
        let usedInvite = newInvites.find(i =>
            (client.db.has(`invite_${member.guild.id}.${i.code}`) &&
                client.db.get(`invite_${member.guild.id}.${i.code}.uses`) < i.uses) ||
            (client.db.get(`url_${member.guild.id}.url`) === i.code)
        );

        if (usedInvite) {
            if (usedInvite.code === member.guild.vanityURLCode) {
                await client.db.set(`invitedby_${member.guild.id}_${member.id}`, "vanity");
            } else {
                const inviterId = usedInvite.inviter.id;
                const invitesOfUser = await client.db.get(`invites_${inviterId}_${member.guild.id}`) || {
                    total: 0,
                    valid: 0,
                    left: 0,
                    bonus: 0
                };

                invitesOfUser.total++;
                invitesOfUser.valid++;

                await client.db.set(`invites_${inviterId}_${member.guild.id}`, invitesOfUser);
                await client.db.set(`invitedby_${member.guild.id}_${member.id}`, inviterId);
                await client.db.set(`invite_${member.guild.id}.${usedInvite.code}.uses`, usedInvite.uses);
                
                // NOUVEAU : Stocker qui a été invité par qui
                const invitedUsers = await client.db.get(`invited_by_${inviterId}_${member.guild.id}`) || [];
                if (!invitedUsers.includes(member.id)) {
                    invitedUsers.push(member.id);
                    await client.db.set(`invited_by_${inviterId}_${member.guild.id}`, invitedUsers);
                }
            }
        }

        // Get the guild's configured color and join/leave log channel
        const color = client.db.get(`color_${member.guild.id}`) || client.config.default_color;
        const channelID = client.db.get(`joinsleave_${member.guild.id}`);

        if (channelID) {
            const logChannel = member.guild.channels.cache.get(channelID);
            if (logChannel && logChannel.permissionsFor(member.guild.members.me).has(Discord.PermissionsBitField.Flags.SendMessages)) {
                const inviterID = await client.db.get(`invitedby_${member.guild.id}_${member.id}`);
                const urlData = await client.db.get(`url_${member.guild.id}`);
                let joinMessage = "";

                if (inviterID === "vanity") {
                    joinMessage = `${member} (\`${member.id}\`) a rejoint le serveur via l'URL personnalisée, utilisations de l'URL : \`${member.guild.vanityURLUses || (urlData ? urlData.uses : 0)}\``;
                } else if (inviterID) {
                    const inviter = member.guild.members.cache.get(inviterID);
                    if (member.user.bot) {
                        joinMessage = `${member} (\`${member.id}\`) a rejoint le serveur via l'API OAuth2.`;
                    } else if (inviter) {
                        joinMessage = `${member} (\`${member.id}\`) a rejoint le serveur, invité par ${inviter} (\`${inviter.id}\`).`;
                    } else {
                        joinMessage = `${member} (\`${member.id}\`) a rejoint le serveur, mais je ne peux pas déterminer qui l'a invité.`;
                    }
                }

                const joinEmbed = new EmbedBuilder()
                    .setColor(color)
                    .setDescription(joinMessage || "Un membre a rejoint le serveur, mais aucun message de journalisation n'a pu être généré.")
                    .setFooter({ text: `Nous sommes maintenant : ${member.guild.memberCount}` });

                try {
                    await logChannel.send({ embeds: [joinEmbed] });
                } catch (error) {
                    console.error(`Erreur lors de l'envoi du log pour ${member.user.tag} dans ${logChannel.name}:`, error);
                }
            }
        }

        // Handle the welcome message if join settings are enabled
        const db = client.db.get(`joinsettings_${member.guild.id}`);
        if (!db || db.status === false) return;

        // Send welcome message in channel if configured
        if (db.channel && db.message) {
            const welcomeChannel = member.guild.channels.cache.get(db.channel);
            if (welcomeChannel && welcomeChannel.permissionsFor(member.guild.members.me).has(Discord.PermissionsBitField.Flags.SendMessages)) {
                let inviter = null;
                let invitesOfUser = { total: 0, valid: 0, left: 0, bonus: 0 };
                
                if (usedInvite && usedInvite.inviter) {
                    inviter = usedInvite.inviter;
                    invitesOfUser = await client.db.get(`invites_${inviter.id}_${member.guild.id}`) || invitesOfUser;
                }

                let joinMessageTemplate = db.message;

                let toSend = joinMessageTemplate
                    .replaceAll('{user.id}', member.user.id)
                    .replaceAll('{user.tag}', member.user.tag)
                    .replaceAll('{user.username}', member.user.username)
                    .replaceAll('{user}', member.user.toString())
                    .replaceAll('{inviter.id}', inviter?.id || 'vanity url')
                    .replaceAll('{inviter.username}', inviter?.username || 'vanity url')
                    .replaceAll('{inviter.tag}', inviter?.tag || 'vanity url')
                    .replaceAll('{inviter}', inviter?.toString() || 'vanity url')
                    .replaceAll('{inviter.total}', invitesOfUser.total)
                    .replaceAll('{inviter.valid}', invitesOfUser.valid)
                    .replaceAll('{inviter.invalide}', invitesOfUser.left)
                    .replaceAll('{inviter.bonus}', invitesOfUser.bonus)
                    .replaceAll('{guild.name}', member.guild.name)
                    .replaceAll('{guild.id}', member.guild.id)
                    .replaceAll('{guild.count}', member.guild.memberCount);

                // Ensure toSend is not empty
                toSend = toSend.trim() || `Bienvenue ${member.user.toString()} sur ${member.guild.name} !`;

                try {
                    let sentMessage;
                    if (db.embed) {
                        const welcomeEmbed = new EmbedBuilder()
                            .setColor(color)
                            .setDescription(toSend)
                            .setFooter(client.footer);
                        sentMessage = await welcomeChannel.send({ embeds: [welcomeEmbed] });
                    } else {
                        sentMessage = await welcomeChannel.send(toSend);
                    }

                    // Suppression automatique du message de bienvenue si configurée
                    if (db.autoDelete?.status && db.autoDelete.time && sentMessage) {
                        setTimeout(() => {
                            sentMessage.delete().catch(err => {
                                console.error(`Erreur lors de la suppression automatique du message de bienvenue:`, err);
                            });
                        }, db.autoDelete.time * 1000);
                    }
                } catch (error) {
                    console.error(`Erreur lors de l'envoi du message de bienvenue pour ${member.user.tag} dans ${welcomeChannel.name}:`, error);
                }
            }
        }

        // Send DM message if configured
        if (db.dm?.status && db.dm.message) {
            try {
                let inviter = null;
                let invitesOfUser = { total: 0, valid: 0, left: 0, bonus: 0 };
                
                if (usedInvite && usedInvite.inviter) {
                    inviter = usedInvite.inviter;
                    invitesOfUser = await client.db.get(`invites_${inviter.id}_${member.guild.id}`) || invitesOfUser;
                }

                let dmMessageTemplate = db.dm.message;

                let toSendDM = dmMessageTemplate
                    .replaceAll('{user.id}', member.user.id)
                    .replaceAll('{user.tag}', member.user.tag)
                    .replaceAll('{user.username}', member.user.username)
                    .replaceAll('{user}', member.user.toString())
                    .replaceAll('{inviter.id}', inviter?.id || 'vanity url')
                    .replaceAll('{inviter.username}', inviter?.username || 'vanity url')
                    .replaceAll('{inviter.tag}', inviter?.tag || 'vanity url')
                    .replaceAll('{inviter}', inviter?.toString() || 'vanity url')
                    .replaceAll('{inviter.total}', invitesOfUser.total)
                    .replaceAll('{inviter.valid}', invitesOfUser.valid)
                    .replaceAll('{inviter.invalide}', invitesOfUser.left)
                    .replaceAll('{inviter.bonus}', invitesOfUser.bonus)
                    .replaceAll('{guild.name}', member.guild.name)
                    .replaceAll('{guild.id}', member.guild.id)
                    .replaceAll('{guild.count}', member.guild.memberCount);

                // Ensure toSendDM is not empty
                toSendDM = toSendDM.trim() || `Bienvenue sur ${member.guild.name} !`;

                let sentDM;
                if (db.dm.embed) {
                    const dmEmbed = new EmbedBuilder()
                        .setColor(color)
                        .setDescription(toSendDM)
                        .setFooter(client.footer);
                    sentDM = await member.send({ embeds: [dmEmbed] }).catch(() => {});
                } else {
                    sentDM = await member.send(toSendDM).catch(() => {});
                }

                // Suppression automatique du message privé si configurée
                if (db.dm.autoDelete?.status && db.dm.autoDelete.time && sentDM) {
                    setTimeout(() => {
                        sentDM.delete().catch(err => {
                            console.error(`Erreur lors de la suppression automatique du DM:`, err);
                        });
                    }, db.dm.autoDelete.time * 1000);
                }
            } catch (error) {
                console.error(`Erreur lors de l'envoi du DM à ${member.user.tag}:`, error);
            }
        }
    }
};