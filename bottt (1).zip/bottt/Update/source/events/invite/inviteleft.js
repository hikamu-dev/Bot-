const { Events } = require("discord.js");

module.exports = {
    name: 'guildMemberRemove',
    run: async (client, member) => {
        if (member.partial) member = await member.fetch();
        
        const inviterId = await client.db.get(`invitedby_${member.guild.id}_${member.id}`);
        if (inviterId && inviterId !== "vanity") {
            const invitesOfUser = await client.db.get(`invites_${inviterId}_${member.guild.id}`);
            if (invitesOfUser) {
                invitesOfUser.valid--;
                invitesOfUser.left++;

                await client.db.set(`invites_${inviterId}_${member.guild.id}`, invitesOfUser);
            }

            // NOUVEAU : Retirer l'utilisateur de la liste des invités
            const invitedUsers = await client.db.get(`invited_by_${inviterId}_${member.guild.id}`) || [];
            const updatedInvitedUsers = invitedUsers.filter(id => id !== member.id);
            
            if (updatedInvitedUsers.length !== invitedUsers.length) {
                await client.db.set(`invited_by_${inviterId}_${member.guild.id}`, updatedInvitedUsers);
            }
        }

        // Nettoyer les données de l'utilisateur qui part
        await client.db.delete(`invitedby_${member.guild.id}_${member.id}`);
    }
};