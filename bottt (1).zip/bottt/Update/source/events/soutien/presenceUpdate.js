const Astroia = require("../../structures/client/index");

module.exports = {
    name: "presenceUpdate",
    run: async (client, oldPresence, newPresence) => {
        const guildID = newPresence.guild?.id;
        if (!guildID) return;

        const db = client.db.get(`soutien_${guildID}`);
        if (!db) return;
        if (db.status === false || !db.names?.length) return;

        const member = newPresence.member;
        const rolesToRemove = db.role;

        if (newPresence.status === 'offline' && rolesToRemove?.length > 0) {
            try {
                await member.roles.remove(rolesToRemove);
            } catch (error) {
                console.log(`Failed to remove roles from offline member ${member.id} in guild ${guildID}:`, error);
            }
            return;
        }

        const customStatus = newPresence.member?.presence?.activities[0]?.state;
        const rolesToAdd = db.role;

        if (db.status === true && customStatus) {
            const hasMatchingStatus = db.names.some(name => customStatus.includes(name));

            if (hasMatchingStatus) {
                if (rolesToAdd?.length > 0) {
                    try {
                        await member.roles.add(rolesToAdd);
                    } catch (error) {
                        console.log(`Failed to add roles to member ${member.id} in guild ${guildID}:`, error);
                    }
                }
            } else {
                if (rolesToRemove?.length > 0) {
                    try {
                        await member.roles.remove(rolesToRemove);
                    } catch (error) {
                        console.log(`Failed to remove roles from member ${member.id} in guild ${guildID}:`, error);
                    }
                }
            }
        }
    }
};