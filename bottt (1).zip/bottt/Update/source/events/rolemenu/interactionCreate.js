module.exports = {
    name: "interactionCreate",
    run: async (client, interaction) => {
        if (interaction.isButton()){
            if (interaction.customId.startsWith("buttonrole") && interaction.customId.includes("_")){
                interaction.deferUpdate().catch(() => false)
                const role = await interaction.guild.roles.fetch(interaction.customId.split("_")[1]).catch(() => false)
                if (!role) return;
        
                if (interaction.member.roles.cache.some(r => r.id === role.id))
                   return interaction.member.roles.remove(role.id).catch(() => false)
                
                else interaction.member.roles.add(role.id).catch(() => false)   
            }
        }
        else if (interaction.isStringSelectMenu()){
            if (interaction.values[0].startsWith("buttonrole") && interaction.values[0].includes("_")){
                interaction.deferUpdate().catch(() => false)
                const role = await interaction.guild.roles.fetch(interaction.values[0].split("_")[1]).catch(() => false)
                if (!role) return;
        
                if (interaction.member.roles.cache.some(r => r.id === role.id))
                   return interaction.member.roles.remove(role.id).catch(() => false)
                
                else interaction.member.roles.add(role.id).catch(() => false)   
            }
        }
    },
};