const Discord = require('discord.js');

module.exports = {
  name: 'messageReactionAdd',
  run: async (client, reaction, user) => {
    if (user.bot) return;

    if (reaction.message.partial) {
      try {
        await reaction.message.fetch();
      } catch {
        return;
      }
    }
    if (reaction.partial) {
      try {
        await reaction.fetch();
      } catch {
        return;
      }
    }

    if (
      client.config.buyers.includes(user.id) ||
      client.db.get(`owner_global_${user.id}`) === true || 
      client.db.get(`owner_${user.id}`) === true

    ) return;

    const antireactChannels = client.db.get(`antireact_${reaction.message.guild.id}`) || [];
    if (!antireactChannels.includes(reaction.message.channel.id)) return;

    try {
      await reaction.users.remove(user);
    } catch (error) {
      console.error(`Impossible de supprimer la réaction de ${user.tag} dans ${reaction.message.channel.name}:`, error);
    }
  }
};
