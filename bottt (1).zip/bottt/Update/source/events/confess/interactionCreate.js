const {
    ModalBuilder,
    TextInputBuilder,
    ActionRowBuilder,
    EmbedBuilder,
    TextInputStyle,
    ComponentType
} = require('discord.js');

module.exports = {
    name: "interactionCreate",
    run: async (client, interaction) => {
        if (interaction.isButton()) {
            if (interaction.customId === 'confession_new') {
                const modal = new ModalBuilder()
                    .setCustomId('confession_modal')
                    .setTitle('Envoyer une confession anonyme');

                const confessionInput = new TextInputBuilder()
                    .setCustomId('confessionInput')
                    .setLabel('Votre confession')
                    .setStyle(TextInputStyle.Paragraph)
                    .setRequired(true)
                    .setMaxLength(1000);

                const firstRow = new ActionRowBuilder().addComponents(confessionInput);
                modal.addComponents(firstRow);

                await interaction.showModal(modal);
            }
        }

        if (interaction.isModalSubmit()) {
            if (interaction.customId === 'confession_modal') {
                await interaction.deferReply({ ephemeral: true });

                const confessionText = interaction.fields.getTextInputValue('confessionInput');

                const guildId = interaction.guild.id;
                const confessionChannelId = client.db.get(`confession_channel_${guildId}`);
                if (!confessionChannelId) {
                    return interaction.editReply({
                        content: '❌ Le salon des confessions anonymes n\'est pas configuré sur ce serveur.'
                    });
                }

                const confessionChannel = interaction.guild.channels.cache.get(confessionChannelId);
                if (!confessionChannel || confessionChannel.type !== 0) {
                    return interaction.editReply({
                        content: '❌ Le salon des confessions configuré est invalide ou inaccessible.'
                    });
                }

                const confessionEmbed = new EmbedBuilder()
                    .setTitle('💬 Nouvelle confession anonyme')
                    .setDescription(confessionText)
                    .setColor(client.color)
                    .setFooter({ text: `Confession reçue le ${new Date().toLocaleDateString('fr-FR')}` })
                    .setTimestamp();

                await confessionChannel.send({ embeds: [confessionEmbed] });

                // Log optionnel
                const logsChannelId = client.db.get(`confession_logs_${guildId}`);
                if (logsChannelId) {
                    const logsChannel = interaction.guild.channels.cache.get(logsChannelId);
                    if (logsChannel && logsChannel.type === 0) {
                        const logEmbed = new EmbedBuilder()
                            .setTitle('Confession envoyée')
                            .addFields(
                                { name: 'Utilisateur', value: `${interaction.user.tag} (${interaction.user.id})` },
                                { name: 'Contenu', value: confessionText.length > 1024 ? confessionText.slice(0, 1021) + '...' : confessionText }
                            )
                            .setColor(client.color)
                            .setTimestamp();

                        logsChannel.send({ embeds: [logEmbed] }).catch(() => { });
                    }
                }

                return interaction.editReply({ content: '✅ Votre confession a bien été envoyée anonymement !', ephemeral: true });
            }
        }
    }
};
