// botperso/source/events/antighostGuard.js
// Anti "ghost ping" tout-en-un (format events: name="ready", run(client)).
// Principe :
//  - On écoute messageCreate : si ça mentionne une "personne protégée", on garde en cache 4 minutes.
//  - On écoute messageDelete : si le message supprimé est encore en cache (< 4 min), on signale le ghost ping.
//
// DB utilisée (même style que tes autres commandes) :
//   antighost_enabled_<guildId> : true|false
//   antighost_list_<guildId>    : [userId, ...]
//   antighost_msg_<guildId>     : string (ex: "⚠️ {author} a essayé de ghost ping {user} sur {guild}.")
// Placeholders disponibles : {author}, {user}, {guild}

module.exports = {
  name: "ready",
  /**
   * @param {import('discord.js').Client} client
   */
  run: async (client) => {
    try {
      // Empêcher le double câblage si ton loader relance "ready"
      if (client._antighostWired) return;
      client._antighostWired = true;

      // Cache partagé en mémoire : messageId -> { guildId, channelId, authorId, hitUserId, createdAt, expiresAt }
      if (!client.antighostCache) client.antighostCache = new Map();
      const EXPIRE_MS = 4 * 60 * 1000; // 4 minutes

      // Helpers
      const isEnabled = (gId) => !!client.db.get(`antighost_enabled_${gId}`);
      const getList = (gId) => Array.from(new Set(client.db.get(`antighost_list_${gId}`) || []));
      const getMsgTemplate = (gId) =>
        client.db.get(`antighost_msg_${gId}`) || "⚠️ {author} a essayé de ghost ping {user} sur {guild}.";

      const isBypass = (guild, userId) => {
        const wl = client.db.get(`wl.${guild.id}`) || [];
        return (
          client.staff?.includes?.(userId) ||
          client.config?.buyers?.includes?.(userId) ||
          client.db.get(`owner_${userId}`) === true ||
          client.db.get(`owner_global_${userId}`) === true ||
          wl.includes(userId) ||
          guild.ownerId === userId
        );
      };

      const cleanCache = () => {
        const now = Date.now();
        for (const [mid, rec] of client.antighostCache) {
          if (!rec || rec.expiresAt <= now) client.antighostCache.delete(mid);
        }
      };

      // 1) TRACK — On note les messages qui mentionnent une personne protégée (pour 4 min)
      client.on("messageCreate", async (message) => {
        try {
          if (!message.guild || message.author?.bot) return;
          const gId = message.guild.id;

          if (!isEnabled(gId)) return;

          // Bypass = pas concerné
          if (isBypass(message.guild, message.author.id)) return;

          const list = getList(gId);
          if (!list.length) return;

          // Récupérer les IDs potentiellement mentionnés
          const mentionedIds = new Set();
          try {
            for (const u of message.mentions.users.values()) mentionedIds.add(u.id);
            for (const m of message.mentions.members.values()) mentionedIds.add(m.id);
            const viaRegex = message.content?.match(/\d{15,20}/g) || [];
            for (const id of viaRegex) mentionedIds.add(id);
          } catch {}

          // Si ça touche une personne protégée, on met en cache
          const hitUserId = [...mentionedIds].find(id => list.includes(id));
          if (!hitUserId) return;

          const now = Date.now();
          client.antighostCache.set(message.id, {
            guildId: gId,
            channelId: message.channel.id,
            authorId: message.author.id,
            hitUserId,
            createdAt: now,
            expiresAt: now + EXPIRE_MS
          });

          // Nettoyage paresseux
          cleanCache();
        } catch (e) {
          console.error("[AntiGhost][messageCreate] ", e);
        }
      });

      // 2) GUARD — Si un message suivi en cache est supprimé < 4 min, on alerte (ghost ping)
      client.on("messageDelete", async (message) => {
        try {
          const gId = message.guild?.id;
          if (!gId) return;
          if (!isEnabled(gId)) return;

          const rec = client.antighostCache.get(message.id);
          if (!rec) return; // soit pas concerné, soit expiré/absent

          // Expiration dépassée ?
          if (rec.expiresAt <= Date.now()) {
            client.antighostCache.delete(message.id);
            return;
          }

          const template = getMsgTemplate(gId);
          const text = template
            .replaceAll("{author}", `<@${rec.authorId}>`)
            .replaceAll("{user}", `<@${rec.hitUserId}>`)
            .replaceAll("{guild}", message.guild.name);

          const chan = message.channel ?? client.channels.cache.get(rec.channelId);
          if (chan && chan.isTextBased()) {
            await chan.send(text).catch(() => {});
          }

          // Consommer & nettoyer
          client.antighostCache.delete(message.id);
          cleanCache();
        } catch (e) {
          console.error("[AntiGhost][messageDelete] ", e);
        }
      });

      // Garbage collector périodique (au cas où)
      setInterval(cleanCache, 60 * 1000);

      console.log("[AntiGhost] Guard armé (fenêtre 4 minutes, messageCreate + messageDelete).");
    } catch (err) {
      console.error("[AntiGhost][ready] ", err);
    }
  }
};
