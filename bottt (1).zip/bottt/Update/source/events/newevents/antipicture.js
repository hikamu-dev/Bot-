// events/antipicture.js
// Supprime les messages contenant des images dans les salons marqués AntiPicture.

const IMAGE_EXT_RE = /\.(png|jpe?g|gif|webp|bmp|tiff?|svg|apng)$/i;

module.exports = {
  name: "messageCreate",
  /**
   * @param {import('discord.js').Client} client
   * @param {import('discord.js').Message} message
   */
  run: async (client, message) => {
    try {
      if (!message.guild || message.author?.bot) return;

      const gId = message.guild.id;
      const list = new Set(client.db.get(`antipic_channels_${gId}`) || []);
      if (!list.size) return;

      // Cible : salon ou thread ; si thread, on applique si le thread lui-même est listé
      // (si tu veux aussi hériter du parent, dé-commente le test parentId plus bas)
      const chId = message.channel.id;
      const parentId = message.channel.parentId;

      const isTarget =
        list.has(chId) /* || (parentId && list.has(parentId)) */;

      if (!isTarget) return;

      // Bypass (ton style)
      const whitelistDB = client.db.get(`wl.${gId}`) || [];
      const bypass =
        client.staff?.includes?.(message.author.id) ||
        client.config?.buyers?.includes?.(message.author.id) ||
        client.db.get(`owner_${message.author.id}`) === true ||
        client.db.get(`owner_global_${message.author.id}`) === true ||
        whitelistDB.includes(message.author.id) ||
        message.guild.ownerId === message.author.id;
      if (bypass) return;

      // Détection d’images :
      // 1) pièces jointes image/*
      const hasImageAttachment = [...message.attachments.values()].some(a =>
        (a.contentType?.startsWith("image/")) ||
        IMAGE_EXT_RE.test((a.name || ""))
      );

      // 2) stickers
      const hasSticker = (message.stickers?.size || 0) > 0;

      // 3) liens direct d'image dans le contenu
      const content = message.content || "";
      const hasImageLink = IMAGE_EXT_RE.test(content);

      if (hasImageAttachment || hasSticker || hasImageLink) {
        // tente de supprimer le message
        await message.delete().catch(() => {});

        // petite notification (mention **uniquement** l’auteur), auto-delete après 5s
        const warn = await message.channel.send({
          content: `<@${message.author.id}> les images ne sont pas autorisées ici.`,
          allowedMentions: { users: [message.author.id], roles: [], parse: [] }
        }).catch(() => null);

        if (warn) setTimeout(() => warn.delete().catch(() => {}), 5000);
      }

    } catch (e) {
      console.error("[AntiPicture] ", e);
    }
  }
};
