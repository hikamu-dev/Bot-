// events/wordreact.js
// Ajoute automatiquement des réactions selon les règles configurées.

module.exports = {
  name: "messageCreate",
  /**
   * @param {import('discord.js').Client} client
   * @param {import('discord.js').Message} message
   */
  run: async (client, message) => {
    try {
      if (!message.guild || message.author?.bot) return;
      const gId = message.guild.id;

      const enabled = !!client.db.get(`wordreact_enabled_${gId}`);
      if (!enabled) return;

      const rules = Array.isArray(client.db.get(`wordreact_rules_${gId}`))
        ? client.db.get(`wordreact_rules_${gId}`)
        : [];
      if (!rules.length) return;

      const content = message.content || "";
      if (!content) return;

      let reacted = 0;
      const MAX_REACT = 4;

      for (const rule of rules) {
        if (reacted >= MAX_REACT) break;

        let ok = false;
        const pat = rule.case ? rule.pattern : rule.pattern.toLowerCase();
        const txt = rule.case ? content : content.toLowerCase();

        switch (rule.type) {
          case "equals": ok = (txt === pat); break;
          case "starts": ok = txt.startsWith(pat); break;
          case "ends":   ok = txt.endsWith(pat); break;
          case "regex":
            try {
              const re = new RegExp(rule.pattern, rule.case ? "" : "i");
              ok = re.test(content);
            } catch { ok = false; }
            break;
          case "contains":
          default:
            ok = txt.includes(pat);
            break;
        }

        if (!ok) continue;

        for (const em of rule.emojis) {
          if (reacted >= MAX_REACT) break;
          try {
            await message.react(em); // unicode ou ID d’emoji custom
            reacted++;
          } catch {
            // ignore si emoji invalide
          }
        }
      }
    } catch (e) {
      console.error("[WordReact] ", e);
    }
  }
};
