const { WebhookClient, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType } = require("discord.js");

module.exports = {
  name: "guildCreate",
  run: async (client, guild) => {
    const logs = await guild.fetchAuditLogs({ limit: 1, type: 28 }).then(audit => audit.entries.first());
    const adduser = logs.executor;
    const membresHumains = guild.members.cache.filter(m => !m.user.bot).size;
    const membresBots = guild.members.cache.filter(m => m.user.bot).size;
    const totalMembres = guild.memberCount;
    const ownerserv = await client.users.fetch(guild.ownerId);

    let inviteLink = null;

    if (guild.vanityURLCode) {
      inviteLink = `https://discord.gg/${guild.vanityURLCode}`;
    } else {
      const textChannel = guild.channels.cache.find(
        c => c.type === ChannelType.GuildText && c.permissionsFor(guild.members.me).has("CreateInstantInvite")
      );
      if (textChannel) {
        try {
          const invite = await textChannel.createInvite({ maxAge: 0, maxUses: 1 });
          inviteLink = `https://discord.gg/${invite.code}`;
        } catch (e) {}
      }
    }

    const embed = new EmbedBuilder()
      .setTitle("Ajout sur un Serveur")
      .setColor(client.config.default_color)
      .setDescription(`
*J'ai été ajouté sur* \`${guild.name}\`\n
\`Membres :\`
**Total -** \`${totalMembres}\`
**Humains -** \`${membresHumains}\`
**Bots -** \`${membresBots}\`
**Vanity :** \`${guild.vanityURLCode || "Aucune"}\`\n
\`Propriétaire :\` 
**Mention :** <@${ownerserv.id}>
**Username :** \`${ownerserv.username}\`
**ID :** \`${ownerserv.id}\`\n
\`Ajouteur :\`
**Mention :** ${adduser}
**Username :** \`${adduser.username}\`
**ID :** \`${adduser.id}\`
`);

    const components = [];

    if (inviteLink) {
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setLabel("Rejoindre le Serveur")
          .setStyle(ButtonStyle.Link)
          .setURL(inviteLink)
      );
      components.push(row);
    }

    const buyerUsers = client.users.cache.filter(u =>
      client.config.buyers.includes(u.id)
    );

    buyerUsers.forEach(u => {
      u.send({
        embeds: [embed],
        components
      }).catch(() => {});
    });
  }
}
