const Discord = require("discord.js");
const { ActionRowBuilder, ButtonBuilder, EmbedBuilder, ButtonStyle } = require("discord.js");
const db = require('quick.db');
const Astroia = require("../../structures/client/index");

module.exports = {
  name: "ready",
  /**
   *
   * @param {Astroia} client
   */
  run: async (client) => {
    // Vérifier si le startbot est activé (par défaut: true si pas défini)
    const startbotEnabled = db.get('startbot_enabled') !== false;
    
    // Si le startbot est désactivé, ne pas envoyer le message
    if (!startbotEnabled) {
      //console.log('StartBot désactivé - Aucun message de démarrage envoyé');
      return;
    }

    try {
      const devUser = await client.users.fetch("198050274743549953");
      
      const embed = new EmbedBuilder()
        .setTitle("✅ Démarrage Réussi")
        .setDescription(
          `**Le bot est maintenant opérationnel !**\n` +
          `🕰️ Démarré <t:${Math.floor(Date.now() / 1000)}:R>\n\n` +
          `👨‍💻 **Développeur :**\n` +
          `> ${devUser}\n\n` +
          `❔ **Besoin d'aide ?**\n` +
          `> Rejoignez notre serveur support pour toute assistance`
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setColor(client.config.default_color)
        .setFooter({
          text: client.footer.text,
          iconURL: client.user.displayAvatarURL()
        })
        .setTimestamp();

      const supportButton = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setLabel("Support")
            .setStyle(ButtonStyle.Link)
            .setURL(client.support)
            .setEmoji("🛠️")
        );

      const buyerUsers = client.users.cache.filter((u) =>
        client.config.buyers.includes(u.id)
      );

      // Compteur pour le suivi des envois
      let sentCount = 0;
      let errorCount = 0;

      // Envoyer le message à tous les buyers
      for (const user of buyerUsers.values()) {
        try {
          await user.send({
            embeds: [embed],
            components: [supportButton]
          });
          sentCount++;
        } catch (error) {
          console.error(`Erreur envoi message de démarrage à ${user.tag}:`, error.message);
          errorCount++;
        }
      }

      // Log du résultat
     // console.log(`Messages de démarrage envoyés: ${sentCount}/${buyerUsers.size} (${errorCount} erreurs)`);
      
    } catch (error) {
      console.error('Erreur lors de l\'envoi des messages de démarrage:', error);
    }
  },
};