const Discord = require('discord.js');

module.exports = {
    name: 'messageCreate',
    run: async (client, message) => {
        // Ignorer les messages hors serveur ou envoyés par le bot lui-même
        if (!message.guild || message.author.id === client.user.id) return;

        // Vérifier si le message mentionne le bot
        if (!message.mentions.has(client.user)) return;

        // Récupérer les configurations d'auto-rank pour ce serveur
        const autorankKey = `autorank_${message.guild.id}`;
        const autorankData = client.db.get(autorankKey) || [];
        if (!autorankData || autorankData.length === 0) return;

        // Filtrer les configurations pour le salon actuel
        const config = autorankData.find(data => data.channelId === message.channel.id);
        if (!config) return;

        // Récupérer le rôle configuré
        const role = message.guild.roles.cache.get(config.roleId);
        if (!role) return;

        // Vérifier si le bot peut gérer le rôle
        const botMember = message.guild.members.cache.get(client.user.id);
        if (!botMember.permissions.has(Discord.PermissionsBitField.Flags.ManageRoles)) return;
        if (role.position >= botMember.roles.highest.position) return;

        // Récupérer le membre
        const member = message.member;
        if (!member) return;

        // Vérifier si le membre a déjà le rôle
        if (member.roles.cache.has(role.id)) return;

        try {
            // Ajouter le rôle
            await member.roles.add(role);

            // Envoyer un modlog
            const embed = new Discord.EmbedBuilder()
                .setColor(client.color)
                .setDescription(`Auto-rank : ${member.user.tag} a reçu le rôle \`${role.name}\` pour avoir ping le bot dans <#${message.channel.id}>.`)
                .setTimestamp();

            const modlogChannel = message.guild.channels.cache.get(client.db.get(`modlogs_${message.guild.id}`));
            if (modlogChannel) {
                modlogChannel.send({ embeds: [embed] }).catch(error => console.error('Erreur lors de l\'envoi du modlog :', error));
            }

            // Envoyer un message de confirmation
            await message.channel.send(`${member.user}, vous avez reçu le rôle \`${role.name}\` !`);
        } catch (error) {
            console.error(`Erreur lors de l'ajout du rôle à ${member.user.tag}:`, error);
        }
    }
};