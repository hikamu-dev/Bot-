const Discord = require('discord.js');
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    name: 'messageDelete',
    /**
     * @param {import('../../structures/client')} client
     * @param {Discord.Message} message
     */
    run: async (client, message) => {
        if (!message || !message.guild) return;
        if (!message.embeds || message.embeds.length === 0) return;

        // Ne pas logger si c'est le bot qui supprime le message
        // Supprime ou commente cette condition :
        /*
        if (message.author && message.author.id === client.user.id) {
            console.log('Bot message deleted');
            return;
        }
        */

        // Récupérer le salon de logs des embeds
        const channelId = client.db.get(`embedslogs_${message.guild.id}`);
        if (!channelId) return;
        const logChannel = message.guild.channels.cache.get(channelId);

        const color = client.db.get(`color_${message.guild.id}`) || client.config.default_color;
        const author = message.author ? `${message.author.tag} (${message.author.id})` : 'Inconnu';

        // Pour chaque embed supprimé, on log
        for (const embed of message.embeds) {
            // 1. Envoie le message de contexte au-dessus de l'embed
            await logChannel.send(
                `🗑️ Embed supprimé de ${message.author ? `<@${message.author.id}>` : 'Inconnu'} dans <#${message.channel.id}>`
            );

            // 2. Prépare le bouton
            const customId = `resend_embed_${message.id}`;
            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId(customId)
                    .setLabel('Renvoyer l\'embed')
                    .setStyle(ButtonStyle.Primary)
            );
            if (!client.deletedEmbeds) client.deletedEmbeds = new Map();
            client.deletedEmbeds.set(customId, {
                embed,
                channelId: message.channel.id
            });

            // 3. Envoie l'embed supprimé tel quel avec le bouton
            await logChannel.send({ embeds: [embed], components: [row] });
        }
    }
};
