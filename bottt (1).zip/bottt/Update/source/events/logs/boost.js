const { EmbedBuilder } = require("discord.js");

module.exports = {
    name: 'guildMemberUpdate',

    run: async (client, oldMember, newMember) => {
        const color = client.db.get(`color_${newMember.guild.id}`) || client.config.default_color;
        const boostChannelId = client.db.get(`logsboost_${newMember.guild.id}`);
        if (!boostChannelId) return;

        const boostChannel = client.channels.cache.get(boostChannelId);
        if (!boostChannel) return;

        const avaitBoost = oldMember.premiumSince;
        const aBoost = newMember.premiumSince;

        if (!avaitBoost && aBoost) {
            const embed = new EmbedBuilder()
                .setColor(color)
                .setFooter(client.footer)
                .setTimestamp()
                .setDescription(`**${newMember.user.username}** (\`${newMember.user.id}\`) vient de **booster** le serveur !\nNous avons maintenant **${newMember.guild.premiumSubscriptionCount} boost(s)**.`);

            boostChannel.send({ embeds: [embed] }).catch(() => {});
        }

        if (avaitBoost && !aBoost) {
            const embed = new EmbedBuilder()
                .setColor(color)
                .setFooter(client.footer)
                .setTimestamp()
                .setDescription(`**${newMember.user.username}** (\`${newMember.user.id}\`) a **retiré son boost** du serveur.\nIl reste maintenant **${newMember.guild.premiumSubscriptionCount} boost(s)**.`);

            boostChannel.send({ embeds: [embed] }).catch(() => {});
        }
    }
}
