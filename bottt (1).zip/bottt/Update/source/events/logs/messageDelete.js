const { Astroia } = require('../../structures/client');
const Discord = require('discord.js');

module.exports = {
    name: 'messageDelete',
    /**
     * 
     * @param {Astroia} client 
     * @param {Astroia} message 
     * @returns 
     */
    run: async (client, message) => {
        if (!message || !message.author || !message.guild) return;
        
        // Ne pas logger si c'est le bot qui supprime le message
        if (message.author.id === client.user.id) return;
        
        // Vérifier si c'est le bot qui a effectué la suppression via les audit logs
        const auditLogs = await message.guild.fetchAuditLogs({
            type: Discord.AuditLogEvent.MessageDelete,
            limit: 1
        }).catch(() => null);
        
        const lastEntry = auditLogs?.entries.first();
        if (lastEntry?.executor?.id === client.user.id) return;

        const channel = client.db.get(`msglogs_${message.guild.id}`);
        if (!channel) return;
        const chan = message.guild.channels.cache.get(channel);
        if (!chan) return;
        const ignored = client.db.get(`msglogs_allow_${message.channel.id}`);
        if (ignored === true) return;

        const action = await message.guild.fetchAuditLogs({ limit: 1, type: 72 }).then(audit => audit.entries.first());
        const executor = action ? action.executor : message.author || await client.lang(`msglog.message10`);

        let msgContent = `**🗑 Message supprimé dans** <#${message.channel.id}>`;
        const color = client.db.get(`color_${message.guild.id}`) || client.config.default_color;

        const Embed = new Discord.EmbedBuilder()
            .setColor(color)
            .setAuthor({
                name: `${message.author.username} - Message Supprimé`,
                iconURL: message.author.displayAvatarURL({ dynamic: true })
            })
            .setDescription(msgContent)
            .addFields({
                name: '📜 Contenu',
                value: message.content 
                    ? `\`\`\`yml\n${message.content.substring(0, 1000)}\n\`\`\`` 
                    : '*Aucun contenu textuel*',
                inline: false
            })
            .setFooter(client.footer)
            .setTimestamp();

        if (message.embeds.length > 0) {
            const embed = message.embeds[0];
            const messages = await client.lang('msglog.message12');
            const replacedChannel = messages.replace(/{channel.name}/g, message.channel.name).replace(/{channel.id}/g, message.guild.id);
            await chan.send({ content: replacedChannel, embeds: [embed] });
        }

        await chan.send({ embeds: [Embed] });
    }
};