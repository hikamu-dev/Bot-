const Discord = require('discord.js');
const fs = require('fs');

module.exports = {
    name: 'messageUpdate',
    run: async (client, oldMessage, newMessage) => {
        if (!oldMessage || !newMessage) return;
        if (!oldMessage.guild || newMessage.author?.bot) return;
        if (newMessage.author?.id === client.user.id) return;

        const channel = client.db.get(`msglogs_${oldMessage.guild.id}`);
        if (!channel) return;

        const chan = oldMessage.guild.channels.cache.get(channel);
        if (!chan) return;

        const ignored = client.db.get(`msglogs_allow_${oldMessage.channel.id}`);
        if (ignored === true) return;

        const author = oldMessage.author || newMessage.author;
        if (!author) return; // Si toujours pas d'auteur
        const color = client.db.get(`color_${oldMessage.guild.id}`) || client.config.default_color;

        const Embed = new Discord.EmbedBuilder()
        .setColor(color)
        .setAuthor({
                name: `${await client.lang('msglog.message9')} ${author.username}`,
                iconURL: author.displayAvatarURL({ dynamic: true })
            })
            .setTitle('✏️ Message Modifié')
            .setDescription(`**${await client.lang('msglog.message13')}** [<#${oldMessage.channel.id}>]`)
            .addFields(
                {
                    name: '📜 Avant',
                    value: oldMessage.content
                        ? `\`\`\`yml\n${oldMessage.content.substring(0, 1000)}\n\`\`\``
                        : '*Message vide*',
                    inline: false
                },
                {
                    name: '📝 Après',
                    value: newMessage.content
                        ? `\`\`\`yml\n${newMessage.content.substring(0, 1000)}\n\`\`\``
                        : '*Message vide*',
                    inline: false
                }
            )
            .setFooter(client.footer)
            .setTimestamp();

        chan.send({ embeds: [Embed] });
    }
};
