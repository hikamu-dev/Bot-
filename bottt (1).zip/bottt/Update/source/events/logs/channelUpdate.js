const Discord = require('discord.js');

module.exports = {
    name: 'channelUpdate',
    run: async (client, oldChannel, newChannel) => {
        const color = client.db.get(`color_${newChannel.guild.id}`) || client.config.default_color;
        const guild = newChannel.guild;
        if (!guild) return;

        const logChannelId = client.db.get(`logschannel_${guild.id}`);
        if (!logChannelId) return;

        const logChannel = guild.channels.cache.get(logChannelId);
        if (!logChannel) return;

        const channelName = newChannel.name;
        const channelId = newChannel.id;
        const channelType = newChannel.type === Discord.ChannelType.GuildText ? 'Texte' : newChannel.type === Discord.ChannelType.GuildVoice ? 'Vocal' : 'Catégorie';

        let updater = '`Inconnu`';
        let maxRetries = 5;
        let retryDelay = 3000;

        const fetchAuditLog = async () => {
            try {
                const auditLogs = await guild.fetchAuditLogs({ type: Discord.AuditLogEvent.ChannelUpdate, limit: 5 });
                const entries = auditLogs.entries.filter(e => e.target.id === newChannel.id);
                const entry = entries.find(e => (Date.now() - e.createdTimestamp) < 30000);
                
                if (entry) {
                    if (entry.executor.id !== client.user.id) {
                        updater = `<@${entry.executor.id}>`;
                    } else {
                        updater = '`Le bot`';
                    }
                } else {
                    updater = '`Inconnu` (aucun log correspondant trouvé dans les 30 dernières secondes)'
                }
            } catch (error) {
                console.error('Erreur lors de la récupération des logs d’audit :', error);
                updater = '`Inconnu` (erreur lors de la récupération des logs)'
            }
        };

        await new Promise(res => setTimeout(res, 2000));
        for (let i = 0; i < maxRetries; i++) {
            await fetchAuditLog();
            if (!updater.startsWith('`Inconnu')) break;
            await new Promise(res => setTimeout(res, retryDelay));
        }

        const changes = [];

        if (oldChannel.name !== newChannel.name) {
            changes.push(`**Nom**: \`${oldChannel.name}\` → \`${newChannel.name}\``);
        }

        if (oldChannel.topic !== newChannel.topic && newChannel.type === Discord.ChannelType.GuildText) {
            changes.push(`**Sujet**: \`${oldChannel.topic || 'Aucun'}\` → \`${newChannel.topic || 'Aucun'}\``);
        }

        if (oldChannel.parentId !== newChannel.parentId) {
            const oldParent = oldChannel.parent ? oldChannel.parent.name : 'Aucune';
            const newParent = newChannel.parent ? newChannel.parent.name : 'Aucune';
            changes.push(`**Catégorie**: \`${oldParent}\` → \`${newParent}\``);
        }

        if (oldChannel.rateLimitPerUser !== newChannel.rateLimitPerUser && newChannel.type === Discord.ChannelType.GuildText) {
            changes.push(`**Mode lent**: \`${oldChannel.rateLimitPerUser || 0} secondes\` → \`${newChannel.rateLimitPerUser || 0} secondes\``);
        }

        if (oldChannel.bitrate !== newChannel.bitrate && newChannel.type === Discord.ChannelType.GuildVoice) {
            changes.push(`**Débit binaire**: \`${oldChannel.bitrate / 1000} kbps\` → \`${newChannel.bitrate / 1000} kbps\``);
        }

        if (oldChannel.userLimit !== newChannel.userLimit && newChannel.type === Discord.ChannelType.GuildVoice) {
            changes.push(`**Limite d'utilisateurs**: \`${oldChannel.userLimit || 'Aucune'}\` → \`${newChannel.userLimit || 'Aucune'}\``);
        }

        if (oldChannel.nsfw !== newChannel.nsfw && newChannel.type === Discord.ChannelType.GuildText) {
            changes.push(`**NSFW**: \`${oldChannel.nsfw ? 'Activé' : 'Désactivé'}\` → \`${newChannel.nsfw ? 'Activé' : 'Désactivé'}\``);
        }

        const oldPerms = oldChannel.permissionOverwrites.cache;
        const newPerms = newChannel.permissionOverwrites.cache;

        const permChanges = [];
        let permsReallyChanged = false;
        newPerms.forEach((newPerm, id) => {
            const oldPerm = oldPerms.get(id);
            if (!oldPerm) {
                permsReallyChanged = true;
                permChanges.push(`**Ajout de permissions** pour <@${id}> (ou rôle <@&${id}>): \`${newPerm.allow.toArray().join(', ') || 'Aucune'}\` (Autorisé), \`${newPerm.deny.toArray().join(', ') || 'Aucune'}\` (Refusé)`);
            } else {
                const changedAllow = newPerm.allow.toArray().filter(perm => !oldPerm.allow.has(perm));
                const changedDeny = newPerm.deny.toArray().filter(perm => !oldPerm.deny.has(perm));
                const removedAllow = oldPerm.allow.toArray().filter(perm => !newPerm.allow.has(perm));
                const removedDeny = oldPerm.deny.toArray().filter(perm => !newPerm.deny.has(perm));

                if (changedAllow.length > 0) {
                    permsReallyChanged = true;
                    permChanges.push(`**Permissions autorisées modifiées** pour <@${id}> (ou rôle <@&${id}>): \`${changedAllow.join(', ')}\` ajoutées`);
                }
                if (changedDeny.length > 0) {
                    permsReallyChanged = true;
                    permChanges.push(`**Permissions refusées modifiées** pour <@${id}> (ou rôle <@&${id}>): \`${changedDeny.join(', ')}\` ajoutées`);
                }
                if (removedAllow.length > 0) {
                    permsReallyChanged = true;
                    permChanges.push(`**Permissions autorisées supprimées** pour <@${id}> (ou rôle <@&${id}>): \`${removedAllow.join(', ')}\``);
                }
                if (removedDeny.length > 0) {
                    permsReallyChanged = true;
                    permChanges.push(`**Permissions refusées supprimées** pour <@${id}> (ou rôle <@&${id}>): \`${removedDeny.join(', ')}\``);
                }
            }
        });

        oldPerms.forEach((oldPerm, id) => {
            if (!newPerms.has(id)) {
                permsReallyChanged = true;
                permChanges.push(`**Suppression de permissions** pour <@${id}> (ou rôle <@&${id}>)`);
            }
        });

        if (permChanges.length > 0 && permsReallyChanged) {
            changes.push(`**Permissions**:\n${permChanges.join('\n')}`);
        }

        if (changes.length === 0) return;

        const description = `Le salon **${channelType}** **${channelName}** (\`${channelId}\`) a été mis à jour par ${updater}.\n\n**Changements**:\n${changes.join('\n')}`;

        const Embed = new Discord.EmbedBuilder()
            .setColor(color)
            .setTitle('Salon Mis à Jour')
            .setDescription(description)
            .setFooter(client.footer)
            .setTimestamp();

        logChannel.send({ embeds: [Embed] });
    },
};
