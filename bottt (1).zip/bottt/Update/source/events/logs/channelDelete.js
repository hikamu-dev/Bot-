const Discord = require('discord.js');

module.exports = {
    name: 'channelDelete',
    /**
     * @param {Astroia} client
     * @param {Discord.GuildChannel} channel
     */
    run: async (client, channel) => {
        const color = client.db.get(`color_${channel.guild.id}`) || client.config.default_color;
        const guild = channel.guild;
        if (!guild) return;

        const logChannelId = client.db.get(`logschannel_${guild.id}`);
        if (!logChannelId) return;

        const logChannel = guild.channels.cache.get(logChannelId);
        if (!logChannel) return;

        const channelName = channel.name;
        const channelId = channel.id;
        const channelType = channel.type === Discord.ChannelType.GuildText ? 'Text' : channel.type === Discord.ChannelType.GuildVoice ? 'Voice' : 'Category';

        let deleter = '`Unknown`';
        try {
            const auditLogs = await guild.fetchAuditLogs({ type: Discord.AuditLogEvent.ChannelDelete, limit: 1 });
            const entry = auditLogs.entries.first();
            if (entry && entry.target.id === channel.id) {
                // Vérifie si l'exécuteur n'est pas le bot
                if (entry.executor.id !== client.user.id) {
                    deleter = `<@${entry.executor.id}>`; // CORRECTION ICI : deleter au lieu de creator
                } else {
                    return; // Sort si c'est le bot qui a supprimé le salon
                }
            }
        } catch (error) {
            console.error('Failed to fetch audit logs for channelDelete:', error);
        }

        const description = `Le salon **${channelType}** **${channelName}** (\`${channelId}\`) a été supprimé par ${deleter}.`;

        const Embed = new Discord.EmbedBuilder()
            .setColor(color)
            .setTitle('Salon Supprimé')
            .setDescription(description)
            .setFooter(client.footer)
            .setTimestamp();

        logChannel.send({ embeds: [Embed] });
    },
};