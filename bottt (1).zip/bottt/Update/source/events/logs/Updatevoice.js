const Discord = require('discord.js');

module.exports = {
    name: 'voiceStateUpdate',
    /**
     * @param {Astroia} client 
     * @returns 
     */
    run: async (client, oldMember, newMember) => {
        const color = client.db.get(`color_${newMember.guild.id}`) || client.config.default_color;
        const guild = newMember.guild;
        if (!guild) return;
        if (newMember.id === client.user.id) return;
        if (newMember.serverMute === true) return;
        if (newMember.serverDeaf === true) return;

        const channel = client.db.get(`voicelogs_${guild.id}`);
        if (!channel) return;

        const chan = newMember.guild.channels.cache.get(channel);
        if (!chan) return;
        const user = await client.users.fetch(newMember.id);

        let title = '';
        let description = '';

        // User joins a voice channel
        if (!oldMember.channelId && newMember.channelId) {
            const newChannel = await client.channels.fetch(newMember.channelId);
            title = '🎙️ Connexion au Salon Vocal';
            description = `<@${user.id}> s'est connecté à <#${newChannel.id}>`;

            const Embed = new Discord.EmbedBuilder()
                .setColor(color)
                .setAuthor({ name: user.username, iconURL: user.avatarURL({ dynamic: true }) })
                .setTitle(title)
                .setDescription(description)
                .setFooter(client.footer)
                .setTimestamp();

            return chan.send({ embeds: [Embed] });
        }

        // User leaves a voice channel
        if (oldMember.channelId && !newMember.channelId) {
            const oldChannel = await client.channels.fetch(oldMember.channelId);
            title = '🎙️ Déconnexion du Salon Vocal';
            description = `<@${user.id}> s'est déconnecté de <#${oldChannel.id}>`;

            const Embed = new Discord.EmbedBuilder()
                .setColor(color)
                .setAuthor({ name: user.username, iconURL: user.avatarURL({ dynamic: true }) })
                .setTitle(title)
                .setDescription(description)
                .setFooter(client.footer)
                .setTimestamp();

            return chan.send({ embeds: [Embed] });
        }

        // Other voice state changes (mute, deaf, streaming, channel switch)
        const oldChannel = oldMember.channelId ? await client.channels.fetch(oldMember.channelId) : null;
        const newChannel = newMember.channelId ? await client.channels.fetch(newMember.channelId) : null;

        if (oldMember.mute !== newMember.mute) {
            title = '🎤 Changement de Statut Micro';
            description = `<@${user.id}> a ${newMember.mute ? 'désactivé' : 'activé'} son micro dans <#${oldChannel.id}>`;
        }
        else if (oldMember.selfDeaf !== newMember.selfDeaf || oldMember.serverDeaf !== newMember.serverDeaf) {
            title = '🎧 Changement de Statut Casque';
            description = `<@${user.id}> a ${newMember.selfDeaf ? 'désactivé' : 'activé'} son casque dans <#${oldChannel.id}>`;
        }
        else if (oldMember.streaming !== newMember.streaming) {
            title = '📹 Changement de Statut Stream';
            description = `<@${user.id}> a ${newMember.streaming ? 'commencé' : 'arrêté'} de streamer dans <#${oldChannel.id}>`;
        }
        else if (oldMember.channelId !== newMember.channelId && oldChannel && newChannel) {
            title = '🔄 Déplacement entre Salons Vocaux';
            description = `<@${user.id}> a bougé de <#${oldChannel.id}> vers <#${newChannel.id}>`;
        }

        if (!title) return; // No changes detected

        const Embed = new Discord.EmbedBuilder()
            .setColor(color)
            .setAuthor({ name: user.username, iconURL: user.avatarURL({ dynamic: true }) })
            .setTitle(title)
            .setDescription(description)
            .setFooter(client.footer)
           .setTimestamp();

        chan.send({ embeds: [Embed] });
    },
};