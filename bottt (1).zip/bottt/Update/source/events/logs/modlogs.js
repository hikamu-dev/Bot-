// Lyna - modlogs.js
const { AuditLogEvent, EmbedBuilder, Events } = require('discord.js');

module.exports = {
  name: 'ready',
  once: true,

  /**
   * Montre les listeners de modération une seule fois quand le bot est prêt.
   * Compatibles avec un loader qui appelle event.run(client, ...args).
   */
  run: async (client) => {
    // Empêche le montage multiple en cas de reload à chaud
    if (client.__modlogsMounted) return;
    client.__modlogsMounted = true;

    const getColor = (guildId) =>
      client.db.get(`color_${guildId}`) || (client.config && client.config.default_color) || 0x2b2d31;

    const getLogChannel = (guild) => {
      if (!guild) return null;
      const id = client.db.get(`modlogs_${guild.id}`);
      return id ? guild.channels.cache.get(id) : null;
    };

    // BAN
    client.on('guildBanAdd', async (ban) => {
      const { user, guild } = ban;
      if (!guild || !user) return;

      try {
        const logs = await guild.fetchAuditLogs({ type: AuditLogEvent.MemberBanAdd, limit: 1 });
        const entry = logs.entries.first();
        if (!entry || (entry.target && entry.target.id) !== user.id) return;

        const logChannel = getLogChannel(guild);
        if (!logChannel) return;

        const executor = entry.executor;
        const embed = new EmbedBuilder()
          .setColor(getColor(guild.id))
          .setTitle('🚨 Modération - Bannissement')
          .addFields(
            { name: '👤 Membre banni', value: `${user.tag} (${user.id})`, inline: true },
            { name: '👮 Modérateur', value: `${executor.tag} (${executor.id})`, inline: true },
            { name: '📝 Raison', value: `${entry.reason || 'Aucune raison spécifiée'}` }
          )
          .setTimestamp()
          .setFooter({ text: 'Lyna - Modlogs', iconURL: client.user.displayAvatarURL() });

        await logChannel.send({ embeds: [embed] });
      } catch (e) {
        console.error('[modlogs] guildBanAdd error', e);
      }
    });

    // UNBAN
    client.on('guildBanRemove', async (ban) => {
      const { user, guild } = ban;
      if (!guild || !user) return;

      try {
        const logs = await guild.fetchAuditLogs({ type: AuditLogEvent.MemberBanRemove, limit: 1 });
        const entry = logs.entries.first();
        if (!entry || (entry.target && entry.target.id) !== user.id) return;

        const logChannel = getLogChannel(guild);
        if (!logChannel) return;

        const executor = entry.executor;
        const embed = new EmbedBuilder()
          .setColor(getColor(guild.id))
          .setTitle('✅ Modération - Révocation de bannissement')
          .addFields(
            { name: '👤 Membre débanni', value: `${user.tag} (${user.id})`, inline: true },
            { name: '👮 Modérateur', value: `${executor.tag} (${executor.id})`, inline: true }
          )
          .setTimestamp()
          .setFooter({ text: 'Lyna - Modlogs', iconURL: client.user.displayAvatarURL() });

        await logChannel.send({ embeds: [embed] });
      } catch (e) {
        console.error('[modlogs] guildBanRemove error', e);
      }
    });

    // KICK (via audit logs)
    client.on('guildMemberRemove', async (member) => {
      try {
        const logs = await member.guild.fetchAuditLogs({ type: AuditLogEvent.MemberKick, limit: 3 }).catch(() => null);
        if (!logs) return;

        // On prend une entrée récente qui cible bien le membre
        const now = Date.now();
        const entry = logs.entries.find(
          (e) => e.target && e.target.id === member.id && now - e.createdTimestamp < 5000
        );
        if (!entry) return;

        const logChannel = getLogChannel(member.guild);
        if (!logChannel) return;

        const executor = entry.executor;
        const embed = new EmbedBuilder()
          .setColor(getColor(member.guild.id))
          .setTitle('🔨 Modération - Kick')
          .addFields(
            { name: '👤 Membre kické', value: `${member.user.tag} (${member.user.id})`, inline: true },
            { name: '👮 Modérateur', value: `${executor.tag} (${executor.id})`, inline: true },
            { name: '📝 Raison', value: `${entry.reason || 'Aucune raison spécifiée'}` }
          )
          .setTimestamp()
          .setFooter({ text: 'Lyna - Modlogs', iconURL: client.user.displayAvatarURL() });

        await logChannel.send({ embeds: [embed] });
      } catch (e) {
        console.error('[modlogs] guildMemberRemove error', e);
      }
    });

    // TIMEOUT / FIN DE TIMEOUT
    client.on(Events.GuildMemberUpdate, async (oldMember, newMember) => {
      const oldTimeout = oldMember.communicationDisabledUntil;
      const newTimeout = newMember.communicationDisabledUntil;
      if (oldTimeout === newTimeout) return;

      const guild = newMember.guild;
      try {
        const logs = await guild.fetchAuditLogs({ type: AuditLogEvent.MemberUpdate, limit: 5 }).catch(() => null);
        if (!logs) return;

        const now = Date.now();
        const entry = logs.entries.find(
          (e) => e.target && e.target.id === newMember.id && now - e.createdTimestamp < 5000
        );
        if (!entry) return;

        const logChannel = getLogChannel(guild);
        if (!logChannel) return;

        const executor = entry.executor;
        const isTimeout = !!newTimeout;

        const embed = new EmbedBuilder()
          .setColor(getColor(guild.id))
          .setTitle(isTimeout ? '🔇 Modération - Timeout' : '🔊 Modération - Fin de Timeout')
          .addFields(
            { name: '👤 Membre concerné', value: `${newMember.user.tag} (${newMember.id})`, inline: true },
            { name: '👮 Modérateur', value: `${executor.tag} (${executor.id})`, inline: true },
            {
              name: isTimeout ? '⏱️ Durée' : '📅 Fin',
              value: isTimeout ? `<t:${Math.floor(newTimeout.getTime() / 1000)}:R>` : 'Timeout retiré'
            }
          )
          .setTimestamp()
          .setFooter({ text: 'Lyna - Modlogs', iconURL: client.user.displayAvatarURL() });

        await logChannel.send({ embeds: [embed] });
      } catch (e) {
        console.error('[modlogs] GuildMemberUpdate error', e);
      }
    });
  },
};
