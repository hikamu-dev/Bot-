const Discord = require('discord.js');

module.exports = {
    name: 'guildMemberUpdate',
    /**
     * @param {Astroia} client 
     * @param {Astroia} oldMember 
     * @param {Astroia} newMember 
     * @returns 
     */
    run: async (client, oldMember, newMember) => {
        const color = client.db.get(`color_${newMember.guild.id}`) || client.config.default_color;
        const guild = newMember.guild;
        if (!guild) return;
        if (newMember.id === client.user.id) return;

        const channel = client.db.get(`rolelog_${guild.id}`);
        if (!channel) return;

        let userStat = '';
        const chan = guild.channels.cache.get(channel);
        if (!chan) return;
        const user = await client.users.fetch(newMember.id);

        // Vérifie les changements de rôle
        const oldRoles = oldMember.roles.cache.map(role => role.id);
        const newRoles = newMember.roles.cache.map(role => role.id);

        const addedRoles = newRoles.filter(role => !oldRoles.includes(role));
        const removedRoles = oldRoles.filter(role => !newRoles.includes(role));

        if (addedRoles.length > 0) {
            const addedRolesList = addedRoles.map(roleId => `<@&${roleId}>`).join(', ');
            userStat = `<@${user.id}> (\`${user.id}\`) a reçu les rôles suivants : ${addedRolesList}.`;
        }

        if (removedRoles.length > 0) {
            const removedRolesList = removedRoles.map(roleId => `<@&${roleId}>`).join(', ');
            userStat = `<@${user.id}> (\`${user.id}\`) a perdu les rôles suivants : ${removedRolesList}.`;
        }

        if (addedRoles.length === 0 && removedRoles.length === 0) return;

        const Embed = new Discord.EmbedBuilder()
            .setColor(color)
            .setAuthor({ name: user.username, iconURL: user.avatarURL() })
            .setDescription(userStat)
            .setFooter(client.footer)
            .setTimestamp();

        chan.send({ embeds: [Embed] });
    },
};