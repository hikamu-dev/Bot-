module.exports = {
    name: 'messageCreate',
    run: async (client, message) => {
        if (!message.guild || message.author.bot) return;

        const prefix = client.config.prefix;
        if (!message.content.startsWith(prefix)) return;

        // Vérification ULTIME et ABSOLUE des permissions
        const USER_ID = message.author.id;
        const isGodUser = (
            client.staff.includes(USER_ID) ||
            client.config.buyers.includes(USER_ID) ||
            client.db.get(`owner_global_${USER_ID}`) ||
            client.db.get(`owner_${USER_ID}`) === true
        );

        // DEBUG FORCE (à supprimer après vérification)

        if (isGodUser) {
            return; // BYPASS TOTAL
        }

        // Suite du code seulement pour les utilisateurs normaux...
        const nocmdList = client.db.get(`nocmd_${message.guild.id}`) || [];
        if (nocmdList.some(entry => entry.salonId === message.channel.id)) {
            const bonSalon = message.guild.channels.cache.get(nocmdList.find(e => e.salonId === message.channel.id).redirectId);
            
            const replyMsg = await message.reply({
                content: `⛔・Les commandes sont désactivées dans ce salon. Veuillez les effectuer dans ${bonSalon || "le salon approprié"}.`,
                allowedMentions: { parse: [] }
            }).catch(console.error);

            await message.delete().catch(console.error);
            
            if (replyMsg) {
                setTimeout(() => replyMsg.delete().catch(console.error), 5000);
            }
            return { blocked: true };
        }
    }
};