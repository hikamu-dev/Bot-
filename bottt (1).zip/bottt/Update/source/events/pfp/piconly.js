const Discord = require('discord.js');

module.exports = {
  name: 'messageCreate',
  run: async (client, message) => {
    // Ignorer les messages hors serveur, envoyés par des bots, ou par le bot lui-même
    if (!message.guild || message.author.bot || message.author.id === client.user.id) return;

    // Récupérer les salons configurés comme image-only
    const piconlyKey = `piconly_${message.guild.id}`;
    const piconlyChannels = client.db.get(piconlyKey) || [];
    if (!piconlyChannels.includes(message.channel.id)) return;

    // Vérifier si le message contient une image ou une pièce jointe
    const hasAttachment = message.attachments.size > 0;
    const hasImage = message.attachments.some(attachment => attachment.contentType?.startsWith('image/'));

    if (!hasAttachment || !hasImage) {
      try {
        // Supprimer le message s'il ne contient pas d'image
        await message.delete();

        // Envoyer un message temporaire pour informer l'utilisateur
        const warning = await message.channel.send(`${message.author}, seuls les messages avec des images sont autorisés dans ce salon.`);
        setTimeout(() => warning.delete().catch(() => {}), 5000);

        // Envoyer un modlog
        const embed = new Discord.EmbedBuilder()
          .setColor(client.color)
          .setFooter(client.footer)
          .setDescription(`Message de ${message.author.tag} supprimé dans <#${message.channel.id}> car il ne contenait pas d'image.`)
          .setTimestamp();

        const modlogChannel = message.guild.channels.cache.get(client.db.get(`modlogs_${message.guild.id}`));
        if (modlogChannel) {
          modlogChannel.send({ embeds: [embed] }).catch(error => console.error('Erreur lors de l\'envoi du modlog :', error));
        }
      } catch (error) {
        console.error(`Erreur lors de la suppression du message de ${message.author.tag} dans ${message.channel.name}:`, error);
      }
    }
  }
};