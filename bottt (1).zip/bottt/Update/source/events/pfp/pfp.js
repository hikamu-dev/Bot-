const Discord = require('discord.js');

module.exports = {
  name: 'ready',
  once: true,
  run: async (client) => {
    // Fonction pour sélectionner un utilisateur aléatoire non-bot
    const getRandomMember = async (guild) => {
      const members = await guild.members.fetch();
      const nonBotMembers = members.filter(member => !member.user.bot);
      if (nonBotMembers.size === 0) return null;
      return nonBotMembers.random();
    };

    // Boucle toutes les 10 secondes
    setInterval(async () => {
      // Parcourir tous les serveurs où le bot est présent
      for (const guild of client.guilds.cache.values()) {
        // Vérifier si la fonctionnalité pfp est activée et si un salon est configuré
        const pfpKey = `pfp_${guild.id}`;
        const pfpConfig = client.db.get(pfpKey) || { enabled: false, channelId: null };
        if (!pfpConfig.enabled || !pfpConfig.channelId) continue;

        // Vérifier le salon configuré
        const channel = guild.channels.cache.get(pfpConfig.channelId);
        if (!channel || channel.type !== Discord.ChannelType.GuildText) continue;

        // Vérifier les permissions du bot
        if (!channel.permissionsFor(guild.members.me).has(Discord.PermissionsBitField.Flags.SendMessages)) continue;

        // Sélectionner un membre aléatoire
        const member = await getRandomMember(guild);
        if (!member) continue;

        // Créer l'embed pour la photo de profil
        const avatarURL = member.user.displayAvatarURL({ format: 'png', dynamic: true, size: 4096 });
        const color = client.db.get(`color_${guild.id}`) || client.config.default_color;
        const embed = new Discord.EmbedBuilder()
        .setColor(color)
        .setFooter(client.footer)
          .setDescription(`<@${member.user.id}> | \`${member.user.id}\``)
          .setImage(avatarURL);

        try {
          await channel.send({ embeds: [embed] });
        } catch (error) {
          console.error(`Erreur lors de l'envoi de la photo de profil de ${member.user.tag} dans ${channel.name}:`, error);
        }
      }
    }, 10000); // 10 secondes
  }
};