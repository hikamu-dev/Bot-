// events/guildMemberUpdate.js
const axios = require("axios");
const Astroia = require("../../structures/client/index");

// cache anti-spam par (guildId:userId)
const lastPostAt = new Map();
const keyOf = (g, u) => `${g}:${u}`;

module.exports = {
  name: "guildMemberUpdate",
  /**
   * @param {Astroia} client
   * @param {import('discord.js').GuildMember} oldMember
   * @param {import('discord.js').GuildMember} newMember
   */
  run: async (client, oldMember, newMember) => {
    try {
      if (newMember.user?.bot) return;

      // Assure des valeurs fraîches (évite le cache)
      try { await newMember.fetch(); } catch {}

      const oldDisplay = oldMember.displayName;
      const newDisplay = newMember.displayName;

      if (oldDisplay === newDisplay) return; // rien de visible n'a changé

      // Anti-burst: évite double POST si Discord émet 2 events très rapprochés
      const k = keyOf(newMember.guild.id, newMember.id);
      const now = Date.now();
      const last = lastPostAt.get(k) || 0;
      if (now - last < 500) return; // 500ms de garde
      lastPostAt.set(k, now);

      // On stocke l'ANCIEN (logique de ton API)
      await axios.post(`http://${client.config.panel}/oldnames`, {
        user_id: newMember.id,
        old_name: oldDisplay,
        new_name: newDisplay    // nouveau pseudo serveu
      });
    } catch (e) {
      console.error("guildMemberUpdate oldnames:", e?.response?.data ?? e.message ?? e);
    }
  },
};
