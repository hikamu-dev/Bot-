// events/userUpdate.js
module.exports = {
  name: "userUpdate",
  run: async () => {
    // On ignore les changements de username/display global pour ne garder QUE les nicknames serveur.
    return;
  },
};
