module.exports = {
    name: 'messageUpdate',
    run: async (client, oldMessage, newMessage) => {
        // Ignorer les messages de bots et les messages en DM
        if (!newMessage.guild || newMessage.author.bot) return;
        
        // Ignorer si le contenu n'a pas changé (embeds, réactions, etc.)
        if (oldMessage.content === newMessage.content) return;
        
        // Ignorer les messages vides
        if (!oldMessage.content && !newMessage.content) return;

        // Initialiser editMap si elle n'existe pas
        if (!client.editMap) {
            client.editMap = new Map();
        }

        const channelID = newMessage.channel.id;
        let editArray = client.editMap.get(channelID) || [];

        // Créer l'objet de données d'édition
        const editData = {
            author: {
                id: newMessage.author.id,
                username: newMessage.author.username,
                avatarURL: () => newMessage.author.displayAvatarURL({ dynamic: true })
            },
            oldContent: oldMessage.content || '[Contenu vide]',
            newContent: newMessage.content || '[Contenu vide]',
            date: Date.now(),
            messageId: newMessage.id,
            channelId: channelID,
            guildId: newMessage.guild.id
        };

        // Ajouter au début du tableau (plus récent en premier)
        editArray.unshift(editData);

        // Limiter à 50 messages modifiés par salon
        if (editArray.length > 50) {
            editArray = editArray.slice(0, 50);
        }

        // Sauvegarder dans la Map
        client.editMap.set(channelID, editArray);
    }
};