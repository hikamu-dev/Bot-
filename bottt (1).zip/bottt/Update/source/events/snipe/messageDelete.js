const { Astroia } = require("../../structures/client/index");
const Discord = require('discord.js');

module.exports = {
    name: 'messageDelete',
    run: async (client, message) => {
        try {
            if (!message.partial) {
                // Ignorer les messages du bot
                if (message.author.id === client.user.id) return;

                const attachmentUrls = [];

                if (message.attachments) {
                    attachmentUrls.push(...message.attachments.map(attachment => attachment.url));
                }

                const snipeData = {
                    author: message.author || null,
                    date: new Date(),
                    content: message.content || null,
                    attachments: attachmentUrls,
                    embeds: message.embeds || []
                };

                // Récupérer le tableau existant ou initialiser un nouveau tableau
                let snipeArray = client.snipeMap.get(message.channel.id) || [];
                // Ajouter le nouveau message supprimé en tête du tableau
                snipeArray.unshift(snipeData);
                // Limiter à 10 messages (ajustable selon vos besoins)
                if (snipeArray.length > 10) snipeArray.pop();

                // Mettre à jour le map avec le nouveau tableau
                client.snipeMap.set(message.channel.id, snipeArray);
            }
        } catch (error) {
            console.error('Une erreur est survenue :', error);
        }
    }
};