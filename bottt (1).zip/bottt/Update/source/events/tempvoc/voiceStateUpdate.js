const { VoiceChannel, CategoryChannel, ChannelType, PermissionsBitField } = require('discord.js');

module.exports = {
    name: "voiceStateUpdate",
    run: async (client, oldState, newState) => {
        // Assurez-vous que les IDs sont définis
        const guildID = newState.guild.id;
        const targetChannelId = client.db.get(`tempvoc_${guildID}_targetChannelId`);
        const categoryId = client.db.get(`tempvoc_${guildID}_categoryId`);

        if (!targetChannelId || !categoryId) return;

        const targetChannel = newState.guild.channels.cache.get(targetChannelId);
        const category = newState.guild.channels.cache.get(categoryId);

        if (!(targetChannel && targetChannel instanceof VoiceChannel)) return;
        if (!(category && category instanceof CategoryChannel)) return;

        // Vérifie si l'utilisateur a rejoint le salon cible
        if (newState.channelId === targetChannel.id && !oldState.channel) {
            const member = newState.member;

            try {
                // Crée un salon vocal temporaire pour le membre
                const privateChannel = await newState.guild.channels.create({
                    name: `🔊・${member.user.username}`,
                    type: ChannelType.GuildVoice,
                    parent: category.id,
                    permissionOverwrites: [
                        {
                            id: newState.guild.id,
                            deny: [PermissionsBitField.Flags.ViewChannel],
                        },
                        {
                            id: member.id,
                            allow: [
                                PermissionsBitField.Flags.ViewChannel,
                                PermissionsBitField.Flags.Connect,
                                PermissionsBitField.Flags.Speak
                            ],
                        },
                    ],
                });

                // Déplace le membre dans le salon vocal privé
                await member.voice.setChannel(privateChannel);

                // Mémorise l'ID du propriétaire
                const ownerId = member.id;

                // Détecte si le proprio quitte le salon
                const handleMemberLeave = (oldState, newState) => {
                    if (
                        oldState.channel &&
                        oldState.channel.id === privateChannel.id &&
                        oldState.member.id === ownerId &&
                        oldState.channelId !== newState.channelId
                    ) {
                        privateChannel.delete().catch(err => console.error(err));
                        client.off('voiceStateUpdate', handleMemberLeave);
                    }
                };

                client.on('voiceStateUpdate', handleMemberLeave);

            } catch (err) {
                console.error(err);
            }
        }
    }
};
