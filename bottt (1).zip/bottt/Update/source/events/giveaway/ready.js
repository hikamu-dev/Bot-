const { ButtonStyle, ActionRowBuilder, ButtonBuilder, EmbedBuilder } = require('discord.js');
const ms = require('ms');

module.exports = {
    name: 'ready',
    run: async (client) => {
        setInterval(async () => {
            try {
                const giveawayKeys = await client.db.all();
                const now = Date.now();

                for (const giveawayKey of giveawayKeys) {
                    if (giveawayKey.ID && giveawayKey.ID.startsWith('giveaway_')) {
                        const idParts = giveawayKey.ID.split('_');
                        if (idParts.length !== 3) continue;
                        
                        const [, guildId, code] = idParts;
                        const giveawayData = giveawayKey.data;
                        
                        // Vérifications de sécurité
                        if (!giveawayData || giveawayData.ended || !giveawayData.temps || giveawayData.temps > now) {
                            continue;
                        }

                        const guild = client.guilds.cache.get(guildId);
                        if (!guild) {
                            console.error(`Guild ${guildId} not found for giveaway ${code}.`);
                            continue;
                        }

                        const giveawayChannel = guild.channels.cache.get(giveawayData.channel);
                        if (!giveawayChannel) {
                            console.error(`Channel ${giveawayData.channel} not found for giveaway ${code}.`);
                            continue;
                        }

                        const participants = giveawayData.participant || [];
                        let message = null;

                        try {
                            message = await giveawayChannel.messages.fetch(giveawayData.messageid);
                        } catch (err) {
                            if (err.code === 10008) {
                                console.error(`Message ${giveawayData.messageid} not found. Cleaning up giveaway ${code}.`);
                                await client.db.set(`giveaway_${guildId}_${code}`, { ...giveawayData, ended: true });
                                continue;
                            }
                            console.error(`Error fetching message ${giveawayData.messageid}: ${err.message}`);
                            continue;
                        }

                        if (!message) continue;

                        const color = client.db.get(`color_${guildId}`) || client.config?.default_color || '#00AAFF';
                        const buttonStyle = ButtonStyle[giveawayData.buttonColor] || ButtonStyle.Primary;

                        if (participants.length === 0) {
                            const embed = new EmbedBuilder()
                                .setTitle('🎉 Giveaway Terminé')
                                .setDescription('Aucun participant. Le giveaway a été annulé.')
                                .setColor(color)
                                .setFooter(client.footer || { text: 'Giveaway System' })
                                .setTimestamp();

                            const row = new ActionRowBuilder().addComponents(
                                new ButtonBuilder()
                                    .setCustomId(`giveaway_entry_${code}`)
                                    .setEmoji(giveawayData.emoji || '🎉')
                                    .setStyle(buttonStyle)
                                    .setDisabled(true),
                                new ButtonBuilder()
                                    .setCustomId(`giveaway_list_${code}`)
                                    .setLabel('Voir les participants')
                                    .setStyle(ButtonStyle.Secondary)
                                    .setDisabled(true)
                            );

                            await safeEdit(message, { embeds: [embed], components: [row], content: null });
                            await client.db.set(`giveaway_${guildId}_${code}`, { ...giveawayData, ended: true });
                            
                            try {
                                await giveawayChannel.send(`❌ Aucun participant pour le giveaway \`${code}\`. Le giveaway a été annulé.`);
                            } catch (err) {
                                console.error(`Failed to send cancellation message: ${err.message}`);
                            }
                        } else {
                            // Filtrer les participants si vocal requis
                            let validParticipants = participants;
                            if (giveawayData.vocal) {
                                validParticipants = participants.filter(userId => {
                                    const member = guild.members.cache.get(userId);
                                    return member && member.voice.channel;
                                });
                            }

                            let winners = [];
                            if (giveawayData.predef && giveawayData.predef.length > 0) {
                                winners = giveawayData.predef.slice(0, giveawayData.gagnant || 1);
                            } else if (validParticipants.length > 0) {
                                const shuffled = [...validParticipants].sort(() => 0.5 - Math.random());
                                winners = shuffled.slice(0, Math.min(giveawayData.gagnant || 1, validParticipants.length));
                            }

                            const embed = new EmbedBuilder()
                                .setTitle('🎉 Giveaway Terminé')
                                .setDescription(
                                    `**Prix** : \`${giveawayData.prix}\`\n` +
                                    `**Gagnants** : ${winners.length > 0 ? winners.map(w => `<@${w}>`).join(', ') : 'Aucun participant'}\n` +
                                    `**Lancée par** : <@${giveawayData.host}>\n` +
                                    `**Code** : \`${code}\``
                                )
                                .setColor(color)
                                .setFooter(client.footer || { text: 'Giveaway System' })
                                .setTimestamp();

                            const row = new ActionRowBuilder().addComponents(
                                new ButtonBuilder()
                                    .setCustomId(`giveaway_entry_${code}`)
                                    .setEmoji(giveawayData.emoji || '🎉')
                                    .setStyle(buttonStyle)
                                    .setDisabled(true),
                                new ButtonBuilder()
                                    .setCustomId(`giveaway_list_${code}`)
                                    .setLabel('Voir les participants')
                                    .setStyle(ButtonStyle.Secondary)
                                    .setDisabled(true)
                            );

                            const success = await safeEdit(message, { embeds: [embed], components: [row], content: null });
                            if (!success) {
                                console.error(`Failed to update giveaway message for ${code}`);
                            }

                            try {
                                if (winners.length > 0) {
                                    await giveawayChannel.send(`🎉 Félicitations ${winners.map(w => `<@${w}>`).join(', ')} ! Vous avez gagné **${giveawayData.prix}** ! Code du giveaway : \`${code}\``);
                                } else {
                                    await giveawayChannel.send(`❌ Aucun gagnant n'a pu être sélectionné pour le giveaway \`${code}\`.`);
                                }
                            } catch (err) {
                                console.error(`Failed to send winner announcement: ${err.message}`);
                            }

                            await client.db.set(`giveaway_${guildId}_${code}`, { ...giveawayData, ended: true });
                        }
                    }
                }
            } catch (error) {
                console.error(`Error in giveaway interval: ${error.message}`);
            }
        }, 5000); // Augmenté à 5 secondes pour réduire la charge
    }
};