const { ButtonStyle, ActionRowBuilder, ButtonBuilder, EmbedBuilder } = require("discord.js");

// Cache pour éviter les interactions multiples
const interactionCache = new Map();

module.exports = {
    name: 'interactionCreate',
    run: async (client, interaction) => {
        if (!interaction.isButton() || !interaction.customId.startsWith('giveaway_')) return;

        const { customId, user, guildId } = interaction;
        const cacheKey = `${user.id}_${customId}_${interaction.message.id}`;

        try {
            // Vérifier si l'interaction est en cours de traitement
            if (interactionCache.has(cacheKey)) {
                return; // Ignorer les interactions en double
            }

            // Marquer l'interaction comme en cours de traitement
            interactionCache.set(cacheKey, true);
            
            // Nettoyer le cache après 30 secondes
            setTimeout(() => {
                interactionCache.delete(cacheKey);
            }, 30000);

            // Vérifier si l'interaction est encore valide
            if (!interaction.isRepliable()) {
                return;
            }

            // Différer la réponse immédiatement
            let deferSuccess = false;
            try {
                await interaction.deferReply({ ephemeral: true });
                deferSuccess = true;
            } catch (error) {
                // Gestion des erreurs de deferReply
                if (isExpiredInteractionError(error)) {
                    return;
                }
                console.error(`Échec du deferReply [${customId}]: ${error.message}`);
                return;
            }

            if (!deferSuccess) {
                return;
            }

            // Router vers les bonnes fonctions avec timeout
            const timeoutPromise = new Promise((_, reject) => {
                setTimeout(() => reject(new Error('Timeout')), 10000);
            });

            let handlerPromise;
            if (customId.startsWith('giveaway_entry_')) {
                handlerPromise = handleEntry(customId, interaction, client, user);
            } else if (customId.startsWith('giveaway_list_')) {
                handlerPromise = handleList(customId, interaction, client);
            } else if (customId.startsWith('giveaway_leave_')) {
                handlerPromise = handleLeave(customId, interaction, client, user);
            }

            if (handlerPromise) {
                await Promise.race([handlerPromise, timeoutPromise]);
            }

        } catch (error) {
            if (error.message === 'Timeout') {
                console.warn(`Timeout pour l'interaction ${customId} de ${user.tag}`);
                await safeEditReply(interaction, { content: "⏱️ L'opération a pris trop de temps. Veuillez réessayer." });
                return;
            }

            // Gestion des erreurs d'interaction expirée
            if (isExpiredInteractionError(error)) {
                return;
            }
            
            console.error(`Erreur lors du traitement de l'interaction [${customId}]: ${error.message}`);
            await safeEditReply(interaction, { content: "❌ Une erreur s'est produite. Veuillez réessayer." });
        } finally {
            // Nettoyer le cache après traitement
            interactionCache.delete(cacheKey);
        }
    }
};

// ===== FONCTIONS UTILITAIRES =====

function isExpiredInteractionError(error) {
    return error.code === 10062 || 
           error.code === 10008 || 
           error.code === 40060 ||
           (error.message && (
               error.message.includes('Unknown interaction') || 
               error.message.includes('interaction has already been acknowledged')
           ));
}

async function safeEdit(message, options) {
    try {
        if (!message || !message.editable) {
            return false;
        }
        await message.edit(options);
        return true;
    } catch (error) {
        console.error(`Failed to edit message: ${error.message}`);
        return false;
    }
}

async function safeEditReply(interaction, options) {
    try {
        if (!interaction.deferred || interaction.replied) {
            return false;
        }
        await interaction.editReply(options);
        return true;
    } catch (error) {
        if (isExpiredInteractionError(error)) {
            return false;
        }
        console.error(`Erreur lors de l'édition de la réponse: ${error.message}`);
        return false;
    }
}

// Gérer l'entrée dans le giveaway
async function handleEntry(customId, interaction, client, user) {
    const giveawayCode = customId.split('_')[2];
    const giveawayData = client.db.get(`giveaway_${interaction.guildId}_${giveawayCode}`);

    if (!giveawayData) {
        await safeEditReply(interaction, { content: "❌ Ce giveaway n'existe pas ou a expiré." });
        return;
    }

    if (giveawayData.temps <= Date.now() || giveawayData.ended) {
        await safeEditReply(interaction, { content: "❌ Ce giveaway est terminé." });
        return;
    }

    // Vérification des invitations requises
    if (giveawayData.requiredInvites && giveawayData.requiredInvites > 0) {
        const userInvites = client.db.get(`invites_${user.id}_${interaction.guildId}`);
        const validInvites = userInvites ? userInvites.valid : 0;
        if (validInvites < giveawayData.requiredInvites) {
            await safeEditReply(interaction, { 
                content: `❌ Vous avez besoin d'au moins ${giveawayData.requiredInvites} invitations pour participer. Vous en avez ${validInvites}.`
            });
            return;
        }
    }

    // Initialiser participant si undefined
    if (!giveawayData.participant) {
        giveawayData.participant = [];
    }

    if (!giveawayData.participant.includes(user.id)) {
        giveawayData.participant.push(user.id);
        
        try {
            await client.db.set(`giveaway_${interaction.guildId}_${giveawayCode}`, giveawayData);
            await safeEditReply(interaction, { content: "✅ Vous participez maintenant au giveaway !" });
            
            // Mettre à jour le message en arrière-plan
            setImmediate(() => {
                updateGiveawayMessage(giveawayData, interaction, client, giveawayCode);
            });
        } catch (error) {
            console.error(`Échec de l'enregistrement: ${error.message}`);
            await safeEditReply(interaction, { content: "❌ Erreur lors de l'enregistrement. Veuillez réessayer." });
        }
    } else {
        const leaveButton = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId(`giveaway_leave_${giveawayCode}`)
                .setLabel("Quitter le giveaway")
                .setEmoji("🚪")
                .setStyle(ButtonStyle.Danger)
        );

        await safeEditReply(interaction, {
            content: "ℹ️ Vous participez déjà à ce giveaway.",
            components: [leaveButton]
        });
    }
}

// Gérer la sortie du giveaway
async function handleLeave(customId, interaction, client, user) {
    const giveawayCode = customId.split('_')[2];
    const giveawayData = client.db.get(`giveaway_${interaction.guildId}_${giveawayCode}`);

    if (!giveawayData) {
        await interaction.reply({ ephemeral: true, content: "❌ Ce giveaway n'existe pas ou a expiré." });
        return;
    }

    if (giveawayData.temps <= Date.now() || giveawayData.ended) {
        await interaction.reply({ ephemeral: true, content: "❌ Ce giveaway est terminé." });
        return;
    }

    if (!giveawayData.participant) {
        giveawayData.participant = [];
    }

    if (giveawayData.participant.includes(user.id)) {
        console.log("Avant suppression", giveawayData.participant);
        giveawayData.participant = giveawayData.participant.filter(id => id !== user.id);
        console.log("Après suppression", giveawayData.participant);
        
        try {
            await client.db.set(`giveaway_${interaction.guildId}_${giveawayCode}`, giveawayData);
            await updateGiveawayMessage(giveawayData, interaction, client, giveawayCode);
            await interaction.editReply({ content: "✅ Vous avez quitté le giveaway !" });
        } catch (error) {
            console.error(`Échec de l'enregistrement: ${error.message}`);
            await interaction.editReply({ content: "❌ Erreur lors de l'enregistrement. Veuillez réessayer." });
        }
    } else {
        await interaction.editReply({ content: "ℹ️ Vous ne participez pas à ce giveaway." });
    }
}


// Gérer la liste des participants
async function handleList(customId, interaction, client) {
    const giveawayCode = customId.split('_')[2];
    const giveawayData = client.db.get(`giveaway_${interaction.guildId}_${giveawayCode}`);

    if (!giveawayData) {
        await safeEditReply(interaction, { content: "❌ Ce giveaway n'existe pas ou a expiré." });
        return;
    }

    const participants = giveawayData.participant || [];
    
    if (participants.length === 0) {
        await safeEditReply(interaction, { content: "📋 Aucun participant pour le moment." });
        return;
    }

    // Limiter le nombre de participants affichés pour éviter les messages trop longs
    const maxParticipants = 50;
    const displayParticipants = participants.slice(0, maxParticipants);
    const participantList = displayParticipants.map(id => `<@${id}>`).join('\n');
    
    const embed = new EmbedBuilder()
        .setTitle('👥 Liste des participants')
        .setDescription(participantList)
        .setColor(client.db.get(`color_${interaction.guildId}`))
        .setFooter({ 
            text: `${participants.length} participant(s)${participants.length > maxParticipants ? ` (${maxParticipants} premiers affichés)` : ''} | Code: ${giveawayCode}` 
        })
        .setTimestamp();

    await safeEditReply(interaction, { embeds: [embed] });
}

// Mettre à jour le message du giveaway (optimisé)
async function updateGiveawayMessage(giveawayData, interaction, client, giveawayCode) {
    try {
        const color = client.db.get(`color_${interaction.guild.id}`);
        const participantsCount = giveawayData.participant ? giveawayData.participant.length : 0;
        const isExpired = giveawayData.temps <= Date.now() || giveawayData.ended;

        const embed = new EmbedBuilder()
            .setTitle(isExpired ? "🎉 Giveaway Terminé" : "🎉 Giveaway")
            .setDescription(
                `**Prix** : \`${giveawayData.prix}\`\n` +
                `**Fin** : <t:${Math.floor(giveawayData.temps / 1000)}:R>\n` +
                `**Lancée par** : <@${giveawayData.host}>\n` +
                `**Participants** : \`${participantsCount}\`\n` +
                `**Code** : \`${giveawayCode}\``
            )
            .setColor(client.color)
            .setFooter(client.footer)
            .setTimestamp();

        const buttonStyle = ButtonStyle[giveawayData.buttonColor] || ButtonStyle.Primary;
        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId(`giveaway_entry_${giveawayCode}`)
                .setEmoji(giveawayData.emoji || '🎉')
                .setStyle(buttonStyle)
                .setDisabled(isExpired),
            new ButtonBuilder()
                .setCustomId(`giveaway_list_${giveawayCode}`)
                .setLabel("Voir les participants")
                .setEmoji("👥")
                .setStyle(ButtonStyle.Secondary)
                .setDisabled(isExpired)
        );

        const giveawayMessage = await interaction.channel.messages.fetch(giveawayData.messageid);
        await safeEdit(giveawayMessage, { embeds: [embed], components: [row], content: null });
    } catch (error) {
        console.error(`Erreur lors de la mise à jour du message: ${error.message}`);
    }
}