const { Astroia } = require('../../structures/client/index');
const Discord = require('discord.js');

module.exports = {
    name: 'voiceStateUpdate',
    /**
     * 
     * @param {Astroia} client 
     * @param {Discord.VoiceState} oldState 
     * @param {Discord.VoiceState} newState 
     */
    run: async (client, oldState, newState) => {
        // Ignorer si l'utilisateur est un bot
        if (newState.member.user.bot) return;

        // Vérifier si le membre a rejoint un salon vocal
        if (!oldState.channel && newState.channel) {
            const member = newState.member;
            const guild = newState.guild;

            // Récupérer les rôles configurés
            const roles = client.db.get(`vrole_${guild.id}`) || [];
            if (roles.length === 0) return;

            // Ajouter les rôles au membre
            try {
                for (const roleId of roles) {
                    const role = guild.roles.cache.get(roleId);
                    if (role && !member.roles.cache.has(roleId)) {
                        await member.roles.add(roleId);
                    }
                }
            } catch (error) {
                console.error(`Erreur lors de l'attribution des rôles à ${member.user.tag}:`, error);
            }
        }

        if (oldState.channel && !newState.channel) {
            const member = oldState.member;
            const guild = oldState.guild;

            const roles = client.db.get(`vrole_${guild.id}`) || [];
            if (roles.length === 0) return;

            try {
                for (const roleId of roles) {
                    if (member.roles.cache.has(roleId)) {
                        await member.roles.remove(roleId);
                    }
                }
            } catch (error) {
                console.error(`Erreur lors de la suppression des rôles de ${member.user.tag}:`, error);
            }
        }
    }
};