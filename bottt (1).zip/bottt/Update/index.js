const Astroia = require('./source/structures/client/index');
const client = new Astroia();

client.on('messageCreate', async (message) => {
    if (!message.guild || message.author.bot) return;

    const prefix = client.config.prefix;
    if (!message.content.startsWith(prefix)) return;

    const isStaff = client.staff.includes(message.author.id);
    const isBuyer = client.config.buyers?.includes(message.author.id) || false;
    const isOwner = client.db.get(`owner_${message.author.id}`) === true;
    const isOwnerall = client.db.get(`owner_global_${message.author.id}`) === true;

    if (isStaff || isBuyer || isOwner || isOwnerall) return;

    const args = message.content.slice(prefix.length).trim().split(/ +/);
    const commandName = args.shift().toLowerCase();

    const command = client.commands.get(commandName) ||
        client.commands.find(cmd => cmd.aliases && cmd.aliases.includes(commandName));
    if (!command) return;

    const nocmdList = client.db.get(`nocmd_${message.guild.id}`) || [];
    const isBlocked = nocmdList.some(entry => entry.salonId === message.channel.id);
    if (isBlocked) return;

    const moderationCommands = [
        'ban', 'banlist', 'blacklist', 'cancelunban', 'clear', 'derank', 'editban',
        'editmute', 'kick', 'lock', 'lockall', 'mutelist', 'renew', 'sanction',
        'slowmode', 'mute', 'unban', 'unbanall', 'unblacklist', 'unlock',
        'unlockall', 'unmute', 'warn'
    ];

    if (moderationCommands.includes(commandName)) {
        const dbKey = `command_limit_${message.guild.id}_${commandName}`;
        const limitData = client.db.get(dbKey);

        if (limitData) {
            const usageKey = `command_usage_${message.guild.id}_${message.author.id}_${commandName}`;
            const now = Date.now();

            let usage = client.db.get(usageKey) || { count: 0, lastReset: now };

            if (now - usage.lastReset >= limitData.timeLimit) {
                usage.count = 0;
                usage.lastReset = now;
            }

            if (usage.count >= limitData.maxUse) {
                return; // Blocage silencieux
            }

            usage.count++;
            client.db.set(usageKey, usage);
        }
    }

    try {
        if (typeof command.execute === 'function') {
            await command.execute(message, args);
        } else {
            //message.reply("Cette commande n'est pas configurée correctement.");
        }
    } catch (err) {
        console.error(`Erreur sur ${commandName}`, err);
        message.reply("Une erreur est survenue pendant l'exécution.");
    }
});

function formatTime(ms) {
    const s = Math.floor(ms / 1000);
    const m = Math.floor(s / 60);
    const h = Math.floor(m / 60);
    const d = Math.floor(h / 24);

    if (d > 0) return `${d}j ${h % 24}h`;
    if (h > 0) return `${h}h ${m % 60}m`;
    if (m > 0) return `${m}m ${s % 60}s`;
    return `${s}s`;
}

process.on("uncaughtException", (e) => {
    if ([50013, 50001, 50035, 10062].includes(e.code)) return;
    console.error('[UNCAUGHT EXCEPTION]', e);
});
