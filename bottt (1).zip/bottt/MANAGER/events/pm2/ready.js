const { exec } = require('child_process');
const { EmbedBuilder } = require('discord.js');
const fs = require('fs'); // Added for directory deletion
require('colors');
const ms = require('ms');

const notifiedBots = new Set(); // Empêche les doubles notifications
const deletedBots = new Set(); // Empêche les doubles suppressions

module.exports = async (client) => {
    exec('pm2 resurrect', (error) => {
        if (error) console.error('Erreur lors de la restauration :'.red, error);
        else console.log('Sauvegarde PM2 restaurée avec succès'.cyan);
    });

    exec('pm2 save');

    setInterval(() => {
        try {
            exec('pm2 jlist', async (error, stdout) => {
                if (error) return console.error('Erreur lors de la récupération de la liste PM2 :', error);

                const pm2List = JSON.parse(stdout);

                client.db.all('SELECT * FROM Astroia', async (err, rows) => {
                    if (err) return console.error('Erreur lors de la récupération des bots de l\'utilisateur :', err);
                    if (rows.length === 0) return;

                    for (const row of rows) {
                        const botId = row.bot_id;
                        const timestamp = Math.floor(row.temps / 1000);
                        const timeRemaining = row.temps - Date.now();
                        const isExpired = timeRemaining < 1000;
                        const timeSinceExpiration = Date.now() - row.temps;

                        // 🔔 Alerte 3 jours avant expiration (entre 72h et 71h)
                        if (timeRemaining <= 259200000 && timeRemaining > 255600000 && !notifiedBots.has(botId)) {
                            notifiedBots.add(botId);

                            try {
                                const botUser = await client.users.fetch(botId);
                                const buyerUser = await client.users.fetch(row.owner);

                                const embed = new EmbedBuilder()
                                    .setColor('Yellow')
                                    .setTitle('⏰ Préavis d\'expiration')
                                    .setDescription(`Votre bot \`${botUser.username}\` expirera dans **moins de 3 jours**.\nDate d'expiration : <t:${timestamp}:R>\nMerci de penser à renouveler.`)
                                    .setFooter({ text: client.config.footer });

                                const publicChannel = client.channels.cache.get(client.config.expiration);
                                //if (publicChannel) publicChannel.send({ embeds: [embed] });

                                try {
                                    await buyerUser.send({ embeds: [embed] });
                                    console.log(`[INFO] Préavis envoyé à ${buyerUser.tag} pour le bot ${botUser.username}`);
                                } catch (dmError) {
                                    console.warn(`[WARN] Impossible d'envoyer un DM à ${buyerUser.tag} (${buyerUser.id})`);
                                }
                            } catch (fetchError) {
                                console.error(`[ERREUR] Impossible de récupérer les infos du bot ou de l'owner pour ${botId}`, fetchError);
                            }
                        }

                        // ⚠️ Bot expiré
                        if (isExpired) {
                            const selectedBotProcess = pm2List.find((process) => process.name === botId);

                            if (selectedBotProcess && selectedBotProcess.pm2_env.status === 'online') {
                                exec('pm2 stop ' + botId, async (error) => {
                                    if (error) {
                                        console.error('Erreur lors de l\'arrêt du bot :', error);
                                        return;
                                    }

                                    try {
                                        const botUser = await client.users.fetch(botId);
                                        const buyerUser = await client.users.fetch(row.owner);
                                        const deletionTimestamp = Math.floor((row.temps + 604800000) / 1000); // 7 days after expiration
                                        const oneWeekLater = Math.floor((Date.now() + 7 * 24 * 60 * 60 * 1000) / 1000);

                                        // Embed pour le buyer
                                        const buyerEmbed = new EmbedBuilder()
                                            .setColor(client.color)
                                            .setTitle('❌ Bot Expiré')
                                            .setDescription(`\`${botUser.username}\` vient d'expirer.\nDate d'expiration : <t:${timestamp}:R>\nSi vous souhaitez le renouveler, merci de créer un ticket sur le serveur support.\nSi vous ne renouveler pas votre robot, il sera automatiquement supprimé <t:${oneWeekLater}:R>.`)
                                            .setFooter({ text: client.config.footer });

                                        // Embed pour le log admin
                                        const adminEmbed = new EmbedBuilder()
                                            .setColor('Red')
                                            .setTitle('📛 Bot Désactivé (Expiration)')
                                            .addFields(
                                                { name: '🧠 Bot', value: `\`${botUser.username}\` (\`${botUser.id}\`)`, inline: false },
                                                { name: '👤 Buyer', value: `<@${buyerUser.id}>`, inline: false },
                                                { name: '⏰ Expiré le', value: `<t:${timestamp}:F>`, inline: false }
                                            )
                                            .setFooter({ text: client.config.footer })
                                            .setTimestamp();

                                        console.log(`${botUser.username} vient d'expirer`);
                                        const publicChannel = client.channels.cache.get(client.config.expiration);
                                        if (publicChannel) publicChannel.send({ embeds: [adminEmbed] });

                                        try {
                                            await buyerUser.send({ embeds: [buyerEmbed] });
                                            console.log(`[INFO] Expiration envoyée à ${buyerUser.tag}`);
                                        } catch (dmError) {
                                            console.warn(`[WARN] Impossible d'envoyer un DM à ${buyerUser.tag} (${buyerUser.id})`);
                                        }
                                    } catch (fetchError) {
                                        console.error(`[ERREUR] lors de l'envoi d'expiration pour ${botId}`, fetchError);
                                    }
                                });
                            }
                            // 🗑️ Suppression du dossier 1 semaine après expiration
                            if (timeSinceExpiration >= 604800000 && !deletedBots.has(botId)) {
                                deletedBots.add(botId);

                                try {
                                    const botUser = await client.users.fetch(botId);
                                    const buyerUser = await client.users.fetch(row.owner);
                            
                                    // Define the bot directory path
                                    const botDir = `/home/ubuntu/bot/${botId}`; // Ensure this path is correct
                            
                                    // Check if the directory exists before attempting deletion
                                    if (fs.existsSync(botDir)) {
                                        exec(`rm -rf ${botDir}`, async (error) => {
                                            if (error) {
                                                console.error(`Erreur lors de la suppression du dossier du bot ${botId} :`, error);
                                                deletedBots.delete(botId); // Permet de réessayer plus tard
                                                return;
                                            }
                                        
                                            console.log(`[INFO] Dossier du bot ${botUser.username} (${botId}) supprimé`);
                                        
                                            // Supprimer le bot de la base de données
                                            client.db.run('DELETE FROM Astroia WHERE bot_id = ?', [botId], (err) => {
                                                if (err) {
                                                    console.error(`[ERREUR] Impossible de supprimer ${botId} de la base de données :`, err);
                                                } else {
                                                    console.log(`[DB] Bot ${botId} supprimé de la base de données.`);
                                                }
                                            });
                            
                                            console.log(`[INFO] Dossier du bot ${botUser.username} (${botId}) supprimé`);
                            
                                            // Embed for the admin deletion log
                                            const deletionEmbed = new EmbedBuilder()
                                                .setColor('DarkRed')
                                                .setTitle('🗑️ Bot Supprimé')
                                                .addFields(
                                                    { name: '🧠 Bot', value: `\`${botUser.username}\` (\`${botUser.id}\`)`, inline: false },
                                                    { name: '👤 Buyer', value: `<@${buyerUser.id}>`, inline: false },
                                                    { name: '⏰ Supprimé le', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false },
                                                    { name: '📅 Expiré depuis', value: `<t:${timestamp}:R>`, inline: false }
                                                )
                                                .setFooter({ text: client.config.footer })
                                                .setTimestamp();
                            
                                            const suppChannel = client.channels.cache.get(client.config.supp);
                                            if (suppChannel) {
                                                suppChannel.send({ embeds: [deletionEmbed] });
                                            } else {
                                                console.warn(`[WARN] Canal de suppression ${client.config.supp} non trouvé`);
                                            }
                                        });
                                    } else {
                                        console.warn(`[WARN] Dossier du bot ${botId} n'existe pas à ${botDir}`);
                                        // Log the deletion attempt as successful since the directory doesn't exist
                                        const deletionEmbed = new EmbedBuilder()
                                            .setColor('DarkRed')
                                            .setTitle('🗑️ Bot Supprimé (Dossier Non Trouvé)')
                                            .addFields(
                                                { name: '🧠 Bot', value: `\`${botUser.username}\` (\`${botUser.id}\`)`, inline: false },
                                                { name: '👤 Buyer', value: `<@${buyerUser.id}>`, inline: false },
                                                { name: '⏰ Supprimé le', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false },
                                                { name: '📅 Expiré depuis', value: `<t:${timestamp}:R>`, inline: false }
                                            )
                                            .setFooter({ text: client.config.footer })
                                            .setTimestamp();
                            
                                        const suppChannel = client.channels.cache.get(client.config.supp);
                                        if (suppChannel) {
                                            suppChannel.send({ embeds: [deletionEmbed] });
                                        }
                                    }
                                } catch (fetchError) {
                                    console.error(`[ERREUR] Impossible de récupérer les infos pour la suppression du bot ${botId}`, fetchError);
                                    // Optionally remove from deletedBots to allow retry
                                    deletedBots.delete(botId);
                                }
                            }
                        }
                    }
                });
            });
        } catch (err) {
            console.error('Erreur :', err);
        }
    }, 1000 * 60); // Changé à 1 minute pour éviter la surcharge
};