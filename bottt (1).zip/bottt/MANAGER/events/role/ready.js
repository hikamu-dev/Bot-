const ms = require('ms');

module.exports = async (client) => {
  const buyerRoleId = client.config.roleclient;
  const guildId = client.config.guildId;
  const guild = client.guilds.cache.get(guildId);

  if (!guild) {
    console.error(`❌ Le serveur avec l'ID ${guildId} n'a pas été trouvé.`);
    return;
  }

  const interval = ms('1m'); // ✅ Vérifie toutes les 1 minute (et plus de 1s)

  setInterval(async () => {
    try {
      const buyerRole = guild.roles.cache.get(buyerRoleId);
      if (!buyerRole) return console.warn(`⚠️ Rôle client introuvable sur ${guild.name}`);

      // ✅ On n'appelle plus guild.members.fetch()
      // On travaille sur les membres déjà connus du cache
      const cachedMembers = guild.members.cache;

      // Récupère la liste des owners actifs depuis la base
      client.db.all('SELECT DISTINCT owner FROM Astroia', async (err, rows) => {
        if (err) return console.error('Erreur SQL (récupération des stats) :', err);

        const activeOwnerIds = new Set(rows.map(row => row.owner));

        for (const member of cachedMembers.values()) {
          const hasBuyerRole = member.roles.cache.has(buyerRoleId);
          const isActiveOwner = activeOwnerIds.has(member.id);

          if (isActiveOwner && !hasBuyerRole) {
            await member.roles.add(buyerRole).catch(() => {});
            console.log(`✅ Rôle client ajouté à ${member.user.username}`);
          } else if (!isActiveOwner && hasBuyerRole) {
            await member.roles.remove(buyerRole).catch(() => {});
            console.log(`❌ Rôle client retiré de ${member.user.username}`);
          }
        }
      });
    } catch (err) {
      if (err.code === 'GuildMembersTimeout') {
        console.warn(`[⚠️] Timeout ignoré sur ${guild.name}`);
      } else {
        console.error(`[❌] Erreur dans le rôle client :`, err);
      }
    }
  }, interval);
};
