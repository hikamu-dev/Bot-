const { REST } = require('@discordjs/rest');
const { Routes } = require('discord.js');
const fs = require('node:fs');
const axios = require('axios');
const { EmbedBuilder } = require('discord.js');
require('colors');

module.exports = async (client) => {
  console.log("Bot".blue + " >>" + ` Connecté sur ${client.user.username} (${client.user.id})`.green);

  const updatePresence = () => {
    client.db.get(`
      SELECT
        COUNT(DISTINCT owner) AS ownerCount,
        COUNT(*) AS totalBots
      FROM Astroia
    `, async (err, row) => {
      if (err) {
        console.error('Erreur lors de la récupération des stats pour le statut:', err);
        client.user.setPresence({
          status: 'idle',
          activities: [{
            name: `0 bots & 0 clients`,
            type: 3,
            url: "https://twitch.tv/discord"
          }]
        });
        return;
      }

      const { ownerCount: totalClients, totalBots } = row;

      client.user.setPresence({
        status: 'idle',
        activities: [{
          name: `${totalBots} bots & ${totalClients} clients`,
          type: 3,
          url: "https://twitch.tv/discord"
        }]
      });

      updateVoiceChannelNames(client, totalBots, totalClients);
    });
  };

  const generateKey = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let key = '';
    for (let i = 0; i < 16; i++) {
      key += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return key;
  };

  const saveKeyToFile = (key) => {
    fs.appendFileSync('./Clée.txt', `${key}\n`, 'utf8');
  };

  const loadProcessedOrders = () => {
    try {
      if (fs.existsSync('./processedOrders.json')) {
        return JSON.parse(fs.readFileSync('./processedOrders.json', 'utf8'));
      }
      return [];
    } catch (error) {
      console.error('Erreur lors du chargement des ordres traités:'.red, error);
      return [];
    }
  };

  const saveProcessedOrder = (orderId) => {
    const processedOrders = loadProcessedOrders();
    if (!processedOrders.includes(orderId)) {
      processedOrders.push(orderId);
      fs.writeFileSync('./processedOrders.json', JSON.stringify(processedOrders, null, 2), 'utf8');
    }
  };

  const handlePaidOrder = async (orderData) => {
    try {
      const processedOrders = loadProcessedOrders();
      if (processedOrders.includes(orderData.id)) return;

      const discordId = orderData.metadata['Identifiant Discord'];
      if (!discordId) {
        console.error('Aucun Discord ID trouvé dans metadata:'.red, orderData.metadata);
        return;
      }

      const key = generateKey();
      saveKeyToFile(key);
      saveProcessedOrder(orderData.id);

      const user = await client.users.fetch(discordId).catch(() => null);
      if (user) {
        const embed = new EmbedBuilder()
          .setTitle('`🎁` 〃 Merci pour votre achat !')
          .setDescription('Voici votre clé d\'activation.')
          .addFields(
            { name: 'Clé', value: `\`${key}\``, inline: true },
            { name: 'Montant', value: `${orderData.endPrice.amount} ${orderData.endPrice.currency}`, inline: true },
            { name: 'Commande', value: '</create:1298372774892539957>', inline: false }
          )
          .setColor('#00FF00')
          .setTimestamp();

        await user.send({ embeds: [embed] });
      } else {
        console.error('Utilisateur Discord introuvable:'.red, discordId);
      }

      const channel = client.channels.cache.get('1393993373861281808');
      if (channel) {
        const customFields = orderData.metadata || {};
        let customFieldsText = 'Aucun champ personnalisé';
        if (Object.keys(customFields).length > 0) {
          customFieldsText = Object.entries(customFields)
            .map(([key, value]) => `${key}: ${value}`)
            .join('\n');
        }

        const orderEmbed = new EmbedBuilder()
          .setTitle('`💸` 〃 Nouvel Ordre Payé')
          .setDescription('Un nouvel ordre a été complété avec succès.')
          .addFields(
            { name: 'ID de l\'ordre', value: `\`${orderData.id}\``, inline: true },
            { name: 'Montant', value: `\`${orderData.endPrice.amount} ${orderData.endPrice.currency}\``, inline: true },
            { name: 'Clé générée', value: `\`${key}\``, inline: false },
            { name: 'Champs personnalisés', value: customFieldsText, inline: false }
          )
          .setColor('#00FF00')
          .setTimestamp();

        await channel.send({ embeds: [orderEmbed] });
      }

      console.log("Ordre payé traité:".green, orderData);
    } catch (error) {
      console.error("Erreur lors du traitement de l'ordre:".red, error);
    }
  };

  const fetchOrderDetails = async (shopId, orderId) => {
    try {
      const response = await axios.get(
        `https://pg-api.billgang.com/v1/dash/shops/${shopId}/orders/${orderId}`,
        {
          headers: {
            Authorization: 'Bearer <TON_TOKEN_BILLGANG_ICI>'
          }
        }
      );
      return response.data.data;
    } catch (error) {
      console.error(`Erreur lors de la récupération des détails de l'ordre ${orderId}:`.red, error.response ? error.response.data : error.message);
      return null;
    }
  };

  const checkBillgangOrders = async () => {
    try {
      const shopId = '347451cc-3cb0-483e-9169-de0045392eea';
      const response = await axios.get(
        `https://pg-api.billgang.com/v1/dash/shops/${shopId}/orders`,
        {
          headers: {
            Authorization: 'Bearer <TON_TOKEN_BILLGANG_ICI>'
          }
        }
      );

      const orders = response.data.data;
      for (const order of orders) {
        if (order.status === 'COMPLETED') {
          const orderDetails = await fetchOrderDetails(shopId, order.id);
          if (orderDetails) {
            await handlePaidOrder(orderDetails);
          }
        }
      }
    } catch (error) {
      console.error("Erreur lors de la vérification des ordres Billgang:".red, error.response ? error.response.data : error.message);
    }
  };

  updatePresence();
  checkBillgangOrders();

  setInterval(updatePresence, 2 * 60 * 1000);
  setInterval(checkBillgangOrders, 1 * 60 * 1000);

  const commandsData = [];
  fs.readdirSync("./commands/").forEach(dirs => {
    const commands = fs.readdirSync(`./commands/${dirs}`).filter(files => files.endsWith(".js"));
    for (const file of commands) {
      const getFName = require(`../../commands/${dirs}/${file}`);
      if (getFName.data) commandsData.push(getFName.data);
    }
  });

  const rest = new REST({ version: '10' }).setToken(client.token);
  const data = await rest.put(Routes.applicationCommands(client.user.id), { body: commandsData });

  console.log("Slashs".blue + " >>" + `${data.length} Commandes chargées`.green);
};

// 🔁 Fonction appelée dans updatePresence
async function updateVoiceChannelNames(client, totalBots, totalClients) {
  try {
    const botChannelId = '1396201805083316307';
    const clientChannelId = '1396201838013055181';

    const botChannel = await client.channels.fetch(botChannelId).catch(() => null);
    const clientChannel = await client.channels.fetch(clientChannelId).catch(() => null);

    if (botChannel && botChannel.setName) {
      const name = `┊🤖・Bots : ${totalBots}`;
      if (botChannel.name !== name) await botChannel.setName(name);
    }

    if (clientChannel && clientChannel.setName) {
      const name = `┊⭐・Clients : ${totalClients}`;
      if (clientChannel.name !== name) await clientChannel.setName(name);
    }

    console.log(`✅ Salons vocaux mis à jour : Bots = ${totalBots}, Clients = ${totalClients}`);
  } catch (err) {
    console.error("❌ Erreur updateVoiceChannelNames :", err);
  }
}
