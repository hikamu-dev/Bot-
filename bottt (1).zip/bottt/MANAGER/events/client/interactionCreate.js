module.exports = async (client, interaction) => {
        if (!interaction.guild) return;
        if (interaction.isCommand()) {
            const command = client.commands.get(interaction.commandName);
            if (!command) return;

            if (command.botOwner){
                if (!client.config.developpeurs.includes(interaction.user.id)) return interaction.reply({
                    content: `\`❌\`〃 Vous n'avez pas les permissions d'utiliser cette commande`,
                    ephemeral: true
                });
            }
            
            command.run(client, interaction);
        };
    
}