const { exec } = require('child_process');
const Discord = require('discord.js');
const fs = require('fs-extra');

module.exports = {
  name: "createcoin",
  description: "Crée un bot coin via token et clé",
  category: "coins",

  run: async (client, interaction) => {
    try {
      const token = interaction.options.getString('token');
      const cle = interaction.options.getString('clé')?.trim();

      await interaction.deferReply({ ephemeral: true });

      if (!token || !cle) {
        return interaction.editReply({ content: '`❌` 〃 Vous devez fournir un token et une clé valides.' });
      }

      const bot = new Discord.Client({ intents: [377744] });
      await interaction.editReply({ content: '\`🔍\` 〃 Connexion au bot coin en cours...' });

      try {
        await bot.login(token);
      } catch (err) {
        console.error('Erreur lors de la connexion du bot coin :', err);
        return interaction.editReply({ content: '`❌` 〃 Token invalide !' });
      }

      if (!bot.user) {
        return interaction.editReply({ content: '`❌` 〃 Échec de la connexion du bot.' });
      }

      const botId = bot.user.id;
      const owner = interaction.user;

      await interaction.editReply({ content: '\`🧾\` 〃 Vérification de la clé...' });

      let clesEnvoyees;
      try {
        clesEnvoyees = fs.readFileSync('Clée.txt', 'utf8').trim().split("\n").map(line => line.trim());
      } catch (err) {
        console.error("Erreur lecture clés envoyées :", err);
        return interaction.editReply({ content: '`❌` 〃 Erreur lors de la lecture des clés envoyées.' });
      }

      const cleanKey = cle.trim().toLowerCase();
      const cleValide = clesEnvoyees.map(k => k.toLowerCase()).includes(cleanKey);

      if (!cleValide) {
        return interaction.editReply({ content: '`❌` 〃 Clé d\'activation invalide.' });
      }

      // Retirer la clé utilisée du fichier
      const updatedCles = clesEnvoyees
        .map(k => k.trim().toLowerCase())
        .filter(entry => entry && entry !== cleanKey);

      fs.writeFileSync('Clée.txt', updatedCles.join('\n') + '\n', 'utf8');

      const folderPath = `/home/ubuntu/CoinBots/${botId}`;
      await interaction.editReply({ content: '\`📁\` 〃 Création du dossier pour le bot coin...' });

      await fs.ensureDir(folderPath);
      await fs.copy('/home/ubuntu/CoinTemplate', folderPath);

      const coinConfig = {
        token,
        buyer_id: owner.id,
        owners: [""],
        color: "#2f3136",
        prefix: "&"
      };

      fs.writeFileSync(`${folderPath}/config.json`, JSON.stringify(coinConfig, null, 2));

      await interaction.editReply({ content: '\`📦\` 〃 Installation de discord.js et better-sqlite3...' });

      exec(`cd ${folderPath} && npm i discord.js better-sqlite3 && pm2 start index.js --name ${botId}`, async (err) => {
        if (err) {
          console.error('Erreur installation discord.js :', err);
          return interaction.editReply({ content: '`❌` 〃 Erreur lors de l\'installation des dépendances.' });
        }

        // Calcul du temps de validité (1 mois = 30 jours)
        const temps = '30d';
        const parsedTime = parseTime(temps);
        const expirationDate = Date.now() + parsedTime;

        try {
          // Ajoute dans la base Astroia (comme le create normal)
          client.db.run(
            'INSERT INTO Astroia (bot_id, owner, temps) VALUES (?, ?, ?)',
            [botId, owner.id, expirationDate]
          );

          // Enregistre la clé utilisée
          client.db.run(
            'INSERT INTO clee (clee, bot_id, author, timetamps) VALUES (?, ?, ?, ?)',
            [cle, botId, owner.id, Date.now()]
          );
        } catch (e) {
          console.error("Erreur insertion DB pour le bot coin :", e);
        }

        // Génération de l’invitation
        const invite = await bot.generateInvite({ scopes: ['bot', 'applications.commands'] });
        const inviteButton = new Discord.ActionRowBuilder().addComponents(
          new Discord.ButtonBuilder()
            .setLabel('Inviter le bot')
            .setStyle(Discord.ButtonStyle.Link)
            .setURL(invite)
        );

        // Embed de log
        const logEmbed = new Discord.EmbedBuilder()
          .setTitle('🪙 Nouveau bot coin créé')
          .setColor('#FFD700')
          .setThumbnail(bot.user.displayAvatarURL({ dynamic: true }))
          .addFields(
            { name: '👤 Créateur', value: `<@${owner.id}>`, inline: true },
            { name: '🤖 Bot', value: `\`${bot.user.tag}\``, inline: true },
            { name: '🆔 ID du Bot', value: `\`${botId}\``, inline: true },
            { name: '🔑 Clé utilisée', value: `\`${cle}\``, inline: true },
            { name: '⏳ Expire le', value: `<t:${Math.floor(expirationDate / 1000)}:F>` },
            { name: '📁 Dossier', value: `\`${folderPath}\`` }
          )
          .setTimestamp();

        try {
          client.channels.cache.get(client.config.clee)?.send({
            embeds: [logEmbed],
            components: [inviteButton]
          });
        } catch (e) {
          console.error("Erreur log :", e);
        }

        try {
          await owner.send(`✅ Votre bot coin **${bot.user.tag}** a été créé avec succès !\n> ⏳ Expiration : <t:${Math.floor(expirationDate / 1000)}:F>`);
        } catch {}

        return interaction.editReply({ content: '`✅` 〃 Le bot coin a été **créé**, **configuré** et **lancé** avec succès !' });
      });

    } catch (error) {
      console.error("Erreur globale :", error);
      return interaction.followUp({ content: '`❌` 〃 Une erreur est survenue lors de la création du bot coin.', ephemeral: true });
    }
  },

  get data() {
    return new Discord.SlashCommandBuilder()
      .setName('createcoin')
      .setDescription('Créer un bot coin Discord avec un token et une clé d\'activation.')
      .addStringOption(option =>
        option.setName('token')
          .setDescription('Le token du bot coin à créer.')
          .setRequired(true))
      .addStringOption(option =>
        option.setName('clé')
          .setDescription('La clé d\'activation.')
          .setRequired(true));
  }
};

// Fonction parseTime (copiée du create.js)
function parseTime(str) {
  const regex = /(\d+)([smhdwy])/;
  const match = str.match(regex);
  if (!match) return null;
  const val = parseInt(match[1]);
  const unit = match[2];
  const unitToMs = {
    s: 1000,
    m: 60000,
    h: 3600000,
    d: 86400000,
    w: 604800000,
    y: 31536000000,
  };
  return unitToMs[unit] ? val * unitToMs[unit] : null;
}
