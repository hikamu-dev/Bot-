const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } = require('discord.js');
const pm2 = require('pm2');
const ms = require('ms');

module.exports = {
  name: "manage",
  description: "Contrôlez vos bots personnels",
  category: "Membres",
  run: async (client, interaction) => {
    const ownerId = interaction.user.id;

    client.db.all('SELECT * FROM Astroia WHERE owner = ?', [ownerId], async (err, botList) => {
      if (err) {
        console.error('Erreur lors de la récupération des bots de l\'utilisateur :', err);
        return interaction.reply({ content: '❌ 〃 Impossible de récupérer vos bots, réessayez plus tard.', ephemeral: true });
      }

      if (!botList.length) {
        return interaction.reply({ content: '❌ 〃 Vous ne possédez actuellement aucun bot.', ephemeral: true });
      }

      const botIds = new Set();
      const botOptions = [];

      for (const botInfo of botList) {
        if (!botIds.has(botInfo.bot_id)) {
          const botUser = await client.users.fetch(botInfo.bot_id).catch(() => null);
          if (!botUser) continue;

          botOptions.push({
            label: botUser.tag,
            value: botInfo.bot_id
          });
          botIds.add(botInfo.bot_id);
        }
      }

      if (!botOptions.length) {
        return interaction.reply({ content: '❌ 〃 Aucun bot disponible pour la gestion.', ephemeral: true });
      }

      const botSelectMenu = new StringSelectMenuBuilder()
        .setCustomId(`select_bot_${interaction.id}`)
        .setPlaceholder('Choisissez un bot à gérer')
        .addOptions(botOptions);

      const actionRow = new ActionRowBuilder().addComponents(botSelectMenu);

      const initialEmbed = new EmbedBuilder()
        .setTitle('Gestion des Bots')
        .setColor(client.color)
        .setDescription('Veuillez sélectionner un bot dans la liste ci-dessous pour le gérer.')
        .setFooter({ text: 'Kibuya - Gestion des bots', iconURL: client.user.avatarURL() })
       

      const botSelectionInteraction = await interaction.reply({
        embeds: [initialEmbed],
        components: [actionRow],
        ephemeral: true,
        fetchReply: true
      });

      const menuCollector = botSelectionInteraction.createMessageComponentCollector({
        filter: (i) => i.user.id === interaction.user.id,
        time: ms('2m')
      });

      menuCollector.on('collect', async (menuInteraction) => {
        try {
          if (!menuInteraction.isStringSelectMenu()) return;
          if (!menuInteraction.values || !menuInteraction.values[0]) {
            return menuInteraction.reply({ content: '❌ 〃 Aucune sélection détectée.', ephemeral: true });
          }

          if (menuInteraction.deferred || menuInteraction.replied) {
            return menuInteraction.followUp({ content: '❌ 〃 Cette interaction a déjà été traitée.', ephemeral: true });
          }

          await menuInteraction.deferUpdate();
          const selectedBotId = menuInteraction.values[0];

          pm2.connect((err) => {
            if (err) {
              console.error('Erreur lors de la connexion à PM2 :', err);
              return menuInteraction.followUp({ content: '❌ 〃 Erreur lors de la gestion du bot.', ephemeral: true });
            }

            pm2.list(async (err, pm2Data) => {
              pm2.disconnect();
              if (err) {
                console.error('Erreur lors de la récupération des processus PM2 :', err);
                return menuInteraction.followUp({ content: '❌ 〃 Erreur lors de la gestion du bot.', ephemeral: true });
              }

              const botProcess = pm2Data.find((process) => process.name === selectedBotId);
              if (!botProcess) {
                return menuInteraction.followUp({ content: '❌ 〃 Bot non trouvé dans la liste.', ephemeral: true });
              }

              const isRunning = botProcess.pm2_env.status === 'online';
              const status = isRunning ? '<:onlyna:1417777717981614163> En ligne' : '<:offlyna:1417777770209083527> Hors ligne';
              const botUser = await client.users.fetch(selectedBotId).catch(() => null);
              if (!botUser) {
                return menuInteraction.followUp({ content: '❌ 〃 Impossible de récupérer les informations du bot.', ephemeral: true });
              }

              client.db.get('SELECT temps FROM Astroia WHERE bot_id = ?', [selectedBotId], async (err, row) => {
                if (err || !row) {
                  console.error('Erreur lors de la récupération des infos de bot :', err);
                  return menuInteraction.followUp({ content: '❌ 〃 Erreur lors de la récupération des infos du bot.', ephemeral: true });
                }

                const timestamp = Math.floor(row.temps / 1000);
                const isExpired = row.temps < Date.now();

                const expirationText = isExpired
                  ? `<:expirelyna:1417778032311144572> **Expiré depuis** : <t:${timestamp}:R>`
                  : `<:timelyna:1417784519192346655> **Expire** : <t:${timestamp}:R>`;

                const botEmbed = new EmbedBuilder()
                  .setTitle(`Gestion de ${botUser.username}`)
                  .setColor(isExpired ? 0xFF0000 : client.color)
                  .setDescription(`État actuel du bot : **${status}**\n${expirationText}`)
                  .setFooter({ text: `Géré par ${interaction.user.username}`, iconURL: interaction.user.avatarURL() })
                  .setTimestamp();

                const controlButtons = new ActionRowBuilder().addComponents(
                  new ButtonBuilder()
                    .setCustomId(`start_${interaction.id}_${selectedBotId}`)
                    .setLabel('Démarrer')
                    .setDisabled(isRunning)
                    .setStyle(ButtonStyle.Success),
                  new ButtonBuilder()
                    .setCustomId(`restart_${interaction.id}_${selectedBotId}`)
                    .setLabel('Redémarrer')
                    .setDisabled(!isRunning)
                    .setStyle(ButtonStyle.Primary),
                  new ButtonBuilder()
                    .setCustomId(`stop_${interaction.id}_${selectedBotId}`)
                    .setLabel('Arrêter')
                    .setDisabled(!isRunning)
                    .setStyle(ButtonStyle.Danger),
                  new ButtonBuilder()
                    .setCustomId(`back_${interaction.id}`)
                    .setLabel('Retour')
                    .setStyle(ButtonStyle.Secondary)
                );

                await menuInteraction.editReply({ embeds: [botEmbed], components: [controlButtons] });

                const buttonCollector = menuInteraction.message.createMessageComponentCollector({
                  filter: (i) => i.user.id === interaction.user.id,
                  time: ms('2m')
                });

                buttonCollector.on('collect', async (buttonInteraction) => {
                  try {
                    const [action, , botId] = buttonInteraction.customId.split('_');

                    if (action === 'back') {
                      return buttonInteraction.update({ embeds: [initialEmbed], components: [actionRow] });
                    }

                    if (buttonInteraction.deferred || buttonInteraction.replied) {
                      return buttonInteraction.followUp({ content: '❌ 〃 Cette interaction a déjà été traitée.', ephemeral: true });
                    }

                    await buttonInteraction.deferUpdate();

                    client.db.get('SELECT temps FROM Astroia WHERE bot_id = ?', [botId], async (err, row) => {
                      if (err) {
                        console.error('Erreur lors de la vérification du temps d\'expiration :', err);
                        return buttonInteraction.followUp({ content: '❌ 〃 Erreur interne lors de la vérification.', ephemeral: true });
                      }

                      const expired = row && row.temps && Date.now() > row.temps;

                      if (expired && (action === 'start' || action === 'restart')) {
                        return buttonInteraction.followUp({ content: '⛔ 〃 Ce bot est expiré. Vous ne pouvez pas le (re)démarrer.', ephemeral: true });
                      }

                      const command = action === 'stop' ? 'stop' : action === 'start' ? 'start' : 'restart';

                      pm2.connect((err) => {
                        if (err) {
                          console.error(`Erreur lors de la connexion à PM2 pour ${command} :`, err);
                          return buttonInteraction.followUp({ content: `❌ 〃 Erreur lors du ${command} du bot.`, ephemeral: true });
                        }

                        pm2[command](botId, async (err) => {
                          pm2.disconnect();
                          if (err) {
                            console.error(`Erreur lors du ${command} du bot ${botId} :`, err);
                            return buttonInteraction.editReply({ content: `❌ 〃 Erreur lors du ${command} du bot.`, embeds: [], components: [] });
                          }

                          try {
                            const botUser = await client.users.fetch(botId);
                            const actionMsg = command === 'start' ? 'démarré' : command === 'restart' ? 'redémarré' : 'arrêté';
                            return buttonInteraction.editReply({
                              content: `✅ 〃 Le bot ${botUser.username} a été ${actionMsg} avec succès.`,
                              embeds: [],
                              components: []
                            });
                          } catch (fetchError) {
                            console.error(`Erreur lors de la récupération du bot ${botId} :`, fetchError);
                            return buttonInteraction.editReply({
                              content: `✅ 〃 Le bot ${botId} a été ${command} avec succès, mais impossible de récupérer ses informations.`,
                              embeds: [],
                              components: []
                            });
                          }
                        });
                      });
                    });
                  } catch (err) {
                    console.error('Erreur inattendue dans le buttonCollector :', err);
                    await buttonInteraction.followUp({ content: '❌ 〃 Une erreur inattendue est survenue.', ephemeral: true });
                  }
                });

                buttonCollector.on('end', (collected, reason) => {
                  if (reason === 'time') {
                    menuInteraction.editReply({ content: '⏰ 〃 La gestion du bot a expiré.', embeds: [], components: [] }).catch(console.error);
                  }
                });
              });
            });
          });
        } catch (err) {
          console.error('Erreur inattendue dans le menuCollector :', err);
          await menuInteraction.followUp({ content: '❌ 〃 Une erreur inattendue est survenue.', ephemeral: true });
        }
      });

      menuCollector.on('end', (collected, reason) => {
        if (reason === 'time') {
          interaction.editReply({ content: '⏰ 〃 La sélection a expiré.', embeds: [], components: [] }).catch(console.error);
        }
      });
    });
  },
  get data() {
    return {
      name: this.name,
      description: this.description,
      integration_types: [0, 1],
      contexts: [0, 1, 2],
    };
  }
};