const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');

module.exports = {
  name: "claim",
  description: "Ajoute 30 jours à un bot via une clé.",
  category: "Membres", // <-- Cette ligne est cruciale
  run: async (client, interaction) => {
    const cle = interaction.options.getString('clé');
    const botId = interaction.options.getString('botid');

    await interaction.deferReply({ ephemeral: true });

    if (!cle || !botId) {
      return interaction.editReply({ content: '`❌` 〃 Veuillez fournir une clé et un identifiant de bot valides.' });
    }

    // Lecture des clés valides
    let storedCles;
    try {
      storedCles = fs.readFileSync('Clée.txt', 'utf8').trim().split("\n").map(line => line.trim());
    } catch (error) {
      console.error("Erreur lors de la lecture du fichier Clée.txt :", error);
      return interaction.editReply({ content: '`❌` 〃 Une erreur est survenue lors de la lecture des clés.' });
    }

    if (!storedCles.includes(cle)) {
      return interaction.editReply({ content: '`❌` 〃 Clé invalide.' });
    }

    // Récupérer le bot dans la base de données
    client.db.get('SELECT * FROM Astroia WHERE bot_id = ?', [botId], async (err, row) => {
      if (err) {
        console.error('Erreur DB :', err);
        return interaction.editReply({ content: '`❌` 〃 Erreur lors de la récupération du bot.' });
      }

      if (!row) {
        return interaction.editReply({ content: '`❌` 〃 Aucun bot trouvé avec cet identifiant.' });
      }

      // Supprimer la clé du fichier
      storedCles = storedCles.filter(item => item !== cle);
      fs.writeFileSync('Clée.txt', storedCles.join('\n'), 'utf8');

      // Ajoute 30 jours
      const currentTime = parseInt(row.temps) || Date.now();
      const newTime = currentTime + (30 * 24 * 60 * 60 * 1000);

      client.db.run('UPDATE Astroia SET temps = ? WHERE bot_id = ?', [newTime, botId], (updateErr) => {
        if (updateErr) {
          console.error('Erreur lors de la mise à jour :', updateErr);
          return interaction.editReply({ content: '`❌` 〃 Erreur lors de la mise à jour du temps.' });
        }

        const embed = new EmbedBuilder()
          .setColor(client.color)
          .setTitle('✅ Temps ajouté')
          .setDescription(`30 jours ont été ajoutés au bot \`${botId}\`.\n⏳ Temps restant : <t:${Math.floor(newTime / 1000)}:R> (<t:${Math.floor(newTime / 1000)}:f>)`)
          .setFooter({ text: client.config.footer, iconURL: client.user.avatarURL() });

        interaction.editReply({ embeds: [embed] });

        // Log
        client.channels.cache.get(client.config.clee)?.send({
          embeds: [
            new EmbedBuilder()
              .setTitle('Ajout de Temps')
              .setColor(client.color)
              .addFields(
                { name: 'Clé utilisée', value: `\`${cle}\``, inline: false },
                { name: 'Bot ID', value: `\`${botId}\``, inline: false },
                { name: 'Ajouté par', value: `[\`${interaction.user.tag}\`](https://discord.com/users/${interaction.user.id})` },
                { name: 'Date', value: `<t:${Math.floor(Date.now() / 1000)}:R>`, inline: false }
              )
              .setThumbnail(interaction.user.displayAvatarURL())
              .setFooter({ text: client.config.footer, iconURL: client.user.avatarURL() })
          ]
        });

        client.db.run('INSERT INTO clee (clee, bot_id, author, timetamps) VALUES (?, ?, ?, ?)', [cle, botId, interaction.user.id, Date.now()]);
      });
    });
  },

  get data() {
    return new SlashCommandBuilder()
      .setName('claim')
      .setDescription("Ajoute 30 jours d'activation à un bot via une clé.")
      .addStringOption(option =>
        option.setName('clé')
          .setDescription('La clé d’activation.')
          .setRequired(true))
      .addStringOption(option =>
        option.setName('botid')
          .setDescription('L’ID du bot à prolonger.')
          .setRequired(true));
  }
};
