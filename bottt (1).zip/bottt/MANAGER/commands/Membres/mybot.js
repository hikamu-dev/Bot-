const { EmbedBuilder } = require('discord.js');
const { exec } = require('child_process');

module.exports = {
  name: "mybot",
  description: "Liste vos bots personnels",
  category: "Membres",

  run: async (client, interaction) => {
    const ownerId = interaction.user.id;

    // Émojis custom — modifie ici
   const EMOJI = {
      actif: "<:onlyna:1417777717981614163>",   // émoji Actif
      off:   "<:offlyna:1417777770209083527>",  // émoji Hors ligne
      expire:"<:expirelyna:1417778032311144572> ",  // émoji Expiré
    };

    // 1) Récupère une fois la liste PM2 -> Map(name -> status)
    const pm2StatusMap = await new Promise((resolve) => {
      exec('pm2 jlist', (err, stdout) => {
        if (err) return resolve(new Map());
        try {
          const arr = JSON.parse(stdout);
          const map = new Map();
          for (const p of arr) {
            map.set(String(p.name), p?.pm2_env?.status || 'stopped');
          }
          resolve(map);
        } catch {
          resolve(new Map());
        }
      });
    });

    client.db.all('SELECT * FROM Astroia WHERE owner = ?', [ownerId], async (err, botData) => {
      if (err) {
        console.error('Erreur DB mybot:', err);
        return interaction.reply({ content: "`❌` 〃 Une erreur s'est produite en accédant à vos bots.", ephemeral: true });
      }
      if (!botData?.length) {
        return interaction.reply({ content: "`📭` 〃 Vous ne possédez actuellement aucun bot.", ephemeral: true });
      }

      const embed = new EmbedBuilder()
        .setTitle("📋 Liste de vos bots")
        .setColor(client.color)
        .setFooter({ text: `Demandé par ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() })
        .setTimestamp();

      let botList = "";

      for (const [index, botInfo] of botData.entries()) {
        const botId = String(botInfo.bot_id);

        // Tag du bot (optionnel)
        let botUser;
        try { botUser = await client.users.fetch(botId); } catch { botUser = { tag: "Inconnu" }; }
        const botTag = botUser.tag || "Inconnu";

        // Expiration
        const expireMs = Number(botInfo.temps);
        const validExpire = Number.isFinite(expireMs) && expireMs >= 1_700_000_000_000;
        const hasExpired = validExpire ? (expireMs <= Date.now()) : false;

        // 2) Statut basé sur PM2 (nom de process = botId)
        let statut;
        if (hasExpired) {
          statut = `${EMOJI.expire} Expiré`;
        } else {
          const pm2Status = pm2StatusMap.get(botId); // ex: "online", "stopped", "errored", "launching"
          const isRunning = pm2Status === 'online' || pm2Status === 'launching';
          statut = isRunning ? `${EMOJI.actif} Actif` : `${EMOJI.off} Hors ligne`;
        }

        // Expiration en FR (+ relatif géré par Discord)
        let expirationTxt = "—";
        if (validExpire) {
          const tsSec = Math.floor(expireMs / 1000);
          const d = new Date(expireMs);
          const frFull = d.toLocaleString('fr-FR', {
            weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
            hour: '2-digit', minute: '2-digit', timeZone: 'Europe/Brussels'
          }).replace(' à ', ' ');
          expirationTxt = `${frFull} (⌛ <t:${tsSec}:R>)`;
        }

        const invite = `https://discord.com/api/oauth2/authorize?client_id=${botId}&permissions=8&scope=bot%20applications.commands`;

        botList += `**${index + 1}. [${botTag}](${invite})**\n`;
        botList += `┖ **Statut :** ${statut}\n`;
        botList += `┖ **Expiration :** ${expirationTxt}\n\n`;
      }

      embed.setDescription(botList);
return interaction.reply({ embeds: [embed] });
    });
  },

  get data() {
    return {
      name: this.name,
      description: this.description,
      integration_types: [0, 1],
      contexts: [0, 1, 2],
    };
  }
};
