const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js')
const fs = require('fs-extra')
const path = require('path')
const ms = require('ms')
const pm2 = require('pm2')

module.exports = {
  name: "changetoken",
  description: "Change le token d'un bot via une interface interactive.",
  category: "Membres",
  botOwner: false,

  run: async (client, interaction) => {
    const ownerId = interaction.user.id

    client.db.all('SELECT * FROM Astroia WHERE owner = ?', [ownerId], async (err, botList) => {
      if (err || !botList.length) {
        return interaction.reply({ content: '`❌` 〃 Aucun bot trouvé ou erreur de récupération.', ephemeral: true })
      }

      const botOptions = []
      const uniqueIds = new Set()

      for (const bot of botList) {
        if (uniqueIds.has(bot.bot_id)) continue
        const botUser = await client.users.fetch(bot.bot_id).catch(() => null)
        if (!botUser) continue
        uniqueIds.add(bot.bot_id)
        botOptions.push({ label: botUser.tag, value: bot.bot_id })
      }

      if (!botOptions.length) {
        return interaction.reply({ content: '`❌` 〃 Aucun bot valide trouvé.', ephemeral: true })
      }

      const selectMenu = new StringSelectMenuBuilder()
        .setCustomId(`select_bot_${interaction.id}`)
        .setPlaceholder('Choisissez un bot')
        .addOptions(botOptions)

      const row = new ActionRowBuilder().addComponents(selectMenu)

      const embed = new EmbedBuilder()
        .setTitle('Changement de Token')
        .setColor(client.color)
        .setDescription('Sélectionnez le bot dont vous souhaitez changer le token.')
        .setFooter({ text: 'Shelia - Changement de token', iconURL: client.user.avatarURL() })
        .setTimestamp()

      const reply = await interaction.reply({ embeds: [embed], components: [row], ephemeral: true, fetchReply: true })

      const collector = reply.createMessageComponentCollector({
        filter: i => i.user.id === interaction.user.id,
        time: ms('2m')
      })

      collector.on('collect', async (menuInteraction) => {
        if (!menuInteraction.isStringSelectMenu() || !menuInteraction.values.length) {
          return menuInteraction.reply({ content: '`❌` 〃 Sélection invalide.', ephemeral: true })
        }

        const botId = menuInteraction.values[0]
        const botData = await client.db.get('SELECT * FROM Astroia WHERE bot_id = ?', [botId])
        if (!botData) {
          return menuInteraction.reply({ content: '`❌` 〃 Bot introuvable.', ephemeral: true })
        }

        if (botData.temps < Date.now()) {
          return menuInteraction.reply({ content: '`⛔` 〃 Bot expiré. Token non modifiable.', ephemeral: true })
        }

        const botUser = await client.users.fetch(botId).catch(() => null)
        const botName = botUser ? botUser.tag : botId

        const btnModal = new ButtonBuilder()
          .setCustomId(`modal_${interaction.id}_${botId}`)
          .setLabel('Entrer un nouveau token')
          .setStyle(ButtonStyle.Primary)

        const btnBack = new ButtonBuilder()
          .setCustomId(`back_${interaction.id}`)
          .setLabel('Retour')
          .setStyle(ButtonStyle.Secondary)

        const buttons = new ActionRowBuilder().addComponents(btnModal, btnBack)

        const botEmbed = new EmbedBuilder()
          .setTitle(`Changer le token de \`${botName}\``)
          .setColor(client.color)
          .setDescription('Cliquez sur "Entrer un nouveau token" pour modifier.')
          .setFooter({ text: `Géré par ${interaction.user.username}`, iconURL: interaction.user.avatarURL() })
          .setTimestamp()

        await menuInteraction.update({ embeds: [botEmbed], components: [buttons] })

        const buttonCollector = menuInteraction.message.createMessageComponentCollector({
          filter: i => i.user.id === interaction.user.id,
          time: ms('2m')
        })

        buttonCollector.on('collect', async (btnInteraction) => {
          const [type, , selectedBotId] = btnInteraction.customId.split('_')

          if (type === 'back') {
            return btnInteraction.update({ embeds: [embed], components: [row] })
          }

          if (type === 'modal') {
            const modal = new ModalBuilder().setCustomId(`tokenmodal_${interaction.id}_${selectedBotId}`).setTitle('Nouveau Token')
            const input = new TextInputBuilder()
              .setCustomId('nouveau_token')
              .setLabel('Token')
              .setStyle(TextInputStyle.Short)
              .setPlaceholder('Entrez le nouveau token')
              .setRequired(true)

            modal.addComponents(new ActionRowBuilder().addComponents(input))
            await btnInteraction.showModal(modal)

            const filter = i => i.customId === `tokenmodal_${interaction.id}_${selectedBotId}` && i.user.id === interaction.user.id
            const modalSubmit = await btnInteraction.awaitModalSubmit({ filter, time: ms('2m') }).catch(() => null)

            if (!modalSubmit) return btnInteraction.followUp({ content: '⏰ 〃 Temps écoulé pour entrer le token.', ephemeral: true })

            await modalSubmit.deferReply({ ephemeral: true })

            const newToken = modalSubmit.fields.getTextInputValue('nouveau_token').trim()
            const { Client, GatewayIntentBits } = require('discord.js')

            const tempClient = new Client({ intents: [GatewayIntentBits.Guilds] })

            let tokenIsValid = true
            await tempClient.login(newToken).catch(() => tokenIsValid = false)
            if (tokenIsValid) {
              tempClient.destroy()
            } else {
              return modalSubmit.followUp({ content: '`❌` 〃 Token invalide.', ephemeral: true })
            }

            const configPath = path.join(`/home/ubuntu/bot/${selectedBotId}/config/config.js`)

            if (!fs.existsSync(configPath)) {
              return modalSubmit.followUp({ content: '`❌` 〃 Fichier de config introuvable.', ephemeral: true })
            }

            let config
            try {
              delete require.cache[require.resolve(configPath)]
              config = require(configPath)
            } catch {
              return modalSubmit.followUp({ content: '`❌` 〃 Erreur de chargement de config.', ephemeral: true })
            }

            if (!config.buyers || !Array.isArray(config.buyers) || !config.buyers.includes(interaction.user.id)) {
              return modalSubmit.followUp({ content: '`❌` 〃 Non autorisé à modifier ce bot.', ephemeral: true })
            }

            config.token = newToken
            fs.writeFileSync(configPath, `module.exports = ${JSON.stringify(config, null, 2)};`)

            pm2.connect((err) => {
              if (err) {
                return modalSubmit.followUp({ content: '`❌` 〃 Connexion à PM2 échouée.', ephemeral: true })
              }

              pm2.list((err, list) => {
                if (err || !list.find(p => p.name === selectedBotId)) {
                  pm2.disconnect()
                  return modalSubmit.followUp({ content: '`❌` 〃 Bot non trouvé dans PM2.', ephemeral: true })
                }

                pm2.restart(selectedBotId, (err) => {
                  pm2.disconnect()
                  if (err) {
                    return modalSubmit.followUp({ content: '`❌` 〃 Redémarrage échoué.', ephemeral: true })
                  }

                  modalSubmit.followUp({ content: `✅ 〃 Bot \`${selectedBotId}\` redémarré avec le nouveau token.`, ephemeral: true })

                  const logChannel = client.channels.cache.get(client.config.changetoken)
                  if (logChannel) {
                    const logEmbed = new EmbedBuilder()
                      .setTitle('🔐 Token mis à jour')
                      .setColor(client.color)
                      .addFields(
                        { name: '👤 Utilisateur', value: `<@${interaction.user.id}> (\`${interaction.user.id}\`)` },
                        { name: '🤖 Bot', value: `\`${selectedBotId}\`` },
                        { name: '📅 Date', value: `<t:${Math.floor(Date.now() / 1000)}:F>` }
                      )
                      .setFooter({ text: client.config.footer, iconURL: client.user.avatarURL() })
                      .setTimestamp()

                    logChannel.send({ embeds: [logEmbed] })
                  }
                })
              })
            })
          }
        })
      })

      collector.on('end', (_, reason) => {
        if (reason === 'time') {
          interaction.editReply({ content: '⏰ 〃 Temps expiré.', embeds: [], components: [] }).catch(() => {})
        }
      })
    })
  },

  get data() {
    return {
      name: this.name,
      description: this.description,
      integration_types: [0, 1],
      contexts: [0, 1, 2]
    }
  }
}
