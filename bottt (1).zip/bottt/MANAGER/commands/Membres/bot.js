const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: "info-bot",
  description: "Afficher les bots d'un membre.",
  category: "Membres",

  run: async (client, interaction) => {
    const user = interaction.options.getUser('user');
    const userId = user.id;

    client.db.all('SELECT * FROM Astroia WHERE owner = ?', [userId], async (err, rows) => {
      if (err) {
        console.error('Erreur lors de la récupération des bots :', err);
        return interaction.reply({
          content: `\`❌\` 〃 Une erreur est survenue lors de la récupération des données.`,
          ephemeral: true
        });
      }

      if (rows.length === 0) {
        return interaction.reply({
          content: `\`❌\` 〃 Ce membre ne possède actuellement aucun bot.`,
          ephemeral: true
        });
      }

      const embed = new EmbedBuilder()
        .setTitle(`📦 Bots enregistrés par ${user.tag}`)
        .setColor(client.color)
        .setThumbnail(user.displayAvatarURL())
        .setFooter({ text: `Total : ${rows.length} bot${rows.length > 1 ? 's' : ''}`, iconURL: client.user.displayAvatarURL() })
        .setTimestamp();

      const description = await Promise.all(rows.map(async (row, index) => {
        const botUser = await client.users.fetch(row.bot_id).catch(() => null);
        const botTag = botUser ? botUser.tag : "Inconnu";
        const botId = row.bot_id;
        const timestamp = Math.floor(row.temps / 1000);
        const timeRemaining = row.temps - Date.now();
        const isExpired = timeRemaining < 1000;
        const etat = isExpired ? "❌ Expiré" : "✅ Actif";
        const expirationText = `<t:${timestamp}:R>`;

        return (
          `\`${index + 1}.\` **[${botTag}](https://discord.com/oauth2/authorize?client_id=${botId}&permissions=8&scope=bot%20applications.commands)**\n` +
          `> 📌 État : \`${etat}\`\n` +
          `> 🆔 \`${botId}\`\n` +
          `> 📅 Expiration : ${expirationText}\n`
        );
      }));

      embed.setDescription(description.join('\n'));

      return interaction.reply({ embeds: [embed], ephemeral: true });
    });
  },

  get data() {
    return {
      name: this.name,
      description: this.description,
      integration_types: [0, 1],
      contexts: [0, 1, 2],
      options: [
        {
          name: "user",
          description: "L'Owner du bot.",
          required: true,
          type: 6
        },
      ]
    };
  }
};
