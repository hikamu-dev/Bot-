const fs = require('fs-extra');
const path = require('path');
const { exec } = require('child_process');
const { EmbedBuilder } = require('discord.js');
const crypto = require('crypto');

module.exports = {
  name: "recup",
  description: "Génère ou récupère un code pour un bot.",
  category: "Membres",
  botOwner: false,

  run: (client, interaction) => {
    const botId = interaction.options.getString('bot-id');
    const code = interaction.options.getString('code');

    client.db.get('SELECT * FROM Astroia WHERE bot_id = ?', [botId], (err, botData) => {
      if (err) {
        console.error("Erreur lors de la récupération des données du bot :", err);
        return interaction.reply({ content: `\`❌\` 〃 Une erreur est survenue lors de la récupération des données du bot.`, ephemeral: true });
      }

      if (!botData) {
        return interaction.reply({ content: `\`❌\` 〃 Aucun bot trouvé avec l'ID \`${botId}\`.`, ephemeral: true });
      }

      const configFilePath = path.join(`/home/ubuntu/bot/${botId}/config/config.js`);
      if (!fs.existsSync(configFilePath)) {
        return interaction.reply({ content: `\`❌\` 〃 Fichier de configuration introuvable.`, ephemeral: true });
      }

      let botConfig = require(configFilePath);

      if (code) {
        client.db.get('SELECT * FROM RecoveryCodes WHERE bot_id = ? AND code = ?', [botId, code], (err, codeData) => {
          if (err) {
            console.error("Erreur lors de la récupération du code :", err);
            return interaction.reply({ content: `\`❌\` 〃 Une erreur est survenue lors de la récupération du code.`, ephemeral: true });
          }

          if (!codeData) {
            return interaction.reply({ content: `\`❌\` 〃 Code invalide ou introuvable.`, ephemeral: true });
          }

          const originalBuyerId = botData.owner;
          const isBuyer = interaction.user.id === originalBuyerId;

          if (!botConfig.buyers) {
            botConfig.buyers = [];
          }

          botConfig.buyers.push(interaction.user.id);
          botConfig.buyers = [...new Set(botConfig.buyers)];
          fs.writeFileSync(configFilePath, `module.exports = ${JSON.stringify(botConfig, null, 2)};`);

          client.db.run('DELETE FROM RecoveryCodes WHERE code = ?', [code], (err) => {
            if (err) {
              console.error("Erreur lors de la suppression du code :", err);
              return interaction.reply({ content: `\`❌\` 〃 Une erreur est survenue lors de la suppression du code.`, ephemeral: true });
            }

            client.db.run('UPDATE Astroia SET owner = ? WHERE bot_id = ?', [interaction.user.id, botId], (err) => {
              if (err) {
                console.error("Erreur lors de la mise à jour du propriétaire du bot :", err);
                return interaction.reply({ content: `\`❌\` 〃 Une erreur est survenue lors de la mise à jour du propriétaire du bot.`, ephemeral: true });
              }

              const logEmbed = new EmbedBuilder()
                .setTitle("🔄 Bot récupéré")
                .setColor(client.color)
                .addFields(
                  { name: "👤 Utilisateur", value: `<@${interaction.user.id}> (\`${interaction.user.id}\`)` },
                  { name: "🤖 Bot ID", value: `\`${botId}\`` },
                  { name: "⏰ Date", value: `<t:${Math.floor(Date.now() / 1000)}:F>` }
                )
                .setFooter({ text: client.config.footer, iconURL: client.user.avatarURL() })
                .setTimestamp();

              const logChannel = client.channels.cache.get(client.config.logChannel);
              if (logChannel) logChannel.send({ embeds: [logEmbed] });

              exec(`pm2 restart ${botId}`, (error, stdout, stderr) => {
                if (error) {
                  console.error(`Erreur lors du redémarrage du bot ${botId} :`, error);
                } else {
                  console.log(`Bot ${botId} redémarré avec succès.`);
                }
              });

              return interaction.reply({ content: `\`✅\` 〃 Bot \`${botId}\` récupéré avec succès.`, ephemeral: true });
            });
          });
        });
      } else {
        const originalBuyerId = botData.owner;
        const isBuyer = interaction.user.id === originalBuyerId;

        if (!isBuyer) {
          return interaction.reply({ content: `\`❌\` 〃 Vous devez être le propriétaire du bot pour générer un code.`, ephemeral: true });
        }

        client.db.get('SELECT * FROM RecoveryCodes WHERE bot_id = ?', [botId], (err, codeData) => {
          if (err) {
            console.error("Erreur lors de la récupération du code :", err);
            return interaction.reply({ content: `\`❌\` 〃 Une erreur est survenue lors de la récupération du code.`, ephemeral: true });
          }

          if (codeData) {
            return interaction.reply({ content: `\`❌\` 〃 Un code existe déjà pour ce bot.`, ephemeral: true });
          }

          const generatedCode = crypto.randomBytes(8).toString('hex');
          client.db.run(
            'INSERT INTO RecoveryCodes (bot_id, code, created_at) VALUES (?, ?, ?)',
            [botId, generatedCode, Math.floor(Date.now() / 1000)],
            (err) => {
              if (err) {
                console.error("Erreur lors de l'insertion du code :", err);
                return interaction.reply({ content: `\`❌\` 〃 Une erreur est survenue lors de la génération du code.`, ephemeral: true });
              }

              const embed = new EmbedBuilder()
                .setTitle("🔑 Code de récupération généré")
                .setColor(client.color)
                .addFields(
                  { name: "🤖 Bot ID", value: `\`${botId}\`` },
                  { name: "🔒 Code", value: `\`${generatedCode}\`` },
                  { name: "⚠️ Attention", value: "Gardez ce code en sécurité et ne le partagez pas." }
                )
                .setFooter({ text: client.config.footer, iconURL: client.user.avatarURL() })
                .setTimestamp();

              return interaction.reply({ embeds: [embed], ephemeral: true });
            }
          );
        });
      }
    });
  },

  get data() {
    return {
      name: this.name,
      description: this.description,
      integration_types: [0, 1],
      contexts: [0, 1, 2],
      options: [
        {
          name: "bot-id",
          description: "L'ID du bot à récupérer",
          type: 3,
          required: true
        },
        {
          name: "code",
          description: "Le code de récupération (facultatif)",
          type: 3,
          required: false
        }
      ]
    };
  }
};
