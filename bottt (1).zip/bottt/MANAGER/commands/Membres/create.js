const { exec } = require('child_process');
const Discord = require('discord.js');
const fs = require('fs-extra');

module.exports = {
  name: "create",
  description: "Crée un bot perso via token et clé",
  category: "Membres",

  run: async (client, interaction) => {
    try {
      const token = interaction.options.getString('token');
      const cle = interaction.options.getString('clé').trim();

      await interaction.deferReply({ ephemeral: true });

      if (!token || !cle) {
        return interaction.editReply({ content: '`❌` 〃 Vous devez fournir un token et une clé valides.' });
      }

      const bot = new Discord.Client({ intents: [377744] });
      await interaction.editReply({ content: '\`🔍\` 〃 Connexion au bot en cours...' });

      try {
        await bot.login(token);
      } catch (err) {
        console.error('Erreur lors de la connexion du bot :', err);
        return interaction.editReply({ content: '`❌` 〃 Token invalide !' });
      }

      if (!bot.user) {
        return interaction.editReply({ content: '`❌` 〃 Échec de la connexion du bot.' });
      }

      const botId = bot.user.id;
      const owner = interaction.user;
      const temps = '30d';
      const parsedTime = parseTime(temps);
      if (!parsedTime) {
        return interaction.editReply({ content: '`❌` 〃 Format de temps incorrect.' });
      }

      const expirationDate = Date.now() + parsedTime;

      await interaction.editReply({ content: '\`🧾\` 〃 Vérification de la clé...' });

      let clesEnvoyees;
      try {
        clesEnvoyees = fs.readFileSync('Clée.txt', 'utf8').trim().split("\n").map(line => line.trim());
      } catch (err) {
        console.error("Erreur lecture clés envoyées :", err);
        return interaction.editReply({ content: '`❌` 〃 Erreur lors de la lecture des clés envoyées.' });
      }

      const cleValide = clesEnvoyees.includes(cle);

      if (!cleValide) {
        return interaction.editReply({ content: '`❌` 〃 Clé d\'activation invalide.' });
      }

// Normalisation pour éviter les bugs de casse ou espaces
const cleanKey = cle.trim().toLowerCase();
const updatedCles = clesEnvoyees
  .map(k => k.trim().toLowerCase())
  .filter(entry => entry && entry !== cleanKey);

fs.writeFileSync('Clée.txt', updatedCles.join('\n') + '\n', 'utf8');


      const folderPath = `/home/ubuntu/bot/${botId}`;
      await interaction.editReply({ content: '\`📁\` 〃 Création du dossier pour le bot...' });

      exec(`mkdir ${folderPath}`, (error) => {
        if (error) {
          console.error('Erreur création dossier :', error);
          return interaction.editReply({ content: '`❌` 〃 Erreur lors de la création du dossier.' });
        }

        interaction.editReply({ content: '\`📦\` 〃 Copie des fichiers de base...' });

        fs.copy('/home/ubuntu/Update', folderPath, async (err) => {
          if (err) {
            console.error('Erreur copie :', err);
            return interaction.editReply({ content: '`❌` 〃 Erreur lors de la copie des fichiers.' });
          }

          fs.mkdirSync(`${folderPath}/config`);

          const botData = {
            token,
            bot_id: botId,
            buyers: [owner.id],
            prefix: "+",
            panel: client.config.api,
            default_color: "#FFC133"
          };

          fs.writeFileSync(`${folderPath}/config/config.js`, `module.exports = ${JSON.stringify(botData, null, 2)};`);

          interaction.editReply({ content: '\`📥\` 〃 Installation des dépendances, cela peut prendre quelques instants...' });

          exec(`cd ${folderPath} && npm i && npm install uuid && npm rebuild better-sqlite3 && pm2 start index.js --name ${botId}`, async (err) => {
            if (err) {
              console.error('Erreur installation dépendances :', err);
              return interaction.editReply({ content: '`❌` 〃 Erreur lors de l\'installation des dépendances.' });
            }

            const botInvite = await bot.generateInvite({ scopes: ['applications.commands', 'bot'] });
            const inviteButton = new Discord.ActionRowBuilder().addComponents(
              new Discord.ButtonBuilder()
                .setLabel('Inviter le bot')
                .setStyle(Discord.ButtonStyle.Link)
                .setURL(botInvite)
            );

            const logEmbed = new Discord.EmbedBuilder()
              .setTitle('🛠️ Clé activée - Bot créé')
              .setColor(client.color)
              .setThumbnail(owner.displayAvatarURL({ dynamic: true }))
              .addFields(
                { name: '🧠 Action', value: '`Création d\'un bot`', inline: true },
                { name: '👤 Activeur', value: `<@${owner.id}> | \`${owner.id}\``, inline: true },
                { name: '🔑 Clé utilisée', value: `\`${cle}\`` },
                { name: '🤖 Bot', value: `\`${bot.user.tag}\``, inline: true },
                { name: '🆔 ID du Bot', value: `\`${bot.user.id}\``, inline: true },
                { name: '🔗 Lien d\'invitation', value: `${botInvite}` },
                { name: '📅 Date', value: `<t:${Math.floor(Date.now() / 1000)}:F> (<t:${Math.floor(Date.now() / 1000)}:R>)` }
              )
              .setFooter({ text: client.config.footer, iconURL: client.user.displayAvatarURL() });

            client.channels.cache.get(client.config.clee)?.send({
              embeds: [logEmbed],
              components: [inviteButton]
            });

            client.db.run('INSERT INTO Astroia (bot_id, owner, temps) VALUES (?, ?, ?)', [botId, owner.id, expirationDate]);
            client.db.run('INSERT INTO clee (clee, bot_id, author, timetamps) VALUES (?, ?, ?, ?)', [cle, botId, owner.id, Date.now()]);

            try {
              await owner.send(`\`✅\` 〃 Votre bot avec l'ID \`${botId}\` a été créé avec succès et est maintenant opérationnel.`);
            } catch (err) {
              console.error("Erreur DM :", err);
            }

            return interaction.editReply({ content: '`✅` 〃 Le bot a été **créé**, **configuré** et **démarré** avec succès !' });
          });
        });
      });

    } catch (error) {
      console.error("Erreur globale :", error);
      return interaction.followUp({ content: `\`❌\` 〃 Une erreur est survenue lors de la création du bot.`, ephemeral: true });
    }
  },

  get data() {
    return new Discord.SlashCommandBuilder()
      .setName('create')
      .setDescription('Créer un bot Discord avec un token et une clé d\'activation.')
      .addStringOption(option =>
        option.setName('token')
          .setDescription('Le token du bot à créer.')
          .setRequired(true))
      .addStringOption(option =>
        option.setName('clé')
          .setDescription('La clé d\'activation.')
          .setRequired(true));
  }
};

function parseTime(str) {
  const regex = /(\d+)([smhdwy])/;
  const match = str.match(regex);
  if (!match) return null;
  const val = parseInt(match[1]);
  const unit = match[2];
  const unitToMs = {
    s: 1000,
    m: 60000,
    h: 3600000,
    d: 86400000,
    w: 604800000,
    y: 31536000000,
  };
  return unitToMs[unit] ? val * unitToMs[unit] : null;
}