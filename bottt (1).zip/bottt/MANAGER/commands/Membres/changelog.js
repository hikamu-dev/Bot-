const { EmbedBuilder, ButtonBuilder, ActionRowBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  name: 'changelog',
  description: 'Liste tous les changelog avec une page par changelog.',
  botOwner: false,
  category: "Membres",
  run: async (client, interaction) => {
    const patchnoteChannelId = '1365769278820974602'; // Verify this ID
    const messagesPerPage = 1; // Une page par changelog

    try {
      // Log the channel fetch attempt
      console.log(`Fetching channel with ID: ${patchnoteChannelId}`);
      const patchnoteChannel = await client.channels.fetch(patchnoteChannelId, { cache: true, force: false });

      if (!patchnoteChannel) {
        console.error(`Channel with ID ${patchnoteChannelId} not found.`);
        return interaction.reply({ content: `\`❌\` 〃 Le salon des changelog est introuvable.`, ephemeral: true });
      }

      // Verify channel type (should be a text-based channel)
      if (!patchnoteChannel.isTextBased()) {
        console.error(`Channel ${patchnoteChannelId} is not a text-based channel.`);
        return interaction.reply({ content: `\`❌\` 〃 Le salon des changelog n'est pas un salon textuel.`, ephemeral: true });
      }

      const fetchedMessages = await patchnoteChannel.messages.fetch({ limit: 100 });
      const patchNotes = fetchedMessages.map(message => ({
        content: message.content.trim(),
        date: message.createdAt.toLocaleDateString('fr-FR', {
          day: '2-digit',
          month: '2-digit',
          year: 'numeric'
        }), // Format DD/MM/YYYY
      }));

      if (patchNotes.length === 0) {
        return interaction.reply({ content: `\`❌\` 〃 Aucun changelog trouvé dans le salon.`, ephemeral: true });
      }

      const generateEmbed = (pageNumber) => {
        const note = patchNotes[pageNumber - 1]; // Une page = un changelog
        let patchContent = note.content || "*Aucun contenu pour ce changelog*";

        // Truncate content to 1024 characters to comply with Discord's limit
        if (patchContent.length > 1024) {
          patchContent = patchContent.substring(0, 1021) + '...';
        }

        const embed = new EmbedBuilder()
          .setTitle(`📜 Changelog ${pageNumber}`)
          .setColor(client.color)
          .setDescription(patchContent)
          .setFooter({ text: `Page ${pageNumber} sur ${patchNotes.length} | Date: ${note.date}` })
          .setTimestamp();

        return embed;
      };

      let currentPage = 1;
      const maxPage = patchNotes.length; // Une page par changelog

      const backButton = new ButtonBuilder()
        .setCustomId('prev_page')
        .setLabel('◀️')
        .setStyle(ButtonStyle.Primary)
        .setDisabled(true);

      const nextButton = new ButtonBuilder()
        .setCustomId('next_page')
        .setLabel('▶️')
        .setStyle(ButtonStyle.Primary)
        .setDisabled(maxPage <= 1);

      const actionRow = new ActionRowBuilder().addComponents(backButton, nextButton);

      const embedMessage = await interaction.reply({
        embeds: [generateEmbed(currentPage)],
        components: [actionRow],
        fetchReply: true,
        ephemeral: true,
      });

      const collector = embedMessage.createMessageComponentCollector({
        time: 120000,
      });

      collector.on('collect', async (buttonInteraction) => {
        if (buttonInteraction.user.id !== interaction.user.id) {
          return buttonInteraction.reply({ content: `\`❌\` 〃 Vous ne pouvez pas utiliser ces boutons.`, ephemeral: true });
        }

        if (buttonInteraction.customId === 'prev_page' && currentPage > 1) {
          currentPage--;
        } else if (buttonInteraction.customId === 'next_page' && currentPage < maxPage) {
          currentPage++;
        }

        backButton.setDisabled(currentPage === 1);
        nextButton.setDisabled(currentPage === maxPage);

        await buttonInteraction.update({
          embeds: [generateEmbed(currentPage)],
          components: [new ActionRowBuilder().addComponents(backButton, nextButton)],
        });
      });

      collector.on('end', () => {
        backButton.setDisabled(true);
        nextButton.setDisabled(true);
        embedMessage.edit({ components: [new ActionRowBuilder().addComponents(backButton, nextButton)] });
      });

    } catch (error) {
      console.error(`Error fetching patchnotes for channel ${patchnoteChannelId}:`, error);
      return interaction.reply({ content: `\`❌\` 〃 Une erreur est survenue lors de la récupération des patchnotes : ${error.message}`, ephemeral: true });
    }
  },
  get data() {
    return {
      name: this.name,
      description: this.description,
      integration_types: [0, 1],
      contexts: [0, 1, 2],
    };
  },
};