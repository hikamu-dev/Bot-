const { exec } = require('child_process');
const Discord = require('discord.js');
const fs = require('fs-extra');

module.exports = {
  name: "stop",
  description: "Arrête un bot existant",
  botOwner: true,
  run: async (client, interaction) => {
    await interaction.deferReply({ ephemeral: true });
    const botId = interaction.options.getString('botid');

    try {
      // Check if bot exists in the database
      const botData = client.db.get('SELECT * FROM Astroia WHERE bot_id = ?', [botId]);
      if (!botData) {
        return interaction.editReply({ content: '`❌` 〃 Aucun bot trouvé avec cet identifiant !', ephemeral: true });
      }

      // Check if user is authorized (owner or buyer)
      const configPath = `/root/bot/${botId}/config/config.js`;
      if (!fs.existsSync(configPath)) {
        return interaction.editReply({ content: '`❌` 〃 Configuration du bot introuvable !', ephemeral: true });
      }


      interaction.editReply({ content: `\`✅\` 〃 Arrêt du bot en cours...`, ephemeral: true });

      // Start the bot using pm2
      exec(`cd /root/bot/${botId} && pm2 stop ${botId}`, (err, stdout, stderr) => {
        if (err) {
          console.error('Erreur lors du démarrage du bot :', err);
          return interaction.editReply({ content: `\`❌\` Une erreur est survenue lors de l\'arrêt du bot.`, ephemeral: true });
        }

        interaction.editReply({ content: '`✅` 〃 Bot Arrêter avec succès !', ephemeral: true });
        console.log(`Bot ${botId} Arrêter par ${interaction.user.username}`);
      });
    } catch (error) {
      console.error('Erreur lors du démarrage du bot :', error);
      interaction.editReply({ content: `\`❌\` 〃 Une erreur est survenue lors de l\'arrêt du bot.`, ephemeral: true });
    }
  },
  get data() {
    return {
      name: this.name,
      description: this.description,
      integration_types: [0, 1],
      contexts: [0, 1, 2],
      options: [
        {
          name: 'botid',
          description: 'L\'ID du bot à démarrer',
          required: true,
          type: 3
        }
      ]
    };
  }
};