// updateall_admin.js
const { SlashCommandBuilder } = require('discord.js');
const fs = require('fs-extra');
const path = require('path');
const { promisify } = require('util');
const { exec } = require('child_process');
const execAsync = promisify(exec);

module.exports = {
  name: "updateall",
  description: "Met à jour tous les bots (miroir commands & events) et redémarre via PM2.",
  botOwner: true,

  run: async (client, interaction) => {
    await interaction.deferReply({ ephemeral: true });

    const botDir = '/home/ubuntu/bot';
    const updateDir = '/home/ubuntu/Update';

    // Répertoires de référence à synchroniser en miroir
    const updateCommandsDir = path.join(updateDir, 'source', 'commands');
    const updateEventsDir   = path.join(updateDir, 'source', 'events');

    // --- Helpers ---
    async function listFilesRecursive(root) {
      const files = [];
      async function walk(dir) {
        const entries = await fs.readdir(dir).catch(() => []);
        for (const name of entries) {
          const full = path.join(dir, name);
          const rel = path.relative(root, full);
          const st = await fs.lstat(full).catch(() => null);
          if (!st) continue;
          if (st.isDirectory()) {
            await walk(full);
          } else if (st.isFile()) {
            files.push(rel.split(path.sep).join('/'));
          }
        }
      }
      const exists = await fs.pathExists(root);
      if (exists) await walk(root);
      return new Set(files);
    }

    async function removeEmptyDirs(dir) {
      if (!(await fs.pathExists(dir))) return;
      const entries = await fs.readdir(dir).catch(() => []);
      for (const name of entries) {
        const full = path.join(dir, name);
        const st = await fs.lstat(full).catch(() => null);
        if (st && st.isDirectory()) {
          await removeEmptyDirs(full);
        }
      }
      const after = await fs.readdir(dir).catch(() => []);
      if (after.length === 0) await fs.remove(dir);
    }

    // Synchronisation "miroir" : supprime dans dst ce qui n'existe pas dans src, copie/écrase le reste
    async function syncMirror(src, dst) {
      if (!(await fs.pathExists(src))) return; // si le dossier source n’existe pas, on ne fait rien (pas d’effacement)
      await fs.ensureDir(dst);

      const [srcFiles, dstFiles] = await Promise.all([
        listFilesRecursive(src),
        listFilesRecursive(dst)
      ]);

      // supprimer dans dst les fichiers absents de src
      for (const rel of dstFiles) {
        if (!srcFiles.has(rel)) {
          await fs.remove(path.join(dst, rel));
        }
      }

      // copier/écraser depuis src
      await fs.copy(src, dst, { overwrite: true, errorOnExist: false });

      // nettoyer dossiers vides
      await removeEmptyDirs(dst);
    }

    try {
      const botDirExists = await fs.pathExists(botDir);
      const updateDirExists = await fs.pathExists(updateDir);
      if (!botDirExists || !updateDirExists) {
        return interaction.editReply('`❌` 〃 Dossier des bots ou dossier Update introuvable.');
      }

      const botFolders = (await fs.readdir(botDir))
        .filter(name => {
          try {
            return fs.lstatSync(path.join(botDir, name)).isDirectory();
          } catch {
            return false;
          }
        });

      if (botFolders.length === 0) {
        return interaction.editReply('`📭` 〃 Aucun bot à mettre à jour.');
      }

      let successCount = 0;
      let errorCount = 0;
      const logs = [];

      for (const botId of botFolders) {
        const targetPath = path.join(botDir, botId);

        // Cibles à synchroniser en miroir
        const targetCommandsDir = path.join(targetPath, 'source', 'commands');
        const targetEventsDir   = path.join(targetPath, 'source', 'events');

        try {
          // 1) synchroniser en miroir source/commands
          await syncMirror(updateCommandsDir, targetCommandsDir);

          // 1 bis) synchroniser en miroir source/events
          await syncMirror(updateEventsDir, targetEventsDir);

          // 2) copier le reste de Update vers le bot (en excluant source/commands et source/events déjà traités)
          await fs.copy(updateDir, targetPath, {
            overwrite: true,
            errorOnExist: false,
            filter: (srcFile) => {
              const rel = path.relative(updateDir, srcFile).split(path.sep).join('/');
              return !rel.startsWith('source/commands') && !rel.startsWith('source/events');
            }
          });

          // 3) dépendances + restart PM2
          const hasLock = await fs.pathExists(path.join(targetPath, 'package-lock.json'));
          const installCmd = hasLock ? 'npm ci --no-audit --quiet' : 'npm i --no-audit --quiet';
          await execAsync(installCmd, { cwd: targetPath, maxBuffer: 1024 * 1024 * 10 });
          await execAsync(`pm2 restart ${botId}`, { cwd: targetPath, maxBuffer: 1024 * 1024 * 10 });

          successCount++;
          logs.push(`✅ ${botId}`);
        } catch (err) {
          errorCount++;
          logs.push(`❌ ${botId} → ${err?.message || err}`);
        }
      }

      const header = `\`✅\` 〃 Mise à jour terminée : **${successCount} bot(s)** mis à jour, **${errorCount} erreur(s)**.`;
      const detail = logs.length ? `\n\n**Détails :**\n• ${logs.join('\n• ')}` : '';
      return interaction.editReply((header + detail).slice(0, 1900));
    } catch (e) {
      console.error('[updateall] Fatal:', e);
      return interaction.editReply('`❌` 〃 Erreur inattendue durant la mise à jour.');
    }
  },

  data: new SlashCommandBuilder()
    .setName('updateall')
    .setDescription('MAJ de tous les bots : miroir commands & events, copie du reste, restart PM2.')
};
