const Discord = require("discord.js");
const fs = require("fs-extra");
const path = require("path");
const { exec } = require("child_process");

module.exports = {
  name: "coinbotdelete",
  description: "Supprime un bot coin (dossier + base de données)",
  botOwner: true,

  run: async (client, interaction) => {
    try {
      const botId = interaction.options.getString("id");
      if (!botId) return interaction.reply({ content: "❌ Vous devez fournir un **ID de bot**.", ephemeral: true });

      await interaction.deferReply({ ephemeral: true });

      const folderPath = `/home/ubuntu/CoinBots/${botId}`;
      let folderExists = fs.existsSync(folderPath);
      let removedFiles = false;

      // Vérifie si le dossier existe
      if (folderExists) {
        await interaction.editReply({ content: `🗑️ Suppression du dossier du bot **${botId}**...` });
        try {
          // Stoppe le bot si actif sous PM2
          exec(`pm2 delete coin-${botId}`, (err) => {
            if (err) console.warn(`⚠️ Impossible de supprimer le process PM2 pour ${botId} (peut être déjà supprimé).`);
          });

          // Supprime le dossier complet
          await fs.remove(folderPath);
          removedFiles = true;
        } catch (err) {
          console.error("Erreur suppression dossier :", err);
        }
      }

      // Supprime de la base de données même si le dossier n’existe plus
      try {
        client.db.run("DELETE FROM Astroia WHERE bot_id = ?", [botId], function (err) {
          if (err) {
            console.error("Erreur suppression DB :", err);
            return interaction.editReply({ content: "❌ Erreur lors de la suppression dans la base de données." });
          }

          const embed = new Discord.EmbedBuilder()
            .setTitle("💀 Bot coin supprimé")
            .setColor("#ff3333")
            .addFields(
              { name: "🆔 ID du Bot", value: `\`${botId}\``, inline: true },
              { name: "📁 Dossier supprimé", value: removedFiles ? "✅ Oui" : "⚠️ Non trouvé", inline: true }
            )
            .setTimestamp();

          client.channels.cache.get(client.config.clee)?.send({ embeds: [embed] });

          interaction.editReply({
            content: removedFiles
              ? `✅ Bot **${botId}** supprimé du disque et de la base.`
              : `✅ Bot **${botId}** supprimé de la base (aucun dossier trouvé).`,
          });
        });
      } catch (err) {
        console.error("Erreur suppression base :", err);
        interaction.editReply({ content: "❌ Erreur interne lors de la suppression." });
      }
    } catch (error) {
      console.error("Erreur globale :", error);
      interaction.reply({ content: "❌ Erreur interne lors de la suppression du bot coin.", ephemeral: true });
    }
  },

  get data() {
    return new Discord.SlashCommandBuilder()
      .setName("coinbotdelete")
      .setDescription("Supprimer un bot coin (fichier + DB).")
      .addStringOption((option) =>
        option
          .setName("id")
          .setDescription("L'ID du bot coin à supprimer.")
          .setRequired(true)
      );
  },
};
