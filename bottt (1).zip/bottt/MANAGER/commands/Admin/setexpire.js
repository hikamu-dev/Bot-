// commands/admin/setexpire.js
const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");

module.exports = {
  name: "setexpire",
  description: "Définir l'heure/minute d'expiration (sans changer la date).",
  category: "Administration",
  botOwner: true,
  run: async (client, interaction) => {
    try {
      const ownerId = interaction.user.id;

      const targetAll = interaction.options.getBoolean("all") || false;
      const botId = interaction.options.getString("bot_id") || null;
      const hour = interaction.options.getInteger("hour");
      const minute = interaction.options.getInteger("minute");

      await interaction.deferReply({ ephemeral: true });

      if (!targetAll && !botId) {
        return interaction.editReply({ content: "`❌` 〃 Spécifie un `bot_id` ou mets `all:true`." });
      }
      if (targetAll && botId) {
        return interaction.editReply({ content: "`❌` 〃 Choisis soit `all:true`, soit un `bot_id`, pas les deux." });
      }
      if (hour === null && minute === null) {
        return interaction.editReply({ content: "`❌` 〃 Tu dois renseigner au moins `hour` ou `minute`." });
      }

      const sql = targetAll
        ? "SELECT * FROM Astroia WHERE owner = ?"
        : "SELECT * FROM Astroia WHERE owner = ? AND bot_id = ?";
      const params = targetAll ? [ownerId] : [ownerId, botId];

      client.db.all(sql, params, async (err, rows) => {
        if (err) {
          console.error("DB read error:", err);
          return interaction.editReply({ content: "`❌` 〃 Erreur en lisant la base de données." });
        }
        if (!rows || rows.length === 0) {
          return interaction.editReply({ content: "`❌` 〃 Aucun bot correspondant trouvé." });
        }

        let updated = 0;
        const updates = [];

        for (const row of rows) {
          let targetTs = parseInt(row.temps, 10);
          if (isNaN(targetTs)) continue;

          const base = new Date(targetTs);
          const hh = (hour !== null) ? hour : base.getHours();
          const mm = (minute !== null) ? minute : base.getMinutes();

          const adjusted = new Date(base);
          adjusted.setHours(hh, mm, 0, 0);
          targetTs = adjusted.getTime();

          client.db.run(
            "UPDATE Astroia SET temps = ? WHERE bot_id = ? AND owner = ?",
            [targetTs, row.bot_id, ownerId],
            (e) => { if (e) console.error("Update error:", e); }
          );

          updates.push({ bot_id: row.bot_id, newTs: targetTs });
          updated++;
        }

        if (updated === 0) {
          return interaction.editReply({ content: "`❌` 〃 Aucun bot mis à jour." });
        }

        const example = updates[0];
        const exampleTsS = Math.floor(example.newTs / 1000);

        const embed = new EmbedBuilder()
          .setTitle(targetAll ? "Expiration mise à jour pour tous vos bots" : "Expiration du bot mise à jour")
          .setColor(client.color)
          .setDescription(
            targetAll
              ? `\`${updated}\` bots mis à jour.`
              : `Bot \`${updates[0].bot_id}\` mis à jour.`
          )
          .addFields(
            { name: "Nouvelle expiration", value: `<t:${exampleTsS}:F> (\`⌛\` <t:${exampleTsS}:R>)` }
          )
          .setFooter({ text: `Demandé par ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() })
          .setTimestamp();

        return interaction.editReply({ embeds: [embed] });
      });
    } catch (e) {
      console.error("setexpire error:", e);
      return interaction.editReply({ content: "`❌` 〃 Erreur pendant l’exécution de la commande." });
    }
  },

  get data() {
    return new SlashCommandBuilder()
      .setName("setexpire")
      .setDescription("Définir l'heure/minute d'expiration (sans changer la date).")
      .addBooleanOption(o =>
        o.setName("all")
         .setDescription("Mettre à jour tous vos bots ? (sinon précisez bot_id)")
         .setRequired(false)
      )
      .addStringOption(o =>
        o.setName("bot_id")
         .setDescription("ID du bot à modifier (si all=false)")
         .setRequired(false)
      )
      .addIntegerOption(o =>
        o.setName("hour")
         .setDescription("Nouvelle heure (0-23)")
         .setMinValue(0).setMaxValue(23)
         .setRequired(false)
      )
      .addIntegerOption(o =>
        o.setName("minute")
         .setDescription("Nouvelles minutes (0-59)")
         .setMinValue(0).setMaxValue(59)
         .setRequired(false)
      );
  }
};
