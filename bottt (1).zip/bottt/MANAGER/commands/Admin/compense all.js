const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: "compense",
  description: "Ajoute du temps à un ou tous les bots (admin)",
  botOwner: true,
  run: async (client, interaction) => {
    const subcommand = interaction.options.getSubcommand();

    if (subcommand === "all") {
      const duration = interaction.options.getString('temps');
      if (!duration) {
        return interaction.reply({ content: "\`❌\` 〃 Tu dois spécifier une durée (ex: 10d, 5h, 1w).", ephemeral: true });
      }

      const parsedTime = parseTime(duration);
      console.log(`Durée entrée: ${duration}, Temps parsé: ${parsedTime} ms`);
      if (!parsedTime || parsedTime <= 0) {
        return interaction.reply({ content: `\`❌\` 〃 Durée invalide (ex: 10d, 5h, 1w).`, ephemeral: true });
      }

      client.db.all('SELECT bot_id, temps FROM Astroia', async (err, rows) => {
        if (err) {
          console.error("Erreur lors de la récupération des bots :", err);
          return interaction.reply({ content: `\`❌\` 〃 Une erreur est survenue lors de la récupération des bots.`, ephemeral: true });
        }

        if (!rows || rows.length === 0) {
          console.log("Aucun bot trouvé dans la base de données.");
          return interaction.reply({ content: `\`❌\` 〃 Aucun bot trouvé dans la base de données.`, ephemeral: true });
        }

        console.log(`Nombre de bots trouvés: ${rows.length}`);
        let updatedCount = 0;
        const stmt = client.db.prepare('UPDATE Astroia SET temps = ? WHERE bot_id = ?');

        for (const row of rows) {
          console.log(`Traitement du bot ${row.bot_id}, temps actuel: ${row.temps}`);
          const currentTime = parseInt(row.temps) || Date.now();
          const newTime = currentTime + parsedTime;
          console.log(`Nouveau temps pour ${row.bot_id}: ${newTime}`);

          try {
            stmt.run(newTime, row.bot_id);
            updatedCount++;
          } catch (updateErr) {
            console.error(`Erreur lors de la mise à jour du bot ${row.bot_id}:`, updateErr);
          }
        }

        stmt.finalize((err) => {
          if (err) {
            console.error("Erreur lors de la finalisation de la requête:", err);
            return interaction.reply({ content: `\`❌\` 〃 Une erreur est survenue lors de la finalisation des mises à jour.`, ephemeral: true });
          }

          console.log(`Mise à jour terminée: ${updatedCount} bots mis à jour.`);
          interaction.reply(`\`✅\` 〃 Le temps a été ajouté à **${updatedCount} bots**. (+${duration})`);
        });
      });
    } else if (subcommand === "bot") {
      const botId = interaction.options.getString('id');
      const duration = interaction.options.getString('temps');

      if (!botId || !duration) {
        return interaction.reply({ content: "\`❌\` 〃 Tu dois spécifier un ID de bot et une durée (ex: 10d, 5h, 1w).", ephemeral: true });
      }

      const parsedTime = parseTime(duration);
      console.log(`Durée entrée: ${duration}, Temps parsé: ${parsedTime} ms`);
      if (!parsedTime || parsedTime <= 0) {
        return interaction.reply({ content: `\`❌\` 〃 Durée invalide (ex: 10d, 5h, 1w).`, ephemeral: true });
      }

      client.db.get('SELECT bot_id, temps FROM Astroia WHERE bot_id = ?', [botId], async (err, row) => {
        if (err) {
          console.error(`Erreur lors de la récupération du bot ${botId} :`, err);
          return interaction.reply({ content: `\`❌\` 〃 Une erreur est survenue lors de la récupération du bot.`, ephemeral: true });
        }

        if (!row) {
          console.log(`Bot ${botId} non trouvé dans la base de données.`);
          return interaction.reply({ content: `\`❌\` 〃 Aucun bot trouvé avec l'ID ${botId}.`, ephemeral: true });
        }

        console.log(`Traitement du bot ${row.bot_id}, temps actuel: ${row.temps}`);
        const currentTime = parseInt(row.temps) || Date.now();
        const newTime = currentTime + parsedTime;
        console.log(`Nouveau temps pour ${row.bot_id}: ${newTime}`);

        try {
          client.db.run('UPDATE Astroia SET temps = ? WHERE bot_id = ?', [newTime, botId], (updateErr) => {
            if (updateErr) {
              console.error(`Erreur lors de la mise à jour du bot ${botId}:`, updateErr);
              return interaction.reply({ content: `\`❌\` 〃 Une erreur est survenue lors de la mise à jour du bot.`, ephemeral: true });
            }

            console.log(`Mise à jour terminée pour le bot ${botId}.`);
            interaction.reply(`\`✅\` 〃 Le temps a été ajouté au bot **${botId}**. (+${duration})`);
          });
        } catch (updateErr) {
          console.error(`Erreur lors de la mise à jour du bot ${botId}:`, updateErr);
          return interaction.reply({ content: `\`❌\` 〃 Une erreur est survenue lors de la mise à jour du bot.`, ephemeral: true });
        }
      });
    }
  },

  get data() {
    return {
      name: this.name,
      description: this.description,
      integration_types: [0, 1],
      contexts: [0, 1, 2],
      options: [
        {
          type: 1,
          name: "all",
          description: "Ajoute du temps à tous les bots.",
          options: [
            {
              name: "temps",
              description: "Temps à ajouter (ex: 5d, 2h)",
              required: true,
              type: 3
            }
          ]
        },
        {
          type: 1,
          name: "bot",
          description: "Ajoute du temps à un bot spécifique.",
          options: [
            {
              name: "id",
              description: "ID du bot",
              required: true,
              type: 3
            },
            {
              name: "temps",
              description: "Temps à ajouter (ex: 5d, 2h)",
              required: true,
              type: 3
            }
          ]
        }
      ]
    };
  }
};

function parseTime(timeString) {
  if (!timeString) return null;
  const regex = /(\d+)([smhdwy])/;
  const match = timeString.match(regex);
  if (!match) return null;

  const value = parseInt(match[1]);
  const unit = match[2];

  switch (unit) {
    case 's': return value * 1000;
    case 'm': return value * 60 * 1000;
    case 'h': return value * 60 * 60 * 1000;
    case 'd': return value * 24 * 60 * 60 * 1000;
    case 'w': return value * 7 * 24 * 60 * 60 * 1000;
    case 'y': return value * 365 * 24 * 60 * 60 * 1000;
    default: return null;
  }
}