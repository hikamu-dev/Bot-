const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');
const path = require('path');
const fs = require('fs').promises;

module.exports = {
  name: "bot-dossier",
  description: "Affiche le contenu du dossier d'un bot spécifié par son ID",
  botOwner: true,

  run: async (client, interaction) => {
    const botId = interaction.options.getString("botid");
    const botFolder = path.join('/home/ubuntu/bot', botId);

    try {
      const botUser = await client.users.fetch(botId).catch(() => null);
      if (!botUser) {
        return interaction.reply({
          content: "\`❌\` 〃 identifiant de bot invalide ou introuvable.",
          ephemeral: true,
        });
      }

      const files = await fs.readdir(botFolder).catch(() => []);
      if (files.length === 0) {
        return interaction.reply({
          embeds: [
            new EmbedBuilder()
              .setTitle(`📂 Dossier de ${botUser.tag}`)
              .setDescription("Le dossier est vide. Aucun fichier ou dossier trouvé.")
              .setColor(client.color)
              .setTimestamp(),
          ],
          ephemeral: true,
        });
      }

      const categories = { folders: [], files: [] };
      for (const fileName of files) {
        const filePath = path.join(botFolder, fileName);
        const stats = await fs.stat(filePath);
        if (stats.isDirectory()) categories.folders.push(`\`\`📁 ${fileName}\`\``);
        else categories.files.push(`\`\`📄 ${fileName}\`\``);
      }

      const buildEmbed = (footerText = `Demandé par ${interaction.user.tag}`) => (
        new EmbedBuilder()
          .setTitle(`\`📂\` Dossier de ${botUser.tag}`)
          .setDescription("Contenu du dossier du bot :")
          .addFields(
            {
              name: "\`📂\` Dossiers",
              value: categories.folders.length ? categories.folders.join('\n') : "Aucun dossier",
              inline: true,
            },
            {
              name: "\`📄\` Fichiers",
              value: categories.files.length ? categories.files.join('\n') : "Aucun fichier",
              inline: true,
            }
          )
          .setColor(client.color)
          .setFooter({ text: footerText, iconURL: interaction.user.displayAvatarURL() })
          .setTimestamp()
      );

      const menu = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId(`botdossier_${interaction.id}`)
          .setPlaceholder("🔍 Sélectionnez une action")
          .addOptions([
            {
              label: "Rafraîchir",
              description: "Actualiser le contenu du dossier",
              value: `refresh_${interaction.id}`,
              emoji: "🔄",
            },
          ])
      );

      const msg = await interaction.reply({ embeds: [buildEmbed()], components: [menu], fetchReply: true });

      const collector = msg.createMessageComponentCollector({
        filter: (i) => i.user.id === interaction.user.id && i.customId === `botdossier_${interaction.id}`,
        time: 120_000,
      });

      collector.on('collect', async (i) => {
        if (i.values[0] === `refresh_${interaction.id}`) {
          await i.deferUpdate();

          const refreshedFiles = await fs.readdir(botFolder);
          const refreshedCategories = { folders: [], files: [] };

          for (const fileName of refreshedFiles) {
            const filePath = path.join(botFolder, fileName);
            const stats = await fs.stat(filePath);
            if (stats.isDirectory()) refreshedCategories.folders.push(`\`\`📁 ${fileName}\`\``);
            else refreshedCategories.files.push(`\`\`📄 ${fileName}\`\``);
          }

          const refreshedEmbed = new EmbedBuilder()
            .setTitle(`\`📂\` Dossier de ${botUser.tag}`)
            .setDescription("Contenu du dossier du bot :")
            .addFields(
              {
                name: "\`📂\` Dossiers",
                value: refreshedCategories.folders.length ? refreshedCategories.folders.join('\n') : "Aucun dossier",
                inline: true,
              },
              {
                name: "\`📄\` Fichiers",
                value: refreshedCategories.files.length ? refreshedCategories.files.join('\n') : "Aucun fichier",
                inline: true,
              }
            )
            .setColor(client.color)
            .setFooter({ text: `Rafraîchi par ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() })
            .setTimestamp();

          await i.editReply({ embeds: [refreshedEmbed], components: [menu] });
        }
      });

      collector.on('end', async () => {
        const disabledMenu = new ActionRowBuilder().addComponents(
          new StringSelectMenuBuilder()
            .setCustomId(`botdossier_${interaction.id}`)
            .setPlaceholder("🔍 Session expirée")
            .setDisabled(true)
            .addOptions([
              {
                label: "Rafraîchir",
                description: "Actualiser le contenu du dossier",
                value: `refresh_${interaction.id}`,
                emoji: "🔄",
              },
            ])
        );
        await msg.edit({ components: [disabledMenu] }).catch(() => {});
      });

    } catch (error) {
      console.error(`Erreur lors de l'accès au dossier du bot ${botId} :`, error);
      return interaction.reply({
        content: "\`❌\` 〃 Une erreur est survenue lors de l'accès au dossier du bot.",
        ephemeral: true,
      });
    }
  },

  get data() {
    return {
      name: this.name,
      description: this.description,
      integration_types: [0, 1],
      contexts: [0, 1, 2],
      options: [
        {
          name: "botid",
          description: "L'ID du bot à inspecter",
          type: 3,
          required: true,
        },
      ],
    };
  },
};
