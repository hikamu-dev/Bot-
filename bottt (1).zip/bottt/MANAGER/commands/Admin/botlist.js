const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: "bot-list",
  description: "Afficher la liste des bots enregistrés",
  botOwner: true,

  run: async (client, interaction) => {
    await interaction.deferReply({ ephemeral: false });

    client.db.all('SELECT bot_id, owner FROM Astroia', async (err, rows) => {
      if (err) {
        console.error('Erreur lors de la récupération des bots :', err);
        return interaction.editReply({
          content: '\❌\ 〃 Une erreur est survenue lors de la récupération des données.',
          ephemeral: true
        });
      }

      const botList = [];

      for (const row of rows) {
        const bot = await client.users.fetch(row.bot_id).catch(() => null);
        const owner = await client.users.fetch(row.owner).catch(() => null);


        botList.push({
          tag: bot ? bot.tag : 'Bot introuvable',
          id: row.bot_id,
          owner: owner ? owner.tag : 'Utilisateur introuvable',
          ownerId: row.owner,
        });
      }

      const embed = new EmbedBuilder()
        .setTitle('🤖 Liste des Bots')
        .setColor(client.color)
        .setThumbnail(client.user.displayAvatarURL())
        .setFooter({ text: `Total : ${botList.length} bots`, iconURL: client.user.displayAvatarURL() })
        .setTimestamp();

      if (botList.length > 0) {
        const formattedList = botList
          .map((bot, index) => `\`${index + 1}.\` ${bot.tag} (\`${bot.id}\`)`)
          .join('\n');
        embed.setDescription(formattedList);
      } else {
        embed.setDescription('\⚠️\ 〃 Aucun bot trouvé dans la base de données.');
      }

      await interaction.editReply({ embeds: [embed] });
    });
  },

  get data() {
    return {
      name: this.name,
      description: this.description,
      integration_types: [0, 1],
      contexts: [0, 1, 2],
    };
  }
};