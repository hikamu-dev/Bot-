const fs = require('fs-extra');
const path = require('path');
const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: "admchange",
  description: "Change le propriétaire d’un bot (commande fondateur)",
  category: "Administration",
  botOwner: true, // Ne pas oublier que ton handler doit vérifier ça correctement

  run: async (client, interaction) => {
    const botId = interaction.options.getString("bot-id");
    const newOwnerId = interaction.options.getString("new-owner");

    client.db.get('SELECT * FROM Astroia WHERE bot_id = ?', [botId], async (err, botData) => {
      if (err || !botData) {
        return interaction.reply({ content: "`❌` 〃 Bot introuvable ou erreur DB.", ephemeral: true });
      }

      const configFilePath = path.join(`/home/ubuntu/bot/${botId}/config/config.js`);
      if (!fs.existsSync(configFilePath)) {
        return interaction.reply({ content: "`❌` 〃 Fichier config.js introuvable.", ephemeral: true });
      }

      let botConfig = require(configFilePath);
      botConfig.buyers = [newOwnerId]; // Reset complet des anciens buyers

      try {
        fs.writeFileSync(configFilePath, `module.exports = ${JSON.stringify(botConfig, null, 2)};`);

        // Met à jour le propriétaire en DB
        client.db.run('UPDATE Astroia SET owner = ? WHERE bot_id = ?', [newOwnerId, botId], (err) => {
          if (err) {
            return interaction.reply({ content: "`❌` 〃 Erreur lors de la mise à jour du propriétaire.", ephemeral: true });
          }

          // Supprime les anciens codes de récupération
          client.db.run('DELETE FROM RecoveryCodes WHERE bot_id = ?', [botId]);

          const embed = new EmbedBuilder()
            .setTitle("👑 Propriétaire modifié")
            .setColor(client.color)
            .addFields(
              { name: "🤖 Bot ID", value: `\`${botId}\`` },
              { name: "👤 Nouveau propriétaire", value: `<@${newOwnerId}> (\`${newOwnerId}\`)` },
              { name: "📅 Date", value: `<t:${Math.floor(Date.now() / 1000)}:F>` }
            )
            .setFooter({ text: client.config.footer, iconURL: client.user.avatarURL() })
            .setTimestamp();

          const logChannel = client.channels.cache.get(client.config.logChannel);
          if (logChannel) logChannel.send({ embeds: [embed] });

          return interaction.reply({ content: "`✅` 〃 Propriétaire mis à jour avec succès.", ephemeral: true });
        });
      } catch (e) {
        console.error(e);
        return interaction.reply({ content: "`❌` 〃 Une erreur est survenue lors de la sauvegarde du fichier.", ephemeral: true });
      }
    });
  },

  get data() {
    return {
      name: this.name,
      description: this.description,
      options: [
        {
          name: "bot-id",
          description: "L'ID du bot à modifier",
          type: 3,
          required: true
        },
        {
          name: "new-owner",
          description: "L'ID du nouveau propriétaire",
          type: 3,
          required: true
        }
      ]
    };
  }
};
