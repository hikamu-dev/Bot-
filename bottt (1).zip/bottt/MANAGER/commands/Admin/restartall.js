const { exec } = require('child_process');
const Discord = require('discord.js');

module.exports = {
  name: "restart",
  description: "Redémarre un bot via son nom PM2",
  botOwner: true,

  run: async (client, interaction) => {
    await interaction.deferReply({ ephemeral: true });

    const botName = interaction.options.getString('botid');

    exec('pm2 jlist', (err, stdout) => {
      if (err) {
        console.error("Erreur PM2 :", err);
        return interaction.editReply({ content: '`❌` 〃 Erreur lors de la récupération de la liste PM2.', ephemeral: true });
      }

      try {
        const pm2List = JSON.parse(stdout);
        const target = pm2List.find(proc => proc.name === botName);

        if (!target) {
          return interaction.editReply({ content: '`❌` 〃 Aucun bot trouvé avec ce nom.', ephemeral: true });
        }

        exec(`pm2 restart ${target.pm_id}`, (error) => {
          if (error) {
            console.error(`Erreur pour ${botName} :`, error);
            return interaction.editReply({ content: '`❌` 〃 Échec du redémarrage.', ephemeral: true });
          }

          interaction.editReply({ content: `\`✅\` 〃 Bot \`${botName}\` redémarré avec succès !`, ephemeral: true });
        });

      } catch (parseError) {
        console.error("Erreur parsing PM2 :", parseError);
        interaction.editReply({ content: '`❌` 〃 Erreur lors de la lecture des données PM2.', ephemeral: true });
      }
    });
  },

  get data() {
    return {
      name: this.name,
      description: this.description,
      integration_types: [0, 1],
      contexts: [0, 1, 2],
      options: [
        {
          name: 'botid',
          description: 'Nom du bot (PM2) à redémarrer',
          required: true,
          type: 3
        }
      ]
    };
  }
};
