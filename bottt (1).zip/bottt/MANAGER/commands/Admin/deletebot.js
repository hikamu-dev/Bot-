const path = require('path');
const { exec } = require('child_process');
const fs = require('fs');

module.exports = {
  name: "delete-bot",
  description: "Supprime un bot de la base de données et son dossier",
  botOwner: true,
  run: async (client, interaction) => {
    const botId = interaction.options.getString('botid');
    if (!botId) {
      return interaction.reply({ content: `\`❌\` Utilisation incorrecte. Utilisez : \`/deletebot <id du bot>\``, ephemeral: true });
    }

    try {
      // Récupère le propriétaire (buyer)
      client.db.get('SELECT owner FROM Astroia WHERE bot_id = ?', [botId], async (err, row) => {
        if (err) {
          console.error("Erreur SQL :", err);
          return interaction.reply({ content: '\`❌\` 〃 Erreur lors de l\'accès à la base de données.', ephemeral: true });
        }

        if (!row) {
          return interaction.reply({ content: '\`❌\` 〃 Aucun bot trouvé avec cet identifiant.', ephemeral: true });
        }

        const ownerId = row.owner;
        const botFolder = path.join('/home/ubuntu/bot', botId);

        // Supprime de la DB et du système
        await client.db.run('DELETE FROM Astroia WHERE bot_id = ?', [botId]);

        exec(`pm2 delete ${botId} && rm -r ${botFolder}`, async (err) => {
          if (err) {
            console.error('Erreur lors de la suppression du bot :', err);
            return interaction.reply({ content: '\`❌\` 〃 Une erreur est survenue lors de la suppression.', ephemeral: true });
          }

          let botTag = botId;
          try {
            const botUser = await client.users.fetch(botId);
            botTag = botUser.tag;
          } catch (e) {
            console.warn("Impossible de récupérer le tag du bot, peut-être qu'il n'est pas en cache.");
          }

          // Envoi du MP au buyer
          try {
            const owner = await client.users.fetch(ownerId);
            await owner.send(`\`❌\` 〃 Votre bot avec l'ID \`${botId}\` (${botTag}) a été supprimé par un administrateur.`);
          } catch (dmErr) {
            console.warn("Impossible d'envoyer un DM à l'owner :", dmErr);
          }

          return interaction.reply({ content: `\`✅\` 〃 Le bot \`${botTag}\` a été supprimé avec succès.`, ephemeral: true });
        });
      });
    } catch (error) {
      console.error('Erreur lors de la suppression du bot :', error);
      return interaction.reply({ content: `\`❌\` 〃 Une erreur est survenue.`, ephemeral: true });
    }
  },
  get data() {
    return {
      name: this.name,
      description: this.description,
      integration_types: [0, 1],
      contexts: [0, 1, 2],
      options: [
        {
          name: "botid",
          description: "L'ID du bot à supprimer.",
          required: true,
          type: 3
        }
      ]
    };
  }
};
