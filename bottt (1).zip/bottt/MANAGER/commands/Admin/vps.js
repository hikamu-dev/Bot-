const os = require('os');
const pidusage = require('pidusage');
const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: "vps",
  description: "Affiche les informations du VPS",
  botOwner: true,
  run: async (client, interaction) => {
    // Récupération des informations système
    const totalMemory = formatBytes(os.totalmem());
    const freeMemory = formatBytes(os.freemem());
    const usedMemory = formatBytes(os.totalmem() - os.freemem());
    const memoryPercent = ((os.totalmem() - os.freemem()) / os.totalmem() * 100).toFixed(2);
    const cpuInfo = os.cpus();
    const cpuUsage = await pidusage(process.pid);
    const cpuPercent = cpuUsage.cpu.toFixed(2);

    const uptime = formatUptime(os.uptime());
    const hostName = os.hostname();
    const platformVersion = os.release();

    // Construction du nouvel embed
    const embed = new EmbedBuilder()
      .setTitle("📊 **Statistiques du VPS**")
      .setColor(client.color)  // Couleur sombre pour l'aspect pro
      .setDescription("Voici les informations détaillées du VPS sur lequel le bot est hébergé :")
      .addFields(
        { name: '🖥️ **Système**', value: `• **Plateforme :** \`${os.platform()}\`\n• **Architecture :** \`${os.arch()}\`\n• **Version OS :** \`${platformVersion}\``, inline: true },
        { name: '🚀 **Performance CPU**', value: `• **Modèle :** \`${cpuInfo[0].model}\`\n• **Utilisation CPU :** \`${cpuPercent}%\`\n• **Cœurs :** \`${cpuInfo.length}\``, inline: true },
        { name: '🧠 **Mémoire**', value: `• **Utilisée :** \`${usedMemory}\`\n• **Libre :** \`${freeMemory}\`\n• **Totale :** \`${totalMemory}\`\n• **Utilisation :** \`${memoryPercent}%\``, inline: true },
        { name: '⏲️ **Uptime**', value: `• **Temps de fonctionnement :** \`${uptime}\``, inline: true },
        { name: '🔗 **Informations Système**', value: `• **Nom d'hôte :** \`LynaVPS\``, inline: true }
      )
      .setFooter({ text: `Statistiques fournies par ${interaction.user.tag}`, iconURL: interaction.user.avatarURL() })
      .setTimestamp();

    // Envoi de l'embed dans la réponse éphemeral
    return interaction.reply({ embeds: [embed] });
  },
  get data() {
    return {
      name: this.name,
      description: this.description,
      integration_types: [0, 1],
      contexts: [0, 1, 2],
    };
  }
};

// Fonction pour formater les octets en unités lisibles (Ko, Mo, etc.)
function formatBytes(bytes) {
  const units = ['octets', 'Ko', 'Mo', 'Go', 'To'];
  let i = 0;
  while (bytes >= 1024 && i < units.length - 1) {
    bytes /= 1024;
    i++;
  }
  return `${bytes.toFixed(2)} ${units[i]}`;
}

// Fonction pour formater le temps de fonctionnement (uptime)
function formatUptime(uptime) {
  const seconds = Math.floor(uptime % 60);
  const minutes = Math.floor((uptime / 60) % 60);
  const hours = Math.floor((uptime / (60 * 60)) % 24);
  const days = Math.floor(uptime / (60 * 60 * 24));

  let formattedUptime = '';
  if (days > 0) formattedUptime += `${days}j `;
  if (hours > 0) formattedUptime += `${hours}h `;
  if (minutes > 0) formattedUptime += `${minutes}m `;
  if (seconds > 0) formattedUptime += `${seconds}s`;

  return formattedUptime.trim();
}
