const { exec } = require('child_process');
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  name: "restartall",
  description: "Redémarre tous les bots enregistrés",
  botOwner: true,

  run: async (client, interaction) => {
    await interaction.deferReply({ ephemeral: false });

    client.db.all('SELECT bot_id FROM Astroia', async (err, rows) => {
      if (err) {
        console.error('Erreur récupération bots :', err);
        return interaction.editReply({ content: '`❌` 〃 Erreur lors de la récupération des bots.' });
      }

      if (!rows || rows.length === 0) {
        return interaction.editReply({ content: '`⚠️` 〃 Aucun bot trouvé dans la base de données.' });
      }

      const botIds = rows.map(row => row.bot_id);
      const restartCommands = botIds.map(id => `pm2 restart ${id}`).join(' && ');

      exec(restartCommands, (error, stdout, stderr) => {
        if (error) {
          console.error("Erreur redémarrage :", error);
          return interaction.editReply({ content: '`❌` 〃 Une erreur est survenue lors du redémarrage des bots.' });
        }

        return interaction.editReply({
          content: `\`✅\` 〃 Tous les bots ont été redémarrés avec succès (${botIds.length} bots).\n\`\`\`bash\n${stdout || "Redémarrage effectué."}\n\`\`\``
        });
      });
    });
  },

  get data() {
    return new SlashCommandBuilder()
      .setName('restartall')
      .setDescription('Redémarre tous les bots en cours via PM2');
  }
};