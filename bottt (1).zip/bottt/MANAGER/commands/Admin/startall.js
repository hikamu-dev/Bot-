const { exec } = require('child_process');

module.exports = {
  name: "start-all",
  description: "Démarrer tous les bots",
  botOwner: true,

  run: async (client, interaction) => {
    await interaction.deferReply({ ephemeral: true });

    exec('pm2 jlist', async (error, stdout) => {
      if (error) {
        console.error("Erreur lors de l'exécution de PM2 :", error);
        return interaction.editReply({ content: `\`❌\` 〃 Erreur lors de la récupération de la liste des bots.`, ephemeral: true });
      }

      try {
        const pm2Data = JSON.parse(stdout);

        const toStart = pm2Data.filter(proc => !["MANAGER", "API", "AstroBump", "ProtectAStro"].includes(proc.name));

        if (toStart.length === 0) {
          return interaction.editReply({ content: `\`❌\` 〃 Aucun bot à démarrer.`, ephemeral: true });
        }

        // Démarrage en boucle
        toStart.forEach(proc => {
          exec(`pm2 start ${proc.name}`, (err) => {
            if (err) {
              console.error(`Erreur pour ${proc.name} :`, err);
            } else {
              console.log(`Bot démarré : ${proc.name}`);
            }
          });
        });

        interaction.editReply({ content: `\`✅\` 〃 ${toStart.length} bot(s) en cours de démarrage.`, ephemeral: true });

      } catch (parseError) {
        console.error("Erreur lors du parsing JSON de PM2 :", parseError);
        interaction.editReply({ content: `\`❌\` 〃 Erreur de lecture des données PM2.`, ephemeral: true });
      }
    });
  },

  get data() {
    return {
      name: this.name,
      description: this.description,
      integration_types: [0, 1],
      contexts: [0, 1, 2],
    };
  }
};
