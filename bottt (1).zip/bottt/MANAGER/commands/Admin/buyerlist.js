const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: "buyer-list",
  description: "Afficher la liste des tags des acheteurs de bots",
  botOwner: true,

  run: async (client, interaction) => {
    client.db.all('SELECT DISTINCT owner FROM Astroia', async (err, rows) => {
      if (err) {
        console.error('Erreur lors de la récupération des acheteurs :', err);
        return interaction.reply({
          content: '\`❌\` 〃 Une erreur est survenue lors de la récupération des données.',
          ephemeral: true
        });
      }

      const buyersList = [];

      for (const row of rows) {
        const buyer = await client.users.fetch(row.owner).catch(() => null);
        if (buyer) {
          buyersList.push({ tag: buyer.tag, id: buyer.id });
        } else {
          buyersList.push({ tag: 'Utilisateur introuvable', id: row.owner });
        }
      }

      const embed = new EmbedBuilder()
        .setTitle('👤 Liste des Acheteurs de Bots')
        .setColor(client.color)
        .setThumbnail(client.user.displayAvatarURL())
        .setFooter({ text: `Total : ${buyersList.length} acheteurs`, iconURL: client.user.displayAvatarURL() })
        .setTimestamp();

      if (buyersList.length > 0) {
        const formattedList = buyersList
          .map((buyer, index) => `\`${index + 1}.\` ${buyer.tag} (\`${buyer.id}\`)`)
          .join('\n');

        embed.setDescription(formattedList);
      } else {
        embed.setDescription('\`⚠️\` 〃 Aucun acheteur trouvé dans la base de données.');
      }

      interaction.reply({ embeds: [embed], ephemeral: false });
    });
  },

  get data() {
    return {
      name: this.name,
      description: this.description,
      integration_types: [0, 1],
      contexts: [0, 1, 2],
    };
  }
};
