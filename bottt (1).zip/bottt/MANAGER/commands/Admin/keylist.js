const fs = require('fs-extra');
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  name: "clée-list",
  description: "Affiche la liste des clés disponibles.",
  botOwner: true,
  run: async (client, interaction) => {
    try {
      let storedKeys;
      try {
        storedKeys = fs.readFileSync('Clée.txt', 'utf8').trim().split("\n").map((line) => line.trim());
      } catch (error) {
        console.error("Erreur lors de la lecture du fichier Clée.txt :", error);
        return interaction.reply({ content: `\`❌\` 〃 Une erreur s'est produite lors de la lecture des clés.`, ephemeral: true });
      }

      if (!storedKeys || storedKeys.length === 0) {
        return interaction.reply({ content: `\`❌\` 〃 Aucune clé n'a été trouvée.`, ephemeral: true });
      }

      const pageSize = 50;
      let currentPage = 0;
      const totalPages = Math.ceil(storedKeys.length / pageSize);

      const generateEmbed = (page) => {
        const start = page * pageSize;
        const end = start + pageSize;
        const keysForPage = storedKeys.slice(start, end);

        const description = keysForPage.map((key, i) => `> ${start + i + 1}. \`${key}\``).join('\n');

        return new EmbedBuilder()
          .setTitle("Clés disponibles")
          .setDescription(description)
          .setColor(client.color || 0x00AE86)
          .setFooter({ text: `Page ${page + 1} / ${totalPages}` })
          .setTimestamp();
      };

      const generateButtons = (page) => {
        return new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId('previous')
            .setLabel('⬅️ Précédent')
            .setStyle(ButtonStyle.Primary)
            .setDisabled(page === 0),
          new ButtonBuilder()
            .setCustomId('next')
            .setLabel('Suivant ➡️')
            .setStyle(ButtonStyle.Primary)
            .setDisabled(page === totalPages - 1)
        );
      };

      await interaction.reply({
        embeds: [generateEmbed(currentPage)],
        components: [generateButtons(currentPage)],
        ephemeral: true
      });

      const message = await interaction.fetchReply();

      const collector = message.createMessageComponentCollector({
        time: 120_000, // 2 minutes
        filter: i => i.user.id === interaction.user.id
      });

      collector.on('collect', async i => {
        if (i.customId === 'next' && currentPage < totalPages - 1) currentPage++;
        else if (i.customId === 'previous' && currentPage > 0) currentPage--;

        await i.update({
          embeds: [generateEmbed(currentPage)],
          components: [generateButtons(currentPage)],
          ephemeral: true
        });
      });

      collector.on('end', async () => {
        try {
          await message.edit({ components: [] });
        } catch (e) {
          console.warn("Impossible de retirer les composants (probablement supprimé) :", e.message);
        }
      });

    } catch (error) {
      console.error("Erreur lors de la récupération de la liste des clés :", error);
      interaction.followUp({ content: `\`❌\` 〃 Une erreur est survenue lors de la récupération des clés.`, ephemeral: true });
    }
  },

  get data() {
    return {
      name: this.name,
      description: this.description,
      integration_types: [0, 1],
      contexts: [0, 1, 2],
    };
  }
};
