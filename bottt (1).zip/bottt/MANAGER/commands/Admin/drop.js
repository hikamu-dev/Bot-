const fs = require('fs-extra');
const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: "drop",
  description: "Génère et envoie une ou plusieurs clés en MP à un utilisateur.",


  run: async (client, interaction) => {
    const allowedIds = ["1022154698163236985", "1343938749502984255", "198050274743549953", "1133346652573401179", "519676063375163404"]; // IDs autorisées
    if (!allowedIds.includes(interaction.user.id)) {
      return interaction.reply({
        content: "❌ 〃 Vous n'êtes pas autorisé à utiliser cette commande.",
        ephemeral: true
      });
    }

    const user = interaction.options.getUser("utilisateur");
    const nombre = interaction.options.getInteger("nombre") || 1;

    const generateKey = () => {
      const chars = "abcdefghijklmnopqrstuvwxyz0123456789";
      let key = "";
      for (let i = 0; i < 16; i++) {
        key += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      return key.toLowerCase().trim();
    };

    if (!user) {
      return interaction.reply({ content: "Utilisateur invalide.", ephemeral: true });
    }

    let clesExistantes = [];
    try {
      clesExistantes = fs.readFileSync("Clée.txt", "utf8")
        .split("\n")
        .map(line => line.trim().toLowerCase())
        .filter(line => line.length > 0);
    } catch (err) {
      // Ignorer si le fichier n'existe pas encore
    }

    const keysToSend = [];
    while (keysToSend.length < nombre) {
      const key = generateKey();
      if (!clesExistantes.includes(key) && !keysToSend.includes(key)) {
        keysToSend.push(key);
      }
    }

    try {
      const embed = new EmbedBuilder()
        .setTitle(`🎁〃Voici ${keysToSend.length} clé(s) d'activation`)
        .setDescription(`Voici ${keysToSend.length > 1 ? "vos clés d'activation" : "votre clé d'activation"} :`)
        .addFields(
          {
            name: "Clé(s)",
            value: keysToSend.map(k => `\`${k}\``).join("\n"),
            inline: false
          },
          {
            name: "Commande",
            value: "</create:1298372774892539957>",
            inline: false
          }
        )
        .setColor("#00FF00")
        .setTimestamp();

      await user.send({ embeds: [embed] });

      interaction.reply({ content: `✅ 〃 ${keysToSend.length} clé(s) envoyée(s) à ${user.tag} en MP.`, ephemeral: true });

      const logData = keysToSend.map(k => k.trim().toLowerCase()).join("\n") + "\n";
      fs.appendFileSync("Clée.txt", logData, "utf8");

    } catch (error) {
      console.error("Erreur lors de l'envoi des MP :", error);
      interaction.reply({
        content: "❌ 〃 Impossible d'envoyer les clés en MP. L'utilisateur a peut-être ses MP fermés.",
        ephemeral: true
      });
    }
  },

  get data() {
    return {
      name: this.name,
      description: this.description,
      integration_types: [0, 1],
      contexts: [0, 1, 2],
      options: [
        {
          name: "utilisateur",
          description: "L'utilisateur à qui envoyer les clés",
          type: 6,
          required: true
        },
        {
          name: "nombre",
          description: "Nombre de clés à envoyer (défaut : 1)",
          type: 4,
          required: false
        }
      ]
    };
  }
};