const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: "tarifs",
  description: "Affiche les tarifs des abonnements pour un bot",
  botOwner: true,
  run: async (client, interaction) => {
    // Création de l'embed
    const embed = new EmbedBuilder()
      .setTitle("📊 Tarifs des abonnements")
      .setColor(client.color)
      .setThumbnail(client.user.displayAvatarURL())
      .setFooter({ text: client.config.footer, iconURL: client.user.displayAvatarURL() })
      .setTimestamp()
      .setDescription("Achetez un abonnement pour votre bot\nVeuillez sélectionner une option d'abonnement ci-dessous :")
      .addFields(
        { name: '1 mois', value: '2€', inline: true },
        { name: '2 mois', value: '3.50€', inline: true },
        { name: '3 mois', value: '4.50€', inline: true },
        { name: '5 mois', value: '5.50€', inline: true },
        { name: '1 an', value: '12.00€', inline: true },
        { name: 'A vie', value: '40.00€', inline: true }
      );

    // Envoie de l'embed dans le canal
    await interaction.channel.send({ embeds: [embed] });

    // Réponse à l'utilisateur (visible uniquement à lui)
    await interaction.reply({ content: "✅ L'embed a été envoyé dans ce canal.", ephemeral: true });
  },

  get data() {
    return {
      name: this.name,
      description: this.description,
      integration_types: [0, 1],
      contexts: [0, 1, 2],
    };
  }
};
