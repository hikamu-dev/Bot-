module.exports = {
  name: "edit-times",
  description: "Modifie le temps d'expiration d'un bot",
  botOwner: true,
  run: async (client, interaction) => {
    const botId = interaction.options.getString('botid');
    const newDuration = interaction.options.getString('duree');

    // Vérifie que la durée est bien fournie
    if (!newDuration) {
      return interaction.reply({ content : `\`❌\` 〃 Tu dois spécifier une durée (exemple : 10d, 5h, 1w).`, ephemeral: true});
    }

    // Parse la durée
    const parsedTime = parseTime(newDuration);
    if (!parsedTime) {
      return interaction.reply({ content : `\`❌\` 〃 Durée invalide (exemple : 10d, 5h, 1w).`, ephemeral: true});
    }

    // Cherche les infos du bot
    const botData = await new Promise((resolve, reject) => {
      client.db.get('SELECT * FROM Astroia WHERE bot_id = ?', [botId], (err, row) => {
        if (err) {
          console.error('Erreur lors de la récupération des données du bot :', err);
          reject(err);
        } else {
          resolve(row);
        }
      });
    });

    // Vérifie que le bot existe
    if (!botData) {
      return interaction.reply({ content: `\`❌\` 〃 Ce bot n'existe pas dans la base de données Shelia.`, ephemeral: true });
    }

    // Met à jour la nouvelle date d'expiration
    const newExpirationDate = Date.now() + parsedTime;
    client.db.run('UPDATE Astroia SET temps = ? WHERE bot_id = ?', [newExpirationDate, botId]);

    const timestamp = Math.floor(newExpirationDate / 1000);
    interaction.reply(`\`✅\` 〃 La nouvelle date d'expiration pour le bot \`${botId}\` est : <t:${timestamp}:R>.`);
  },

  get data() {
    return {
      name: this.name,
      description: this.description,
      integration_types: [0, 1],
      contexts: [0, 1, 2],
      options: [
        {
          name: "botid",
          description: "L'ID du bot.",
          required: true,
          type: 3
        },
        {
          name: "duree",
          description: "La durée du bot",
          required: false,
          type: 3
        }
      ]
    };
  }
};

// Fonction de parsing de la durée
function parseTime(timeString) {
  if (!timeString) return null;
  const regex = /(\d+)([smhdwy])/;
  const match = timeString.match(regex);
  if (!match) return null;

  const value = parseInt(match[1]);
  const unit = match[2];

  switch (unit) {
    case 's':
      return value * 1000;
    case 'm':
      return value * 60 * 1000;
    case 'h':
      return value * 60 * 60 * 1000;
    case 'd':
      return value * 24 * 60 * 60 * 1000;
    case 'w':
      return value * 7 * 24 * 60 * 60 * 1000;
    case 'y':
      return value * 365 * 24 * 60 * 60 * 1000;
    default:
      return null;
  }
}
