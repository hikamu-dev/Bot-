const Discord = require('discord.js')
module.exports = {
    name: "clee-info",
    description: "Affiche les infos d'une clé selon si elle est déjà utilisée",
    botOwner: true,
    run: async (client, interaction) => {
        const cleeRecherchee = interaction.options.getString('cle'); 

        client.db.get('SELECT * FROM clee WHERE clee = ?', [cleeRecherchee], async (err, row) => {
            if (err) {
                console.error(err);
                return interaction.reply({ content: `\`❌\` 〃 Une erreur s'est produite.`, ephemeral: true });
            }

            if (row) {
                const embed = {
                    color: client.color,
                    title: 'Informations sur la clé \`${cleeRecherchee}\`',
                    fields: [
                      {
                        name: 'Bot ID',
                        value: `[\`${(await client.users.fetch(row.bot_id)).username}\`](https://discord.com/users/${row.bot_id}) (\`${row.bot_id}\`)`
                      },
                      {
                        name: 'Auteur',
                        value: `[\`${(await client.users.fetch(row.author)).username}\`](https://discord.com/users/${row.author}) (\`${row.author}\`)`
                      },
                      { name: 'Timestamps', value: `<t:${Math.floor(row.timetamps / 1000)}:R>` }
                    ]
                  }
            return interaction.reply({ embeds: [embed] });
            } else {
                return interaction.reply({ content:`\`❌\` 〃 La clé \`${cleeRecherchee}\` n'a pas été trouvée ou elle n'est pas utilisée.`, ephemeral: true });
            }
        });
    },
    get data() {
      return {
          name: this.name,
          description: this.description,
          integration_types: [0, 1],
          contexts: [0, 1, 2],
          options: [
            {
                name: "cle",
                description: "La clé à rechercher.",
                required: true,
                type: 3
            }
        ]
      }
    }
}
