const sqlite3 = require('sqlite3').verbose();
const Discord = require('discord.js');
const express = require('express');
const fs      = require('node:fs');
const app     = express();
require('colors');

const client = new Discord.Client({
    intents: Object.keys(Discord.GatewayIntentBits),
    partials: [ Discord.Partials.Message, Discord.Partials.Channel, Discord.Partials.GuildMember, Discord.Partials.User, Discord.Partials.Reaction, Discord.Partials.ThreadMember ],
})

const db = new sqlite3.Database('Astroia.db');

db.run('CREATE TABLE IF NOT EXISTS Astroia (owner TEXT, bot_id TEXT, temps TEXT)', err => {
    if (err) console.error(err);
    else console.log("Table".blue + " >> " + `Astroia`.red + ` bdd chargée avec succès`.green)    
});

db.run('CREATE TABLE IF NOT EXISTS clee (clee TEXT, bot_id TEXT, author TEXT, timetamps TEXT)', err => {
    if (err) console.error(err);
    else console.log("Table".blue + " >> " + `Clée`.red + ` bdd chargée avec succès`.green)
});

db.run('CREATE TABLE IF NOT EXISTS GBL (gbl TEXT, raison TEXT, author TEXT)', err => {
    if (err) console.error(err);
    else console.log("Table".blue + " >> " + `GBL`.red + ` bdd chargée avec succès`.green)
});
db.run('CREATE TABLE IF NOT EXISTS RecoveryCodes (bot_id TEXT, code TEXT, created_at INTEGER)', err => {
    if (err) console.error(err);
    else console.log("Table".blue + " >> " + `RecoveryCodes`.red + ` bdd chargée avec succès`.green);
});


// db.run('DELETE FROM RecoveryCodes', (err) => {
//     if (err) {
//         console.error('Erreur SQLite:', err);
//     } else {
//         console.log('Toutes les entrées de la table RecoveryCodes ont été supprimées.');
//     }
// });



client.config = require("./config.json")
client.commands = new Discord.Collection()
client.aliases = new Discord.Collection()
client.db = db
client.color = 0x00FFFF
client.login(client.config.token || process.env.token)

fs.readdirSync("./commands/").forEach(dirs => {
    const commands = fs.readdirSync(`./commands/${dirs}/`).filter(files => files.endsWith(".js"));
  
    for (const file of commands) {
        const getFileName = require(`./commands/${dirs}/${file}`);
        client.commands.set(getFileName.name, getFileName);
        console.log("System".blue + " >> " + `commande `.green + `${getFileName.name}`.red+ ` chargé `.green)
    };
});
  
fs.readdirSync("./events").forEach(dirs => {
    const events = fs.readdirSync(`./events/${dirs}/`).filter(files => files.endsWith(".js"));
  
    for (const event of events) {
        const evt = require(`./events/${dirs}/${event}`);
        client.on(event.split(".")[0], evt.bind(null, client));
        console.log("System".blue + " >> " + `event `.green +  event.split(".")[0].red + ` chargé`.green)
    };
});




app.use(express.json());
app.listen(3003, () => {
});
app.post("/API/start", async (req, res) => {
    try {
        const botId = req.body.bot;
        const connectionChannel = client.channels.cache.get(client.config.connection);

        if (connectionChannel) {
            const botUser = await client.users.fetch(botId);

            db.get('SELECT owner FROM Astroia WHERE bot_id = ?', [botId], async (err, row) => {
                if (err) {
                    console.error("Erreur DB:", err);
                    return res.status(500).send("Erreur base de données");
                }

                const owner = row ? row.owner : "Inconnu";

                const embed = {
                    color: 0xFFA500,
                    title: '**Connexion au Lyna [MANAGER]**',
                    timestamp: new Date().toISOString()
                };

                const connected = {
                    color: 0xFFC133,
                    title: 'Connexion au système',
                    description: `\`${botUser.tag}\` (ID: \`${botUser.id}\`) vient de se connecter au système.\n - Propriétaire: <@${owner}> (\`${owner}\`)`,
                    timestamp: new Date().toISOString()
                };

                connectionChannel.send({ embeds: [embed] });
                connectionChannel.send({ embeds: [connected] });
                return res.status(200).send("Accès au serveur autorisé.");
            });
        } else {
            return res.status(404).send("Salon de connexion introuvable.");
        }
    } catch (error) {
        console.error("API Error:", error);
        return res.status(500).send("Une erreur vient de se produire...");
    }
});


app.post("/API/gbl", async (req, res) => {
    try {
        db.all('SELECT * FROM gbl', [], async (err, rows) => {
            if (err) {
                console.error('Erreur lors de la récupération des données :', err);
                res.status(500).send('Erreur lors de la récupération des données');
            }
            else if (rows.length === 0) return res.status(404).send('Aucune donnée');
            else return res.json({ gbl: rows });
        });
    } catch (error) {
        console.error('Erreur lors du traitement de la requête :', error);
        return res.status(400).send('Requête incorrecte');
    }
});

app.post("/API/expire", async (req, res) => {
    try {
        const bot = req.body.bot;
        console.log(bot);

        db.all('SELECT * FROM Astroia WHERE bot_id = ?', [bot], (err, rows) => {
            if (err) {
                console.error('Erreur lors de la récupération des données :', err);
                res.status(500).send('Erreur lors de la récupération des données');
            }
            else if (rows.length === 0) return res.status(404).send('Bot inconnu');
            else return res.json(rows[0].temps);
        });
    } catch (error) {
        console.error('Erreur lors du traitement de la requête :', error);
        return res.status(400).send('Requête incorrecte');
    }
});


app.get('/API/bot/:owner_id', (req, res) => {
    db.all('SELECT * FROM Astroia WHERE owner = ?', [req.params.owner_id], (err, rows) => {
        if (err) {
            console.error(err);
            res.status(500).json({ error: 'Une erreur est survenue lors de la récupération des données.' });
        }
        else if (!rows || rows.length === 0) return res.json('aucun bot');
        else return res.json(rows);
    });
});


/*process.on("unhandledRejection", (reason, p) => {

});
process.on("uncaughtException", (err, origin) => {

});
process.on("uncaughtExceptionMonitor", (err, origin) => {
 
});
process.on("multipleResolves", (type, promise, reason) => {
 
});
*/