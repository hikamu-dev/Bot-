// save.js
// Fonction pour enregistrer l'ancien pseudo + log embed (ancien + nouveau si fourni)

async function save_oldname(client, res, user_id, old_name, timestamp, new_name = null) {
  try {
    const now = Date.now();
    const lastMinuteTs = Math.floor((now - 60 * 1000) / 1000);

    // Anti-duplicate 1 minute (même user + même old_name)
    client.db.get(
      "SELECT COUNT(*) as count FROM oldnames WHERE user_id = ? AND old_name = ? AND timestamp > ?",
      [user_id, old_name, lastMinuteTs],
      (err, row) => {
        if (err) {
          console.error(err);
          return res.status(500).json({ error: client.erreur500 || "DB error" });
        }

        if (row?.count > 0) {
          res.json({ message: "Prevname non save (duplicate en 1 minute)" });
          console.log(`[Prevname] ${user_id} : "${old_name}" ignoré (duplicate <1min)`);
          return;
        }

        // On garde le schéma existant: on enregistre seulement (user_id, old_name, timestamp)
        client.db.run(
          "INSERT INTO oldnames (user_id, old_name, timestamp) VALUES (?, ?, ?)",
          [user_id, old_name, timestamp],
          function (err2) {
            if (err2) {
              console.error(err2);
              return res.status(500).json({ error: client.erreur500 || "DB error" });
            }

            res.json({ message: "Prevname save" });
            console.log(`[Prevname] ${user_id} : "${old_name}" saved`);

            const channel = client.channels.cache.get(client.config.channelprevname);
            if (!channel) return;

            client.users.fetch(user_id).then((user) => {
              const username = user.username;

              // Sécurise et tronque les textes
              const fmt = (s) => (s && String(s).trim().slice(0, 128)) || "—";
              const oldNick = fmt(old_name);
              // ✅ IMPORTANT: on ne formate le new_name que s'il est fourni
              const newNick = new_name ? fmt(new_name) : null;

              const embed = new client.discord.EmbedBuilder()
                .setColor("#b6ff92") // sobre, style Discord
                .setAuthor({
                  name: `${username} (${user_id})`,
                  iconURL: user.displayAvatarURL({ size: 128 }),
                })
                .setTitle("✨ Mise à jour de pseudo ✨")
                .setDescription(
                  `Le changement de pseudo de **${username}** a été enregistré !\n\n` +
                  (newNick ? `**Ancien Pseudo** : \`${oldNick}\`\n┖ **Nouveau Pseudo** \`${newNick}\`` : `\`${oldNick}\``)
                )
                .setFooter({
                  text: `Prevnames • Log automatique • ${client.user.username}`,
                  iconURL: client.user.displayAvatarURL({ size: 128 }),
                })
                .setTimestamp();

              channel.send({ embeds: [embed] }).catch(() => {});
            }).catch((e) => {
              console.log("[Prevname fetch user error]:", e);
            });
          }
        );
      }
    );
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: client.erreur500 || "Erreur serveur" });
  }
}

module.exports = save_oldname;
