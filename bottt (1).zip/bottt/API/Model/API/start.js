async function start(client) {
  const now = new Date();
  const timestamp = Math.floor(now.getTime() / 1000);
  
  const channel = client.channels.cache.get(client.config.channelstart);
  if (!channel) return console.error("Canal de démarrage introuvable !");

  const startEmbed = new client.discord.EmbedBuilder()
      .setTitle('🚀 Démarrage de l\'API')
      .setDescription(
          `**Heure de démarrage:**\n` +
          `📅 <t:${timestamp}:D>\n` +
          `⏰ <t:${timestamp}:T>\n` +
          `🔄 <t:${timestamp}:R>`
      )
      .setColor(client.config.color || '#0099ff')
      .setFooter({
          text: `API Status | v${client.config.version}`,
          iconURL: client.user?.displayAvatarURL() || undefined
      })
      .setThumbnail(client.user?.displayAvatarURL() || null)
      .setTimestamp();

  try {
      await channel.send({ 
          content: '📢 Notification de démarrage',
          embeds: [startEmbed] 
      });

      setInterval(async () => {
          const latency = client.ws.ping;
          if (latency > 200) {
              const latencyEmbed = new client.discord.EmbedBuilder()
                  .setTitle('⚠️ Latence élevée détectée')
                  .setDescription(
                      `La latence de l'API est anormalement élevée:\n` +
                      `**\`${latency}ms\`**\n` +
                      `Dernière vérification: <t:${Math.floor(Date.now() / 1000)}:T>`
                  )
                  .setColor('#FF0000') // Rouge pour alerte
                  .setFooter({
                      text: `API Status | v${client.config.version}`,
                      iconURL: client.user?.displayAvatarURL() || undefined
                  })
                  .setTimestamp();

              try {
                  await channel.send({
                      content: '<@198050274743549953>',
                      embeds: [latencyEmbed]
                  });
              } catch (error) {
                  console.error("Erreur lors de l'envoi de l'alerte de latence:", error);
              }
          }
      }, 500000);

  } catch (error) {
      console.error("Erreur lors de l'envoi de la notification de démarrage:", error);
  }
}

module.exports = start;