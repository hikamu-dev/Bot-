// commands/admin/clearall-prevnames.js
const axios = require("axios");
const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require("discord.js");

function normalizePanel(panel) {
  if (!panel) return "http://localhost:3002";
  const p = String(panel).trim();
  return /^https?:\/\//i.test(p) ? p : "http://" + p;
}

async function deleteAllViaAPI(base) {
  const routes = [
    `${base}/oldnames`,
    `${base}/prevnames`,
    `${base}/names`,
  ];
  for (const url of routes) {
    try {
      const res = await axios.delete(url, { timeout: 8000 });
      const count =
        res?.data?.count ??
        res?.data?.deleted ??
        (typeof res?.data === "number" ? res.data : null);
      return { ok: true, count, via: "api", url };
    } catch (e) {
      if (e?.response?.status === 404) continue;
    }
  }
  return { ok: false };
}

async function deleteAllViaSQLite(client) {
  const tableExists = await new Promise((resolve) => {
    client.db.all(
      "SELECT name FROM sqlite_master WHERE type='table' AND name='oldnames'",
      [],
      (err, rows) => resolve(!err && rows && rows.length > 0)
    );
  });
  if (!tableExists) return { ok: false, err: new Error("Table 'oldnames' introuvable") };

  const changes = await new Promise((resolve, reject) => {
    client.db.run("DELETE FROM oldnames", [], function (err) {
      if (err) return reject(err);
      resolve(this.changes || 0);
    });
  });

  return { ok: true, count: changes, via: "sqlite" };
}

module.exports = {
  name: "clearall-prevnames",
  description: "Efface TOUT l’historique des anciens pseudos (développeur uniquement).",
  devOnly: true,

  data: new SlashCommandBuilder()
    .setName("clearall-prevnames")
    .setDescription("Efface TOUT l’historique des anciens pseudos (développeur uniquement)."),

  run: async (client, interaction) => {
    const isDev =
      Array.isArray(client.config?.développeurs) &&
      client.config.développeurs.includes(interaction.user.id);

    if (!isDev) {
      return interaction.reply({
        content: "`❌` 〃 Tu n’as pas la permission d’utiliser cette commande.",
        ephemeral: true,
      });
    }

    // Embed de confirmation
    const embed = new EmbedBuilder()
      .setTitle("⚠️ Confirmation requise")
      .setDescription(
        "Tu es sur le point d’effacer **TOUS les prevnames** de la base.\n\n" +
        "Cette action est **irréversible**.\n\n" +
        "Veux-tu continuer ?"
      )
      .setColor(0xff0000);

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("confirm_clearall_prevnames")
        .setLabel("✅ Confirmer")
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId("cancel_clearall_prevnames")
        .setLabel("❌ Annuler")
        .setStyle(ButtonStyle.Secondary)
    );

    await interaction.reply({
      embeds: [embed],
      components: [row],
      ephemeral: true,
    });

    // Collecteur de boutons
    const collector = interaction.channel.createMessageComponentCollector({
      filter: (i) => i.user.id === interaction.user.id,
      time: 30_000,
    });

    collector.on("collect", async (i) => {
      if (i.customId === "cancel_clearall_prevnames") {
        await i.update({
          content: "`ℹ️` 〃 Suppression annulée.",
          embeds: [],
          components: [],
        });
        collector.stop();
        return;
      }

      if (i.customId === "confirm_clearall_prevnames") {
        await i.update({
          content: "`⌛` 〃 Suppression en cours...",
          embeds: [],
          components: [],
        });

        const base = normalizePanel(client.config?.panel);
        let result = await deleteAllViaAPI(base);
        if (!result.ok) result = await deleteAllViaSQLite(client);

        if (!result.ok) {
          await interaction.editReply("`❌` 〃 Impossible d’effacer les prevnames (API/DB).");
        } else {
          const countStr = Number.isFinite(result.count)
            ? ` (${result.count} entrées supprimées)`
            : "";
          const via = result.via === "api" ? "via API" : "via DB locale";

          await interaction.editReply(
            `\`✅\` 〃 Tous les prevnames ont été effacés ${via}${countStr}.`
          );
        }

        collector.stop();
      }
    });

    collector.on("end", async (collected) => {
      if (collected.size === 0) {
        await interaction.editReply({
          content: "`⌛` 〃 Temps écoulé, aucune action effectuée.",
          embeds: [],
          components: [],
        });
      }
    });
  },
};
