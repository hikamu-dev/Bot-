const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'ping',
  description: 'Affiche la latence du bot',
  usage: '/ping',
  category: 'Informations',
  userPerms: [],
  botPerms: [],
  cooldown: 5,
  guildOnly: false,
  maintenance: false,
  options: [],
  run: async (client, interaction) => {
    try {
      // Mesure précise du temps avant l'envoi
      const startTime = process.hrtime.bigint();
      
      // Envoi initial et récupération du message
      await interaction.deferReply();
      const endTime = process.hrtime.bigint();
      
      // Calculs de latence avec plus de précision
      const apiLatency = client.ws.ping;
      const botLatencyNs = endTime - startTime;

      // Création de l'embed amélioré
      const pingEmbed = new EmbedBuilder()
        .setColor(client.config.color || '#3BA55D')
        .setAuthor({ 
          name: `${client.user.username} • Latence`, 
          iconURL: client.user.displayAvatarURL() 
        })
        .setDescription('**Statistiques de performance en temps réel**')
        .addFields(
          { 
            name: '🌐 Bot', 
            value: `\`${apiLatency}ms\``, 
            inline: true 
          },
          { 
            name: '📊 Uptime', 
            value: `<t:${Math.floor(client.readyTimestamp / 1000)}:R>`, 
            inline: false 
          }
        )
        .setFooter({ 
          text: `Demandé par ${interaction.user.username}`, 
          iconURL: interaction.user.displayAvatarURL() 
        })
        .setTimestamp()
        .setThumbnail();

      await interaction.editReply({ 
        content: '🏓 **Pong!**', 
        embeds: [pingEmbed] 
      });
      
    } catch (error) {
      console.error('Erreur avec la commande ping:', error);
      await interaction.editReply({ 
        content: `\`❌\` 〃 Impossible de mesurer la latence - veuillez réessayer plus tard`, 
        ephemeral: true 
      });
    }
  },
};