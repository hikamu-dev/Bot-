const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'prevname',
  description: 'Affiche vos anciens pseudos avec une belle présentation',
  usage: '/prevname',
  category: 'Owners',
  userPerms: [],
  botPerms: [],
  cooldown: 0,
  guildOnly: false,
  maintenance: false,
  options: [
    {
      type: 3,
      name: "user",
      description: "ID de l'utilisateur",
      required: false,
    },
  ],
  run: async (client, interaction) => {
    const userId = interaction.options.getString('user') || interaction.user.id;
    const selectQuery = 'SELECT * FROM oldnames WHERE user_id = ?';

    client.db.all(selectQuery, [userId], (err, rows) => {
      if (err) {
        console.error('Erreur lors de la récupération des anciens pseudos :', err);
        return interaction.reply({ content: `\`❌\` 〃 Une erreur s\'est produite lors de la récupération des anciens pseudos.`, ephemeral: true });
      }

      const pseudonyms = rows.map(row => ({
        old_name: row.old_name,
        timestamp: row.timestamp
      }));

      try {
        const pseudonymCount = pseudonyms.length;

        if (pseudonymCount === 0) {
          return interaction.reply({ content: 'Aucun pseudo trouvé.', ephemeral: true });
        } else {
          client.users.fetch(userId).then((user) => {
            const tag = user.username;
            const url = `https://discord.com/users/${userId}`;

            const embed = new EmbedBuilder()
              .setColor(client.config.color) // Couleur de Discord
              .setTitle(`✨ Anciens pseudos de ${tag} ✨`)
              .setDescription(pseudonyms.map((entry, index) => 
                `**${index + 1})** **Pseudo :** \`${entry.old_name}\`\n` +
                `**Date de changement :** <t:${Math.floor(entry.timestamp)}:F>\n` +
                `**Depuis :** <t:${Math.floor(entry.timestamp)}:R>\n` 
              ).join('\n\n'))
              .setFooter({ text: `Total : ${pseudonymCount} anciens pseudos`, iconURL: interaction.user.displayAvatarURL() })
              .setTimestamp()
              .setThumbnail(user.displayAvatarURL({ dynamic: true }));

            return interaction.reply({ embeds: [embed], ephemeral: true });
          }).catch(err => {
            console.error('Erreur lors de la récupération de l\'utilisateur :', err);
            return interaction.reply({ content: `\`❌\` 〃 Une erreur est survenue lors de la récupération des informations de l\'utilisateur.`, ephemeral: true });
          });
        }
      } catch (error) {
        console.error('Erreur lors de la construction de la réponse :', error);
        return interaction.reply({ content: `\`❌\` 〃 Une erreur est survenue lors de la construction de la réponse.`, ephemeral: true });
      }
    });
  },
};
