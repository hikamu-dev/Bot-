module.exports = {
  "token": "token",
  "botid": "1395522564729606224",
  "développeurs": [
    "198050274743549953"
  ],
  "color": "#65bfff",
  "panel": "localhost",
  "port": "3002",
  "version": "v2",
  "versionapi": "1",
  "channelprevname": "1419413037479231571",
  "channelstart": "1395515055964950650",
  "guildid": "1339521606392877151"
};